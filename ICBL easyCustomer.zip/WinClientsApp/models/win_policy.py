import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone

class WinPolicy(models.Model):
    Account_Number = models.CharField(max_length=50, null = False, db_column='Account_Number',primary_key=True)
    Broker_Code = models.CharField(max_length=50, null = True, db_column='Broker_Code')
    Broker_Name = models.CharField(max_length=255, null = True, db_column='Broker_Name')
    Type_Of_Product = models.CharField(max_length=255, null = True, db_column='Type_Of_Product')
    Type_Of_Policy = models.CharField(max_length=255, null = True, db_column='Type_Of_Policy')
    Issuing_Company = models.CharField(max_length=255, null = True, db_column='Issuing_Company')
    Policy_Status = models.CharField(max_length=255, null = True, db_column='Policy_Status')
    Policy_Sub_Status = models.CharField(max_length=255, null = True, db_column='Policy_Sub_Status')
    Owner_Name = models.CharField(max_length=255, null = True, db_column='Owner_Name')
    Jurisdiction = models.CharField(max_length=255, null = True, db_column='Jurisdiction')
    ContractCurrency = models.CharField(max_length=255, null = True, db_column='ContractCurrency')
    Application_Received_By_Company = models.CharField( max_length=255, null = True, db_column='Application_Received_By_Company')
    Application_Completed = models.CharField(max_length=255, null = True, db_column='Application_Completed')
    Policy_Sent_To_Representative = models.CharField(max_length=255, null = True, db_column='Policy_Sent_To_Representative')
    Effective_Date = models.CharField(max_length=255, null = True, db_column='Effective_Date')
    Placed_Date = models.CharField(max_length=255, null = True, db_column='Placed_Date')
    In_Good_Order_Date = models.CharField(max_length=255, null = True, db_column='In_Good_Order_Date')
    Client_Id = models.CharField( max_length=255,null = True, db_column='ClientID')

    class Meta:
        db_table='ICBLPolicySample'

    def __str__(self):
        return f"{self.Client_Id}"