import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone

class WinClientsContact(models.Model):
    Client_Id = models.CharField(max_length=50, null = False, db_column='ClientID',primary_key=True)
    Address_Effective_Date = models.CharField( max_length=50, null = True, db_column='AddressEffectiveDate')
    Email = models.CharField( max_length=50, null = True, db_column='Email')
    Office_Phone = models.CharField( max_length=50, null = True, db_column='Office_Phone')
    Office_Extenstion = models.CharField( max_length=500, null = True, db_column='Office_Extenstion')
    Private_Cell_Phone = models.CharField( max_length=500, null = True, db_column='PrivateCellPhone')
    Home_Phone = models.CharField( max_length=500, null = True, db_column='Home_Phone')
    Home_Extenstion = models.CharField(max_length=500, null = True, db_column='Home_Extenstion')
    

    class Meta:
        db_table='ICBLClientContactInfo'

    def __str__(self):
        return f"{self.Client_Id}"

    # class ReadonlyMeta:
    #     readonly = ['Policy_id','Transaction_id','Policy_Number',]