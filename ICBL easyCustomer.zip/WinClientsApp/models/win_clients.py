from django.db import models

class WinClients(models.Model):
    Client_Id = models.CharField(primary_key=True,max_length=500,null = False , db_column='CLIENTID')
    # Common_Identifier = models.CharField(max_length=500, null = True , db_column='CommonIdentifier')
    Address_Type = models.CharField(max_length=500, null = True , db_column='Address_Type')
    Address_Line_1 = models.CharField(max_length=500, null = True , blank = True, db_column='Address_Line_1')
    Address_Line_2 = models.CharField(max_length=500, null = True , blank = True, db_column='Address_Line_2')
    City = models.CharField(max_length=500, null = True , blank = True, db_column='City')
    Province = models.CharField(max_length=500,null = True , blank = True, db_column='Province')
    Country	= models.CharField(max_length=500, null = True , blank = True, db_column='Country')
    Postal_Code	= models.CharField(max_length=500, null = True , blank = True, db_column='Postal_Code')
    Title = models.CharField(max_length=500, null = True , db_column='Title')
    Client_First_Name = models.CharField(max_length=500, null = True, db_column='Client_First_Name')
    Client_Middle_Name	= models.CharField(max_length=500, null = True , blank = True, db_column='Client_Middle_Name')
    Client_Preferred_Name = models.CharField(max_length=500, null = True , blank = True, db_column='Client_Preferred_Name')
    Client_Last_Name = models.CharField(max_length=500, null = True , blank = True, db_column='Client_Last_Name')
    Suffix = models.CharField(max_length=500, null = True , blank = True, db_column='Suffix')
    Client_Status = models.CharField(max_length=500, null = True , blank = True, db_column='Client_Status')
    Client_Gender = models.CharField(max_length=500, null = True , blank = True, db_column='Client_Gender')
    Client_BirthDate =models.CharField(max_length=500,null = True , db_column='Client_BirthDate')
    Client_SSN = models.CharField(max_length=500, null = True , blank = True, db_column='Client_SSN')
    # CN = models.CharField(max_length=500, null = True , blank = True, db_column='CN')

    class Meta:
        db_table='ICBLClient'

    def __str__(self):
        return f"{self.Client_Id}-{self.Client_First_Name}"