import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone

class WinCoverage(models.Model):
    Account_Number = models.CharField( max_length=500,null = False, db_column='Account_Number',primary_key=True)
    Coverage_Name = models.CharField(max_length=255, null = True, db_column='Coverage_Name')
    Coverage_Status = models.CharField(max_length=255, null = True, db_column='Coverage_Status')
    Coverage_Code = models.CharField(max_length=255, null = True, db_column='Coverage_Code')
    Coverage_Issue_Class = models.CharField(max_length=255, null = True, db_column='Coverage_Issue_Class')
    Coverage_Issue_Gender = models.CharField(max_length=255, null = True, db_column='Coverage_Issue_Gender')
    Coverage_Premium_Mode = models.CharField(max_length=255, null = True, db_column='Coverage_Premium_Mode')
    Insured_Name = models.CharField(max_length=255, null = True, db_column='Insured_Name')
    Death_Benefit_Name = models.CharField(max_length=255, null = True, db_column='DeathBenefitName')
    VirtGatePlan_Name = models.CharField(max_length=255, null = True, db_column='VirtGatePlanName')
    VirtGatePlan_Code = models.CharField(max_length=255, null = True, db_column='VirtGatePlanCode')
    Coverage_Date = models.CharField(  max_length=500, db_column='Coverage_Date')
    Approved_Date = models.CharField(  max_length=500, db_column='Approved_Date')
    Coverage_ISSUE_AGE = models.CharField( max_length=500, null = True, db_column='Coverage_ISSUE_AGE')
    Client_Id = models.CharField( max_length=500, null = True, db_column='ClientID')
    Coverage_Modal_Premium = models.CharField( max_length=500, null = True, db_column='Coverage_Modal_Premium')
    Coverage_AMOUNT = models.CharField( max_length=500, null = True, db_column='Coverage_AMOUNT')
    Coverage_Annual_Premium = models.CharField( max_length=500, null = True, db_column='Coverage_Annual_Premium')

    Rider_Number = models.CharField( max_length=500, null = True, db_column='RiderNumber')

    class Meta:
        db_table='ICBLCoverage'

    def __str__(self):
        return f"{self.Client_Id}"