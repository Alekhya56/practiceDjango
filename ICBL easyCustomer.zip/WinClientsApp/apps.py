from django.apps import AppConfig


class WinclientsappConfig(AppConfig):
    name = 'WinClientsApp'
