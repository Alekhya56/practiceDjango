from django.contrib import admin


from WinClientsApp.models.win_clients import WinClients
from WinClientsApp.models.win_clients_contact import WinClientsContact
from WinClientsApp.models.win_coverage import WinCoverage
from WinClientsApp.models.win_policy import WinPolicy


# Register your models here.
admin.site.register(WinClients)
admin.site.register(WinClientsContact)
admin.site.register(WinCoverage)
admin.site.register(WinPolicy)