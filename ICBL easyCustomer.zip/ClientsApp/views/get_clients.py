'''

Searchs client data from SSPure and Wynsure database.

Params:
'''

from django.core import serializers
from SSPClientsApp.models.clients import Clients
from SSPClientsApp.models.policy import Policy
from SSPClientsApp.models.clients_contacts import ClientContacts
from WinClientsApp.models.win_clients import WinClients
from WinClientsApp.models.win_clients_contact import WinClientsContact
from WinClientsApp.models.win_policy import WinPolicy
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from django.db.models import Q
from functionalities.helpers import _ReturnError, _CheckRequestData, _RequestParse

# logging imports
import os
import logging
import logging.handlers
from datetime import datetime
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'Clients')
file_handler = RotatingFileHandler(filename + '/' + os.path.basename(__file__).replace('.py', '') + '.log',
                                   maxBytes=1000000, backupCount=6)
# file_handler = TimedRotatingFileHandler(filename + '/Clients.log', when="d",interval=1,backupCount= 6)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)


@api_view(['POST', ])
@permission_classes([IsAuthenticated, ])
# @permission_classes([AllowAny,])
def GetClients(request):
    result = []
    ReturnData = []
    WinClientFilter = {}
    SSPClientFilter = {}
    SSPClientFFilter = {}
    SSPClientLFilter = {}
    SSPClientContactFilter = {}
    SSPPolicyFilter = {}
    WynClientFilter = {}
    WynClientFFilter = {}
    WynClientLFilter = {}
    WynClientContactFilter = {}
    WynPolicyFilter = {}
    cn = []
    contact = (None,None,None,None,None)
    Contact_Email = None
    Contact_Type = None
    Contact = None
    Check = True
    policy_obj = []
    client_obj = []
    client_c_obj = []
    email_obj = []
    logger.info(request.data)
    Name = request.data.get('name', None)
    Email = request.data.get('email', None)
    request.data['FirstName'] = None
    request.data['LastName'] = None
    logger.info("Given Search Data %s", request.data.values())
    # Splitting the name which is full name into two parts so that we get firstname and lastname
    if Name is not None and Name != "":
        # * logger.info("Name is Being Splitted")
        if Name.__contains__(" "):
            if len(Name.split(" ")) == 2:
                FirstName, LastName = Name.split(" ")
                request.data['FirstName'] = FirstName
                request.data['LastName'] = LastName
            if len(Name.split(" ")) == 3:
                FirstName1, FirstName2, LastName = Name.split(" ")
                request.data['FirstName'] = FirstName1 + " " + FirstName2
                request.data['LastName'] = LastName
            if len(Name.split(" ")) == 4:
                FirstName1, FirstName2, LastName1, LastName2 = Name.split(" ")
                request.data['FirstName'] = FirstName1 + " " + FirstName2
                request.data['LastName'] = LastName1 + " " + LastName2
        else:
            # * logger.info("No Split Requires")
            request.data['FirstName'] = Name
            request.data['LastName'] = Name

    # * logger.info("Initialising the Filters for Search")

    # Dictionaries which will be used to map the data from request \
    # and create a dynamic query based on the data given
    SSPPolicyFilters = {
        "vehicleregno": "Vehicle_Reg_No__contains",
        "policyno": "Policy_Number__contains",
    }
    SSPClientFilters = {
        "FirstName": "First_Name__startswith",
        "LastName": "Last_Name__startswith",
        "dateofbirth": "Date_Of_Birth",
        "id": "Id_Number__contains",
        "id_type": "Type_Id__contains",
    }

    WynPolicyFilters = {
        "policyno": "Account_Number__contains",
    }

    WynClientFilters = {
        "FirstName": "Client_First_Name__contains",
        "LastName": "Client_Last_Name__contains",
        "dateofbirth": "Client_BirthDate__contains",
    }
    WynClientContactFilters = {
        "email": "Email__contains",
        "Tel. Home": "Home_Phone__contains",
        "Tel. Work": "Office_Phone__contains",
        "Cellular Telephone": "Private_Cell_Phone__contains",
    }
    # request.data['telhome'] = ''
    # request.data['telwork'] = ''
    # request.data['telphone'] = ''
    # request.data['fax'] = ''

    SSPClientContact = Q()

    if request.data.get('telhome',None):
        SSPClientContact |= Q(NumberOrEmailOrWeb__contains=request.data['telphone']) & Q(Type_Code="TELEPHONE ")
    if request.data.get('telwork',None):
        SSPClientContact |= Q(NumberOrEmailOrWeb__contains=request.data['telwork']) & Q(Type_Code="TELWORK")
    if request.data.get('telphone',None):
        SSPClientContact |= Q(NumberOrEmailOrWeb__contains=request.data['telhome']) & Q(Type_Code="MOBILE")
    if request.data.get('fax',None):
        SSPClientContact |= Q(NumberOrEmailOrWeb__contains=request.data['fax']) & Q(Type_Code="FAX")
    if request.data.get('email',None):
        SSPClientContact &= Q(NumberOrEmailOrWeb__contains=request.data['email']) & Q(Type_Code="MEMAIL")


    WynClientContact = Q()
    if request.data.get('telhome',None):
        WynClientContact |= Q(Home_Phone__contains=request.data['telhome'])
    if request.data.get('telphone',None):
        WynClientContact |= Q(Private_Cell_Phone__contains=request.data['telphone'])
    if request.data.get('telwork',None):
        WynClientContact |= Q(Office_Phone__contains=request.data['telwork'])
    if request.data.get('email',None):
        WynClientContact &= Q(Email__contains=request.data['email'])

    # * logger.info("Filters Initialised")
    # * logger.info("Filters are being implemented")

    # mapping the data in the lookup dictionaries with the data from request
    for i in request.data:
        if request.data[i] is not None and request.data[i] != "":
            # if i in ['email']:
            #     WynClientContactFilter[WynClientContactFilters[i]] = request.data[i]
            if i in ["vehicleregno", "policyno"]:
                SSPPolicyFilter[SSPPolicyFilters[i]] = request.data[i]
            if i in ['policyno']:
                WynPolicyFilter[WynPolicyFilters[i]] = request.data[i]
            if request.data['FirstName'] != request.data['LastName']:
                if i in ['FirstName', 'LastName', 'dateofbirth', "id", "id_type"]:
                    SSPClientFilter[SSPClientFilters[i]] = request.data[i]
                if i in ['FirstName', 'LastName', 'dateofbirth']:
                    WynClientFilter[WynClientFilters[i]] = request.data[i]
            if request.data['FirstName'] == request.data['LastName']:
                if request.data['FirstName'] is not None and request.data['FirstName'] != "" \
                        and request.data['LastName'] is not None and request.data['LastName'] != "":
                    if i in ['FirstName', 'dateofbirth', "id", "id_type"]:
                        SSPClientFFilter[SSPClientFilters[i]] = request.data[i]
                    if i in ['LastName', 'dateofbirth', "id", "id_type"]:
                        SSPClientLFilter[SSPClientFilters[i]] = request.data[i]
                    if i in ['FirstName', 'dateofbirth']:
                        WynClientFFilter[WynClientFilters[i]] = request.data[i]
                    if i in ['LastName', 'dateofbirth']:
                        WynClientLFilter[WynClientFilters[i]] = request.data[i]
                else:
                    if i in ['dateofbirth', "id", "id_type"]:
                        SSPClientFilter[SSPClientFilters[i]] = request.data[i]
                    if i in ['dateofbirth']:
                        WynClientFilter[WynClientFilters[i]] = request.data[i]

    logger.info("Filters are implemented")
    logger.info("SSPClient Filter %s,%s__________________-", SSPClientFilter, len(SSPClientFilter))
    logger.info("SSPClient L Filter :%s,%s__________________-", SSPClientLFilter, len(SSPClientLFilter))
    logger.info("SSPClient F Filter :%s,%s__________________-", SSPClientFFilter, len(SSPClientFFilter))
    logger.info("SSPClientContact :%s,%s__________________-", SSPClientContact, len(SSPClientContact))
    logger.info("SSPPolicyFilter :%s,%s__________________-", SSPPolicyFilter, len(SSPPolicyFilter))
    logger.info("WynClientFilter %s,%s______ ____________-", WynClientFilter, len(WynClientFilter))
    logger.info("WynClientFFilter%s,%s__________________-", WynClientFFilter, len(WynClientFFilter))
    logger.info("WynClientLFilter %s,%s__________________-", WynClientLFilter, len(WynClientLFilter))
    logger.info("WynClientContactFilter %s,%s__________________-", WynClientContactFilter, len(WynClientContactFilter))
    logger.info("WynPolicyFilter %s,%s__________________-", WynPolicyFilter, len(WynPolicyFilter))

    logger.info("________________________________STARTED SEARCHING IN SSP_________________________________")
    # Case when only Policy Number or VehicleNo or Both are given and also some other details
    if len(SSPPolicyFilter):
        logger.info("Search using Policy.NO or Vel.Reg.No or Both")
        try:
            policy_obj = Policy.objects.filter(**SSPPolicyFilter)[0:25]
            for policy in policy_obj:
                if len(SSPPolicyFilter) and len(SSPClientContact) and (
                        len(SSPClientFilter) or (len(SSPClientLFilter) and len(SSPClientFFilter))):
                    logger.info(
                        "Search using Policy.NO or Vel.Reg.No or Both and check with Client Data and Client Contact Data")
                    if len(SSPClientFilter):
                        logger.info("SSPClientFilter")
                        n_check = Clients.objects.filter(Client_Id=policy.Client_Id, **SSPClientFilter).first()
                        if n_check is not None:
                            logger.info("Client object Found")
                            client_obj = n_check
                        else:
                            logger.info("Client object Not Found")
                            Check = False
                    if len(SSPClientLFilter) and len(SSPClientFFilter):
                        logger.info("SSPClientLFilter && SSPClientFFilter")
                        l_check = Clients.objects.filter(Client_Id=policy.Client_Id, **SSPClientLFilter).first()
                        f_check = Clients.objects.filter(Client_Id=policy.Client_Id, **SSPClientFFilter).first()
                        if l_check is not None:
                            logger.info("Client object Found with last name")
                            client_obj = l_check
                        if f_check is not None:
                            logger.info("Client object Found with first name")
                            client_obj = f_check
                        if f_check is None and l_check is None:
                            logger.info("Client object not Found with F or L name")
                            Check = False
                    if Check:
                        client_c_obj = ClientContacts.objects.filter(SSPClientContact,
                                                                     Client_Id=policy.Client_Id).first()
                        if client_c_obj is None:
                            logger.info("Client Contact object Not Found")
                            Check = False
                if len(SSPPolicyFilter) and len(SSPClientContact) and not len(SSPClientFilter) and not len(
                        SSPClientLFilter) and not len(SSPClientFFilter):
                    logger.info("Search using Policy.NO or Vel.Reg.No or Both and check with Client Contact Data")
                    client_obj = Clients.objects.filter(Client_Id=policy.Client_Id).first()
                    client_c_obj = ClientContacts.objects.filter(SSPClientContact, Client_Id=policy.Client_Id).first()
                    if client_c_obj == None:
                        logger.info("Client Contact object Not Found or did not match with policy data")
                        Check = False
                if len(SSPPolicyFilter) and not len(SSPClientContact) and (
                        len(SSPClientFilter) or (len(SSPClientLFilter) and len(SSPClientFFilter))):
                    logger.info("Search using Policy.NO or Vel.Reg.No or Both and check with Client Data")
                    if len(SSPClientFilter):
                        logger.info("SSPClientFilter")
                        logger.info(policy.Client_Id)
                        logger.info(SSPClientFilter)
                        n_check = Clients.objects.filter(Client_Id=policy.Client_Id, **SSPClientFilter).first()
                        if n_check is not None:
                            logger.info("Client object Found")
                            client_obj = n_check
                        else:
                            logger.info("Client object Not Found")
                            Check = False
                    if len(SSPClientLFilter) and len(SSPClientFFilter):
                        logger.info("SSPClientLFilter && SSPClientFFilter")
                        l_check = Clients.objects.filter(Client_Id=policy.Client_Id, **SSPClientLFilter).first()
                        f_check = Clients.objects.filter(Client_Id=policy.Client_Id, **SSPClientFFilter).first()
                        if l_check is not None:
                            client_obj = l_check
                        if f_check is not None:
                            client_obj = f_check
                        if f_check is None and f_check is None:
                            logger.info("Client object Not Found with f or l Name")
                            Check = False
                    # client_c_obj = ClientContacts.objects.filter(Client_Id=policy.Client_Id).first()
                if len(SSPPolicyFilter) and not len(SSPClientContact) and not len(SSPClientFilter) and not len(
                        SSPClientLFilter) and not len(SSPClientFFilter):
                    logger.info("Search using Only Policy.NO or Vel.Reg.No or Both")
                    client_obj = Clients.objects.filter(Client_Id=policy.Client_Id).first()
                    ReturnData.append(
                        {
                            "Customer_Name": client_obj.First_Name.replace(" ",
                                                                           "") + " " + client_obj.Last_Name.replace(" ",
                                                                                                                    ""),
                            "Policy_Number": policy.Policy_Number,
                            "Status": policy.Status,
                            # date time should be changed
                            "DOB": client_obj.Date_Of_Birth.strftime(
                                "%Y-%m-%d") if client_obj.Date_Of_Birth is not None else None,
                            "Id_Type": client_obj.Type_Id if client_obj.Type_Id != "Null" else None,
                            "system": "SSP Pure",
                            "ClientID": client_obj.Client_Id
                        }
                    )
        except Exception as e:
            logger.exception("Some Error Occured while searching using Policy.NO or Vel.Reg.No or Both %s :", e)
    # For Case when Only Contact details are given
    if len(SSPClientContact) and not len(SSPClientFilter) and not len(SSPClientFFilter) and not len(
            SSPClientLFilter) and not len(SSPPolicyFilter):
        logger.info("Search using only Contact details")
        try:
            logger.info(client_c_obj)
            for client in client_c_obj:
                client_obj = Clients.objects.filter(Client_Id=client.Client_Id).first()
                policy_obj = Policy.objects.filter(Client_Id=client.Client_Id)
                if client_obj is not None:
                    if len(policy_obj):
                        for policy in policy_obj:
                            ReturnData.append({
                                "Customer_Name": client_obj.First_Name.replace(" ",
                                                                               "") + " " + client_obj.Last_Name.replace(
                                    " ", ""),
                                "Policy_Number": policy.Policy_Number,
                                "Status": policy.Status,
                                "DOB": client_obj.Date_Of_Birth.strftime(
                                    "%Y-%m-%d") if client_obj.Date_Of_Birth is not None else None,
                                "Id_Type": client_obj.Type_Id if client_obj.Type_Id != "Null" else None,
                                "system": "SSP Pure",
                                "ClientID": client_obj.Client_Id
                            })
                    else:
                        ReturnData.append({
                            "Customer_Name": client_obj.First_Name.replace(" ",
                                                                           "") + " " + client_obj.Last_Name.replace(" ",
                                                                                                                    ""),
                            "Policy_Number": None,
                            "Status": policy.Status,
                            "DOB": client_obj.Date_Of_Birth.strftime(
                                "%Y-%m-%d") if client_obj.Date_Of_Birth is not None else None,
                            "Id_Type": client_obj.Type_Id if client_obj.Type_Id != "Null" else None,
                            "system": "SSP Pure",
                            "ClientID": client_obj.Client_Id,
                        })
        except Exception as e:
            logger.exception("Some Error Occured while searching using only Contact details %s:", e)
    # For case when only Full name is given and checking with contact info, if given
    if len(SSPClientFilter) and not len(SSPPolicyFilter):
        logger.info("Search using both First Name and Last Name")
        try:
            client_obj = Clients.objects.filter(**SSPClientFilter)[0:50]
            logger.info("result clients: %s", client_obj)
            if client_obj:
                for client in client_obj:
                    if Check:
                        client_obj = Clients.objects.filter(Client_Id=client.Client_Id).first()
                        logger.info(contact)
                        policy_obj = Policy.objects.filter(Client_Id=client.Client_Id)
                        if len(policy_obj) and client_obj:
                            for policy in policy_obj:
                                ReturnData.append({
                                    "Customer_Name": client_obj.First_Name.replace(" ",
                                                                                   "") + " " + client_obj.Last_Name.replace(
                                        " ", ""),
                                    "Policy_Number": policy.Policy_Number,
                                    "Status": policy.Status,
                                    "DOB": client_obj.Date_Of_Birth.strftime(
                                        "%Y-%m-%d") if client_obj.Date_Of_Birth is not None else None,
                                    "Id_Type": client_obj.Type_Id if client_obj.Type_Id != "Null" else None,
                                    "system": "SSP Pure",
                                    "ClientID": client_obj.Client_Id,
                                })
                        elif client_obj:
                            ReturnData.append({
                                "Customer_Name": client_obj.First_Name.replace(" ",
                                                                               "") + " " + client_obj.Last_Name.replace(
                                    " ", ""),
                                "Policy_Number": None,
                                "Status": None,
                                "DOB": client_obj.Date_Of_Birth.strftime(
                                    "%Y-%m-%d") if client_obj.Date_Of_Birth is not None else None,
                                "Id_Type": client_obj.Type_Id if client_obj.Type_Id != "Null" else None,
                                "system": "SSP Pure",
                                "ClientID": client_obj.Client_Id,
                            })
        except Exception as e:
            logger.exception("Some Error Occured while searching using both First Name and Last Name %s:", e)
    #  For case when name is given but dont know if it is first or last name and also checking
    #  with contact data given
    if len(SSPClientLFilter) and len(SSPClientFFilter) and not len(SSPPolicyFilter):
        logger.info("Search using First Name or Last Name")
        # * These are important but removed due to reasons
        # * logger.info("L and F filters %s,%s",SSPClientLFilter,SSPClientFFilter)
        try:
            client_obj.extend(list(Clients.objects.filter(**SSPClientLFilter)[0:25]))
            client_obj.extend(list(Clients.objects.filter(**SSPClientFFilter)[0:25]))
            if client_obj:
                    for client in client_obj:
                        client_obj = Clients.objects.filter(Client_Id=client.Client_Id).first()
                        policy_obj = Policy.objects.filter(Client_Id=client.Client_Id)
                        try:
                            if len(policy_obj) and client_obj:
                                for policy in policy_obj:
                                    ReturnData.append({
                                        "Customer_Name": client_obj.First_Name.replace(" ",
                                                                                       "") + " " + client_obj.Last_Name.replace(
                                            " ", ""),
                                        "Policy_Number": policy.Policy_Number,
                                        "Status": policy.Status,
                                        "DOB": client_obj.Date_Of_Birth.strftime(
                                            "%Y-%m-%d") if client_obj.Date_Of_Birth is not None else None,
                                        "Id_Type": client_obj.Type_Id if client_obj.Type_Id != "Null" else None,
                                        "system": "SSP Pure",
                                        "ClientID": client_obj.Client_Id,
                                    })
                            elif client_obj:
                                ReturnData.append({
                                    "Customer_Name": client_obj.First_Name.replace(" ",
                                                                                   "") + " " + client_obj.Last_Name.replace(
                                        " ", ""),
                                    "Policy_Number": None,
                                    "Status": None,
                                    "DOB": client_obj.Date_Of_Birth.strftime(
                                        "%Y-%m-%d") if client_obj.Date_Of_Birth is not None else None,
                                    "Id_Type": client_obj.Type_Id if client_obj.Type_Id != "Null" else None,
                                    "system": "SSP Pure",
                                    "ClientID": client_obj.Client_Id,
                                })
                        except Exception as e:
                            logger.exception(e)
        except Exception as e:
            logger.exception("Some Error Occured while searching using both First Name or Last Name %s :", e)
    # For case when only Email is given
    logger.info("________________________________STARTED SEARCHING IN WYNSURE_________________________________")
    policy_obj = []
    client_obj = []
    client_c_obj = []
    email_obj = []
    if len(WynPolicyFilter):
        logger.info("Searching Policy")
        try:
            policy_obj = WinPolicy.objects.filter(**WynPolicyFilter)[0:20]
            if policy_obj is not None:
                for policy in policy_obj:
                    policy.Client_Id = str(int(policy.Client_Id))
                    if len(WynPolicyFilter) and len(WynClientContactFilter) and (
                            len(WynClientFilter) or (len(WynClientFFilter) and len(WynClientLFilter))):
                        logger.info(
                            "Search using Policy.NO or Vel.Reg.No or Both and check with Client Data and Client Contact Data")
                        if len(WynClientFilter):
                            logger.info("WynClientFilter :%s:%s", WynClientFilter, policy.Client_Id)
                            n_check = WinClients.objects.filter(Client_Id__contains=policy.Client_Id,
                                                                **WynClientFilter).first()
                            if n_check is not None:
                                logger.info("Client object found")
                                client_obj = n_check
                            else:
                                logger.info("Client object Not found")
                                Check = False
                        if len(WynClientLFilter) and len(WynClientFFilter):
                            logger.info("WynClientLFilter && WynClientFFilter")
                            l_check = WinClients.objects.filter(Client_Id__contains=policy.Client_Id,
                                                                **WynClientLFilter).first()
                            f_check = WinClients.objects.filter(Client_Id__contains=policy.Client_Id,
                                                                **WynClientFFilter).first()
                            if l_check is not None:
                                client_obj = l_check
                            if f_check is not None:
                                client_obj = f_check
                            if f_check is None and f_check is None:
                                logger.info("Client object not found for f or l name")
                                Check = False
                        if Check:
                            client_c_obj = WinClientsContact.objects.filter(Client_Id__contains=policy.Client_Id,
                                                                            **WynClientContactFilter).first()
                        if client_c_obj is None:
                            Check = False
                    if len(WynPolicyFilter) and len(WynClientContactFilter) and not len(WynClientFilter) and not len(
                            WynClientLFilter) and not len(WynClientFFilter):
                        logger.info("Search using Policy.NO or Both and check with Client Contact Data")
                        client_obj = WinClients.objects.filter(Client_Id__contains=policy.Client_Id).first()
                        client_c_obj = WinClientsContact.objects.filter(Client_Id__contains=policy.Client_Id,
                                                                        **WynClientContactFilter).first()
                        if client_c_obj == None:
                            logger.info("Client contact object not found")
                            Check = False
                    if len(WynPolicyFilter) and not len(WynClientContactFilter) and (
                            len(WynClientFilter) or (len(WynClientLFilter) and len(SSPClientFFilter))):
                        logger.info("Search using Policy.NO or Both and check with Client Data")
                        if len(WynClientFilter):
                            logger.info("WynClientFilter")
                            n_check = WinClients.objects.filter(Client_Id__contains=policy.Client_Id,
                                                                **WynClientFilter).first()
                            if n_check is not None:
                                client_obj = n_check
                            else:
                                logger.info("Client object not found")
                                Check = False
                        if len(WynClientLFilter) and len(WynClientFFilter):
                            logger.info("WynClientLFilter && WynClientFFilter")
                            l_check = WinClients.objects.filter(Client_Id__contains=policy.Client_Id,
                                                                **WynClientLFilter).first()
                            f_check = WinClients.objects.filter(Client_Id__contains=policy.Client_Id,
                                                                **WynClientFFilter).first()
                            if l_check is not None:
                                client_obj = l_check
                            if f_check is not None:
                                client_obj = f_check
                            logger.info("l_check,f_check", l_check, f_check)
                            if f_check is None and l_check is None:
                                logger.info("Check Failed")
                                Check = False
                            else:
                                logger.info("False", Check)
                        client_c_obj = WinClientsContact.objects.filter(Client_Id__contains=policy.Client_Id).first()
                    if len(WynPolicyFilter) and not len(WynClientContactFilter) and not len(
                            WynClientFilter) and not len(WynClientLFilter) and not len(WynClientFFilter):
                        logger.info("Search using Only Policy.NO")
                        logger.info(policy.Client_Id)
                        client_obj = WinClients.objects.filter(Client_Id__contains=policy.Client_Id).first()
                        client_c_obj = WinClientsContact.objects.filter(Client_Id__contains=policy.Client_Id).first()
                    if Check and client_obj:
                        logger.info("All checks made Returning Data")
                        if Email is not None and Email != "":
                            email_obj = WinClientsContact.objects.filter(Client_Id__contains=policy.Client_Id,
                                                                         Email__startswith=Email).first()
                        else:
                            email_obj = WinClientsContact.objects.filter(Client_Id__contains=policy.Client_Id).first()

                        ReturnData.append(
                            {
                                "Customer_Name": client_obj.Client_First_Name.replace(" ",
                                                                                      "") + " " + client_obj.Client_Last_Name.replace(
                                    " ", ""),
                                "Policy_Number": policy.Account_Number,
                                "Status": policy.Policy_Status,
                                # date time should be changed
                                "DOB": (
                                    client_obj.Client_BirthDate).replace(' ','') if client_obj.Client_BirthDate is not None else None,
                                "system": "Wynsure",
                                "ClientID": client_obj.Client_Id,
                                # "ContactType": Contact_Type,
                                # "Contact": Contact,
                                "Email": email_obj.Email if email_obj is not None else None
                            }
                        )
        except Exception as e:
            logger.error("Some Error Occured while Searching with Policy No and its cases")
            logger.exception(e)
    if len(WynClientContact) and not len(WynClientFilter) and not len(WynClientFFilter) and not len(
            WynClientLFilter) and not len(WynPolicyFilter):
        logger.info("Search using Wynsure Contact details")
        try:
            client_c_obj = WinClientsContact.objects.filter(WynClientContact)[0:20]
            for client in client_c_obj:
                client_obj = WinClients.objects.filter(Client_Id__contains=client.Client_Id).first()
                policy_obj = WinPolicy.objects.filter(Client_Id__contains=client.Client_Id)
                if client_obj is not None:
                    if len(policy_obj) and client_obj:
                        for policy in policy_obj:
                            ReturnData.append({
                                "Customer_Name": client_obj.Client_First_Name.replace(" ",
                                                                                      "") + " " + client_obj.Client_Last_Name.replace(
                                    " ", ""),
                                "Policy_Number": policy.Account_Number,
                                "Status": policy.Policy_Status,
                                # date time should be changed
                                "DOB": (
                                    client_obj.Client_BirthDate).replace(' ','') if client_obj.Client_BirthDate is not None else None,
                                "system": "Wynsure",
                                "ClientID": client_obj.Client_Id,
                            })
                    elif client_obj:
                        ReturnData.append({
                            "Customer_Name": client_obj.Client_First_Name.replace(" ",
                                                                                  "") + " " + client_obj.Client_Last_Name.replace(
                                " ", ""),
                            "Policy_Number": None,
                            "Status": None,
                            # date time should be changed
                            "DOB": (client_obj.Client_BirthDate).replace(' ','') if client_obj.Client_BirthDate is not None else None,
                            "system": "Wynsure",
                            "ClientID": client_obj.Client_Id
                        })
        except Exception as e:
            logger.error("Some Error Occured while searching using Contact details")
            logger.exception(e)
    if len(WynClientFilter) and not len(WynPolicyFilter):
        logger.info("Search using both First Name and Last Name")
        try:
            client_obj = WinClients.objects.filter(**WynClientFilter)[0:50]
            if client_obj:
                for client in client_obj:
                    if len(WynClientContactFilter):
                        logger.info("Search using Client Data and Client Contact")
                        client_c_obj = WinClientsContact.objects.filter(WynClientContact,
                                                                        Client_Id=client.Client_Id).first()
                        if client_c_obj is None:
                            Check = False
                            logger.info("Check Failed Contacts did not match with Data")
                    else:
                        client_c_obj = WinClientsContact.objects.filter(Client_Id=client.Client_Id).first()
                    if Check:
                        client_obj = WinClients.objects.filter(Client_Id=client.Client_Id).first()
                        policy_obj = WinPolicy.objects.filter(Client_Id=client.Client_Id)
                        if len(policy_obj) and client_obj:
                            for policy in policy_obj:
                                ReturnData.append({
                                    "Customer_Name": client_obj.Client_First_Name.replace(" ",
                                                                                          "") + " " + client_obj.Client_Last_Name.replace(
                                        " ", ""),
                                    "Policy_Number": policy.Account_Number,
                                    "Status": policy.Policy_Status,
                                    # date time should be changed
                                    "DOB": (
                                        client_obj.Client_BirthDate).replace(' ','') if client_obj.Client_BirthDate is not None else None,
                                    "system": "Wynsure",
                                    "ClientID": client_obj.Client_Id
                                })
                        elif client_obj:
                            ReturnData.append({
                                "Customer_Name": client_obj.Client_First_Name.replace(" ",
                                                                                      "") + " " + client_obj.Client_Last_Name.replace(
                                    " ", ""),
                                "Policy_Number": None,
                                "Status": None,
                                # date time should be changed
                                "DOB": client_obj.Client_BirthDate.replace(' ','') if client_obj.Client_BirthDate is not None else None,
                                "system": "Wynsure",
                                "ClientID": client_obj.Client_Id
                            })
        except Exception as e:
            logger.exception("Some Error Occured while searching using both First Name and Last Name %s:", e)
    if len(WynClientFFilter) and len(WynClientLFilter) and not len(WynPolicyFilter):
        logger.info("Search using First Name or Last Name")
        try:
            # logger.info(WynClientLFilter)
            # logger.info(WynClientFFilter)
            # logger.info(client_obj)
            client_obj.extend(list(WinClients.objects.filter(**WynClientLFilter)[0:25]))
            client_obj.extend(list(WinClients.objects.filter(**WynClientFFilter)[0:25]))
            # * logger.info(client_obj)
            if client_obj:
                for client in client_obj:
                    if len(WynClientContactFilter):
                        logger.info("Search using Client Data and Client Contact")
                        client_c_obj = WinClientsContact.objects.filter(WynClientContact,
                                                                        Client_Id=client.Client_Id).first()
                        if client_c_obj is None:
                            Check = False
                            logger.info("Check Failed Contacts did not match with Data")
                    else:
                        client_c_obj = WinClientsContact.objects.filter(Client_Id=client.Client_Id).first()

                    if Check:
                        client_obj = WinClients.objects.filter(Client_Id=client.Client_Id).first()
                        Contact = client_c_obj.Home_Phone if client_c_obj else None
                        Contact_Email = client_c_obj.Email if client_c_obj else None
                        policy_obj = WinPolicy.objects.filter(Client_Id=client.Client_Id)
                        try:
                            if len(policy_obj) and client_obj:
                                for policy in policy_obj:
                                    ReturnData.append({
                                        "Customer_Name": client_obj.Client_First_Name.replace(" ",
                                                                                              "") + " " + client_obj.Client_Last_Name.replace(
                                            " ", ""),
                                        "Policy_Number": policy.Account_Number,
                                        "Status": policy.Policy_Status,
                                        # date time should be changed
                                        "DOB": (
                                            client_obj.Client_BirthDate).replace(' ','') if client_obj.Client_BirthDate is not None else None,
                                        "system": "Wynsure",
                                        "ClientID": client_obj.Client_Id
                                    })
                            elif client_obj:
                                ReturnData.append({
                                    "Customer_Name": client_obj.Client_First_Name.replace(" ",
                                                                                          "") + " " + client_obj.Client_Last_Name.replace(
                                        " ", ""),
                                    "Policy_Number": None,
                                    "Status": None,
                                    # date time should be changed
                                    "DOB": (
                                        client_obj.Client_BirthDate).replace(' ','') if client_obj.Client_BirthDate is not None else None,
                                    "system": "Wynsure",
                                    "ClientID": client_obj.Client_Id
                                })
                        except Exception as e:
                            logger.exception(e)
        except Exception as e:
            logger.exception("Some Error Occured while searching using First Name or Last Name %s:", e)
    return Response({"Clients":ReturnData}, status= status.HTTP_200_OK)

