from SSPClientsApp.models.clients_contacts import ClientContacts
from WinClientsApp.models.win_clients_contact import WinClientsContact
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status

# logging imports
import os
import logging
from datetime import datetime
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'Clients')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST',])
@permission_classes([IsAuthenticated,])
def GetContact(request):
    Id =  request.data.get("Id",None)
    Contact_Type = request.data.get("Contact_Type",None)
    System = request.data.get("System",None)
    result = "None"
    if System.__contains__("SSP Pure") :
        logger.info("Contact form SSP Pure %s,%s,%s",Id,Contact_Type,type(Contact_Type))
        try:
            Contact = ClientContacts.objects.filter(Client_Id = Id, Type_Desc = Contact_Type).first()
            result = Contact.NumberOrEmailOrWeb.replace(" ","") if Contact is not None else None
        except Exception as e:
            logger.exception("Error Finding the Contact in ssp DB %s:",e)
    if System.__contains__("Wynsure"):
        logger.info("Contact form Wynsure")
        try:
            contact_obj = WinClientsContact.objects.filter(Client_Id = Id).first()
            if contact_obj is not None:
                if Contact_Type == "Tel. Home":
                    result = contact_obj.Home_Phone
                if Contact_Type == "Tel. Work":
                    result = contact_obj.Office_Phone
                if Contact_Type == "Cellular Telephone":
                    result = contact_obj.Private_Cell_Phone
                if Contact_Type == "Fax No.":
                    result = None
        except Exception as e:
            logger.exception("Error Finding the Contact in winsure DB %s :",e)
    return Response({"contact_number":result}, status= status.HTTP_200_OK)
    