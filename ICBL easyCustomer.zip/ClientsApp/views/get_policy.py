from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from SSPClientsApp.models.policy import Policy
from SSPClientsApp.models.clients import Clients
from SSPClientsApp.models.clients_o_a import ClientsOA
from SSPClientsApp.models.clients_contacts import ClientContacts
from WinClientsApp.models.win_clients import WinClients
from WinClientsApp.models.win_clients_contact import WinClientsContact
from WinClientsApp.models.win_coverage import WinCoverage
from WinClientsApp.models.win_policy import WinPolicy
from functionalities.helpers import _ReturnError
#from ClientsApp.views.get_clients import get_contact_details
# logging imports
import os
import logging
from datetime import datetime
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'Clients')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST',])
@permission_classes([IsAuthenticated,])

def GetPolicy(request):
    logger.info("Data: %s",request.data)
    ClientID = request.data.get("ClientID", None)
    system = request.data.get("system", None)
    PolicyNo = request.data.get("Policy_Number", None)
    if PolicyNo == "":
        PolicyNo = None
    ClientData = {}
    PolicyData = []
    Policy_Data = None
    Contact_Email = None
    Contact_Type = "Tel. Home"
    Contact = None
    OA = None
    try:
        if system =='SSP Pure':
            logger.info("Searching Policy details in ssp DB")
            policyData = Policy.objects.filter(Client_Id = ClientID)
            clientData = Clients.objects.filter(Client_Id = ClientID).values()
            #contact_obj = ClientContacts.objects.filter(Client_Id = ClientID, Type_Desc= "Tel. Home").first()
            email_obj = ClientContacts.objects.filter(Client_Id = ClientID,Type_Code__contains=("MEMAIL")).first()
            logger.info("Searching is done, altering the data")
            if email_obj is not None:
                Contact_Email = email_obj.NumberOrEmailOrWeb
                if Contact_Email is not None:
                    Contact_Email = email_obj.NumberOrEmailOrWeb.replace(" ","")
            logger.info("Retrieved contact details are %s", clientData)
            contact = get_contact_details(ClientID)
            logger.info("Retrieved contact details are %s",contact)
            DOB = clientData[0]['Date_Of_Birth'].strftime("%Y-%m-%d") if clientData[0]['Date_Of_Birth'] is not None else "NA"
            if PolicyNo is not None and PolicyNo != "":
                # Policy_Data = Policy.objects.filter(Client_Id = ClientID,Policy_Number=PolicyNo).first()
                Policy_Data = Policy.objects.filter(Policy_Number=PolicyNo).first()

            ClientData = {
                "Customer_Name": clientData[0]['First_Name'].replace(" ","") + " "+ clientData[0]['Last_Name'].replace(" ",""),
                "DOB": DOB.replace(' ',''),
                "Id" : clientData[0]['Id_Number'],
                "Id_Type": clientData[0]['Type_Id'] if clientData[0]['Type_Id'] != "Null" and clientData[0]['Type_Id'] is not None else "Barbados Id",
                "Email": Contact_Email,
                "System": system,
                "Policy_Number" : Policy_Data.Policy_Number if Policy_Data is not None else None,
                "Vehicle_Reg_No" : Policy_Data.Vehicle_Reg_No if Policy_Data is not None else None,
                "telephone": contact[0],
                "telwork": contact[1],
                "telhome": contact[2],
                "fax": contact[3],
                }
            for p in policyData:
                # OA = ClientsOA.objects.filter(Client_Id=ClientID, Insurance_Ref__contains = p.Policy_Number).first()
                OA = ClientsOA.objects.filter(Insurance_Ref__contains = p.Policy_Number).first()
                logger.info(OA)
                PolicyData.append(
                    {
                        "Customer_Name": clientData[0]['First_Name'].replace(" ","") + " "+ clientData[0]['Last_Name'].replace(" ",""),
                        "DOB": DOB.replace(' ',''),
                        "Outstanding_Balance": OA.Total_OA if OA is not None else None,
                        "Payment_Method": OA.Payment_Method if OA is not None else None,
                        "Scheme_Name": OA.Scheme_Name if OA is not None else None,
                        "Payment_Due_Date": OA.Payment_Due_Date if OA is not None else None,
                        "Paid_Date": OA.Paid_Date if OA is not None else None,
                        "Next_Payment_Date": OA.Next_Payment_Date if OA is not None else None,
                        "Policy_Number" : p.Policy_Number,
                        "Policy_Start_Date" : p.Policy_Start_Date.strftime("%Y-%m-%d"),
                        "Policy_End_Date" : p.Policy_End_Date.strftime("%Y-%m-%d"),
                        "Policy_Status": p.Status,
                        "Renewal_Date" : p.Renewal_Date.strftime("%Y-%m-%d"),
                        "Premium" : p.Premium,
                    }       
                )
        elif system  == 'Wynsure':
            logger.info("Searching Policy details in WYNSURE DB")
            ClientData = {}
            PolicyData = []

            policyData = WinPolicy.objects.filter(Client_Id = ClientID)
            clientData = WinClients.objects.filter(Client_Id= ClientID).values()
            contact_obj = WinClientsContact.objects.filter(Client_Id = ClientID).first()
            logger.info("Searching is done, altering the data")
            PolicyData = []
            DOB = clientData[0]['Client_BirthDate'] if clientData[0]['Client_BirthDate'] is not None else "NA"
        
            if contact_obj is not None:
                Contact_Email = contact_obj.Email
                TelHome = contact_obj.Home_Phone
                TelPhone = contact_obj.Private_Cell_Phone
                TelWork = contact_obj.Office_Phone
            if PolicyNo is not None and PolicyNo != "":
                Policy_Data = WinPolicy.objects.filter(Client_Id = ClientID,Account_Number__startswith=PolicyNo).first()
            ClientData = {
                "Customer_Name": clientData[0]['Client_First_Name'].replace(" ","") + " " + clientData[0]['Client_Last_Name'].replace(" ",""),
                "DOB": DOB.replace(' ',''),
                "Id" : clientData[0]['Client_Id'],
                "Id_Type": "Barbados Id",
                "telhome":TelHome,
                "telephone":TelPhone,
                "telwork":TelWork,
                "Email": Contact_Email,
                "System": system,
                "Policy_Number":Policy_Data.Account_Number if Policy_Data is not None else None
                }
            if policyData is not None:
                for p in policyData:

                    print(p,"______________")
                    coverage = WinCoverage.objects.filter(Account_Number = p.Account_Number).first()
                    PolicyData.append(
                        {
                            "Customer_Name": clientData[0]['Client_First_Name'].replace(" ","") + " "+ clientData[0]['Client_Last_Name'].replace(" ",""),
                            "DOB": DOB.replace(' ',''),
                            "Policy_Number" : p.Account_Number,
                            "Policy_Start_Date" : p.Effective_Date,
                            "Policy_End_Date" : None,
                            "Policy_Status" : p.Policy_Status,
                            "Renewal_Date" : None,
                            "Outstanding_Balance": OA,
                            "Payment_Method": OA,
                            "Scheme_Name": OA,
                            "Payment_Due_Date": OA,
                            "Paid_Date": OA,
                            "Next_Payment_Date": OA,
                            "Premium" : coverage.Coverage_AMOUNT if coverage is not None else None
                        }       
                    )
            else:
                PolicyData.append(
                        {
                            "Customer_Name": clientData[0]['Client_First_Name'].replace(" ","") + " "+ clientData[0]['Client_Last_Name'].replace(" ",""),
                            "DOB": DOB.replace(' ',''),
                            "Policy_Number" : None,
                            "Policy_Start_Date" : None,
                            "Policy_End_Date" : None,
                            "Policy_Status" : None,
                            "Renewal_Date" : None,
                            "Outstanding_Balance": None,
                            "Premium" : None
                        }       
                    )
        return Response({"ClientData":ClientData,"PolicyData":PolicyData}, status= status.HTTP_200_OK)
    except Exception as e:
        logger.exception("Policy Details not found %s",e)
        return(_ReturnError("Policy Details not found",e))

def get_contact_details(ClientID):
    logger.info("In get contact details function %s",ClientID)
    telephone = None
    telwork = None
    telhome = None
    fax = None
    email = None
    # logger.info(dir(client_obj))
    client_c_obj = ClientContacts.objects.filter(Client_Id=ClientID).order_by('-S_N')[0:20]
    # logger.info(client_c_obj)
    for i in client_c_obj.values():
        if i['Type_Code'].replace(" ", "") == "TELEPHONE":
            telhome  = i['NumberOrEmailOrWeb'].replace(" ", "")

        if i['Type_Code'].replace(" ", "") == "TELWORK":
            telwork = i['NumberOrEmailOrWeb'].replace(" ", "")

        if i['Type_Code'].replace(" ", "") == "MOBILE":
            telephone = i['NumberOrEmailOrWeb'].replace(" ", "")

        if i['Type_Code'].replace(" ", "") == "FAX":
            fax = i['NumberOrEmailOrWeb'].replace(" ", "")

    return (telephone, telwork,telhome, fax)
