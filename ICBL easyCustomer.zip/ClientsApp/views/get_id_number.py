from SSPClientsApp.models.clients import Clients
from rest_framework import status
from rest_framework.decorators import api_view,permission_classes
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.response import Response
from functionalities.helpers import _ReturnError,_CheckRequestData,_RequestParse

# logging imports
import os
import logging
from datetime import datetime
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'Clients')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST',])
@permission_classes([IsAuthenticated,])
def GetIdNumber(request):

    logger.info("Data: %s",request.data)
    Client_Id = request.data.get("Id",None)
    Id_Type = request.data.get("Id_Type",None)
    result = "None"
    try:
        client_obj = Clients.objects.filter(Client_Id = Client_Id, Type_Id__contains = Id_Type).first()
        if client_obj is not None:
            result = client_obj.Id_Number 
    except Exception as e:
        logger.exception("Error Fetching the Id %s:",e)
    return Response({"ID":result}, status= status.HTTP_200_OK)