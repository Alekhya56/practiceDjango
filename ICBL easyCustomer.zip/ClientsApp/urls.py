from django.urls import path
from ClientsApp.views.get_clients import GetClients
from ClientsApp.views.get_policy import GetPolicy
from ClientsApp.views.get_contact import GetContact
from ClientsApp.views.get_id_number import GetIdNumber
urlpatterns = [
    path('get/users', GetClients),
    path('get/policy',GetPolicy),
    path('get/contact',GetContact),
    path('get/idnumber',GetIdNumber)
]