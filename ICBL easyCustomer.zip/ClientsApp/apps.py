from django.apps import AppConfig


class ClientsappConfig(AppConfig):
    name = 'ClientsApp'
