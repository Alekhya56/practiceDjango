from django.urls import path
from ExtraApp.views.report_manager import ReportManager
urlpatterns = [
    path('reports/generate', ReportManager),
]