from django.apps import AppConfig


class ExtraappConfig(AppConfig):
    name = 'ExtraApp'
