import os
import math
from django.http import HttpResponse, HttpResponseNotFound
from django.conf import settings
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from login.models import users
from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Customer_Response import CustomerResponse
from InAndOutBoundApp.models.Departments import Departments
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from InAndOutBoundApp.models.Products import Products
from InAndOutBoundApp.models.Queries import Queries
from InAndOutBoundApp.models.Requests import Requests
from InAndOutBoundApp.models.Type_Of_Channel import TypeOfChannel
from django.db.models import Count, Case, When, CharField, F, IntegerField, Q
from InAndOutBoundApp.models.Searched_Customers import SearchedCustomers
from functionalities.helpers import delete_excel
from openpyxl.styles.borders import Border, Side
from openpyxl.drawing.image import Image
from openpyxl.styles import Alignment
import openpyxl
from itertools import chain

import logging
from django.conf import settings
from datetime import datetime, timedelta 
from django.db.models import Max
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'Reports')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST',])
@permission_classes([AllowAny,])
def ReportManager(request):
    logger.info("Data: %s",request.data)
    print(request.data)
    file = request.data.get('file',None)
    GTDate = request.data.get('fromdate',None)
    LTDate = request.data.get('todate',None)
    # styling sheet
    thin_border = Border(left=Side(style='thin'), 
                     right=Side(style='thin'), 
                     top=Side(style='thin'), 
                     bottom=Side(style='thin'))
    # ______________________
    logger.info("setting up all look up tables")
    products = Products.objects.all()
    requests = Requests.objects.all()
    departments = Departments.objects.all()
    users_info = users.objects.all()
    channels = TypeOfChannel.objects.all()
    customer_response = CustomerResponse.objects.all()
    
    products_lookup={}
    requests_lookup={}
    departments_lookup={}
    users_lookup={}
    channel_lookup={}
    customer_response_lookup = {}
    logo_path =os.path.abspath(os.path.join(settings.EXCEL_URL,"..","..","images","icbl_logo.png"))
    print("logopath :%s",logo_path)
    for p in products:
        products_lookup[p.Product_id] = p.Product_Description
    for r in requests:
        requests_lookup[r.Request_Id] = r.Request_Description
    for d in departments:
        departments_lookup[d.Department_id] = d.Department_Description
    for u in users_info:
        users_lookup[u.UserID] = u.username
    for c in channels:
        channel_lookup[c.Channel_Id] = c.Channel_Description
    for cr in customer_response:
        customer_response_lookup[cr.Customer_Response_Id] = cr.Response_Description
        
    logger.info("Completed setting up look up tables")
    try:
        if file == "Download_users":
            logger.info("Initializing data to download Agent_list.xlsx")
            filename = f"Agent_list.xlsx"
            file_path = os.path.abspath(os.path.join(settings.EXCEL_URL, "Agent_list.xlsx"))
            save_path = os.path.abspath(os.path.join(settings.TEMP_URL, filename))
            book = openpyxl.load_workbook(file_path)
            sheet = book.active
            logger.info("Reports started for Contact_Update_Report.xlsx")
            user_s = users.objects.using('write_db').exclude(username='django_admin').all()
            row = 3
            img = Image(logo_path)
            sheet.add_image(img, 'A1')
            for i in user_s:
                sheet.cell(row=row, column=1).value = i.DisplayName
                sheet.cell(row=row, column=2).value = i.email
                sheet.cell(row=row, column=3).value = i.Role
                sheet.cell(row=row, column=4).value = i.Status
                sheet.cell(row=row, column=5).value = "Authority to ressign" if i.Permissions is not None else None
                sheet.cell(row=row, column=6).value = departments_lookup[int(i.Department)] if i.Department is not None else None
                for i in range(1, 7):
                    sheet.cell(row=row, column=i).border = thin_border

                row += 1
            book.save(save_path)
        if file == "Contact_Update_Report":
            logger.info("Initializing Data for Contact_Update_Report.xlsx")
            datestring = datetime.strftime(datetime.now(), '%Y_%m_%d_%H_%M_%S')
            filename = f"Contact_Update_Report_{datestring}.xlsx"
            file_path = os.path.abspath(os.path.join(settings.EXCEL_URL,"Contact_Update_Report.xlsx"))
            save_path = os.path.abspath(os.path.join(settings.TEMP_URL,filename))
            book = openpyxl.load_workbook(file_path)
            sheet = book.active
            request = Requests.objects.filter(Request_Description= 'Update Contact Details').first()
            # request_check = Requests.objects.filter(Request_Description='Update Contact Check Box').first()
            Updated_Contacts = Queries.objects.select_related().filter(
                Request_Type_Id = request.Request_Id,
                Call_Date__gte = GTDate, Call_Date__lte = LTDate).order_by('-Added')
            Updated_Contacts_check = Queries.objects.select_related().filter(
                Update_contact_checkbox =True, Call_Date__gte=GTDate, Call_Date__lte=LTDate).order_by('-Added')
            Updated_Contacts = Updated_Contacts | Updated_Contacts_check

            logger.info("Initialized Data for Contact_Update_Report.xlsx")
            
            logger.info("Reports started for Contact_Update_Report.xlsx")
            row = 3
            img = Image(logo_path)
            sheet.add_image(img, 'A1')
            for query in Updated_Contacts:
                product_Id = ""
                request_Id = ""
                call_Details = ""
                task_Id = ""
                daysopen = ""
                date_closed = ""
                closed_by = ""
                days_taken_to_close = ""
                query_status = ""
                resolution_notes = ""
                other_dept = ""
                customer_id = query.Customer_Id.Searched_Customer_Id
                if query is not None:
                    task_Id = query.pk
                    if query.Product_Type_Id is not None:
                        product_Id = products_lookup[int(query.Product_Type_Id)]
                    if query.Request_Type_Id is not None:
                        request_Id = requests_lookup[int(query.Request_Type_Id)]
                    if (query.Customer_Id.Existing_Customer == "No" or query.Customer_Id.Existing_Customer is None) and customer_id == 0:
                        customer_id = "NEW CLIENT"
                    elif query.Customer_Id.Existing_Customer == "Yes" and customer_id == 0:
                        customer_id = "UNIDENTIFIED EXISTING CLIENT"
                    
                    if query.Call_Type ==  "Outbound":
                        O= OutboundCallDetails.objects.filter(Query_Id = query.pk).order_by('-Outbound_Id').first()
                        if O is not None:
                            call_Details = O.Call_Details
                            other_dept = O.Dept_Email
                            query_status = O.Status
                            resolution_notes = O.Resolution_Notes
                            if O.Status != 'closed':
                                daysopen = (datetime.now().date() - query.Call_Date).days
                            if O.Status == 'closed':
                                closed_by = O.Last_Updated_By
                                date_closed = O.Last_Updated_Date
                                days_taken_to_close = (O.Last_Updated_Date - query.Call_Date).days
                    if query.Call_Type ==  "Inbound":
                        I= InboundCallDetails.objects.filter(Query_Id = query.pk).order_by('-Inbound_Id').first()
                        if I is not None:
                            call_Details = I.Call_Details
                            query_status = I.Status
                            resolution_notes = I.Resolution_Notes
                            if I.Status != 'closed':
                                daysopen = (datetime.now().date() - query.Call_Date).days
                            if I.Status == 'closed':
                                closed_by = I.Last_Updated_By
                                date_closed = I.Last_Updated_Date
                                days_taken_to_close = (I.Last_Updated_Date - query.Call_Date).days
                    
                    
                # print(product_Id)
                # print(u)
                # data = sheet.cell(row=1, column=2).value
                TeleHome = None
                TeleWork = None
                TelePhone = None
                Fax = None
                contact_number = query.Customer_Id.Contact_Number
                contact_type = query.Customer_Id.Contact_Type
                if contact_type is not None and contact_number is not None:
                    if contact_type == "Tel. Home" or contact_type =='Tel. Home':
                        TeleHome= contact_number
                    if contact_type == "Tel. Work" or contact_type =='Cellular Telephone':
                        TeleWork= contact_number
                    if contact_type == "Cellular Telephone" or contact_type =='Cellular Phone':
                        TelePhone= contact_number
                    if contact_type == "Fax No":
                        Fax= contact_number
                elif contact_type is None and contact_number is not None:
                    TeleWork = contact_number
                elif contact_type is None and contact_number is not None:
                    TeleHome = None
                    TeleWork = None
                    TelePhone = None
                    Fax = None
                else:
                    TeleHome = query.Customer_Id.TeleHome
                    TeleWork = query.Customer_Id.TeleWork
                    TelePhone = query.Customer_Id.TelePhone
                    Fax = query.Customer_Id.Fax
                    toc = query.Customer_Id.Type_Of_Channel
                sheet.cell(row=row, column=1).value =  query.Call_Date
                sheet.cell(row=row, column=2).value =  channel_lookup[int(toc)] if toc else None #users_lookup[int(query.User_Id_id)]
                sheet.cell(row=row, column=3).value =  task_Id
                sheet.cell(row=row, column=4).value =  users_lookup[int(query.User_Id_id)]
                sheet.cell(row=row, column=5).value =  query.Customer_Id.Customer_Name
                sheet.cell(row=row, column=6).value =  customer_id
                # sheet.cell(row=row, column=7).value =  query.Customer_Id.Contact_Number
                sheet.cell(row=row, column=7).value =  query.Customer_Id.Email
                sheet.cell(row=row, column=8).value =  TeleHome
                sheet.cell(row=row, column=9).value =  TeleWork
                sheet.cell(row=row, column=10).value = TelePhone
                sheet.cell(row=row, column=11).value =  Fax
                sheet.cell(row=row, column=12).value =  str(query.Customer_Id.Date_Of_Birth)
                sheet.cell(row=row, column=13).value =  query.Customer_Id.Policy_Number
                sheet.cell(row=row, column=14).value =  product_Id
                sheet.cell(row=row, column=15).value =  call_Details
                sheet.cell(row=row, column=16).value =  resolution_notes
                sheet.cell(row=row, column=17).value =  request_Id
                sheet.cell(row=row, column=18).value = "" if query.Other_Request == None else str(query.Other_Request)
                sheet.cell(row=row, column=29).value = other_dept
                sheet.cell(row=row, column=20).value = str(daysopen)
                sheet.cell(row=row, column=21).value = str(query_status)
                sheet.cell(row=row, column=22).value = str(date_closed)
                sheet.cell(row=row, column=23).value = str(closed_by)
                sheet.cell(row=row, column=24).value = str(days_taken_to_close)
                
                
                for i in range(1,25):
                    sheet.cell(row=row, column=i).border = thin_border
                
                row +=1
            
            book.save(save_path)
        if file == "Overdue_Inquiries_Report":
            logger.info("Initializing Data for Overdue_Inquiries_Report.xlsx")
            datestring = datetime.strftime(datetime.now(), '%Y_%m_%d_%H_%M_%S')
            filename = f"Overdue_Inquiries_Report_{datestring}.xlsx"
            file_path = os.path.abspath(os.path.join(settings.EXCEL_URL,"Overdue_Inquiries_Report.xlsx"))
            save_path = os.path.abspath(os.path.join(settings.TEMP_URL,filename))
            book = openpyxl.load_workbook(file_path)
            sheet = book.active
            img = Image(logo_path)
            sheet.add_image(img, 'A1')

            iob_arr = []
            Dept_Email = ""
            date_closed= ""
            closed_by = ""
            days_taken_to_close = ""
            other_dept = ""
            in_queries = InboundCallDetails.objects.values('Query_Id').filter(Query_Id__Call_Date__gte = GTDate, Query_Id__Call_Date__lte = LTDate).annotate(Max('Inbound_Id'))
            out_queries = OutboundCallDetails.objects.values('Query_Id').filter(Query_Id__Call_Date__gte = GTDate, Query_Id__Call_Date__lte = LTDate).annotate(Max('Outbound_Id'))

            in_queries = sorted(in_queries, key=lambda k: k['Inbound_Id__max'], reverse=True)
            out_queries = sorted(out_queries, key=lambda k: k['Outbound_Id__max'], reverse=True)
            
            in_queries_list = []
            out_queries_list = []
            
            for i in in_queries:
                in_queries_list.append(i['Inbound_Id__max'])
            for o in out_queries:
                out_queries_list.append(o['Outbound_Id__max'])
            print(len(in_queries_list),len(out_queries_list))
            in_count2000 = math.floor(len(in_queries_list)/2000)+1
            in_data = []
            for i in range(in_count2000):
                start,stop = 2000*i,2000*(i+1)
                print("data")
                temp_in_data = InboundCallDetails.objects.filter(~Q(Status = 'closed'), Inbound_Id__in =in_queries_list[start:stop]).prefetch_related('Query_Id', 'Query_Id__Customer_Id').all()
                in_data = chain(in_data,temp_in_data)
            out_count2000 = math.floor(len(out_queries_list)/2000)+1
            out_data = []
            for i in range(out_count2000):
                start,stop = (2000*i,2000*(i+1))
                temp_out_data = OutboundCallDetails.objects.filter(~Q(Status = 'closed'), Outbound_Id__in =out_queries_list[start:stop]).prefetch_related('Query_Id', 'Query_Id__Customer_Id').all()
                out_data = chain(out_data,temp_out_data)
            data = chain(in_data, out_data)
            for i in data:
                if i and i.Status != "closed":
                    if (datetime.now().date() - i.Query_Id.Call_Date).days > 0:
                        iob_arr.append(i)
                # if data and data.Status != "closed":
                #     if (datetime.now().date() - data.Query_Id.Call_Date).days > 0:
                #         iob_arr.append(data)
                #         Dept_Email = data.Dept_Email
                # if data.Status == "closed":
                #     closed_by = data.Last_Updated_Date
                #     date_closed = data.Last_Updated_By
                #     days_taken_to_close = (data.Last_Updated_Date - data.Query_Id.Call_Date).days

            logger.info("Initialized Data for Overdue_Inquiries_Report.xlsx")
            logger.info("Reports started for Overdue_Inquiries_Report.xlsx")
            row = 3
            for io in iob_arr:
                customer_id = io.Query_Id.Customer_Id.Searched_Customer_Id
                if (io.Query_Id.Customer_Id.Existing_Customer == "No" or io.Query_Id.Customer_Id.Existing_Customer is None) and customer_id == 0:
                    customer_id = "NEW CLIENT"
                elif io.Query_Id.Customer_Id.Existing_Customer == "Yes" and customer_id == 0:
                    customer_id = "UNIDENTIFIED EXISTING CLIENT"
                Contact_Number = io.Query_Id.Customer_Id.Contact_Number
                toc = io.Query_Id.Customer_Id.Type_Of_Channel
                rti = io.Query_Id.Request_Type_Id
                pti = io.Query_Id.Product_Type_Id
                sheet.cell(row=row, column=1).value =  io.Query_Id.Call_Date
                sheet.cell(row=row, column=2).value =  channel_lookup[int(toc)] if toc else None
                sheet.cell(row=row, column=3).value =  io.Query_Id_id
                sheet.cell(row=row, column=4).value =  users_lookup[int(io.Query_Id.User_Id_id)]
                sheet.cell(row=row, column=5).value =  io.Query_Id.Customer_Id.Customer_Name
                sheet.cell(row=row, column=6).value =  customer_id
                sheet.cell(row=row, column=7).value =  Contact_Number.replace(',','|') if Contact_Number is not None else None
                sheet.cell(row=row, column=8).value =  io.Query_Id.Customer_Id.Policy_Number
                sheet.cell(row=row, column=9).value =  products_lookup[int(pti)] if pti else None
                sheet.cell(row=row, column=10).value =  io.Call_Details
                sheet.cell(row=row, column=11).value =  io.Resolution_Notes
                sheet.cell(row=row, column=12).value =  io.Remarks
                sheet.cell(row=row, column=13).value =  requests_lookup[int(rti)] if rti else None
                sheet.cell(row=row, column=14).value =  "" if io.Query_Id.Other_Request is None else io.Query_Id.Other_Request
                sheet.cell(row=row, column=15).value =  getdepartments(io.Depart_Id,departments_lookup) if io.Depart_Id is not None else None
                sheet.cell(row=row, column=16).value =  io.Dept_Email
                sheet.cell(row=row, column=17).value =  io.Status
                sheet.cell(row=row, column=18).value =  (datetime.now().date() - io.Query_Id.Call_Date).days
                sheet.cell(row=row, column=19).value =  "Yes" if io.Query_Id.Complaint else "No"
                sheet.cell(row=row, column=20).value =  io.Query_Id.Priority
                sheet.cell(row=row, column=21).value =  "" if io.Follow_Up_Date is None else str(io.Follow_Up_Date)
                sheet.cell(row=row, column=22).value =  io.Query_Id.Customer_Id.System
                
                for i in range(1,23):
                    sheet.cell(row=row, column=i).border = thin_border
                    sheet.cell(row=row, column=i).alignment = Alignment(horizontal='left',vertical="center")
                    
                # sheet.cell(row=row, column=2).border = thin_border
                # sheet.cell(row=row, column=3).border = thin_border
                # sheet.cell(row=row, column=4).border = thin_border
                # sheet.cell(row=row, column=5).border = thin_border
                # sheet.cell(row=row, column=6).border = thin_border
                # sheet.cell(row=row, column=7).border = thin_border
                # sheet.cell(row=row, column=8).border = thin_border
                # sheet.cell(row=row, column=9).border = thin_border
                # sheet.cell(row=row, column=10).border = thin_border
                # sheet.cell(row=row, column=11).border = thin_border
                # sheet.cell(row=row, column=12).border = thin_border
                # sheet.cell(row=row, column=13).border = thin_border
                # sheet.cell(row=row, column=14).border = thin_border
                # sheet.cell(row=row, column=15).border = thin_border
                # sheet.cell(row=row, column=16).border = thin_border
                # sheet.cell(row=row, column=17).border = thin_border
                # sheet.cell(row=row, column=18).border = thin_border
                # sheet.cell(row=row, column=19).border = thin_border
                
                row +=1

            logger.info("Reports Finished for Overdue_Inquiries_Report.xlsx")
            book.save(save_path)
        if file == "Inbound_Call_Activity_Report":
            logger.info("Initializing Data for Inbound_Call_Activity_Report.xlsx")
            datestring = datetime.strftime(datetime.now(), '%Y_%m_%d_%H_%M_%S')
            filename = f"Inbound_Call_Activity_Report_{datestring}.xlsx"
            file_path = os.path.abspath(os.path.join(settings.EXCEL_URL,"Inbound_Call_Activity_Report.xlsx"))
            save_path = os.path.abspath(os.path.join(settings.TEMP_URL,filename))
            book = openpyxl.load_workbook(file_path)
            sheet = book.active
            img = Image(logo_path)
            sheet.add_image(img, 'A1')

            ib_arr = []
            daysopen = ""
            closed_by = ""
            date_closed = ""
            days_taken_to_close = ""
            other_dept = ""
            in_queries = InboundCallDetails.objects.values('Query_Id').filter(Query_Id__Call_Date__gte = GTDate, Query_Id__Call_Date__lte = LTDate).annotate(Max('Inbound_Id'))
            in_queries = sorted(in_queries, key=lambda k: k['Inbound_Id__max'], reverse=True)
            in_queries_list = []
            for i in in_queries:
                in_queries_list.append(i["Inbound_Id__max"])
            print(len(in_queries_list))
            count2000 = math.floor(len(in_queries_list)/2000) + 1
            print(count2000)  
            ib_arr_temp = [] 
            for i in range(count2000):
                start = 2000*i
                stop = 2000*(i+1)
                temp_ib_arr = InboundCallDetails.objects.filter(Inbound_Id__in = in_queries_list[start:stop]).prefetch_related('Query_Id', 'Query_Id__Customer_Id').all()
                ib_arr_temp = chain(ib_arr_temp,temp_ib_arr)
            ib_arr = list(ib_arr_temp)
            logger.info("Initialized Data for Inbound_Call_Activity_Report.xlsx")
            logger.info("Reports started for Inbound_Call_Activity_Report.xlsx")
            row = 3
            print(len(ib_arr))
            if len(ib_arr) == 0:
                print("inside if")
                response = Response({"error":"Unable to generate Excel Report"}, status= status.HTTP_422_UNPROCESSABLE_ENTITY)
                pass
            for i in ib_arr:
                if i.Status != 'closed':
                    daysopen = (datetime.now().date() - i.Query_Id.Call_Date).days
                    closed_by = None
                    date_closed = None
                    days_taken_to_close = None
                if i.Status == 'closed':
                    closed_by = i.Last_Updated_Date
                    date_closed = i.Last_Updated_By
                    days_taken_to_close = (i.Last_Updated_Date - i.Query_Id.Call_Date).days
                customer_id = i.Query_Id.Customer_Id.Searched_Customer_Id
                
                if (i.Query_Id.Customer_Id.Existing_Customer == "No" or i.Query_Id.Customer_Id.Existing_Customer is None) and customer_id == 0:
                    customer_id = "NEW CLIENT"
                elif i.Query_Id.Customer_Id.Existing_Customer == "Yes" and customer_id == 0:
                    customer_id = "UNIDENTIFIED EXISTING CLIENT"
                call_time = divmod((i.Query_Id.Call_End_Time - i.Query_Id.Call_Start_Time).seconds, 60)
                Contact_Number = i.Query_Id.Customer_Id.Contact_Number
                toc = i.Query_Id.Customer_Id.Type_Of_Channel
                rti = i.Query_Id.Request_Type_Id
                pti = i.Query_Id.Product_Type_Id
                sheet.cell(row=row, column=1).value =  i.Query_Id.Call_Date
                sheet.cell(row=row, column=2).value =  channel_lookup[int(toc)] if toc else None
                sheet.cell(row=row, column=3).value =  i.Query_Id_id
                sheet.cell(row=row, column=4).value =  users_lookup[int(i.Query_Id.User_Id_id)]
                sheet.cell(row=row, column=5).value =  i.Query_Id.Customer_Id.Customer_Name
                sheet.cell(row=row, column=7).value =  Contact_Number.replace(',','|') if Contact_Number is not None else None
                sheet.cell(row=row, column=6).value = customer_id
                sheet.cell(row=row, column=8).value = i.Query_Id.Customer_Id.Policy_Number
                sheet.cell(row=row, column=9).value = products_lookup[int(pti)] if pti else None
                sheet.cell(row=row, column=10).value =  i.Call_Details
                sheet.cell(row=row, column=11).value =  i.Resolution_Notes
                sheet.cell(row=row, column=12).value =  i.Remarks
                sheet.cell(row=row, column=13).value =  requests_lookup[int(rti)] if rti else None
                sheet.cell(row=row, column=14).value =  "" if i.Query_Id.Other_Request is None else i.Query_Id.Other_Request
                sheet.cell(row=row, column=15).value =  getdepartments(i.Depart_Id,departments_lookup)
                sheet.cell(row=row, column=16).value = i.Dept_Email
                sheet.cell(row=row, column=17).value =  i.Status
                sheet.cell(row=row, column=18).value =  daysopen
                sheet.cell(row=row, column=19).value =  "Yes" if i.Query_Id.Complaint else "No"
                sheet.cell(row=row, column=20).value =  i.Query_Id.Priority
                sheet.cell(row=row, column=21).value =  str(closed_by)
                sheet.cell(row=row, column=22).value =  str(days_taken_to_close)
                sheet.cell(row=row, column=23).value =  str(date_closed)
                sheet.cell(row=row, column=24).value =  "" if i.Follow_Up_Date is None else str(i.Follow_Up_Date)
                sheet.cell(row=row, column=25).value =  i.Query_Id.Customer_Id.System
                sheet.cell(row=row, column=26).value =  str(call_time[0])+":"+str(call_time[1])
                
                for i in range(1,27):
                    sheet.cell(row=row, column=i).border = thin_border
                row +=1
            logger.info("Reports completed for Inbound_Call_Activity_Report.xlsx")
            book.save(save_path)
        if file == "Outbound_Call_Activity_Report":
            logger.info("Initializing Data for Outbound_Call_Activity_Report.xlsx")
            datestring = datetime.strftime(datetime.now(), '%Y_%m_%d_%H_%M_%S')
            filename = f"Outbound_Call_Activity_Report_{datestring}.xlsx"
            file_path = os.path.abspath(os.path.join(settings.EXCEL_URL,"Outbound_Call_Activity_Report.xlsx"))
            save_path = os.path.abspath(os.path.join(settings.TEMP_URL,filename))
            book = openpyxl.load_workbook(file_path)
            sheet = book.active
            img = Image(logo_path)
            sheet.add_image(img, 'A1')

            ob_arr = []
            daysopen = ""
            closed_by = ""
            date_closed = ""
            days_taken_to_close = ""
            other_dept = ""
            out_queries = OutboundCallDetails.objects.values('Query_Id').annotate(Max('Outbound_Id'))
            out_queries = sorted(out_queries, key=lambda k: k['Outbound_Id__max'], reverse=True)
            logger.info("Initialized Data for Outbound_Call_Activity_Report.xlsx")
            out_queries_list = []
            for o in out_queries:
                out_queries_list.append(o["Outbound_Id__max"])
            count2000 = math.floor(len(out_queries_list)/2000)+1
            ob_arr = []
            for i in range(count2000):
                start,stop = 2000*i,2000*(i+1)
                temp_ob_arr = OutboundCallDetails.objects.filter(Outbound_Id__in=out_queries_list[start:stop], Query_Id__Call_Date__gte = GTDate, Query_Id__Call_Date__lte = LTDate).prefetch_related('Query_Id', 'Query_Id__Customer_Id').all()
                ob_arr= chain(ob_arr, temp_ob_arr)
                # if len(data):
                #     ob_arr.append(data[0])
            row = 3
            logger.info("Reports started for Outbound_Call_Activity_Report.xlsx")
            for o in ob_arr:
                customer_response = ""
                if o.Status != 'closed':
                    daysopen = (datetime.now().date() - o.Query_Id.Call_Date).days
                    closed_by = ""
                    date_closed = ""
                    days_taken_to_close = ""
                    
                if o.Status == 'closed':
                    closed_by = o.Last_Updated_Date
                    date_closed = o.Last_Updated_By
                    days_taken_to_close = (o.Last_Updated_Date - o.Query_Id.Call_Date).days
                
                customer_id = o.Query_Id.Customer_Id.Searched_Customer_Id
                if (o.Query_Id.Customer_Id.Existing_Customer == "No" or o.Query_Id.Customer_Id.Existing_Customer is None) and customer_id == 0:
                    customer_id = "NEW CLIENT"
                elif o.Query_Id.Customer_Id.Existing_Customer == "Yes" and customer_id == 0:
                    customer_id = "UNIDENTIFIED EXISTING CLIENT"
                if o.Customer_Response_Id is not None:
                    customer_response = customer_response_lookup[int(o.Customer_Response_Id)]
                call_time = divmod((o.Query_Id.Call_End_Time - o.Query_Id.Call_Start_Time).seconds, 60)
                Contact_Number = o.Query_Id.Customer_Id.Contact_Number
                toc = o.Query_Id.Customer_Id.Type_Of_Channel
                rti = o.Query_Id.Request_Type_Id
                pti = o.Query_Id.Product_Type_Id
                sheet.cell(row=row, column=1).value =  o.Query_Id.Call_Date
                sheet.cell(row=row, column=2).value =  channel_lookup[int(toc)] if toc else None
                sheet.cell(row=row, column=3).value =  o.Query_Id_id
                sheet.cell(row=row, column=4).value =  users_lookup[int(o.Query_Id.User_Id_id)]
                sheet.cell(row=row, column=5).value =  o.Query_Id.Customer_Id.Customer_Name
                sheet.cell(row=row, column=6).value =  customer_id
                sheet.cell(row=row, column=7).value =  Contact_Number.replace(',','|') if Contact_Number is not None else None
                sheet.cell(row=row, column=8).value = o.Query_Id.Customer_Id.Policy_Number
                sheet.cell(row=row, column=9).value = products_lookup[int(pti)] if pti else None
                sheet.cell(row=row, column=10).value =  o.Customer_Reached
                sheet.cell(row=row, column=11).value =  customer_response
                sheet.cell(row=row, column=12).value =  o.Call_Details
                sheet.cell(row=row, column=13).value =  o.Resolution_Notes
                sheet.cell(row=row, column=14).value =  o.Remarks
                sheet.cell(row=row, column=15).value =  requests_lookup[int(rti)] if rti else None
                sheet.cell(row=row, column=16).value =  "" if o.Query_Id.Other_Request is None else o.Query_Id.Other_Request
                sheet.cell(row=row, column=17).value = getdepartments(o.Depart_Id,departments_lookup)
                sheet.cell(row=row, column=18).value =  o.Dept_Email
                sheet.cell(row=row, column=19).value =  o.Status
                sheet.cell(row=row, column=20).value =  daysopen
                sheet.cell(row=row, column=21).value =  "Yes" if o.Query_Id.Complaint else "No"
                sheet.cell(row=row, column=22).value =  o.Query_Id.Priority
                sheet.cell(row=row, column=23).value =  str(closed_by)
                sheet.cell(row=row, column=24).value =  str(days_taken_to_close)
                sheet.cell(row=row, column=25).value =  str(date_closed)
                sheet.cell(row=row, column=26).value =  "" if o.Follow_Up_Date is None else str(o.Follow_Up_Date)
                sheet.cell(row=row, column=27).value =  o.Query_Id.Customer_Id.System
                sheet.cell(row=row, column=28).value =  str(call_time[0])+":"+str(call_time[1])
                
                for i in range(1,29):
                    sheet.cell(row=row, column=i).border = thin_border
                row +=1
            logger.info("Reports Completed for Outbound_Call_Activity_Report.xlsx")
            book.save(save_path)
        if file == "Agent_Performance_Report":
            logger.info("Initializing Data for Agent_Performance_Report.xlsx")
            datestring = datetime.strftime(datetime.now(), '%Y_%m_%d_%H_%M_%S')
            filename = f"Agent_Performance_Report_{datestring}.xlsx"
            file_path = os.path.abspath(os.path.join(settings.EXCEL_URL,"Agent_Performance_Report.xlsx"))
            save_path = os.path.abspath(os.path.join(settings.TEMP_URL,filename))
            book = openpyxl.load_workbook(file_path)
            sheet = book.active
            img = Image(logo_path)
            sheet.add_image(img, 'A1')

            Out= Queries.objects.filter(Call_Date__gte = GTDate, Call_Date__lte = LTDate).values('User_Id','User_Id__username').annotate(
                incalls=Count('Query_Id',filter=Q(Call_Type='Inbound')),
                outcalls=Count('Query_Id',filter=Q(Call_Type='Outbound')),
                totalcalls=Count('Query_Id')
                )
            # Getting Unique Customer Values
            unique_users = None
            q = Queries.objects.filter(Call_Date__gte = GTDate, Call_Date__lte = LTDate).values('Customer_Id__Customer_Name','User_Id').distinct()
            unique_users = q.values_list('User_Id')
            count = {}
            for i in unique_users:
                count[str(i[0])] = q.filter(User_Id = i[0]).count()
            logger.info("Initialized Data for Agent_Performance_Report.xlsx")

            row = 3
            logger.info("Reports started for Agent_Performance_Report.xlsx")
            for user in Out:
                # print(user)
                query_i = Queries.objects.filter(User_Id = int(user['User_Id']), Call_Type="Inbound", Call_Date__gte = GTDate, Call_Date__lte = LTDate).all()
                query_o = Queries.objects.filter(User_Id = int(user['User_Id']), Call_Type="Outbound", Call_Date__gte = GTDate, Call_Date__lte = LTDate).all()
                AvgIbTime = 0
                AvgObTime = 0
                if len(query_i):
                    for i in query_i:
                        call_time = (i.Call_End_Time-i.Call_Start_Time).seconds/60
                        AvgIbTime += call_time
                    if AvgIbTime:
                        AvgIbTime= AvgIbTime/len(query_i)
                if len(query_o):
                    for i in query_o:
                        call_time = (i.Call_End_Time-i.Call_Start_Time).seconds/60
                        AvgObTime += call_time
                    if AvgIbTime:
                        AvgObTime= AvgObTime/len(query_o)

                sheet.cell(row=row, column=1).value =  user['User_Id__username']
                sheet.cell(row=row, column=1).border = thin_border
                sheet.cell(row=row, column=2).value =  user['totalcalls']
                sheet.cell(row=row, column=2).border = thin_border
                sheet.cell(row=row, column=3).value =  user['outcalls']
                sheet.cell(row=row, column=3).border = thin_border
                
                sheet.cell(row=row, column=1).value =  user['User_Id__username']
                sheet.cell(row=row, column=1).border = thin_border
                sheet.cell(row=row, column=2).value =  user['totalcalls']
                sheet.cell(row=row, column=2).border = thin_border
                sheet.cell(row=row, column=3).value =  user['outcalls']
                sheet.cell(row=row, column=3).border = thin_border
                sheet.cell(row=row, column=4).value =  user['incalls']
                sheet.cell(row=row, column=4).border = thin_border
                sheet.cell(row=row, column=5).value =  "{:.2f}".format(AvgObTime)
                sheet.cell(row=row, column=5).border = thin_border
                sheet.cell(row=row, column=6).value =  "{:.2f}".format(AvgIbTime)
                sheet.cell(row=row, column=6).border = thin_border
                sheet.cell(row=row, column=7).value =  count[str(user['User_Id'])]
                sheet.cell(row=row, column=7).border = thin_border

                row +=1
            logger.info("Reports Completed for Agent_Performance_Report.xlsx")
            book.save(save_path)
        
    except Exception as e:
        print(e)
        logger.exception(e)
    # This code down here Creates local copy of excel and 
    # deletes before sending by storing in a variable
    try:    
        with open(save_path, 'rb') as f:
           file_data = f.read()
        logger.info("Ready to Send Temp file")

        # sending response 
        response = HttpResponse(file_data, content_type='application/vnd.ms-excel')
        # print(filename,"_____________________________________")
        response['Content-Disposition'] = 'attachment; filename='+filename
        delete_excel(save_path)
        logger.info("Succesfully Deleted Temp file")
    except IOError:
        # handle file not exist case here rerturn error
        response = Response({"error":"Unable to generate Excel Report"}, status= status.HTTP_422_UNPROCESSABLE_ENTITY)
    logger.info("Successfully Send Temp file")
    return response


def getdepartments(dept_ids,departments_lookup):
    if dept_ids is None or dept_ids== "":
        return None
    temp = dept_ids.replace(" ", "") 
    departments = temp.split(",")
    dept = ""
    for i in departments:
        if i == "":
            continue
        dept_desc = departments_lookup[int(i)]
        if dept == "":
            dept = dept_desc
            continue
        dept = dept + " , "+ dept_desc
    return dept