import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from django.conf import settings
from rest_framework.response import Response
from rest_framework import status
import random
import string
import jwt
import os
from datetime import datetime
from functionalities.defaults import STATUS_DELETE, STATUS_INACTIVE, STATUS_ACTIVE, ROLES_ADMIN, ROLES_GENERIC
def _ResponseOK():
    message ="success"
    return Response("message: Success", status = status.HTTP_200_OK)
    # return Response("result": "Success", status = status.HTTP_200_OK)

def _RandomStringwithDigitsAndSymbols(stringLength=10):
    """Generate a random string of letters, digits and special characters """

    password_characters = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.choice(password_characters) for i in range(stringLength))

def _SendEmail(to_address,subject,body,cc=[]):
    
    domain = settings.MAILSERVER_DOMAIN
    email= settings.MAILSERVER_USERNAME
    if settings.ENVIRONMENT == "DEVELOPMENT":
        port= settings.MAILSERVER_PORT
        password=settings.MAILSERVER_PASSWORD

    msg = MIMEMultipart()
    msg['subject'] = subject
    msg['from'] = email
    msg['to'] = ', '.join(to_address)
    msg['cc'] = ', '.join(cc)
    msg.attach(MIMEText(body, 'html'))
    
    if settings.ENVIRONMENT == "DEVELOPMENT":
        # connecting to mailserver and send the email
        mailserver = smtplib.SMTP_SSL(domain, port=port)
        mailserver.login(email, password)

    if settings.ENVIRONMENT != "DEVELOPMENT":
        # connecting to mailserver and send the email
        mailserver = smtplib.SMTP(domain)
    try:
        mailserver.sendmail(email, (to_address+cc), msg.as_string())

    except Exception as e:
        print(e)
        domain = settings.ER_MAILSERVER_DOMAIN
        email= settings.ER_MAILSERVER_USERNAME
        to_address = ["shaik.farooq@manomay.biz","neetha.pasham@manomay.biz"]
        if settings.ENVIRONMENT == "DEVELOPMENT":
            port= settings.ER_MAILSERVER_PORT
            password=settings.ER_MAILSERVER_PASSWORD
        msg = MIMEMultipart()
        msg['subject'] = "Error Sending Mails" + subject
        msg['from'] = email
        msg['to'] = ', '.join(to_address)
        body = f'''<p>Hi, Admin(Easy Customer)</p>
                    <p>Looks like There is some Problem triggering the Emails</p>
                    <p>Please Check!</p>
                    <p>Error is {e}</p>
                    <p>Thanks and Regards</p>
                '''
        msg.attach(MIMEText(body, 'html'))
        
        if settings.ENVIRONMENT == "DEVELOPMENT":
            # connecting to mailserver and send the email
            mailserver = smtplib.SMTP_SSL(domain, port=port)
            mailserver.login(email, password)

        if settings.ENVIRONMENT != "DEVELOPMENT":
            # connecting to mailserver and send the email
            mailserver = smtplib.SMTP(domain)
        mailserver.sendmail(email, (to_address), msg.as_string())
        return f"mail failed: {e}"
    print("mail sent") 
    return "mail sent"

def _CheckRequestData(req, name):
    return req[name] if name in req else None

def _RequestParse(**kwargs):  
    Return_error= "The request Data should have: "
    for key, value in kwargs.items():
        # print("%s == %s" %(key, value))
        if value is None:
            Return_error = Return_error + str(key) + ","
            return Response("message:"+Return_error, status= status.HTTP_422_UNPROCESSABLE_ENTITY)
    return None

def _ReturnError(message, error=None):
    print(message+str(error))
    return Response({"error":message}, status=status.HTTP_422_UNPROCESSABLE_ENTITY)

def token_verify(token,email):
    Authorization = token.replace("Bearer","")
    print(type(Authorization))
    decoded_token = jwt.decode(Authorization,None,None)
    print(decoded_token,"*******")
    if decoded_token["role"] not in [ROLES_ADMIN,ROLES_GENERIC]:
        return(_ReturnError("Access Denied, No such role"))
    # if decoded_token["email"] not in [ROLES_ADMIN,ROLES_GENERIC]:
    #     return(_ReturnError("Access Denied, No such role"))
    return True

def delete_excel(filename):
    # time.sleep(5)  # ??!!
    print("deleting file -" + filename)
    os.remove(filename)

def date_conv(d):
	if d.__contains__("-"):
		return datetime.strptime(d, '%d-%m-%Y').strftime('%Y-%m-%d')
	else:
		return datetime.fromtimestamp(int(d)).strftime('%Y-%m-%d')