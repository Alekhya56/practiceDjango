from rest_framework.decorators import api_view,permission_classes
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny

class MyIpAPIView(APIView):
    # Allow any user (authenticated or not) to access this url 
    permission_classes = (AllowAny,)
 
    def get(self, request):
        user_ip = {}
        print('_______________________')
        # print(request.META)
        x_real_ip = request.META['HTTP_X_REAL_IP'] if 'HTTP_X_REAL_IP' in request.META else None
        # LOG.debug('X-Real-Ip: %s', x_real_ip)
    
        x_forwarded_ip = request.META['HTTP_X_FORWARDED_FOR'] if 'HTTP_X_FORWARDED_FOR' in request.META else None
        # LOG.debug('X-Forwarded-For: %s', x_forwarded_ip)
    
        remote_addr = request.environ['REMOTE_ADDR'] if 'REMOTE_ADDR' in request.environ else ''
        # LOG.debug('REMOTE_ADDR: %s', flask_remote_addr)
        user_ip['ip'] = x_real_ip if x_real_ip else x_forwarded_ip if x_forwarded_ip else remote_addr
        print("real_ip",x_real_ip,"forward",x_forwarded_ip,"remote",remote_addr)
        return Response(user_ip)