class WriteRouter:
    def db_for_read(self, model, **hints):
        """
        Reads go to the posts db
        """
        return 'write_db'

    def db_for_write(self, model, **hints):
        return 'write_db'

    def allow_relation(self, obj1, obj2, **hints):
        """
        Relations between objects are allowed if both objects are
        in the write_db database
        """
        db_name = 'write_db'
        if obj1._state.db == db_name and obj2._state.db == db_name:
            return True
        return False

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        """
        All non newsletter models end up in the write_db database
        """
        if db == 'read_db':
            return False
        if app_label == 'SSPClientsApp' or app_label == 'WinClientsApp':
            return False
        return True