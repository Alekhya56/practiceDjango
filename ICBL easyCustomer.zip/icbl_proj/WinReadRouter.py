class WinReadRouter:
    """
    A router to control all operations on models in the
    WinClientsApp application
    """

    def db_for_read(self, model, **hints):
        """
        Attempts to read WinClientsApp models go to win_read_db
        NOTE: model._meta.app_label is the name of the respective app
        so it might be WinClientsApp or posts or auth or contenttypes or w/e if it's 
        django default or 3rd party app
        """
        print(model)
        if model._meta.app_label == 'WinClientsApp':
            return 'win_read_db'
        return None

    def db_for_write(self, model, **hints):
        """
        Attempts to write to WinClientsApp models go to win_read_db
        """
        if model._meta.app_label == 'WinClientsApp':
            return 'win_read_db'
        return None


    def allow_relation(self, obj1, obj2, **hints):
        """
        Allow relationships only if obj1._meta.app_label == obj2._meta.app_label
        """
        app_label_name = 'WinClientsApp'
        #If both models have app_label = 'WinClientsApp' allow relation between them
        if obj1._meta.app_label == app_label_name and \
        obj2._meta.app_label == app_label_name:
            return True
        #If both models don't have app_label = 'WinClientsApp' pass None to proceed
        #to next router
        elif app_label_name not in [obj1._meta.app_label, obj2._meta.app_label]:
            return None

        #Else - one model has app_label = 'WinClientsApp' the other one does not -
        #Forbid a relationship spanning multiple databases - not supported in Django
        else:
            return False


    def allow_migrate(self, db, app_label, model_name=None, **hints):
        """
        Make sure the WinClientsApp app only appears in the 'win_read_db'
        """
        # print(db,app_label)
        # if db == 'win_read_db':
        #     return app_label == 'WinClientsApp'

        # elif app_label == 'WinClientsApp':
        #     return False
        # return None
        if db == 'win_read_db':
            return False