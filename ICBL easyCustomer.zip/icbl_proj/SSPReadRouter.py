class SSPReadRouter:
    """
    A router to control all operations on models in the
    SSPClientsApp application
    """

    def db_for_read(self, model, **hints):
        """
        Attempts to read SSPClientsApp models go to ssp_read_db
        NOTE: model._meta.app_label is the name of the respective app
        so it might be SSPClientsApp or posts or auth or contenttypes or w/e if it's 
        django default or 3rd party app
        """
        print(model)
        if model._meta.app_label == 'SSPClientsApp':
            return 'ssp_read_db'
        return None

    def db_for_write(self, model, **hints):
        """
        Attempts to write to SSPClientsApp models go to ssp_read_db
        """
        if model._meta.app_label == 'SSPClientsApp':
            return 'ssp_read_db'
        return None


    def allow_relation(self, obj1, obj2, **hints):
        """
        Allow relationships only if obj1._meta.app_label == obj2._meta.app_label
        """
        app_label_name = 'SSPClientsApp'
        #If both models have app_label = 'SSPClientsApp' allow relation between them
        if obj1._meta.app_label == app_label_name and \
        obj2._meta.app_label == app_label_name:
            return True
        #If both models don't have app_label = 'SSPClientsApp' pass None to proceed
        #to next router
        elif app_label_name not in [obj1._meta.app_label, obj2._meta.app_label]:
            return None

        #Else - one model has app_label = 'SSPClientsApp' the other one does not -
        #Forbid a relationship spanning multiple databases - not supported in Django
        else:
            return False


    def allow_migrate(self, db, app_label, model_name=None, **hints):
        """
        Make sure the SSPClientsApp app only appears in the 'ssp_read_db'
        """
        # print(db,app_label)
        # if db == 'ssp_read_db':
        #     return app_label == 'SSPClientsApp'

        # elif app_label == 'SSPClientsApp':
        #     return False
        # return None
        if db == 'ssp_read_db':
            return False