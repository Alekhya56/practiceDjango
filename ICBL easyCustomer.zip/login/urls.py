from django.urls import path
from login.views.login import authenticate_user
from login.views.logout import LogOut
from login.views.password_change import ChangePassword
from login.views.password_reset import ResetPassword
from login.views.user_create import CreateUser
from login.views.user_update import UpdateUser
from login.views.user_delete import DeleteUser
# from login.views.clients_get import GetClients
# from login.views.policy_get import GetPolicy
from login.views.get_internal_user import GetInternalUsers
from login.views.token_check import TokenCheck

app_name = 'users'
urlpatterns = [
    path('admin/createuser', CreateUser),
    path('admin/user/internal/delete', DeleteUser),
    path('admin/users/internal/get', GetInternalUsers),
    path('admin/user/update', UpdateUser),
    path('auth/login', authenticate_user),
    path('auth/logout', LogOut),
    path('auth/password/change', ChangePassword),
    path('auth/password/reset', ResetPassword),
    path('auth/token/check', TokenCheck),
    # path('client/get', GetClients),
    # path('policy/get', GetPolicy),
    # path('update/', UserRetrieveUpdateAPIView.as_view()),
]