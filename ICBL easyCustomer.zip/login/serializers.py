# users/serializers.py
from rest_framework import serializers
from .models import users
 
class usersSerializer(serializers.ModelSerializer):
 
    UserCreatedTime = serializers.ReadOnlyField()
    PassLastUpdatedDate = serializers.ReadOnlyField()
    
    class Meta(object):
        model = users
        fields = ('UserID', 'email', 'username','TemporaryPassword','DisplayName','Department','Team',
                  'password', 'UserCreatedTime','PassLastUpdatedDate','Role','Status','CreatedBy','Permissions')
    