import uuid
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings
from django.utils import timezone
   
users = settings.AUTH_USER_MODEL

class users(AbstractUser):
    UserID = models.AutoField(primary_key = True)
    username = models.CharField(max_length = 255, unique = True, null = False)
    TemporaryPassword= models.BooleanField(default = False,null = True)
    email = models.CharField(max_length = 255, unique = True)
    DisplayName = models.CharField(max_length = 255, default= 'New User',)
    SessionDuration = models.CharField(max_length = 255, null = True) 
    PhoneNumber = models.CharField(max_length = 255, null = True)
    Role = models.CharField(max_length = 255, null = True)
    Status = models.CharField(max_length = 255, null = True)
    UserCreatedTime = models.DateField(default= timezone.now, null = True)
    TimeZone = models.CharField(max_length = 255, null = True)
    Language = models.CharField(max_length = 255, null = True)
    Last5Passwords = models.CharField(max_length = 255, null = True)
    PassLastUpdatedDate = models.DateField(default= timezone.now)
    CreatedBy = models.CharField(max_length = 255, null = True) 
    jwt_secret = models.UUIDField(default=uuid.uuid4)
    Department = models.CharField(max_length = 255, null = True, blank = True) 
    Team = models.CharField(max_length = 255, null = True, blank = True) 
    last_login = models.DateTimeField(auto_now = True)
    Permissions = models.CharField(max_length = 255, null = True, blank = True)

    USERNAME_FIELD = 'username'
    # REQUIRED_FIELDS = ['username']
    
    def __str__(self):
        return str(self.username)
    
    class Meta:
        db_table='users'
        managed = True
 
class BlacklistTokens(models.Model):
    token = models.CharField(max_length=500)
    user = models.ForeignKey(users, related_name="token_user", on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'login_blacklisttokens'
        managed = True
    

# class Policy(models.Model):
#     clientCode =  models.FloatField()
#     AgentNumber = models.FloatField()
#     AgentCode = models.CharField( max_length=50)
#     AgentName = models.CharField( max_length=50)
#     PolicyNumber = models.CharField(primary_key = True, max_length=50)
#     cover_start_date = models.DateField( auto_now=False, auto_now_add=False)
#     expiry_date = models.DateField(auto_now=False, auto_now_add=False)
#     TotalPremium = models.FloatField()

#     def __str__(self):
#         return PolicyNumber
#     class Meta:
#         app_label = 'ICBLDataView'
#         db_table = 'policyData'
    
    
