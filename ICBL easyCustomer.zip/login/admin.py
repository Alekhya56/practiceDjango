from django.contrib import admin
from .models import users,BlacklistTokens

# Register your models here.
admin.site.register(users)
admin.site.register(BlacklistTokens)
