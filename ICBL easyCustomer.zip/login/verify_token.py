from rest_framework.permissions import BasePermission
from rest_framework.views import APIView
from login.models import users,BlacklistTokens
from datetime import datetime
from django.conf import settings
from logging.handlers import RotatingFileHandler
import os
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'login')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=5000, backupCount= 6)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

class IsTokenValid(BasePermission):
    def has_permission(self, request, view):
        user = request.user        
        logger.info("Checking the User: %s",user.username)
        is_allowed_user = True
        try:
            token = request.auth.decode("utf-8")
            print("Token :%s",token)
            is_blackListed = BlacklistTokens.objects.get(user=user, token=token)
            if is_blackListed:
                logger.warning("This user tried to breach with the JWT Token: %s",token)
                is_allowed_user = False
        except:
            is_allowed_user = True
        # print("*******",is_allowed_user)
        return is_allowed_user