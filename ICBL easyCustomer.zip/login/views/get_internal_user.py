'''

Get all users with status of 'ACTIVE'
'''
import jwt
from login.models import users
from InAndOutBoundApp.models.Departments import Departments
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from functionalities.helpers import _ReturnError
from functionalities import defaults
from login.verify_token import IsTokenValid
from django.db.models import Q
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'login')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['GET'])
@permission_classes([IsAuthenticated, IsTokenValid ])
def GetInternalUsers(request):
    # Getting the JWT TOken to get the user info and his role
    Authorization = request.META.get("HTTP_AUTHORIZATION")
    username = request.META.get("HTTP_USERNAME")
    Authorization = Authorization.replace("Bearer","")
    decoded_token = jwt.decode(Authorization,None,None)
    logger.info(decoded_token)

    if decoded_token["role"] not in [defaults.ROLES_ADMIN]:
        logger.warning('Access Denied for Customer Rep')
        return(_ReturnError("Access Denied"))


    if decoded_token["user"] != username:
        logger.warning('Access Denied for Unauthenticate user %s',decoded_token["user"])
        return(_ReturnError("Access Denied"))

    try:
            user_s = users.objects.using('write_db').filter(~Q(Status = defaults.STATUS_DELETE)).exclude(username='django_admin').all()
            internal_users = []
            departments = Departments.objects.all()
            department_look_up = {}

            for i in departments:
                department_look_up[i.Department_id] = i.Department_Description

            for user in user_s:
                internal_users.append({
                    "Username": user.username,
                    "DisplayName": user.DisplayName,
                    "Email": user.email,
                    "Status": user.Status,
                    "PhoneNumber": user.PhoneNumber,
                    "Role": user.Role,
                    "Department":department_look_up[int(user.Department)] if user.Department is not None else None,
                    "Team":user.Team,
                    "Permissions":user.Permissions
                })

            res = {"users": internal_users}
            logger.info('Getting users from users table')
            return Response(res, status=status.HTTP_200_OK)

    except Exception as e:
        logger.exception("Can't add employer to user %s",e)        
        return(_ReturnError("Can't add employer to user",e))
