from rest_framework.decorators import api_view,permission_classes
from login.models import BlacklistTokens
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from rest_framework.response import Response
from django.conf import settings
from logging.handlers import RotatingFileHandler
import os
import logging
from login.verify_token import IsTokenValid


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'login')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

@api_view(['POST',])
@permission_classes([IsAuthenticated,IsTokenValid])
# Use this endpoint to log out all sessions for a given user.

def LogOut(request):

    logger.info("LOGGED OUT User Details : %s",request.data)
    user= request.user
    token = request.auth.decode("utf-8")
    BlacklistTokens.objects.using('write_db').get_or_create(token = token, user = user)
    return Response("user logged out",status=status.HTTP_200_OK)
