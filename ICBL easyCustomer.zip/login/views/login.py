'''

Authenticate the user with username and password.
'''
import jwt
import logging
from rest_framework_jwt.settings import api_settings
from login.models import users
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from functionalities.encryption import Encryption
from login.verify_token import IsTokenValid
from functionalities.helpers import _ReturnError, _RequestParse
from functionalities import defaults
import os
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'login')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST'])
@permission_classes([AllowAny, IsTokenValid])
def authenticate_user(request):

    username = request.data.get('username')
    password = request.data.get('password')
    ipaddress = request.data.get('Ipaddress')
    logger.info(request.data)
    parser_error= _RequestParse(username = username, password = password, Ipaddress = ipaddress)

    if(parser_error):
        logger.warning('No Username or Password is given %s:',parser_error)
        return parser_error

    logger.info("user: %s logged in on ipaddress: %s",username,ipaddress)
    password = Encryption().encrypt(password)
    # logger.info(password)

    # Fetching user data from users table
    try:
        user = users.objects.get(username=username, password=password)

        if user.Status == defaults.STATUS_INACTIVE:
            logger.warning('User is marked Inactive, Please contact Admin')
            return Response({"UserLoginError":"User Inactive, please contact Administrator"}, status=status.HTTP_422_UNPROCESSABLE_ENTITY)
        
        if user.Status == defaults.STATUS_DELETE:
            logger.warning('User is marked Deleted, Please contact Admin')
            return Response({"UserLoginError":"Deleted User, please contact Administrator"}, status=status.HTTP_422_UNPROCESSABLE_ENTITY)
    
    except Exception as e:
        logger.exception("User details not found %s:", parser_error)
        return Response({"UserLoginError":"Please enter A valid username/password"}, status=status.HTTP_422_UNPROCESSABLE_ENTITY)
    
    if user:

        from datetime import datetime
        user.last_login = datetime.now()
        user.save()
        try:

            # creating jwt token
            name = user.DisplayName
            jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
            jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER

            payload = jwt_payload_handler(user)
            payload['role']=user.Role
            payload['user']=user.username
            payload['permission'] = user.Permissions
            token = jwt.encode(payload, settings.SECRET_KEY)

            # sending user data
            user_details = {}
            user_details['email'] = user.email
            user_details['username'] = user.username
            user_details['firstname'] = name
            user_details['lastname'] = name
            user_details['role'] = user.Role
            user_details['temppass'] = bool(user.TemporaryPassword)
            user_details['token'] = token
            user_details['securityQuestion'] = "What is your Pet name ?"
            user_details['securityanswer'] = True
            user_details['timezone'] = user.TimeZone
            user_details['language'] = user.Language

            if user.Permissions:
                user_details['permissions'] = user.Permissions
            else:
                user_details['permissions'] = 'None'
            logger.info('User successfully logged In')
            return Response(user_details, status=status.HTTP_200_OK, content_type="application/json")

        except Exception as e:
            logger.exception("some error occured in login %s", e)
            return(_ReturnError("some error occured",e))
    else:
        res = {'error': 'can not authenticate with the given credentials or the account has been deactivated'}
        logger.exception("Can not authenticate with the given credentials or the account has been deactivated")
        return Response(res, status=status.HTTP_403_FORBIDDEN)