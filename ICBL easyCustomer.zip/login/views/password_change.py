'''

Update the user with new password.
'''

from login.models import users
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from functionalities.encryption import Encryption
from login.verify_token import IsTokenValid
from functionalities.helpers import _ReturnError, _RequestParse, _CheckRequestData
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'login')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)


@api_view(['POST'])
@permission_classes([IsAuthenticated,IsTokenValid])
def ChangePassword(request):

    username = request.data.get("user")
    oldPassword = request.data.get("oldPassword")
    newPassword = request.data.get("newPassword")
    parser_error =_RequestParse(username = username, oldPassword= oldPassword, newPassword= newPassword)
    logger.info("User %s Changed the password",username)

    if parser_error:
        logger.warning('No Username or Password is given')
        return parser_error

    try: 
        user = users.objects.using('write_db').get(username = username)
    except Exception as e:
        logger.exception('Error fetching the user %s',e)
        return(_ReturnError("Error fetching the user",e))

    if user.password != Encryption().encrypt(oldPassword):
        logger.warning("Old password is not correct")
        return Response({"PasswordUpdateError":"Incorrect old password"}, status=status.HTTP_422_UNPROCESSABLE_ENTITY)

    try:
        user.password = Encryption().encrypt(newPassword)
        user.TemporaryPassword = False
        user.save()
        logger.info("Password updated successfully")
        return Response("Password updated successfully")
    except Exception as e:
        logger.exception("Error updating the user's Password %s:",e)
        return Response("message: Error updating the user's Password", status= status.HTTP_422_UNPROCESSABLE_ENTITY)

