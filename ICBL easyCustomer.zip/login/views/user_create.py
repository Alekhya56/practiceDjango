'''

Creates new user and sends a mail with temporary password.
'''

from InAndOutBoundApp.models.Departments import Departments
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from login.serializers import usersSerializer
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from functionalities.encryption import Encryption
from functionalities.helpers import _RandomStringwithDigitsAndSymbols,_SendEmail
from functionalities import defaults
from login.verify_token import IsTokenValid
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'login')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST',])
@permission_classes([IsAuthenticated,IsTokenValid])
def CreateUser(request):
    try:
        user = request.data
        logger.info("New user create request is made :%s",user)
        dept = Departments.objects.filter(Department_Description = user["Department"]).first()

        if user['email'] is not None and not (user['email'].endswith(settings.EMAIL_ALLOWED)):
            logger.info('Email is not of the domain: %s',settings.EMAIL_ALLOWED)
            return Response({"message":f"Email is Invalid"}, status= status.HTTP_422_UNPROCESSABLE_ENTITY)

        user["Status"] = defaults.STATUS_ACTIVE
        password = _RandomStringwithDigitsAndSymbols()
        enc_password = Encryption().encrypt(password)
        user["Department"] = dept.Department_id if dept is not None else None
        user['password'] = enc_password
        user['TemporaryPassword']= True
        user['CreatedBy']= defaults.ROLES_ADMIN
        serializer = usersSerializer(data=user)
        serializer.status = 'APPROVED'
        serializer.is_valid(raise_exception=True)
        serializer.save()
        logger.info("User Created Successfully: %s",serializer.data)
    except Exception as e:
        logger.exception('username or email already exists %s',e)
        return Response({"message":"username or email already exists"}, status= status.HTTP_422_UNPROCESSABLE_ENTITY)
    
    message = f'<p>Dear {user["DisplayName"]}</p>' + \
            f'<p>User Name: {user["username"]}</p>' + \
            f'<p>Email: {user["email"]}</p>' + \
            f'<p>Your Account has been Created.</p>' + \
            f'<p>The temporary password is: <b style="color:red">{password}</b></p>'+\
            f'<p><a href="{settings.FRONTEND_URL}"><b>Click Here!</b></a> or open : {settings.FRONTEND_URL}</p>'  
    subject= "New Account- ICBL-Easy Customer"

    response=_SendEmail(to_address=[user["email"]],subject=subject,body=message)
    logger.info("Response of Mail sending: %s",response)
    logger.info("Mail for user creation is done.")
    return Response({"result":"Success"}, status=status.HTTP_200_OK)