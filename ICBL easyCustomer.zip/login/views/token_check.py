from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from functionalities.helpers import _ReturnError, _RequestParse, token_verify

@api_view(['POST',])
@permission_classes([AllowAny,])
def TokenCheck(request):
    Authorization = request.META.get("HTTP_AUTHORIZATION")
    print("Token Check %s",Authorization)
    print("Token Check %s",Authorization)
    user = request.data.get("user")
    parser_error = _RequestParse(Authorization = Authorization, user= user)
    if parser_error:
        return parser_error
    verified= token_verify(Authorization, user)
    if not verified:
        return(_ReturnError("Access is Denied"))
    return Response({"result": True}, status=status.HTTP_200_OK)