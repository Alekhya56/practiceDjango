'''

Sends a mail to the user with temporary password.
'''
from login.models import users
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from functionalities.encryption import Encryption
from login.verify_token import IsTokenValid
from functionalities.helpers import _RandomStringwithDigitsAndSymbols,_SendEmail, _ResponseOK, _ReturnError, _RequestParse, _CheckRequestData 
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'login')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST'])
@permission_classes([AllowAny, IsTokenValid])
def ResetPassword(request):
    try:
        request_type = request.data.get("request_type")
        username = request.data.get("username")
        # Answer = request.data.get("answer")
        email = request.data.get("Email")
        logger.info(request.data)
        parser_error= _RequestParse(request_type = request_type, username =username, Email=email )

        if parser_error:
            logger.warning('No Username or Email is given')
            return parser_error
        logger.info("User %s reset the password",username)

        try:
            user = users.objects.using('write_db').get(username=username,email=email)
        except Exception as e:
            logger.exception("User data is not available in database %s",e)
            return(_ReturnError("User data is not available in database", e))

        if not (request_type=="Email" or request_type== "Admin" \
             or request_type== "SecurityQuestion"):
            logger.warning("Allows only Email or Admin or SecurityQuestion")
            return Response({"message: request_type allows - Email or Admin or SecurityQuestion"}, status=status.HTTP_422_UNPROCESSABLE_ENTITY)
        
        if request_type=="Email":
            if user.email is None:
                logger.warning("Email Id Not available in the system, Please Contact Administrator")
                return Response({"message: Email Id Not available in the system, Please Contact Administrator"}, status=status.HTTP_422_UNPROCESSABLE_ENTITY)
        
        if request_type == "Admin":
            pass
        logger.info("Pasword reset successful")
        return _ResetPassword(user.DisplayName,user.username)
        
    except Exception as e:
        logger.exception("Some error occured reseting password %s",e)
        return(_ReturnError("Some error occured reseting password", e))

# Helper functions for clean code
def _ResetPassword(display_name,username):
    user = users.objects.using('write_db').get(username= username)
    password = _RandomStringwithDigitsAndSymbols()
    logger.info(password)
    enc_pass = Encryption().encrypt(password)
    user.password = enc_pass
    user.TemporaryPassword = True
    user.save()

    message = f'<p>Dear {display_name}</p>' + \
                f'<p>Your password has been reset.</p>' + \
                f'<p>Username: {user.username}</p>' + \
                f'<p>Email: {user.email}</p>' + \
                f'<p>The temporary password is: <b style="color:red">  {password} </b></p>' + \
                f'<p>Please log into your system as soon as possible to set your new password.</p>' +\
                f'<p><a href="{settings.FRONTEND_URL}"><b>Click Here!</b></a> or open : {settings.FRONTEND_URL}</p>'
    subject= "Reset Password- ICBL-Easy Customer"

    response=_SendEmail(to_address=[user.email],subject=subject,body=message)
    logger.info(response)
    logger.info("Mail has been sent for reset password")
    return(_ResponseOK())