from login.models import users
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from login.verify_token import IsTokenValid

from functionalities.encryption import Encryption
from functionalities.helpers import _RandomStringwithDigitsAndSymbols,_SendEmail, _ResponseOK, _ReturnError, _RequestParse, _CheckRequestData
from functionalities import defaults
import os
import logging
from datetime import datetime
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'login')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST'])
@permission_classes([IsAuthenticated,IsTokenValid])
def UpdateUser(request):
    user = request.data.get("user")
    displayname = request.data.get("displayname")
    email = request.data.get("email")
    password = request.data.get("password")
    role = request.data.get("role")
    _status = request.data.get("status")
    phonenumber = request.data.get("phonenumber")
    permission = request.data.get("Permissions")
    statuschange = bool(request.data.get("statuschange"))
    passwordchange = bool(request.data.get("passwordchange"))
    logger.info(request.data)
    parser= _RequestParse( 
        user = user,   
        email = email, 
        statuschange = statuschange, 
        passwordchange = passwordchange)
    if parser:
        logger.info("No username/email/status change/password given")
        return parser

    try:
        user= users.objects.using('write_db').get(username = user)
        
    except Exception as e:
        logger.exception("user data not found in database %s",e)
        return(_ReturnError("user data not found in database", e))
    
    user.DisplayName = displayname
    user.email = email
    user.Role = role
    user.Permissions = None if permission == '' else permission
    if statuschange:
        if _status not in [defaults.STATUS_ACTIVE,defaults.STATUS_INACTIVE,defaults.STATUS_DELETE]:
            logger.info("Status INVALID")
            return(_ReturnError("Status INVALID"))
        user.Status = _status.upper()
    
    if phonenumber is not None:
        user.phonenumber = phonenumber
    
    msgtext = None
    subject = None
    if passwordchange:
        logger.info(passwordchange)
        Random_pass = _RandomStringwithDigitsAndSymbols()
        logger.info(Random_pass)
        enc_password = Encryption().encrypt(Random_pass)
        user.password = enc_password
        user.TemporaryPassword = True
        msgtext = f'<p>Your password has been reset. The temporary password is: '+\
                    f'<b style="color:red"> {Random_pass} </b></p>' + \
                  '<p>Please log into your system as soon as possible to set your new password.</p>'
        subject = "Temporary Password - ICBL Easy Customer"
    else:
        if password is not None:
            logger.info(password)
            user.TemporaryPassword = True
            user.password = Encryption().encrypt(password)
            logger.info(password)
    try:
        user.save()
        if msgtext is not None and subject is not None:
            to_address = [user.email]
            _SendEmail(to_address,body=msgtext,subject=subject)
    except Exception as e:
        logger.exception("Cannot Update user details %s",e)
        return(_ReturnError("Cannot Update", e))
    logger.info("Successfully updated user details")
    return Response("message: Success", status = status.HTTP_200_OK)