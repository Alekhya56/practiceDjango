'''

Deactivate the user. Make user status as 'DELETE'.
'''
from login.models import users
from rest_framework.decorators import api_view,permission_classes
from rest_framework.permissions import AllowAny,IsAuthenticated
from login.verify_token import IsTokenValid
from functionalities.helpers import _ReturnError, _RequestParse, _ResponseOK
from functionalities import defaults
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'login')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST'])
@permission_classes([IsAuthenticated,IsTokenValid])
def DeleteUser(request):
    username = request.data.get("user")
    parser_error= _RequestParse(user= username)
    if(parser_error):
        logger.info("No username provided %s",parser_error)
        return parser_error
    try:
        logger.info("Requested to delete User %s",username)
        user = users.objects.using('write_db').get(username=username)
        user.Status = defaults.STATUS_DELETE
        user.save()
    except Exception as e:
        logger.exception("Error Occured deleting the user %s",e)
        return(_ReturnError("Error Occured deleting the user",e))
    logger.info("User deleted successfully")
    return(_ResponseOK())