from rest_framework import serializers
from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from InAndOutBoundApp.models.Queries import Queries
from InAndOutBoundApp.models.Searched_Customers import SearchedCustomers

class InboundCallDetailsSerializer(serializers.ModelSerializer):
    class Meta(object):
        model = InboundCallDetails
        fields = ('Inbound_Id', 'Query_Id', 'Depart_Id', 'Dept_Email','Reassigned_Depart_Id','Reassigned_Dept_Email','Version_No','Resolution_Notes','Responded_By',
                  'Last_Updated_Date','Last_Updated_By','Closed_By','Status','Follow_Up_Date','Call_Details','Remarks','Close_comment' )

class OutboundCallDetailsSerializer(serializers.ModelSerializer):
    class Meta(object):
        model = OutboundCallDetails
        fields = ('Outbound_Id','Query_Id', 'Depart_Id', 'Dept_Email', 'Reassigned_Depart_Id', 'Reassigned_Dept_Email', 'Version_No','Closed_By','Call_Details','Responded_By',
                    'Customer_Reached','Customer_Response_Id','Resolution_Notes','Last_Updated_By','Status','Follow_Up_Date','Remarks','Close_comment')

class QueriesSerializer(serializers.ModelSerializer):
    class Meta(object):
        model = Queries
        fields = ('Query_Id','Customer_Id','Call_Type','Call_Date','Call_Start_Time','Call_End_Time','Other_Request',
                  'Product_Type_Id','Request_Type_Id','Update_contact_checkbox','User_Id','User_Email_id','Priority','Complaint')

class SearchedCustomersSerializer(serializers.ModelSerializer):
    class Meta(object):
        model = SearchedCustomers
        fields = ('Customer_Id','Customer_Name','Date_Of_Birth','Id','Contact_Number','Existing_Customer','Id_Type',
                  'Contact_Type','Type_Of_Channel','Policy_Number','Searched_Customer_Id','Vehicle_Reg_No','Email',
                  'System','Fax','TeleHome','TeleWork','TelePhone')
        extra_kwargs = {'Barbados_id': {'read_only': True},}
