from django.contrib import admin
from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Customer_Response import CustomerResponse
from InAndOutBoundApp.models.Departments import Departments
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from InAndOutBoundApp.models.Products import Products
from InAndOutBoundApp.models.Queries import Queries
from InAndOutBoundApp.models.Requests import Requests
from InAndOutBoundApp.models.Searched_Customers import SearchedCustomers
from InAndOutBoundApp.models.Type_Of_Channel import TypeOfChannel

# Register your models here.

admin.site.register(InboundCallDetails)
admin.site.register(CustomerResponse)
admin.site.register(Departments)
admin.site.register(OutboundCallDetails)
admin.site.register(Products)
admin.site.register(Queries)
admin.site.register(SearchedCustomers)
admin.site.register(Requests)
admin.site.register(TypeOfChannel)

