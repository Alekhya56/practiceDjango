from django.db import models
import django
import datetime
import uuid

class SearchedCustomers(models.Model):
    Customer_Id = models.AutoField(primary_key = True, max_length = 250, unique = True)
    Searched_Customer_Id = models.IntegerField(default=0)
    Customer_Name = models.CharField(max_length = 250, null = True, blank=True)
    Date_Of_Birth = models.DateField(max_length = 250, null = True, blank=True)
    Id_Type = models.CharField(max_length = 250, null = True, blank=True)
    Id = models.CharField(max_length = 250, null = True, blank=True)
    Contact_Type = models.CharField(max_length = 250, null = True, blank=True)
    Type_Of_Channel = models.CharField(max_length = 250, null = True, blank=True)
    Contact_Number = models.CharField(max_length = 250, null = True, blank=True)
    Existing_Customer = models.CharField(max_length = 250, null = True, blank=True)
    Policy_Number = models.CharField(max_length = 250, null = True, blank=True)
    Vehicle_Reg_No = models.CharField(max_length = 250, null = True, blank=True)
    Email = models.CharField(max_length = 250, null = True, blank=True)
    System = models.CharField(max_length = 250, null = True, blank=True)
    TeleHome = models.CharField(max_length = 250, null = True, blank=True)
    TeleWork = models.CharField(max_length=250, null=True, blank=True)
    Fax = models.CharField(max_length=250, null=True, blank=True)
    TelePhone = models.CharField(max_length=250, null=True, blank=True)
    Added = models.DateTimeField(auto_now_add = True)
    
    class Meta:
        managed = True
    
    def __str__(self):
        return str(self.Customer_Id)
