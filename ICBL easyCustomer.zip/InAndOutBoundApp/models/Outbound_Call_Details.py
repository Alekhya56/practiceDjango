from InAndOutBoundApp.models.Queries import Queries
from InAndOutBoundApp.models.Departments import Departments
from django.db import models
import django
import datetime
import uuid

# def Get_Outbound_Id():
#     '''
#     Returns the next default value for the `Inbound_id` field, starts with 
#     1001
#     '''
#     try:
#         outbound_id = OutboundCallDetails.objects.latest('added')
#         print((outbound_id.Outbound_id),"*******************")
#         ID = outbound_id.Outbound_id
#         c = ID.split("-")
#         return str(c[0]+"-"+str(int(c[1]) + 1))
#     except:
#         return str("OUTB-1")

class OutboundCallDetails(models.Model):
    Outbound_Id = models.AutoField(primary_key=True, unique = True)
    Query_Id = models.ForeignKey(Queries, related_name="Outbound_Query_Id", on_delete=models.CASCADE)
    Depart_Id = models.CharField(max_length = 250, null = True, blank=True)
    Dept_Email = models.TextField(max_length = 250, null = True, blank=True)
    Reassigned_Depart_Id = models.CharField(max_length = 250, null = True)
    Reassigned_Dept_Email = models.TextField(max_length = 250, null = True)
    Call_Details = models.TextField(null = True, blank=True)
    Customer_Reached = models.CharField(max_length = 250, null = True, blank=True)
    Customer_Response_Id = models.CharField(max_length = 250, null = True, blank=True)
    Last_Updated_Date = models.DateField(auto_now=True, auto_now_add=False)
    Last_Updated_By = models.CharField(max_length = 250, null = True, blank=True)
    Version_No = models.CharField(max_length = 250, null = True, blank=True)
    Responded_By = models.TextField(null = True, blank=True)
    Remarks = models.TextField(null = True, blank=True)
    Resolution_Notes = models.TextField(null = True, blank=True)
    Closed_By = models.CharField(max_length = 250, null = True, blank=True)
    Status = models.CharField(max_length = 250, null = True, blank=True)
    Follow_Up_Date = models.DateField(auto_now=False, null = True, blank=True)
    Added = models.DateTimeField(auto_now_add = True)
    Close_comment = models.TextField(null=True, blank=True)

    
    class Meta:
        managed = True

    def __str__(self):
        return f"{self.Outbound_Id}"