from django.db import models
from InAndOutBoundApp.models.Queries import Queries
from InAndOutBoundApp.models.Departments import Departments
import datetime
import uuid


class InboundCallDetails(models.Model):
    Inbound_Id = models.AutoField(primary_key=True, unique = True)
    Query_Id = models.ForeignKey(Queries, related_name="Inbound_Query_Id", on_delete=models.CASCADE)
    Depart_Id = models.CharField(max_length = 250, null = True, blank=True)
    Dept_Email = models.TextField(max_length = 250, null = True, blank=True)
    Reassigned_Depart_Id = models.CharField(max_length = 250, null = True, blank=True)
    Reassigned_Dept_Email = models.TextField(max_length = 250, null = True, blank=True)
    Call_Details = models.TextField(null = True, blank=True)
    Last_Updated_Date = models.DateField(auto_now=True, auto_now_add=False)
    Last_Updated_By = models.CharField(max_length = 250, null = True, blank=True) 
    Version_No = models.CharField(max_length = 250, null = True, blank=True)
    Responded_By = models.TextField(null = True, blank=True)
    Remarks = models.TextField(null = True, blank=True)
    Resolution_Notes = models.TextField(null = True, blank=True)
    Closed_By = models.CharField(max_length = 250, null = True, blank=True)
    Status = models.CharField(max_length = 250, null = True, blank=True)
    Follow_Up_Date = models.DateField(auto_now=False, null = True, blank=True)
    Added = models.DateTimeField(auto_now_add = True)
    Close_comment = models.TextField(null=True, blank=True)


    class Meta:
        managed = True

    def __str__(self):
        return f"{self.Inbound_Id}"

    def get_id(self):
        return self.Inbound_Id