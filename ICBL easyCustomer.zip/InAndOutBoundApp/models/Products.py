from django.db import models
# import datetime
# import uuid

class Products(models.Model):
    Product_id = models.AutoField(primary_key = True, unique = True)
    Product_Description = models.CharField(max_length = 250, unique = True)
    Status = models.CharField(max_length=250, unique=False, default='ACTIVE')

    class Meta:
        managed = True
    
    def __str__(self):
        return f"{self.Product_Description}"