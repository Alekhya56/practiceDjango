from django.db import models


class Requests(models.Model):
    Request_Id = models.AutoField(primary_key = True , unique = True)
    Request_Description = models.CharField(max_length = 250, unique = True)
    Status = models.CharField(max_length=250, unique=False, default='ACTIVE')

    def __str__(self):
        return f"{self.Request_Description}"