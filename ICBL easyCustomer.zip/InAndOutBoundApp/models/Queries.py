from InAndOutBoundApp.models.Searched_Customers import SearchedCustomers
from InAndOutBoundApp.models.Products import Products
from InAndOutBoundApp.models.Requests import Requests
from login.models import users
from django.db import models
import datetime
import uuid
    

class Queries(models.Model):
    Query_Id = models.AutoField(primary_key = True, unique = True)
    Customer_Id = models.ForeignKey(SearchedCustomers, related_name="Query_Customer_Id", on_delete=models.CASCADE)
    Call_Type = models.CharField(max_length = 250, null = True, blank=True)
    Call_Date = models.DateField(auto_now=False, null = True, blank=True)
    Call_Start_Time  = models.DateTimeField(null = True, blank=True)
    Call_End_Time  = models.DateTimeField(null = True, blank=True) 
    Product_Type_Id = models.CharField(max_length = 250, null = True, blank=True)
    Request_Type_Id = models.CharField(max_length = 250, null = True, blank=True)
    Update_contact_checkbox = models.BooleanField(default=False)
    User_Id = models.ForeignKey(users, related_name="Query_User_Id", on_delete=models.CASCADE)
    User_Email_id = models.CharField(max_length = 250, null = True, blank=True)
    Priority = models.CharField(max_length = 250, null = True, blank=True)
    Other_Request = models.CharField(max_length = 250, null = True, blank=True)
    Complaint = models.BooleanField(default=False)
    Added = models.DateTimeField(auto_now_add = True)

    class Meta:
        managed = True

    # def __str__(self):
    #     return self.Query_Id
