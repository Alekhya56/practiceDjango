from django.db import models
import datetime
import uuid
      

class CustomerResponse(models.Model):
    Customer_Response_Id = models.AutoField(primary_key=True, unique = True)
    Response_Description = models.CharField(max_length = 250, unique = True)
    Status =  models.CharField(max_length = 250, unique = False, default='ACTIVE')
    Response_option = models.CharField(max_length = 250, unique = False,null=False)

    class Meta:
        managed = True

    def __str__(self):
        return f"{self.Response_Description}" 