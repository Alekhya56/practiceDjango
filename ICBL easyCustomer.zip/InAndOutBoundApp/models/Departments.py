from django.db import models
import datetime
import uuid


class Departments(models.Model):
    Department_id = models.AutoField(primary_key=True, unique = True)
    Department_Description = models.CharField(max_length = 250, unique = True)
    Dept_Email_id = models.CharField(max_length = 250, unique = False)
    Status = models.CharField(max_length=250, unique=False,default='ACTIVE')
    
    class Meta:
        managed = True
    
    def __str__(self):
        return f"{self.Department_Description}"
    def get_values(self):
        dept_info = {}
        dept_info['Department_id'] = self.Department_id
        dept_info['Department_Description'] = self.Department_Description
        dept_info['Dept_Email_id'] = self.Dept_Email_id
        return dept_info