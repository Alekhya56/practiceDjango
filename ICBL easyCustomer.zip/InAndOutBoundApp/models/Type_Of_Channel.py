from django.db import models
import datetime
import uuid


class TypeOfChannel(models.Model):
    Channel_Id = models.AutoField(primary_key=True, unique = True)
    Channel_Description = models.CharField(max_length = 250, unique = True)
    Status = models.CharField(max_length=250, unique=False, default='ACTIVE')

    class Meta:
        managed = True

    def __str__(self):
        return f"{self.Channel_Description}" 