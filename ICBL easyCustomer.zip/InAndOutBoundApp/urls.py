from django.urls import path
from InAndOutBoundApp.views.Create_inquiry import Searched_Customers_Transaction
from InAndOutBoundApp.views.Last_Correspondence import LastCorrespondence
from InAndOutBoundApp.views.All_inquiries import All_Inquiries
from InAndOutBoundApp.views.Callback_enquiries import Callback_Enquiries
from InAndOutBoundApp.views.Referred_inquiries import Referred_Inquiries
from InAndOutBoundApp.views.Complaints import Complaints
from InAndOutBoundApp.views.GetInfo import GetInfo
from InAndOutBoundApp.views.close_comments import Close_comment
from InAndOutBoundApp.views.Refer_inquiry_versions import Refer_Inquiry_Versions
from InAndOutBoundApp.views.get_lookup_table_values import get_table_values
urlpatterns = [
    path('queries/inquiry',Searched_Customers_Transaction),
    path('queries/all_inquiries/<int:page_ind>/<int:items_size>/<int:len>',All_Inquiries),
    path('queries/last',LastCorrespondence),
    path('queries/callback/<int:page_ind>/<int:items_size>/<int:len>',Callback_Enquiries),
    path('queries/complaints/<int:page_ind>/<int:items_size>/<int:len>',Complaints),
    path('queries/referred_inquiries/<int:page_ind>/<int:items_size>/<int:len>',Referred_Inquiries),
    path('queries/getinfo',GetInfo),
    path('queries/close_comments',Close_comment),
    path('queries/refer_inquiry_versions',Refer_Inquiry_Versions),
    path('queries/get_lookup_values',get_table_values),
    # path('queries/sort_data',Sort_data),
]