from django.apps import AppConfig


class InandoutboundappConfig(AppConfig):
    name = 'InAndOutBoundApp'
