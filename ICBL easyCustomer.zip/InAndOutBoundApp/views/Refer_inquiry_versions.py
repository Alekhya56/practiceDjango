from login.models import users
from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Departments import Departments
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from InAndOutBoundApp.models.Products import Products
from InAndOutBoundApp.models.Requests import Requests
from InAndOutBoundApp.serializers import OutboundCallDetailsSerializer
from InAndOutBoundApp.serializers import InboundCallDetailsSerializer
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from functionalities.helpers import _ReturnError
from InAndOutBoundApp.views.Create_inquiry import SendMail
# logging imports
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'InAndOutBound')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST',])
@permission_classes([IsAuthenticated,])
# @permission_classes([AllowAny,])
def Refer_Inquiry_Versions(request):
    logger.debug("Refer_Inquiry **** Refer_Inquiry_versions")
    try:
        inb=[]
        otb=[]
        info = None
        transaction = request.data
        logger.info("Data :%s",transaction)
        dept_look_id = {}
        dept_look_up = {}
        departments = Departments.objects.all()
        # Creating a hash table for DEpartments
        for department in departments:
            dept_look_up[department.Department_Description] = [department.Department_id,
                                                               department.Dept_Email_id]
            dept_look_id[department.Department_id] = department.Department_Description
        dept_list = transaction.get('dept', None)
        dept_id_list = []
        dept_email = []
        # Here Department IDs are taken from lookuptable into dept_id_list
        for i in dept_list:
            dept_id_list.append(str(dept_look_up[i][0]))
            if i != "Other":
                # Here only the departments selected (except others) thier emails are mapped from look up table
                dept_email.append(dept_look_up[i][1])

        Depart_Ids = ", ".join(dept_id_list)
        # mail['Dept_Email'] = dept_email
        # Here the additional Emails provided **only when others is selected in FrontEnd
        # They are added to dept_email
        if "Other" in dept_list:
            other = ""
            other_email_list = request.data.get('other_dept_email', [])
            # customer_transaction['Dept_Email'] = ", ".join(other_email_list)
            dept_email = dept_email + (other_email_list)

        if transaction['inquirytype'] == "Inbound":
            inb = InboundCallDetails.objects.get(Inbound_Id = transaction['inq_id'])
            info = inb
            if transaction['action'] == 'Save':
                inb.Resolution_Notes = request.data['Resolution_Notes']
                inb.Responded_By = request.data['Responded_By']
                inb.Last_Updated_Date = request.data['Last_Updated_Date']
                inb.Last_Updated_By = request.data['Last_Updated_By']
                inb.Remarks = request.data['Remarks']
                if transaction['dept']:
                        inb.Reassigned_Dept_Email = dept_email
                        inb.Reassigned_Depart_Id = Depart_Ids
                inb.save()

            elif request.data['action'] == 'Close':
                if inb.Dept_Email:
                    transaction['Dept_Email'] = inb.Dept_Email
                transaction['Depart_Id'] = inb.Depart_Id
                transaction['Query_Id'] = inb.Query_Id.Query_Id
                transaction['Call_Details'] = inb.Call_Details
                transaction['Version_No'] = int(inb.Version_No) + 1
                transaction['Status'] = 'closed'
                transaction['Last_Updated_Date'] = request.data['Last_Updated_Date']
                transaction['Closed_By'] = request.data['Closed_By']
                transaction['Last_Updated_By'] = request.data['Last_Updated_By']
                if transaction['dept']:
                    transaction['Reassigned_Dept_Email'] = dept_email
                    transaction['Reassigned_Depart_Id'] = Depart_Ids
                serializer = InboundCallDetailsSerializer(data=transaction)
                serializer.is_valid(raise_exception=True)
                serializer.save()
                
        elif transaction['inquirytype'] == "Outbound":
            otb = OutboundCallDetails.objects.get(Outbound_Id = transaction['inq_id'])
            info = otb
            if request.data['action'] == 'Save':
                otb.Resolution_Notes = request.data['Resolution_Notes']
                otb.Responded_By = request.data['Responded_By']
                otb.Last_Updated_Date = request.data['Last_Updated_Date']
                otb.Last_Updated_By = request.data['Last_Updated_By']
                otb.Remarks = request.data['Remarks']
                if transaction['dept']:
                    otb.Reassigned_Dept_Email = dept_email
                    otb.Reassigned_Depart_Id = Depart_Ids
                otb.save()
                
            elif request.data['action'] == 'Close':
                transaction['Version_No'] = int(otb.Version_No) + 1
                transaction['Status'] = 'closed'
                transaction['Last_Updated_By'] = request.data['Last_Updated_By']
                transaction['Last_Updated_Date'] = request.data['Last_Updated_Date']
                transaction['Customer_Reached'] = otb.Customer_Reached
                transaction['Customer_Response_Id'] = otb.Customer_Response_Id
                transaction['Closed_By'] = request.data['Closed_By']
                transaction['Depart_Id'] = otb.Depart_Id
                if transaction['dept']:
                    transaction['Reassigned_Dept_Email'] = dept_email
                    transaction['Reassigned_Depart_Id'] = Depart_Ids

                if otb.Dept_Email:
                    transaction['Dept_Email'] = otb.Dept_Email
                transaction['Call_Details'] = otb.Call_Details
                transaction['Query_Id'] = otb.Query_Id.Query_Id
            
                serializer = OutboundCallDetailsSerializer(data=transaction)
                serializer.is_valid(raise_exception=True)
                serializer.save()
        contact_numberfor_old = info.Query_Id.Customer_Id.Contact_Number
        id = info.Query_Id.Customer_Id
        m = []
        if id.TeleHome:
            m.append(id.TeleHome)
        if id.TelePhone:
            m.append(id.TelePhone)
        if id.TeleWork:
            m.append(id.TeleWork)
        if id.Fax:
            m.append(id.Fax)
        phone = "|".join(m)
        logger.info(m)
        # Sending mail for the closed Complaint
        if request.data['action'] == 'Close' and request.data['Complaint'] is True and info is not None:
            data = {
                    'request_type' : Requests.objects.get(Request_Id = int(info.Query_Id.Request_Type_Id)).Request_Description,
                    'product' : Products.objects.get(Product_id = int(info.Query_Id.Product_Type_Id)).Product_Description,
                    'Query' : request.data['inquirytype'],
                    'Customer_Name' : info.Query_Id.Customer_Id.Customer_Name,
                    'email' : info.Query_Id.Customer_Id.Email,
                    'dept_name' : [],
                    'Phone' : contact_numberfor_old if contact_numberfor_old else phone,
                    'inquiry_details' : info.Call_Details,
                    'Vehicle_No' : info.Query_Id.Customer_Id.Vehicle_Reg_No,
                    'Policy_No' : info.Query_Id.Customer_Id.Policy_Number,
                    'Complaint' : request.data['Complaint'],
                    'Complaint_Email' : [str(settings.COMPLAINTS_EMAIL)],
                    'Reassign': False,
                    'Reassign_Dept_Email': [],
                    'csr_email' : [info.Query_Id.User_Email_id],
                    'Status': "closed",
                    'username' : users.objects.get(UserID = int(info.Query_Id.User_Id.UserID)).DisplayName,
                    'Dept_Email' : [],
                    'INQ_Id' : info.Query_Id_id,
                    'Update_contact': False,
                     'update_dept_name': ''
                    }
            logger.info("mail Data :%s",data)
            SendMail(data)

        if transaction['dept'] and transaction['editable'] is True:
            data = {
                'request_type': Requests.objects.get(Request_Id=int(info.Query_Id.Request_Type_Id)).Request_Description,
                'product': Products.objects.get(Product_id=int(info.Query_Id.Product_Type_Id)).Product_Description,
                'Query': request.data['inquirytype'],
                'Customer_Name': info.Query_Id.Customer_Id.Customer_Name,
                'email': info.Query_Id.Customer_Id.Email,
                'dept_name': [],
                'Phone': contact_numberfor_old if contact_numberfor_old else phone,
                'inquiry_details': info.Call_Details,
                'Vehicle_No': info.Query_Id.Customer_Id.Vehicle_Reg_No,
                'Policy_No': info.Query_Id.Customer_Id.Policy_Number,
                'Reassign': True,
                'Reassign_Dept_Email': dept_email,
                'Complaint': False,
                'Complaint_Email': [],
                'csr_email': [info.Query_Id.User_Email_id],
                'Status': info.Status,
                'username': users.objects.get(UserID=int(info.Query_Id.User_Id.UserID)).DisplayName,
                'user_dapartment': dept_look_id[int(info.Query_Id.User_Id.Department)],
                'Dept_Email': [],
                'INQ_Id': info.Query_Id_id,
                'Update_contact': False,
                'update_dept_name': ''
            }
            logger.info("mail Data :%s", data)
            SendMail(data)

        return Response ({"Referred_inquiry":"success"},status=status.HTTP_200_OK)
    except Exception as e:
        logger.exception("Could not create  or save transaction for refer details %s",e)
        return(_ReturnError("Could not create  or save transaction for refer details",e))
