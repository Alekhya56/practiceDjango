from login.models import users
from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Customer_Response import CustomerResponse
from InAndOutBoundApp.models.Departments import Departments
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from InAndOutBoundApp.models.Products import Products
from InAndOutBoundApp.models.Requests import Requests
from InAndOutBoundApp.models.Type_Of_Channel import TypeOfChannel
from ExtraApp.views.report_manager import getdepartments
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from functionalities.helpers import _ReturnError
# logging imports
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'InAndOutBound')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['POST',])
@permission_classes([IsAuthenticated,])
def GetInfo(request):
    Id = request.data.get("id",None)
    type_of_request = request.data.get("typeofinquiry",None)
    info = None
    if Id is not None:
        if type_of_request == "Inbound":
            info = InboundCallDetails.objects.get(Inbound_Id = Id)
        if type_of_request == "Outbound":
            info = OutboundCallDetails.objects.get(Outbound_Id = Id)

        if info is not None:
            departments = Departments.objects.all()
            departments_lookup={}
            for d in departments:
                departments_lookup[d.Department_id] = d.Department_Description
            
            Department = getdepartments(info.Depart_Id,departments_lookup)
            Product = Products.objects.get(Product_id = info.Query_Id.Product_Type_Id).Product_Description
            Request = Requests.objects.get(Request_Id = info.Query_Id.Request_Type_Id).Request_Description
            Channel = TypeOfChannel.objects.get(Channel_Id = info.Query_Id.Customer_Id.Type_Of_Channel).Channel_Description
            Department_Email = info.Dept_Email
            result = {
                "TypeOfInquiry":"Inbound" if type_of_request == "Inbound" else "Outbound",
                "Name":info.Query_Id.Customer_Id.Customer_Name,
                "DateOfBirth":info.Query_Id.Customer_Id.Date_Of_Birth,
                "TeleHome":info.Query_Id.Customer_Id.Contact_Number if info.Query_Id.Customer_Id.Contact_Number else info.Query_Id.Customer_Id.TeleHome,
                "TeleWork": info.Query_Id.Customer_Id.TeleWork,
                "TelePhone": info.Query_Id.Customer_Id.TelePhone,
                "Fax": info.Query_Id.Customer_Id.Fax,
                "Type_Of_Channel":Channel,
                "PolicyNumber":info.Query_Id.Customer_Id.Policy_Number,
                "Id_Type":info.Query_Id.Customer_Id.Id_Type,
                "Id":info.Query_Id.Customer_Id.Id,
                "Email":info.Query_Id.Customer_Id.Email,
                "VehicleRegNo":info.Query_Id.Customer_Id.Vehicle_Reg_No,
                "TypeOfRequest":Request,
                "OtherRequest": info.Query_Id.Other_Request,
                "TypeOfProduct":Product,
                "TypeOfDepartment": Department,
                "Remarks": info.Remarks,
                "DepartmentEmail": Department_Email,
                "DetailsOfCall": info.Call_Details,
                "Notes": info.Resolution_Notes,
                "FollowUpDate": info.Follow_Up_Date,
                "Priority": info.Query_Id.Priority,
                "ExistingCustomer":info.Query_Id.Customer_Id.Existing_Customer,
                "Complaints":info.Query_Id.Complaint
            }
            if type_of_request == "Outbound":
                result["CustomerReached"] = info.Customer_Reached
                result["CustomerResponse"] = CustomerResponse.objects.get(Customer_Response_Id = info.Customer_Response_Id).Response_Description

            return Response({"info":result}, status=status.HTTP_200_OK, content_type="application/json")
        return Response({"info":[]}, status=status.HTTP_200_OK, content_type="application/json")
    logger.info("Id Cannot be None")
    return _ReturnError("Id Cannot be None")