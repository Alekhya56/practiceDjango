from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from django.db.models import Q, Max
from InAndOutBoundApp.models.Queries import Queries
from InAndOutBoundApp.models.Requests import Requests
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
from rest_framework import status
from functionalities.helpers import _ReturnError
# logging imports
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'InAndOutBound')
file_handler = RotatingFileHandler(filename + '/' + os.path.basename(__file__).replace('.py', '') + '.log',
                                   maxBytes=1000000, backupCount=6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)


@api_view(['POST', ])
@permission_classes([IsAuthenticated, ])
def LastCorrespondence(request):
    result = []
    Filter = {}

    QueryFilters = {
        "name": "Customer_Id__Customer_Name__contains",
        "phone": "Customer_Id__Contact_Number__contains",
        "barbadosid": "Customer_Id__Id__contains",
        "dateofbirth": "Customer_Id__Date_Of_Birth__contains",
        "email": "Customer_Id__Customer_Email__contains",
        "vehicleregno": "Customer_Id__Date_Of_Birth",
        'policyno': "Customer_Id__Policy_Number"
    }
    try:
        for i in request.data:
            if request.data[i] is not None and request.data[i] != "":
                if i in ['phone', 'barbadosid', 'email', 'vehicleregno', 'policyno']:
                    continue
                Filter[QueryFilters[i]] = request.data[i]
        if len(Filter):
            try:
                queries = Queries.objects
                queries = queries.filter(**Filter)
                queries = queries.filter(Q(Inbound_Query_Id__isnull=False) | Q(Outbound_Query_Id__isnull=False)).order_by("-Query_Id").select_related().annotate(inmax=Max('Inbound_Query_Id'),outmax=Max('Outbound_Query_Id'))
            except Exception as e:
                logger.exception("Error getting the data %s", e)
                return _ReturnError("Error getting the data", e)
            for i in queries:
                Id = None
                requests = None
                close_date = None
                if i.Call_Type == 'Inbound' and i.inmax is not None:
                    customer = InboundCallDetails.objects.filter(Inbound_Id=i.inmax).first()
                    if customer.Status == "closed":
                        close_date = (customer.Last_Updated_Date - customer.Query_Id.Call_Date).days
                    Request_Type_Id = customer.Query_Id.Request_Type_Id
                    print(Request_Type_Id)
                    if Request_Type_Id:
                        requests = Requests.objects.get(Request_Id=Request_Type_Id)
                    result.append({
                            'Call_Date': customer.Query_Id.Call_Date,
                            'Customer_Name': customer.Query_Id.Customer_Id.Customer_Name,
                            'Type_Of_Inquiry': requests.Request_Description if requests else None,
                            'Details_Call': customer.Call_Details,
                            'Last_Updated_By': customer.Last_Updated_By,
                            'Resolution_Notes': customer.Resolution_Notes,
                            'Status': customer.Status,
                            'Policy_No': customer.Query_Id.Customer_Id.Policy_Number,
                            'Task_Id': customer.Query_Id_id,
                            'Closed_Days': close_date,
                        })

                elif i.Call_Type == 'Outbound' and i.outmax is not None:
                    customer = OutboundCallDetails.objects.filter(Outbound_Id=i.outmax).first()
                    close_date = None
                    requests = None
                    if customer.Status == "closed":
                        print((customer.Last_Updated_Date - customer.Query_Id.Call_Date).days)
                        close_date = (customer.Last_Updated_Date - customer.Query_Id.Call_Date).days
                    Request_Type_Id = customer.Query_Id.Request_Type_Id
                    if Request_Type_Id:
                        requests = Requests.objects.get(Request_Id=Request_Type_Id)
                    result.append({
                        'Call_Date': customer.Query_Id.Call_Date,
                        'Customer_Name': customer.Query_Id.Customer_Id.Customer_Name,
                        'Type_Of_Inquiry': requests.Request_Description if requests else None,
                        'Details_Call': customer.Call_Details,
                        'Last_Updated_By': customer.Last_Updated_By,
                        'Resolution_Notes': customer.Resolution_Notes,
                        'Status': customer.Status,
                        'Policy_No': customer.Query_Id.Customer_Id.Policy_Number,
                        'Task_Id': customer.Query_Id_id,
                        'Closed_Days': close_date,
                    })
    except Exception as e:
        logger.exception("Unable to fetch user detials %s", e)
    logger.info(result)
    return Response({"Clients": result}, status=status.HTTP_200_OK, content_type="application/json")
