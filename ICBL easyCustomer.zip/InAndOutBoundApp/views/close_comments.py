from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Departments import Departments
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from InAndOutBoundApp.serializers import OutboundCallDetailsSerializer
from InAndOutBoundApp.serializers import InboundCallDetailsSerializer
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
from rest_framework import status
from functionalities.helpers import _ReturnError

# logging imports
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'InAndOutBound')
file_handler = RotatingFileHandler(filename + '/' + os.path.basename(__file__).replace('.py', '') + '.log',
                                   maxBytes=1000000, backupCount=6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)


@api_view(['POST', ])
@permission_classes([IsAuthenticated, ])
def Close_comment(request):
    try:
        transaction = request.data
        logger.info("Data :%s", transaction)

        depts = Departments.objects.all()
        dept_look_up = {}
        for department in depts:
            dept_look_up[department.Department_Description] = [department.Department_id]

        if transaction['Type_Of_Inquiry'] == "Inbound":
                inb = InboundCallDetails.objects.get(Inbound_Id=transaction['ID'])
                logger.info(inb)
                if inb.Dept_Email:
                    transaction['Dept_Email'] = inb.Dept_Email
                transaction['Depart_Id'] = inb.Depart_Id
                transaction['Query_Id'] = inb.Query_Id.Query_Id
                transaction['Call_Details'] = inb.Call_Details
                transaction['Version_No'] = int(inb.Version_No) + 1
                transaction['Status'] = 'closed'
                transaction['Last_Updated_Date'] = request.data['Last_Updated_Date']
                transaction['Closed_By'] = request.data['Closed_By']
                transaction['Last_Updated_By'] = request.data['Last_Updated_By']
                transaction['Close_comment'] = request.data['Close_Comment']
                serializer = InboundCallDetailsSerializer(data=transaction)
                serializer.is_valid(raise_exception=True)
                serializer.save()

        elif transaction['Type_Of_Inquiry'] == "Outbound":
                otb = OutboundCallDetails.objects.get(Outbound_Id=transaction['ID'])
                logger.info(otb)
                transaction['Version_No'] = int(otb.Version_No) + 1
                transaction['Status'] = 'closed'
                transaction['Last_Updated_By'] = request.data['Last_Updated_By']
                transaction['Last_Updated_Date'] = request.data['Last_Updated_Date']
                transaction['Customer_Reached'] = otb.Customer_Reached
                transaction['Customer_Response_Id'] = otb.Customer_Response_Id
                transaction['Closed_By'] = request.data['Closed_By']
                transaction['Depart_Id'] = otb.Depart_Id
                transaction['Close_comment'] = request.data['Close_Comment']
                transaction['Call_Details'] = otb.Call_Details
                transaction['Query_Id'] = otb.Query_Id.Query_Id

                serializer = OutboundCallDetailsSerializer(data=transaction)
                serializer.is_valid(raise_exception=True)
                serializer.save()

        return Response({"Close Comments": "success"}, status=status.HTTP_200_OK)
    except Exception as e:
        logger.exception("Could not create  or save transaction for close comments details %s", e)
        return (_ReturnError("Could not create  or save transaction for close comments details", e))
