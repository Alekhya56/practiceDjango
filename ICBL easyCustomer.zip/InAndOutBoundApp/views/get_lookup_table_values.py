from InAndOutBoundApp.models.Customer_Response import CustomerResponse
from InAndOutBoundApp.models.Departments import Departments
from InAndOutBoundApp.models.Products import Products
from InAndOutBoundApp.models.Requests import Requests
from InAndOutBoundApp.models.Type_Of_Channel import TypeOfChannel
from rest_framework.decorators import api_view,permission_classes
from rest_framework.permissions import IsAuthenticated
from django.db.models import Q
import os
import logging
from rest_framework.response import Response
from rest_framework import status
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'InAndOutBound')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)
@api_view(['POST','GET'])
@permission_classes([IsAuthenticated,])
def get_table_values(request):
    departments = Departments.objects.filter(Q(Status='ACTIVE')).all()
    products = Products.objects.filter(Q(Status='ACTIVE')).all()
    requests = Requests.objects.filter(Q(Status='ACTIVE')).all()
    channels = TypeOfChannel.objects.filter(Q(Status='ACTIVE')).all()
    customer_response_reached = CustomerResponse.objects.filter(Q(Status='ACTIVE') & Q(Response_option='Reached')).all()
    customer_response_unreached = CustomerResponse.objects.filter(Q(Status='ACTIVE') & Q(Response_option='UnReached')).all()
    products_lookup = {}
    requests_lookup = {}
    channel_lookup = {}
    customer_response_lookup_no = {}
    customer_response_lookup_yes = {}
    departments_lookup = {}
    departments_list = []
    products_list = []
    requests_list = []
    customer_response_yes_list = []
    customer_response_no_list = []
    channel_list = []
    for d in departments:
        departments_list.append(d.Department_Description)
    for p in products:
        products_list.append(p.Product_Description)
    for r in requests:
        requests_list.append(r.Request_Description)
    for c in channels:
        channel_list.append(c.Channel_Description)
    for cr in customer_response_unreached:
            customer_response_no_list.append(cr.Response_Description)
    for cr in customer_response_reached:
            customer_response_yes_list.append(cr.Response_Description)
    departments_list.sort()
    products_list.sort()
    requests_list.sort()
    channel_list.sort()
    customer_response_no_list.sort()
    customer_response_yes_list.sort()
    for indx,d in enumerate(departments_list):
        departments_lookup[indx] = d
    for indx,p in enumerate(products_list):
        products_lookup[indx] = p
    for indx,r in enumerate(requests_list):
        requests_lookup[indx] = r
    for indx,c in enumerate(channel_list):
        channel_lookup[indx] = c
    for indx,cr in enumerate(customer_response_yes_list):
        customer_response_lookup_yes[indx] = cr
    for indx,cr in enumerate(customer_response_no_list):
        customer_response_lookup_no[indx] = cr
    return Response({"Departments":departments_lookup,'Products':products_lookup,
                     "Type_of_channel":channel_lookup,'requests':requests_lookup
                        ,'customer_response_yes':customer_response_lookup_yes,
                      'customer_response_no':customer_response_lookup_no,
                     },
                    status=status.HTTP_200_OK, content_type="application/json")