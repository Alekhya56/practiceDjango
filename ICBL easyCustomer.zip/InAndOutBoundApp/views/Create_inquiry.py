from SSPClientsApp.models.clients import Clients
from SSPClientsApp.models.clients_contacts import ClientContacts
from WinClientsApp.models.win_clients_contact import WinClientsContact
from login.models import users
from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Customer_Response import CustomerResponse
from InAndOutBoundApp.models.Departments import Departments
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from InAndOutBoundApp.models.Products import Products
from InAndOutBoundApp.models.Requests import Requests
from InAndOutBoundApp.models.Type_Of_Channel import TypeOfChannel
from InAndOutBoundApp.serializers import SearchedCustomersSerializer
from InAndOutBoundApp.serializers import QueriesSerializer
from InAndOutBoundApp.serializers import OutboundCallDetailsSerializer
from InAndOutBoundApp.serializers import InboundCallDetailsSerializer
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
from rest_framework import status
import datetime
from functionalities.helpers import _SendEmail, _ReturnError
# logging imports
import os
import logging
from datetime import datetime
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'InAndOutBound')
file_handler = RotatingFileHandler(filename + '/' + os.path.basename(__file__).replace('.py', '') + '.log',
                                   maxBytes=1000000, backupCount=6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)


@api_view(['POST', ])
@permission_classes([AllowAny, ])
def Searched_Customers_Transaction(request):

    # ID can be in/outbound id
    other_Dept_Email = None
    ID = request.data.get('inquiryid', None)

    # Changing the values from front end as per our need 
    if request.data.get('System', None) is not None and request.data.get('System', None) != "":
        request.data['System'] = request.data['System'].replace("; System: ", "")

    if request.data.get('Complaint', None) is None:
        request.data['Complaint'] = False

    if request.data.get('Status', None) is not None and request.data.get('Status', None) != "":
        if request.data['Status'] == "refer":
            request.data['Status'] = "referred"

        if request.data['Status'] == "close":
            request.data['Status'] = "closed"

    if ID is not None and ID != "":

        # update the data in old inquiry
        logger.info("Update the Enquiry")
        Call_Details = request.data.get('Call_Details', None)
        Remarks = request.data.get('Remarks', None)
        Follow_Up_Date = request.data.get('Follow_Up_Date', None)
        Status = request.data.get('Status', None)
        CustomerRespons = request.data.get('Customer_Response', None)
        CustomerReached = request.data.get('Customer_Reached', None)
        Call_Type = request.data.get('Call_Type', None)
        Remarks = request.data.get('Remarks', None)
        Complaint = request.data.get('Complaint', None)
        info = None

        logger.info("Data recieved From callBack request: %s", request.data)
        logger.info("%s,%s,%s,%s", ID, Call_Details, Remarks, Status)

        if ID is None:
            logger.warning("ID is not given")
            return Response({"Error": "ID is not given"})

        if request.data.get('dept_name', None) is not None and request.data.get('dept_name', None) != "":

            try:
                dept_look_up = {}
                other_email_list = []
                departments = Departments.objects.all()

                for department in departments:
                    dept_look_up[department.Department_Description] = [department.Department_id,
                                                                       department.Dept_Email_id]
                dept_list = request.data.get('dept_name', None)
                dept_id_list = []
                dept_email = []

                for i in dept_list:
                    dept_id_list.append(str(dept_look_up[i][0]))
                    if i != "Other":
                        dept_email.append(dept_look_up[i][1])

                DepartEmails = dept_email
                Depart_Ids = ", ".join(dept_id_list)

                if "Other" in dept_list:
                    other_email_list = request.data.get('Dept_email', [])
                    other_Dept_Email = ", ".join(other_email_list)
                    DepartEmails = DepartEmails + (other_email_list)

                logger.info("dept ids : %s", other_email_list)
                logger.info("dept ids : %s, depart mails: %s ", dept_id_list, DepartEmails)

            except Exception as e:
                logger.exception(f"Undefined Department Selected %s {e}")
                return _ReturnError("Undefined Department Selected", e)

        if Call_Type == "Inbound":
            info = InboundCallDetails.objects.get(Inbound_Id=ID)

        if Call_Type == "Outbound":

            try:

                logger.info("outbound")
                info = OutboundCallDetails.objects.get(Outbound_Id=ID)
                info.Customer_Response_Id = CustomerResponse.objects.get(
                    Response_Description=CustomerRespons).Customer_Response_Id
                info.Customer_Reached = CustomerReached
                info.save()
                logger.info("CustomerReached: %s,CustomerResponse: %s",info.CustomerResponse,info.Customer_Reached)

            except Exception as e:
                logger.exception("Could not get records %s", e)

        if info is not None:

            info.pk = None
            info.Call_Details = Call_Details
            info.Remarks = Remarks
            info.Status = Status
            info.Version_No = int(info.Version_No) + 1
            # info.Follow_Up_Date = Follow_Up_Date if Follow_Up_Date is not None else ""
            info.Follow_Up_Date = Follow_Up_Date or None
            if Status == "referred":
                info.Dept_Email = other_Dept_Email
                info.Depart_Id = Depart_Ids
            info.save()
            logger.info("Data saved- pk: %s, Call_Details:%s, Remarks: %s, Status: %s, Version: %s, FollowUpDate: %s," \
                        "Dept_Email: %s, Dept_id: %s", \
                        info.pk, info.Call_Details, Remarks, info.Status, info.Version_No, info.Follow_Up_Date,
                        info.Dept_Email, info.Depart_Id)

            # Send mail in case the enquiry is refered
            if Status == "referred" or (Status == "closed" and Complaint is not None and Complaint is True):
                logger.info("Started Email Sending for callback enquiry for Status:%s and Complaint:%s"
                            , Status, Complaint)

                if (Status == "closed" or Status == "open") and Complaint is not None and Complaint is True:
                    dept_list = []
                    DepartEmails = []

                contact_numberfor_old = info.Query_Id.Customer_Id.Contact_Number
                logger.info(contact_numberfor_old)
                id = info.Query_Id.Customer_Id
                m = []

                if id.TeleHome:
                    m.append(id.TeleHome)
                if id.TelePhone:
                    m.append(id.TelePhone)
                if id.TeleWork:
                    m.append(id.TeleWork)
                if id.Fax:
                    m.append(id.Fax)

                Phone = "|".join(m)
                data = {
                    'request_type': Requests.objects.get(
                        Request_Id=int(info.Query_Id.Request_Type_Id)).Request_Description,
                    'product': Products.objects.get(Product_id=int(info.Query_Id.Product_Type_Id)).Product_Description,
                    'Query': Call_Type,
                    'Customer_Name': info.Query_Id.Customer_Id.Customer_Name,
                    'email': info.Query_Id.Customer_Id.Email,
                    'dept_name': dept_list,
                    'Phone': contact_numberfor_old if contact_numberfor_old else Phone,
                    'inquiry_details': Call_Details,
                    'Vehicle_No': info.Query_Id.Customer_Id.Vehicle_Reg_No,
                    'Policy_No': info.Query_Id.Customer_Id.Policy_Number,
                    'Complaint': Complaint,
                    'Complaint_Email': [str(settings.COMPLAINTS_EMAIL)],
                    'csr_email': [info.Query_Id.User_Email_id],
                    'Status': Status,
                    'username': users.objects.get(UserID=int(info.Query_Id.User_Id.UserID)).DisplayName,
                    'Dept_Email': DepartEmails,
                    'INQ_Id': info.Query_Id_id,
                    'Reassign' : False,
                    'Update_contact': False,
                    'update_dept_name': ''
                }

                logger.info("mail Data :%s", data.values())
                SendMail(data)

        logger.info(f"Info Updated as Status :{Status}")
        return Response({"result": "Successcallback"})

    else:
        # creates new enquiry
        try:
            customer_transaction = request.data
            logger.info("customer_transaction %s",customer_transaction)

            # adding customer id to the data
            customer_transaction['Searched_Customer_Id'] = request.data.get('ClientID', None)

            if customer_transaction['Searched_Customer_Id'] is None or customer_transaction[
                'Searched_Customer_Id'] == "":
                customer_transaction['Searched_Customer_Id'] = 0

            if request.data['req_desc'] == "Update Contact Details":
                logger.info("Requested for Updating client contact details %s, %s:", request.data['Customer_Name'] \
                            , request.data['Policy_Number'])

            # Initializing The mail data so that it can be used in the email template
            mail = {}
            # Changing the Data according to our need
            for i in customer_transaction:
                if customer_transaction[i] == "":
                    customer_transaction[i] = None

                if customer_transaction['Follow_Up_Date'] == "Invalid date":
                    customer_transaction['Follow_Up_Date'] = None

                if customer_transaction['Date_Of_Birth'] == "Invalid date":
                    customer_transaction['Date_Of_Birth'] = None

            # fetching Data from the LOOK UP TAbles
            if request.data.get('Type_Of_Channel') is not None:
                customer_transaction["Type_Of_Channel"] = TypeOfChannel.objects.filter(
                    Channel_Description=customer_transaction['Type_Of_Channel']).first().Channel_Id

            #  Capturing fields to send mail
            mail['request_type'] = request.data.get('req_desc', None)
            mail['product'] = request.data.get('product_desc', None)
            mail['Query'] = request.data.get('Call_Type', None)
            mail['Customer_Name'] = request.data.get('Customer_Name', None)
            mail['email'] = request.data.get('Email', None)
            mail['dept_name'] = request.data.get('dept_name', None)
            telphone  = request.data.get('telhome', None)
            telwork = request.data.get('telwork', None)
            telhome = request.data.get('telphone', None)
            fax = request.data.get('fax', None)
            Email = request.data.get('email', None)

            m = []
            if telhome:
                m.append(telhome)
            if telwork:
                m.append(telwork)
            if telphone:
                m.append(telphone)
            if fax:
                m.append(fax)
            logger.info(m)
            m = "|".join(m)

            customer_transaction['TeleHome'] = telphone
            customer_transaction['TeleWork'] = telwork
            customer_transaction['Fax'] = fax
            customer_transaction['TelePhone'] = telhome
            mail['Phone'] = m
            mail['Update_contact'] = False
            mail['Reassign'] = False
            mail['inquiry_details'] = request.data.get('Call_Details', None)
            mail['Vehicle_No'] = request.data.get('Vehicle_Reg_No', None)
            mail['Policy_No'] = request.data.get('Policy_Number', None)
            mail['Complaint'] = request.data.get('Complaint', None)
            mail['Status'] = request.data.get('Status', None)
            mail['Dept_Email'] = []
            mail['Complaint_Email'] = [str(settings.COMPLAINTS_EMAIL)]

            logger.info("Mail data initialised %s", mail)
            logger.info("New inquiry request %s", customer_transaction)

            # Saving data to customer transaction table
            serializer = SearchedCustomersSerializer(data=customer_transaction)
            serializer.is_valid(raise_exception=True)
            serializer.save()

            customer_transaction['Last_Updated_By'] = request.data.get('username', None)
            logger.info("User -----------%s------------", customer_transaction['Last_Updated_By'])
            customer_transaction['Customer_Id'] = int(serializer.data['Customer_Id'])
            logger.info("Customer Id -----------%s------------", int(serializer.data['Customer_Id']))

            if request.data['req_desc'] == "Update Contact Details":
                logger.info("Requested for Updating client contact details %s, %s by the user: %s", \
                            request.data['Customer_Name'], request.data['Policy_Number'], request.data['username'])

            logger.info("Successfully saved inquiry details in Search customer table")

            # UPDATING THE  Customer Details i.e email or phone number or ID
            if request.data.get('ClientID', None) and request.data.get('System', None):
                logger.info("In UPDATING THE  Customer Details i.e email or phone number or ID-------")
                System = request.data.get('System', None)
                ClientID = request.data.get('ClientID', None)
                Email = request.data.get('email', None)

                if System.__contains__("SSP Pure"):
                    logger.info("In SSP Pure UPDATING THE  Customer Details-------")

                    Type_Id = request.data.get('Id_Type', None)
                    Id_Number = request.data.get('Id', None)

                    logger.info("the clientid is %s ----------- request is %s",ClientID,request.data['req_desc'])

                    if ClientID is not None and (request.data['req_desc'] == "Update Contact Details" or request.data['update_contact'] is True):
                        logger.info("In Clientid is not none and UPDATING THE  Customer Details-------")
                        ssp_client = Clients.objects.filter(Client_Id=ClientID).first()
                        logger.info("Client data before update %s:", ssp_client.GetAllValues())
                        # Updating ID
                        customer_transaction['Update_contact_checkbox'] = request.data['update_contact']
                        mail['Update_contact']= request.data['update_contact']

                        if request.data['req_desc'] == "Update Contact Details":

                            if Type_Id is not None and Type_Id != "" and Id_Number is not None and Id_Number != "":
                                ssp_client.Type_Id = Type_Id
                                ssp_client.Id_Number = Id_Number
                                ssp_client.save()
                                logger.info("Client data after update %s by the user %s:", ssp_client.GetAllValues(),
                                            request.data['username'])
                                logger.info(f"type {Type_Id}: Number {Id_Number} updated in SSP Pure")

                            else:
                                logger.info("ID Was Not Updated Due to Type id or Number not given")

                        # Updating Contact
                        if telphone is not None and telphone != "" and telphone != "None":
                            Type_Desc = "Tel. Home"
                            Type_Code = "TELEPHONE "
                            update_or_create_contact(ClientID, Type_Desc, Type_Code, telphone,
                                                         request.data['username'])

                        if telwork is not None and telwork != "" and telwork != "None":
                                Type_Desc = "Tel. Work"
                                Type_Code = "TELWORK"
                                update_or_create_contact(ClientID, Type_Desc, Type_Code, telwork,
                                                         request.data['username'])

                        if telhome is not None and telhome != "" and telhome != "None":
                                Type_Desc = "Cellular Telephone"
                                Type_Code = "MOBILE"
                                update_or_create_contact(ClientID, Type_Desc, Type_Code, telhome,
                                                         request.data['username'])

                        if fax is not None and fax != "" and fax != "None":
                                Type_Desc = "Fax No."
                                Type_Code = "FAX"
                                update_or_create_contact(ClientID, Type_Desc, Type_Code, fax,
                                                         request.data['username'])

                        if Email is not None and Email != "" and Email != "None":
                                Type_Desc = "Main Email Contact"
                                Type_Code = "MEMAIL"
                                update_or_create_contact(ClientID, Type_Desc, Type_Code, Email,
                                                         request.data['username'])

                    # initiating mail data
                    contact_dict = {"Tel. Home": "", "Cellular Telephone": "", "Tel. Work": "","Fax No.":""}
                    contact_details = ""

                    try:
                        contacts = ClientContacts.objects.exclude(Type_Desc__contains="MAIL").filter(
                            Client_Id=ClientID).all()

                        for i in contacts:
                            contact_dict[i.Type_Desc] = i.NumberOrEmailOrWeb.replace(" ",
                                                                                     "") if i.NumberOrEmailOrWeb is not None else "UNAVAILABLE"

                        for i in contact_dict: contact_details = contact_details + "  " + contact_dict[i]
                        mail['Phone'] = contact_dict["Tel. Home"] + " | " + contact_dict["Cellular Telephone"] + " | " + \
                                        contact_dict["Tel. Work"] + " | " + contact_dict["Fax No."]
                    except:
                        logger.exception("some error occured pulling contact data")

                if System.__contains__("Wynsure"):

                    try:
                        win_client_contact = WinClientsContact.objects.get(Client_Id__contains=ClientID)

                        try:
                            logger.info("Client contact exists Updating the contact")

                            if win_client_contact is not None and (request.data['req_desc'] == "Update Contact Details" or request.data['update_contact'] is True):
                                customer_transaction['Update_contact_checkbox']= request.data['update_contact']
                                mail['Update_contact']= request.data['update_contact']

                                if win_client_contact:

                                    if telhome:
                                        win_client_contact.Home_Phone = telhome

                                    if telwork:
                                        win_client_contact.Office_Phone = telwork

                                    if telphone:
                                        win_client_contact.Private_Cell_Phone = telphone

                                    if Email:
                                        win_client_contact.Email = Email

                                    win_client_contact.save()
                                    logger.info("Phone number or Email or Id has been updated in Wysure ")
                        except:
                            logger.info("creating a new contact on Wynsure")

                            NewContact = WinClientsContact.objects.create(Client_Id=ClientID,
                                                                          Address_Effective_Date=str(
                                                                              datetime.now().date()),
                                                                          Home_Phone=telhome, Office_Phone=telwork,
                                                                          Private_Cell_Phone=telphone, Email=Email)
                            NewContact.save()

                        contact = WinClientsContact.objects.filter(Client_Id=ClientID).first()
                        mail['Phone'] = str(contact.Home_Phone) + " | " + str(contact.Private_Cell_Phone) + " | " \
                                        + str(contact.Office_Phone)
                    except Exception as e:
                        logger.exception("some error occured %s", e)

            # using Look up tables for fetching the id of product type
            p_desc = request.data.get('product_desc', None)

            if p_desc is not None:
                try:
                    p = Products.objects.filter(Product_Description=p_desc).values()
                    customer_transaction['Product_Type_Id'] = p[0]['Product_id']
                except Exception as e:
                    logger.exception(f"Undefined Product Selected %s {e}")
                    return _ReturnError("Undefined Product Selected", e)
            else:
                customer_transaction['Product_Type_Id'] = None

            # using Look up tables for fetching the id of request type
            req_desc = request.data.get('req_desc', None)
            if req_desc is not None:
                try:
                    r = Requests.objects.filter(Request_Description=req_desc).values()
                    customer_transaction['Request_Type_Id'] = r[0]['Request_Id']
                except Exception as e:
                    logger.exception(f"Undefined Request Selected %s {e}")
                    return _ReturnError("Undefined Request Selected", e)

            # if other request type take the other value
            if req_desc == "Other":
                customer_transaction['Others_request'] = request.data.get('Other_Request', None)
                mail['request_type'] = request.data.get('req_desc', None) + " : " + \
                                       request.data.get('Other_Request', None)

            # fetching user details to extract his email (CSR Email)
            try:
                u = users.objects.get(username=request.data.get('username', None))
            except Exception as e:
                logger.exception(f"User Details not found %s {e}")
                return _ReturnError("User Details not found", e)

            # Updating Query details to The Query table
            try:
                customer_transaction['User_Id'] = u.UserID
                customer_transaction['User_Email_id'] = u.email
                mail['csr_email'] = [u.email]
                mail['username'] = u.DisplayName
                serializer = QueriesSerializer(data=customer_transaction)
                serializer.is_valid(raise_exception=True)
                serializer.save()
                print("Query id: -----------%s------------", serializer.data["Query_Id"])
                customer_transaction['Query_Id'] = int(serializer.data["Query_Id"])
                mail['INQ_Id'] = serializer.data["Query_Id"]

                if request.data['req_desc'] == "Update Contact Details":
                    logger.info("Updated client contact details %s:", customer_transaction)
                logger.info("Inquiry stored in Query table")
            except Exception as e:
                logger.exception(f"User Details not found %s,{e}")
                return _ReturnError("User Details not found", e)
            # Taking the Departments selected form the front end and mapping thier ids(lookup table)\
            #  and mapping thier emails (to send email to respective departments)
            if request.data.get('dept_name', None) is not None and request.data.get('dept_name', None) != "":
                # Making some Changes requried if the department ids are given
                try:
                    dept_look_up = {}
                    departments = Departments.objects.all()
                    # Creating a hash table for DEpartments
                    for department in departments:
                        dept_look_up[department.Department_Description] = [department.Department_id,
                                                                           department.Dept_Email_id]
                    dept_list = request.data.get('dept_name', None)
                    dept_id_list = []
                    dept_email = []
                    # Here Department IDs are taken from lookuptable into dept_id_list
                    for i in dept_list:
                        dept_id_list.append(str(dept_look_up[i][0]))
                        if i != "Other":
                            # Here only the departments selected (except others) thier emails are mapped from look up table
                            dept_email.append(dept_look_up[i][1])
                    mail['Dept_Email'] = dept_email
                    customer_transaction['Depart_Id'] = ", ".join(dept_id_list)
                    logger.info("Emails without Other %s", mail['Dept_Email'])
                    logger.info("dept ids%s", customer_transaction['Depart_Id'])
                    # Here the additional Emails provided **only when others is selected in FrontEnd
                    # They are added to dept_email
                    if "Other" in dept_list:
                        other = ""
                        other_email_list = request.data.get('Dept_email', [])
                        customer_transaction['Dept_Email'] = ", ".join(other_email_list)
                        mail['Dept_Email'] = mail['Dept_Email'] + (other_email_list)
                    logger.info("dept ids : %s, depart mails: %s ", dept_id_list, mail['Dept_Email'])
                except Exception as e:
                    logger.exception(f"Undefined Department Selected %s {e}")
                    return _ReturnError("Undefined Department Selected", e)
            elif request.data.get('dept_name', None) is None or request.data.get('dept_name', None) == "":
                # Keeping the Depart_Id,Dept_Email None when the User sends empty data
                customer_transaction['Depart_Id'] = None
                customer_transaction['Dept_Email'] = None
            policy_service_team = Departments.objects.filter(Department_Description='Policy Services')
            policy_service_team_id = policy_service_team.values()[0]['Dept_Email_id']
            mail['update_dept_name'] = ''

            # Adding Version Number
            customer_transaction['Version_No'] = '1'
            logger.info("The data that is going to insert is %s",customer_transaction)
            if request.data.get('Call_Type', None) == "Inbound":
                #  Code for creating data in Inbound if it was a Inbound call
                if customer_transaction['Status'] == 'closed':
                    customer_transaction['closed_By'] = request.data.get('closed_by', None)
                    customer_transaction['Closed_By'] = request.data.get('username', None)
                serializer = InboundCallDetailsSerializer(data=customer_transaction)
                serializer.is_valid(raise_exception=True)
                serializer.save()
                logger.info("Inquiry saved in Inbound table")
                if customer_transaction['Status'] == 'referred':
                    try:
                        SendMail(mail)
                    except Exception as e:
                        logger.exception(f"Couldn't send mail for referred %s {e}")
                if (customer_transaction['Status'] == 'closed') \
                        and mail['Complaint'] is not None and mail['Complaint'] is True:
                    mail['Dept_Email'] = []
                    try:
                        SendMail(mail)
                    except Exception as e:
                        logger.exception(f"Couldn't send mail for referred %s {e}")
                if request.data.get('update_contact') is True:
                    mail['update_dept_name'] = "Policy Services"
                    mail['Update_Dept_Email'] = [policy_service_team_id]
                    # mail['update_dept_name'] = ''
                    try:
                        SendMail(mail)
                    except Exception as e:
                        logger.exception(f"Couldn't send mail for update contact %s {e}")
                return Response({"result": "Success"}, status=status.HTTP_200_OK)

            elif request.data.get('Call_Type', None) == "Outbound":
                #  Code for creating data in Outbound if it was a Outbound call
                try:
                    cust_response = request.data.get('Customer_Response', None)
                    try:
                        c = CustomerResponse.objects.filter(Response_Description=cust_response).values()
                    except Exception as e:
                        logger.exception(f"Undefined Department Selected %s: {e}")
                        return _ReturnError("Undefined Department Selected", e)
                    customer_transaction['Customer_Response_Id'] = c[0]['Customer_Response_Id']
                    customer_transaction['Version_No'] = 1

                    if customer_transaction['Status'] == 'closed':
                        customer_transaction['Closed_By'] = request.data.get('username', None)
                    # customer_transaction['Reassigned_Depart_Id'] = None
                    # customer_transaction['Reassigned_Dept_Email'] = None
                    serializer = OutboundCallDetailsSerializer(data=customer_transaction)
                    serializer.is_valid(raise_exception=True)
                    serializer.save()
                    logger.info("Outbound id : %s", serializer.data['Outbound_Id'])
                    if customer_transaction['Status'] == 'referred':
                        try:
                            SendMail(mail)
                        except Exception as e:
                            logger.exception(f"Couldn't send mail for referred %s {e}")
                    if (customer_transaction['Status'] == 'closed') \
                            and mail['Complaint'] is not None and mail['Complaint'] is True:
                        mail['Dept_Email'] = []
                        try:
                            SendMail(mail)
                        except Exception as e:
                            logger.exception(f"Couldn't send mail for referred %s {e}")
                    if request.data.get('update_contact') is True:
                        mail['update_dept_name'] = "Policy Services"
                        mail['Update_Dept_Email'] = [policy_service_team_id]
                        # mail['update_dept_name'] = ''
                        try:
                            SendMail(mail)
                        except Exception as e:
                            logger.exception(f"Couldn't send mail for update contact %s {e}")
                except Exception as e:
                    logger.exception(f" Could not create transaction for Outbound call details %s {e}")
                    return (_ReturnError("Could not create transaction for Outbound call details", e))

                return Response({"result": "Success"}, status=status.HTTP_200_OK)

        except Exception as e:
        
            logger.info(f"Could not create transaction for inquiry call details %s ---------->{e}")
            return Response({"message": "Could not create transaction for inquiry call details"},
                            status=status.HTTP_422_UNPROCESSABLE_ENTITY)


def SendMail(data):
    logger.info("In Send Mail")
    logger.info("data Mail %s", data)
    cc = data['csr_email']
    reference = ""
    uat_code = '''<p><b> *** TEST EMAIL *** </b></p>'''
    if data["Policy_No"] is not None:
        reference = "Policy Number-" + str(data["Policy_No"]) + " | "
    if data["Vehicle_No"] is not None:
        reference = reference + 'Vehicle Number-' + str(data["Vehicle_No"])
    logger.info("%s", data['Dept_Email'])
    if data['Complaint'] is True:
        logger.info("%s", data['Complaint_Email'])
        data['Dept_Email'] = data['Dept_Email'] + data['Complaint_Email']
        logger.info("%s", data['Dept_Email'] + data['Complaint_Email'])
    update_contact_info = ''
    referallline = '''<p>Please be reminded to update easyCustomer with your completed actions.</p>'''
    secondline = '''<p style="color:grey;">A new request has been assigned to you. Please see the inquiry details
         given below:</p>'''
    if data['Reassign'] is True:
        secondline =f"<p style='color:grey;'>A request has been re-assigned to you by {data['username']} from {data['user_dapartment']} department. Please see the inquiry details given below:</p>"
        data['Dept_Email'] = data['Reassign_Dept_Email']
        # referallline = ""
    if data['Update_contact'] is True:
        update_contact_info = '''<p style ="color:red;">*** Contact details have been updated. </p>'''
        # referallline = ""
    if data['Update_contact'] is True and data['update_dept_name'] == 'Policy Services':
        update_contact_info = ''
        secondline = '''<p>Please update the contact information for the customer provided below:</p>'''
        data['Dept_Email'] = data['Update_Dept_Email']
        referallline = ""
    if data['Status'] == "closed" and data['Complaint'] is True:
        secondline = '  ''<p style="color:grey;">The Complaint has been Closed. Please see the inquiry details given:</p>'''
        referallline = ""
    to_address = data['Dept_Email']
    to_address = list(set(to_address))
    logger.info("TO ADDRESS : %s", to_address)
    subject = f"easyCUSTOMER - New Task {data['INQ_Id']} - {data['Customer_Name']}"
    if data['Update_contact'] is True and data['update_dept_name'] == 'Policy Services':
        body = f'''
                <p style="color:grey;">Hello Team,</p>
                {uat_code}
                {secondline}
                <table
                    border="0"
                    cellpadding="6"
                    cellspacing="0"
                    width="800"
                    id="emailContainer">
                    <thead>
                    <th colspan="2" align="center" valign="top" bgcolor="purple" style="color:white;">Customer Details
                    / Request Details<th/>
                    </thead>
                    <tr>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Customer name</td>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;">{data['Customer_Name']}</td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Contact number(s)</td>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;">{data['Phone']}</td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Email address</td>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" >{data['email']}</td>
                    </tr>
                </table>
                {referallline}
                <p ><b style="color:grey;">Thanks & Regards</b></p>
                <p style="color:grey; margin: 0;padding: 0;"><em>{data['username']} on behalf of</em><p>
                <p style="margin-bottom: 0;padding-bottom: 0;"><b style="color:grey;">easyCUSTOMER</b></p>
                <p style="color:grey; margin: 0;padding: 0;">Address: Roebuck St, P.O. Box 1221, Bridgetown, BB11000, Barbados</p>
                <p style="color:grey; margin: 0;padding: 0;">Website: <a href="https://icbl.com/">https://icbl.com/</a></p>
                '''
    else:
        body = f'''
            <p style="color:grey;">Hello Team,</p>
            {uat_code}
            {secondline}
            {update_contact_info}
            <table
                border="0"
                cellpadding="6"
                cellspacing="0"
                width="800"
                id="emailContainer">
                <thead>
                <th colspan="2" align="center" valign="top" bgcolor="purple" style="color:white;">Customer Details<th/>
                </thead>
                <tr>
                    <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Customer name</td>
                    <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;">{data['Customer_Name']}</td>
                </tr>
                <tr>
                    <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Contact number(s)</td>
                    <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;">{data['Phone']}</td>
                </tr>
                <tr>
                    <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Email address</td>
                    <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" >{data['email']}</td>
                </tr>
                <thead>
                    <th colspan="2" align="center" valign="top" bgcolor="purple" style="color:white;">Request Details<th/>
                </thead>
                <tr>
                    <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Reference</td>
                    <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;">{reference}</td>
                </tr>
                <tr>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Type of Request</td>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;">{data['request_type']}</td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Product</td>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;">{data['product']}</td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;" width="200">Details</td>
                        <td align="left" valign="top" style="border: 1px solid #cccccc; border-collapse: collapse;">{data['inquiry_details']}</td>
                    </tr>
                
            </table>
            
            {referallline}
            <p ><b style="color:grey;">Thanks & Regards</b></p>
            <p style="color:grey; margin: 0;padding: 0;"><em>{data['username']} on behalf of</em><p>
            <p style="margin-bottom: 0;padding-bottom: 0;"><b style="color:grey;">easyCUSTOMER</b></p>
            <p style="color:grey; margin: 0;padding: 0;">Address: Roebuck St, P.O. Box 1221, Bridgetown, BB11000, Barbados</p>
            <p style="color:grey; margin: 0;padding: 0;">Website: <a href="https://icbl.com/">https://icbl.com/</a></p>
            '''

    response = _SendEmail(to_address, subject, body, cc)
    logger.info(response)
    logger.info("Mail send to %s and cc to %s and status: %s and complaint: %s", to_address, cc, data['Status'],
                data['Complaint'])
    # if not sent:
    #     return "success - mail not triggered"
    return "success"


def update_or_create_contact(ClientID, Type_Desc, Type_Code, contact, username):
    ssp_client_contact = ClientContacts.objects.filter(Client_Id=ClientID,Type_Desc__contains=Type_Desc).first()
    # ssp_client_contact = ClientContacts.objects.filter(Client_Id=ClientID, Type_Code__contains=Type_Code).first()
    # logger.info(contact)
    # logger.info([ssp_client_contact.S_N])
    logger.info("Client Contact details before updating %s", ssp_client_contact)
    if ssp_client_contact:
        logger.info(ssp_client_contact.NumberOrEmailOrWeb)
        if ssp_client_contact.NumberOrEmailOrWeb != contact:
            ssp_client_contact.Type_Desc = Type_Desc
            ssp_client_contact.NumberOrEmailOrWeb = contact
            ssp_client_contact.save()
            logger.info("Client data after updating %s by the user %s:", ssp_client_contact.get_contact_info(),
                        username)
            logger.info(f"Phone number {contact} of type {Type_Desc} has been updated in SSP Pure")
        else:
            logger.info("Same Record, Did Not Update")
    else:
        Contact = ClientContacts.objects.create(
            Client_Id=ClientID,
            Type_Desc=Type_Desc,
            Type_Code=Type_Code,
            NumberOrEmailOrWeb=contact)
        Contact.save()
        logger.info("Created new contact for this client %s by the user :", Contact.get_contact_info(), username)
