from login.models import users
from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from InAndOutBoundApp.models.Queries import Queries
from django.db.models import Q, Max, F
import re
from InAndOutBoundApp.models.Departments import Departments
from InAndOutBoundApp.models.Products import Products
from InAndOutBoundApp.models.Requests import Requests
from InAndOutBoundApp.models.Type_Of_Channel import TypeOfChannel
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from django.utils import timezone

# logging imports
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'InAndOutBound')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['GET','POST',])
@permission_classes([IsAuthenticated,])
def Referred_Inquiries(request,page_ind, items_size, len):
    # logger.info(request.data)
    if request.data.get('sortdata'):
        return Response ({"Referred_inquiries":request.data['sortdata'],
                          'search_count':request.data['searchrecords'],
                          'count':request.data['noofrecords']},
                         status=status.HTTP_200_OK, content_type="application/json")

    result = []
    depts = {}
    u = None
    count = 0
    username  = request.data.get("username", None)
    CustomerName = request.data.get("customer",None)
    Department = request.data.get("Department", None)
    InqueryId = request.data.get("inquiryId", None)
    Request = request.data.get("requestType", None)
    GTDate = request.data.get('fromdate', None)
    LTDate = request.data.get('todate', None)
    type_of_inquiry = request.data.get('inquiryType', None)
    logger.info(request.data)
    try:
        # Gets total count of all referred inquiries.
        count = Queries.objects.filter(Q(Inbound_Query_Id__isnull=False) | Q(Outbound_Query_Id__isnull=False)).order_by(
            "-Query_Id").select_related().annotate(inmax = Max('Inbound_Query_Id'), outmax =  Max('Outbound_Query_Id')).filter(
            Q(Q(Inbound_Query_Id__Inbound_Id = F('inmax')) & Q(Inbound_Query_Id__Status = 'referred')) | Q(
            Outbound_Query_Id__Outbound_Id = F('outmax')) & Q(Outbound_Query_Id__Status = 'referred')).count()

        depts = Departments.objects.all()
        reqs = Requests.objects.all()
        tocs = TypeOfChannel.objects.all()
        products = Products.objects.all()

        dept_look_up ={}
        for department in depts:
            dept_look_up[department.Department_id] = department.Department_Description

        requests_look_up = {}
        for request in reqs:
            requests_look_up[request.Request_Id] = request.Request_Description

        toc_look_up = {}
        for channel in tocs:
            toc_look_up[channel.Channel_Id] = channel.Channel_Description

        products_look_up = {}
        for product in products:
            products_look_up[product.Product_id] = product.Product_Description

        if username is not None and username != "":
            u = users.objects.filter(username__contains=username).first()

        search_dept_ids = []
        if Department is not None and Department !="":
            for i in dept_look_up:
                if re.search(Department, dept_look_up[i], re.IGNORECASE):
                    search_dept_ids.append(i)

        queries = Queries.objects

        if InqueryId is not None and InqueryId != "":
            queries = queries.filter(Query_Id__contains=InqueryId)

        if Request is not None and Request != "":
                req_id = list(requests_look_up.keys())[list(requests_look_up.values()).index(Request)]
                queries = queries.filter(Request_Type_Id=req_id)

        if GTDate is not None and LTDate is None:
            queries = queries.filter(Call_Date=GTDate)

        elif GTDate is None and LTDate is not None:
            queries = queries.filter(Call_Date=LTDate)

        elif GTDate is not None and LTDate is not None:
            queries = queries.filter(Call_Date__gte=GTDate, Call_Date__lte=LTDate)

        if username is not None and username != "":
            queries = queries.filter(User_Id = u.UserID)

        if type_of_inquiry is not None and type_of_inquiry != "":
            queries = queries.filter(Call_Type=type_of_inquiry)

        if CustomerName is not None and CustomerName != "":
            queries = queries.filter(Customer_Id__Customer_Name__contains = CustomerName)

        if Department is not None and Department != "":
            queryfilter = Q()
            if not search_dept_ids.__len__():
                return Response({"Referred_inquiries":[], "count":count}, status=status.HTTP_200_OK, content_type="application/json")
            for Id in search_dept_ids:
                queryfilter = queryfilter | (Q(Inbound_Query_Id__Depart_Id__contains = ", "+str(Id)+",") | Q(
                    Outbound_Query_Id__Depart_Id__contains = ", "+str(Id)+",") | Q(Inbound_Query_Id__Depart_Id = str(Id)) | Q(
                    Outbound_Query_Id__Depart_Id = str(Id)) | Q(Inbound_Query_Id__Depart_Id__startswith = str(Id)+",") | Q(
                    Outbound_Query_Id__Depart_Id__startswith = str(Id)+",") | Q(Inbound_Query_Id__Depart_Id__endswith = ", "+str(Id)) | Q(
                    Outbound_Query_Id__Depart_Id__endswith = ", "+str(Id)) )
            queries = queries.filter(queryfilter)

        queries_s = queries.filter(Q(Inbound_Query_Id__isnull=False) | Q(Outbound_Query_Id__isnull=False)).order_by(
            "-Query_Id").select_related().annotate(inmax = Max('Inbound_Query_Id'), outmax =  Max('Outbound_Query_Id'))

        queries_out = queries_s.filter(
            Q(Q(Inbound_Query_Id__Inbound_Id = F('inmax')) & Q(Inbound_Query_Id__Status = 'referred')) | Q(
                Outbound_Query_Id__Outbound_Id = F('outmax')) & Q(Outbound_Query_Id__Status = 'referred'))

        search_count = queries_out.count()
        logger.info(count)
        queries_out = queries_out[len:page_ind * items_size]
        temp = []
        Type_Of_Request = None
        for i in queries_out:
            if i.Call_Type == 'Inbound' and i.inmax is not None:
                    temp = InboundCallDetails.objects.filter(Inbound_Id=i.inmax).first()
                    query_Id = temp.Inbound_Id
                    logger.info("inbound %s",i.inmax)
            elif i.Call_Type == 'Outbound' and i.outmax is not None:
                    temp = OutboundCallDetails.objects.filter(Outbound_Id=i.outmax).first()
                    query_Id = temp.Outbound_Id
                    logger.info("outbound: %s",i.outmax)
            else:
                continue
            other_request = None

            Type_Of_Request = requests_look_up[int(i.Request_Type_Id)]
            if Type_Of_Request == "Other":
                other_request = i.Other_Request

            Type_Of_Channel = toc_look_up[int(i.Customer_Id.Type_Of_Channel)]
            Product = products_look_up[int(i.Product_Type_Id)]

            reassaigned_dept = ""
            if temp.Reassigned_Depart_Id is not None and temp.Reassigned_Depart_Id != "":
                ids = temp.Reassigned_Depart_Id.replace(" ", "")
                departments = ids.split(",")
                for j in departments:
                    if j == "":
                        continue
                    dept_desc = dept_look_up[int(j)]
                    if reassaigned_dept == "":
                        reassaigned_dept = dept_desc
                        continue
                    reassaigned_dept = reassaigned_dept + " , " + dept_desc

            dept = ""
            if temp.Depart_Id is not None and temp.Depart_Id != "":
                ids = temp.Depart_Id.replace(" ", "")
                departments = ids.split(",")
                for j in departments:
                    if j == "":
                        continue
                    dept_desc = dept_look_up[int(j)]
                    if dept == "":
                        dept = dept_desc
                        continue
                    dept = dept + " , " + dept_desc
            if temp is not None:
                Days_Open = (timezone.now().date() - temp.Last_Updated_Date).days
                result.append({
                        'Added': temp.Added,
                        'Call_Date': temp.Query_Id.Call_Date,
                        'Complaint': temp.Query_Id.Complaint,
                        'Customer_Name': temp.Query_Id.Customer_Id.Customer_Name,
                        'Details_Call': temp.Call_Details,
                        'Days_Open': Days_Open,
                        'Department_Name':dept,
                        'Reassaigned_dept':reassaigned_dept,
                        'Follow_Up_Date':temp.Follow_Up_Date,
                        'QueryID':i.Query_Id,
                        'ID': query_Id,
                        'Last_Updated_By':temp.Last_Updated_By,
                        'Other_Request': other_request,
                        'Other_Department':temp.Dept_Email,
                        'Priority': temp.Query_Id.Priority,
                        'Remarks':temp.Remarks,
                        'Resolution_Notes': temp.Resolution_Notes,
                        'Responded_By': temp.Responded_By,
                        'Status': temp.Status,
                        'Type_Of_Inquiry': i.Call_Type,
                        'Type_Of_Request': Type_Of_Request,
                        'Type_Of_Channel': Type_Of_Channel,
                        'Type_Of_Product': Product,
                        'Policy_No':temp.Query_Id.Customer_Id.Policy_Number,
                        'Task_Id': temp.Query_Id_id
                })
    except Exception as e:
        print(e)
        logger.exception("Unable to fetch callback inquiries %s",e) 
    return Response({"Referred_inquiries":result, "count":count,"search_count":search_count},
                    status=status.HTTP_200_OK, content_type="application/json")