from login.models import users
from InAndOutBoundApp.models.Inbound_Call_Details import InboundCallDetails
from InAndOutBoundApp.models.Outbound_Call_Details import OutboundCallDetails
from InAndOutBoundApp.models.Queries import Queries
from InAndOutBoundApp.models.Requests import Requests
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.decorators import api_view,permission_classes
from rest_framework import status
from django.db.models import Max, Q
# logging imports
import os
import logging
from django.conf import settings
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

filename = os.path.join(settings.FILE_PATH, 'InAndOutBound')
file_handler = RotatingFileHandler(filename +'/'+os.path.basename(__file__).replace('.py','')+'.log', maxBytes=1000000, backupCount= 6)

formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(lineno)d:%(message)s')
file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

@api_view(['GET','POST',])
@permission_classes([IsAuthenticated,])
def Complaints(request,page_ind, items_size, len):

    if request.data.get('sortdata'):
        return Response ({"Complaints":request.data['sortdata'],
                          'search_count':request.data['searchrecords'],
                          'count':request.data['noofrecords']},
                         status=status.HTTP_200_OK, content_type="application/json")
    result = []
    u = None
    count = 0
    try:
        # Gets total count of complaint inquiries
        count = Queries.objects.filter(Complaint = True).filter(Q(Inbound_Query_Id__isnull=False) | Q(Outbound_Query_Id__isnull=False)).order_by("-Query_Id").select_related().annotate(inmax = Max('Inbound_Query_Id'), outmax =  Max('Outbound_Query_Id')).count()

        reqs = Requests.objects.all()
        requests_look_up = {}
        for single_request in reqs:
            requests_look_up[single_request.Request_Id] = single_request.Request_Description

        username  = request.data.get("username", None)
        CustomerName = request.data.get("customer",None)
        InqueryId = request.data.get("inquiryId", None)
        Request = request.data.get("requestType", None)
        GTDate = request.data.get('fromdate', None)
        LTDate = request.data.get('todate', None)

        if username is not None and username != "":
            u = users.objects.filter(username__contains=username).first()
        queries = Queries.objects

        if InqueryId is not None and InqueryId != "":
            queries = queries.filter(Query_Id__contains=InqueryId)

        if Request is not None and Request != "":
                req_id = list(requests_look_up.keys())[list(requests_look_up.values()).index(Request)]
                queries = queries.filter(Request_Type_Id=req_id)

        if GTDate is not None and LTDate is None:
            queries = queries.filter(Call_Date=GTDate)

        if GTDate is None and LTDate is not None:
            queries = queries.filter(Call_Date=LTDate)

        if GTDate is not None and LTDate is not None:
            queries = queries.filter(Call_Date__gte=GTDate, Call_Date__lte=LTDate)

        if username is not None and username != "":
                queries = queries.filter(User_Id = u.UserID)

        if CustomerName is not None and CustomerName != "":
                queries = queries.filter(Customer_Id__Customer_Name__contains = CustomerName)
                
        queries = queries.filter(Complaint = True)  
        queries = queries.filter(Q(Inbound_Query_Id__isnull=False) | Q(Outbound_Query_Id__isnull=False)).order_by(
            "-Query_Id").select_related().annotate(inmax = Max('Inbound_Query_Id'), outmax =  Max('Outbound_Query_Id'))
        search_count = queries.count()
        queries = queries[len:page_ind * items_size]
        temp = []
        Type_Of_Request = None
        for i in queries:
            close_date = None
            if i.Call_Type == 'Inbound' and i.inmax is not None:
                    temp = InboundCallDetails.objects.filter(Inbound_Id=i.inmax).first()
                    Type_Of_Request = requests_look_up[int(i.Request_Type_Id)]
                    query_Id = temp.Inbound_Id
                    if temp.Status == "closed":
                        print((temp.Last_Updated_Date - i.Call_Date).days)
                        close_date = (temp.Last_Updated_Date - i.Call_Date).days
            elif i.Call_Type == 'Outbound' and i.outmax is not None:
                    temp = OutboundCallDetails.objects.filter(Outbound_Id=i.outmax).first()
                    Type_Of_Request = requests_look_up[int(i.Request_Type_Id)]
                    query_Id = temp.Outbound_Id
                    if temp.Status == "closed":
                        print((temp.Last_Updated_Date - i.Call_Date).days)
                        close_date = (temp.Last_Updated_Date - i.Call_Date).days
            else:
                continue

            if temp is not None:
                result.append({
                        "ID": query_Id,
                        'Call_Date': i.Call_Date,
                        'Customer_Name': i.Customer_Id.Customer_Name,
                        'Status':temp.Status,
                        'Type_Of_Inquiry': i.Call_Type,
                        'Type_Of_Request': Type_Of_Request,
                        'Details_Call': temp.Call_Details,
                        'Resolution_Notes': temp.Resolution_Notes,
                        'Remarks':temp.Remarks,
                        'Last_Updated_By':temp.Last_Updated_By,
                        'Added': temp.Added,
                        'Policy_No':temp.Query_Id.Customer_Id.Policy_Number,
                        'Task_Id': temp.Query_Id_id,
                        'Closed_Days': close_date,
                })
    except Exception as e:
        print(e)
        logger.exception("Unable to fetch callback inquiries %s",e) 
    return Response({"Complaints":result, "count":count,"search_count":search_count},
                    status=status.HTTP_200_OK, content_type="application/json")
     