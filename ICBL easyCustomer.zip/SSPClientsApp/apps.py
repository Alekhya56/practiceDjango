from django.apps import AppConfig


class SspclientsappConfig(AppConfig):
    name = 'SSPClientsApp'
