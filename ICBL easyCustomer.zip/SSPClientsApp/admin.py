from django.contrib import admin

from SSPClientsApp.models.clients import Clients
from SSPClientsApp.models.clients_o_a import ClientsOA
from SSPClientsApp.models.policy import Policy
from SSPClientsApp.models.clients_contacts import ClientContacts

# Register your models here.
admin.site.register(Clients)
admin.site.register(ClientsOA)
admin.site.register(Policy)
admin.site.register(ClientContacts)