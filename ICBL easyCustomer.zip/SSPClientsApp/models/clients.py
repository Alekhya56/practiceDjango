import uuid
from django.db import models
# from django.contrib.auth.models import AbstractUser
from django.conf import settings
from django.utils import timezone

class Clients(models.Model):
    Client_Id = models.IntegerField(primary_key=True, db_column='id')
    Client_Code = models.CharField(max_length=500, null = False, db_column='code')
    First_Name = models.CharField(max_length=500, null = True , db_column='FirstName')
    Last_Name = models.CharField(max_length=500, null = True, db_column='LastName')
    Date_Of_Birth = models.DateTimeField(auto_now=False, auto_now_add=False, null = True, db_column='DateOfBirth')
    Gender = models.CharField(max_length=500, null = True, db_column='Gender')
    Id_Number = models.CharField(max_length=500,unique = True, null = True, db_column='IdNumber')
    Type_Id = models.CharField(max_length=500, null = True, db_column='IdType')
    Occupation = models.CharField(max_length=500, null = True, db_column='Occupation1')
    Nationality = models.CharField(max_length=500, null = True, db_column='Nationality')
    
    
    def __str__(self):
        return f"{str(self.Client_Id)}-{self.First_Name} {self.Last_Name}"

    def GetAllValues(self):
        clients_info = {}
        clients_info['Client_Id'] = self.Client_Id
        clients_info['Client_Code'] = self.Client_Code.replace(" ","")
        clients_info['First_Name'] = self.First_Name.replace(" ","")
        clients_info['Last_Name'] = self.Last_Name.replace(" ","")
        clients_info['Date_Of_Birth'] = self.Date_Of_Birth
        clients_info['Id_Number'] = self.Id_Number
        clients_info['Type_Id'] = self.Type_Id
        clients_info['Gender'] = self.Gender
        return clients_info

    class Meta:
        db_table='Clients'