import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone

def get_sno():
    count = ClientContacts.objects.all().count()
    count += 1
    return count

class ClientContacts(models.Model):
    # ClientID	TypeCode	TypeDescription	Description	AreaCode	NumberOrEmailOrWeb	Extension
    S_N = models.IntegerField(primary_key=True, db_column='UniClieId', null = False, default=get_sno)
    K = models.IntegerField( db_column='k', null = False, default=0)
    Client_Id = models.IntegerField( db_column='ClientID')
    Type_Code =  models.CharField(max_length=500, null = False, db_column='TypeCode')
    Type_Desc =  models.CharField(max_length=500, null = False, db_column='TypeDescription')
    Description = models.CharField(max_length=500, null = True, db_column='Description')
    # Area_Code =  models.FloatField(max_length=500, db_column='AreaCode')
    NumberOrEmailOrWeb = models.CharField(max_length=500, null = False, db_column='NumberOrEmailOrWeb')
    Extension = models.CharField(max_length=500, null = False, db_column='Extension')

    def __str__(self):
        return str(self.Client_Id)
        # return f"{str(self.Client_Id)}"
        # return f"{str(self.Client_Id)},{str(self.Type_Code)},{self.NumberOrEmailOrWeb}"

    def get_contact_info(self):
        contact_info = {}
        contact_info['S_N'] = self.S_N
        contact_info['Client_Id'] = self.Client_Id
        contact_info['Type_Code'] = self.Type_Code
        contact_info['Type_Desc'] = self.Type_Desc
        contact_info['Description'] = self.Description
        contact_info['NumberOrEmailOrWeb'] = self.NumberOrEmailOrWeb
        contact_info['Extension'] = self.Extension
        return contact_info

    class Meta:
        db_table='ClientContacts'