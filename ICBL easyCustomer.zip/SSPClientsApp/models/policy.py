import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone

class Policy(models.Model):
    # Transaction_id = models.FloatField(primary_key=True)
    Policy_Id = models.IntegerField( null = False, db_column='PolicyId',primary_key=True)
    Client_Id =  models.IntegerField( null = False, db_column='id', default ="null")
    Policy_Number = models.CharField(max_length=255, null = False, unique = True, db_column='PolicyNumber')
    Inception_Date = models.DateTimeField(auto_now=False, auto_now_add=False, null = True,  db_column='inception_date_tpi')
    Policy_Start_Date = models.DateTimeField(auto_now=False, auto_now_add=False, null = True,  db_column='cover_start_date')
    Policy_End_Date = models.DateTimeField(auto_now=False, auto_now_add=False, null = True, db_column='expiry_date')
    Trans_Type = models.CharField( max_length=50, null = True, db_column='TransType')
    Product_Description = models.CharField( max_length=500, null = True, db_column='ProductDescription')
    Renewal_Date = models.DateTimeField(auto_now=False, auto_now_add=False, null = True,  db_column='renewal_date')
    Status= models.CharField(max_length=500, null = True, db_column='Status')
    Premium = models.DecimalField(max_digits=19, decimal_places=10, null = True, db_column='TotalPremium')
    Vehicle_Reg_No = models.CharField(max_length=500, null = True, db_column='Vehicle_Registration')
    Home_Risk_Address1 = models.CharField(max_length=255, null=True, db_column='Risk_Address1' )
    Home_Risk_Address2 = models.CharField(max_length=255, null=True, db_column='Risk_Address2')
    class Meta:
        db_table='Policy'

    def __str__(self):
        return f"Policy_No-{self.Policy_Number}- client_ID-{self.Client_Id}"
    