import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone

class ClientsOA(models.Model):
    Client_Id = models.IntegerField(primary_key=True,db_column='account_key')
    # Client_Code = models.CharField(max_length=500, db_column='clientcode')
    Insurance_Ref = models.CharField(max_length=500, null = True, db_column='insurance_ref')
    Total_OA = models.DecimalField(max_digits=19, decimal_places=10, null = False, db_column='TotalOutstandingAmount')
    Payment_Method = models.CharField(max_length=500, null = True, db_column='payment_method')
    Scheme_Name = models.CharField(max_length=500, null = True, db_column='SchemeName')
    Payment_Due_Date = models.DateField(auto_now=False, auto_now_add=False, null = True, db_column='PaymentDueDate')
    Paid_Date = models.DateField(auto_now=False, auto_now_add=False, null = True, db_column='PaidDate')
    Next_Payment_Date = models.DateField(auto_now=False, auto_now_add=False, null = True, db_column='NExtPaymentDate')

    def __str__(self):
        return f"{self.Client_Id}-{self.Insurance_Ref}" 
    def getOA(self):
        client_oa = {}
        client_oa ['Client_Id'] = self.Client_Id
        client_oa ['Insurance_Ref'] = self.Insurance_Ref
        client_oa ['Total_OA'] = self.Total_OA
        return client_oa 

    class Meta:
        db_table='OutstandingAmount'