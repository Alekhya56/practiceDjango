from os import remove,path
import smtplib
from email.mime.multipart import MIMEMultipart
# from email.mime.application import MIMEApplication
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
import pyodbc
from openpyxl import load_workbook
from openpyxl.styles.borders import Border, Side
from datetime import date
from email import encoders

def send_email(to_address,subject,body,attachment,cc=[]):
    MAILSERVER_DOMAIN = 'smtp.gmail.com'
    MAILSERVER_USERNAME = 'manomaytesting@gmail.com'
    ENVIRONMENT = "DEVELOPMENT"
    MAILSERVER_PORT = 587
    MAILSERVER_PASSWORD = 'jzaemibovlwkqvht'

    msg = MIMEMultipart()
    msg['subject'] = subject
    msg['from'] = MAILSERVER_USERNAME
    msg['to'] = ', '.join(to_address)
    msg['cc'] = ', '.join(cc)
    fp = open(attachment, 'rb')
    part = MIMEBase('application','vnd.ms-excel')
    part.set_payload(fp.read())
    fp.close()
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment', filename='ICB_OnHold.xlsx')
    msg.attach(part)
    msg.attach(MIMEText(body, 'html'))

    if ENVIRONMENT == "DEVELOPMENT":
        # connecting to mailserver and send the email
        mailserver = smtplib.SMTP(MAILSERVER_DOMAIN, port=MAILSERVER_PORT)
        mailserver.starttls() #enable security
        mailserver.login(MAILSERVER_USERNAME, MAILSERVER_PASSWORD)

    if ENVIRONMENT == "PRODUCTION":
        # connecting to mailserver and send the email
        mailserver = smtplib.SMTP(domain)
    try:
        mailserver.sendmail(MAILSERVER_USERNAME, (to_address+cc), msg.as_string())

    except Exception as e:
        print(e)
        domain = MAILSERVER_DOMAIN
        email= MAILSERVER_USERNAME
        to_address = "alekhya.muddada@manomay.biz"
        # to_address = ["shaik.farooq@manomay.biz","neetha.pasham@manomay.biz
        if ENVIRONMENT == "DEVELOPMENT":
            port= MAILSERVER_PORT
            password= MAILSERVER_PASSWORD

        msg = MIMEMultipart()
        msg['subject'] = "Error Sending Mails"
        msg['from'] = email
        msg['to'] = ', '.join(to_address)
        body = f'''<p>Hi, Admin</p>
                    <p>Looks like There is some Problem triggering the Emails</p>
                    <p>Please Check!</p>
                    <p>Error is {e}</p>
                    <p>Thanks and Regards</p>
                '''
        msg.attach(MIMEText(body, 'html'))

        if ENVIRONMENT == "DEVELOPMENT":
            # connecting to mailserver and send the email
            mailserver = smtplib.SMTP_SSL(domain, port=port)
            mailserver.login(email, password)

        if ENVIRONMENT == "PRODUCTION":
            # connecting to mailserver and send the email
            mailserver = smtplib.SMTP(domain)
        mailserver.sendmail(email, (to_address), msg.as_string())
        return f"mail failed: {e}"
    print("mail sent")
    return "mail sent"
# Notify the user with Temporary Password

name = 'Alekhya'
email = 'alekhya.muddada@manomay.biz'
password = 'jzaemibovlwkqvht'
FRONTEND_URL = ''
today_date = date.today()
subject = f"On Hold -{today_date}"
body = f'''<p>Hi,</p>
        <p>Enclosed are the records for which the IUR updates are on hold.</p>
        <p>Please log on to <ICB UI application link> and make the necessary updates.</p>
        '''
cc = []
toaddress = [email]
conn= pyodbc.connect('Driver={SQL Server};'
                      'Server=LAPTOP-5KNII04G;'
                      'Database=Icb_db;'
                      'Trusted_Connection=yes;')
cursor = conn.cursor()
cursor.execute('''select ClientId,ClientName,[IUR Number] as IUR,RiskAddress,
 RiskLine,SubProductDescription,PolicyNumber,ItemNumber,CoverageDEscription,CoverageLevelSumInsured_Reporting,
 CoveragePremium,EntryDate,LastUpdatedDate,LastUpdatedBy,Status from Multipolicy where status='HOLD' ''')
rows = cursor.fetchall()
onhold_count = len(rows)
try:
    file_name = f'ICB_OnHold_Template.xlsx'
    excel_url = path.abspath(path.join(path.abspath(__file__),".."))
    temp_url = path.abspath(path.join(path.abspath(__file__),".."))
    file_path = path.abspath(path.join(excel_url, file_name))
    save_path = path.abspath(path.join(temp_url, "hold_data.xlsx"))

    sheet_name ="OnHold"
    thin_border = Border(left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                        bottom=Side(style='thin'))
    wb = load_workbook(file_path)
    sheet= wb.active
    row=3
    if sheet_name in wb.sheetnames:
        #to check whether sheet you need already exists
        for r in rows:
            sheet.cell(row=row, column=1).value = r.ClientId
            sheet.cell(row=row, column=2).value = r.ClientName
            sheet.cell(row=row, column=3).value = r.IUR
            sheet.cell(row=row, column=4).value = r.RiskAddress
            sheet.cell(row=row, column=5).value = r.RiskLine
            sheet.cell(row=row, column=6).value = r.SubProductDescription
            sheet.cell(row=row, column=7).value = r.PolicyNumber
            sheet.cell(row=row, column=8).value = r.ItemNumber
            sheet.cell(row=row, column=9).value = r.CoverageDEscription
            sheet.cell(row=row, column=10).value = r.CoverageLevelSumInsured_Reporting
            sheet.cell(row=row, column=11).value = r.CoveragePremium
            sheet.cell(row=row, column=12).value = r.EntryDate
            sheet.cell(row=row, column=13).value = r.LastUpdatedDate
            sheet.cell(row=row, column=14).value = r.LastUpdatedBy
            sheet.cell(row=row, column=15).value = r.Status
            for i in range(1,16):
                sheet.cell(row=row, column=i).border = thin_border
            row +=1
    wb.save(save_path)

    if len(toaddress):
    # Mail to be sent with the temporary password
        send_email(
                body=body,
                subject=subject,
                to_address=toaddress,
                attachment = save_path,
                cc=cc
                )

    def generate():
        with open(save_path,'rb') as f:
            yield from f
        remove(save_path)
except Exception as e:
    print(e)

