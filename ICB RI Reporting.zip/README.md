# ICB_RI_Dev_Updated
Steps to install and run the application
1. Create and activate virtual environment
   pip install virtualenv
   python -m virtualenv venv
   cd venv/Scripts
   activate
   
2. Install required packages 
   Navigate to the root folder and execute pip install -r requirements.txt
   
3. Once after cloning in config folder->development.py file check for the required database link according to the environment
4. Once after cloning in config folder->development.py file check for the required mails related link according to the environment
5. In Reports directory update the local paths
6. Flask run to run the application
   python -m flask run -h 192.168.2.147 -p 9000
