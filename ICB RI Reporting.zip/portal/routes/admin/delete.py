from datetime import datetime

from flask import flash, request
from flask_login import login_required
from flask_restx import Resource
from werkzeug.datastructures import ImmutableMultiDict
from werkzeug.exceptions import UnprocessableEntity

from ... import LOG
from ...models import db
from ...models.users import Users
from . import ns
from .admin import get_users


@ns.route("/delete")
class DeleteUser(Resource):
    """Deletes an active employee changes employee status 'DELETE'.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Internal_users  : dict
                    Active and inactive employees with 'Success' string

    """
    @login_required
    def post(self):
        try:
            # login requires to access this route
            dataframelist = request.form
            imd = ImmutableMultiDict(dataframelist)
            imd1 = imd.to_dict(flat=False)
            user = Users.query.filter_by(Email=imd1['email'][0]).first()
            if user is not None:
                flash("User not found")
                UnprocessableEntity("User not found")

            # Updates Status and Action to 'DELETE' and time of modified.
            user.Status = "DELETE"
            user.Action = "DELETE"
            user.Last_Modified = datetime.today()
            db.session.commit()
            flash("User deleted Successfully")
            LOG.info("User %s Deleted Successfully", user.UserName)
            users = get_users()
            return {
                    "result": "success",
                    "internal_users": users,
                    "count": len(users),
                    "error": None
                    }
        except Exception as e:
            LOG.error(e)
