from datetime import datetime

from flask import flash, request
from flask_login import login_required
from flask_restx import Resource
from werkzeug.datastructures import ImmutableMultiDict
from werkzeug.exceptions import UnprocessableEntity

from ... import APP, LOG
from ...encryption import Encryption
from ...helpers import random_string_with_digits_and_symbols, send_email
from ...models import db
from ...models.users import Users
from . import ns
from .admin import get_users


@ns.route("/create")
class CreateUser(Resource):
    """Creates an active employee with given details and

        sends a mail with username and temporar password details.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Internal_users  : dict
                    Active and inactive employees with 'Success' string

    """
    @login_required
    def post(self):
        try:
                # collecting data from request
                dataframelist = request.form
                imd = ImmutableMultiDict(dataframelist)
                imd1 = imd.to_dict(flat=False)
                t = datetime.today()

                users = get_users()
                """ Filter employee details with given
                employee email and id details in request."""
                user = Users.query.filter(Users.Email == imd1["email"][0]).first()
                if user:
                    flash("User exists with this email or employee id")
                    return {
                        "result": "success",
                        "internal_users": users,
                        "count": len(users),
                        "error": None
                        }
                password = random_string_with_digits_and_symbols()
                pass_encrypt = Encryption().encrypt(password)
                # Creates user with given details in request
                usermodel = Users(
                                UserName=imd1['name'][0],
                                Password=pass_encrypt,
                                Email=imd1['email'][0],
                                Status="ACTIVE",
                                Role=imd1['role'][0],
                                LastLogin=None,
                                Action_by='username',
                                LastPasswordChanged=None,
                                Last_Modified=t.strftime("%d.%m.%Y %H:%M:%S"),
                                TemporaryPassword=True,
                                Action="CREATE"
                                )

                # Notify the user with Temporary Password
                subject = f"Account Creation"
                body = f'''<p>Dear {imd1['name'][0]},</p>
                        <p>Your account has been registered on ICB RI system.</p>
                        <p>Please use the following credentials to log
                        in for the first-time</p>
                        <p>Email Id : {imd1['email'][0]}</p>
                        <p>Password : {password}</p>
                        <p>Please note this is a temporary password & you
                        would be forced to setup a new password on the first
                        <a href={APP.config["FRONTEND_URL"]}>login</a></p>
                        '''
                cc = []
                toaddress = [imd1['email'][0]]
                print(toaddress)
                if len(toaddress):

                    # Mail to be sent with the temporary password
                    send_email(
                                body=body,
                                subject=subject,
                                cc=cc,
                                to_address=toaddress
                                )
                else:
                    LOG.error("CREATE USER : MAIL NOT SEND DUE\
                        TO NO TO ADDRESS GIVEN")
                    UnprocessableEntity("Cannot Send Mail")

                #  Adds and commits Employee details
                db.session.add(usermodel)
                db.session.commit()
                print("hi--------------")
                return {
                        "result": "success",
                        "internal_users": users,
                        "count": len(users),
                        "error": None
                        }
        except Exception as e:
            LOG.error(e)
