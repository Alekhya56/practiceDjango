from datetime import datetime

from flask import flash, request
from flask_login import current_user, login_required
from flask_restx import Resource
from werkzeug.datastructures import ImmutableMultiDict

from ... import LOG
from ...models import db
from ...models.users import Users
from . import ns
from .admin import get_users


@ns.route("/update")
class UpdateUser(Resource):
    """Updates employee details.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Internal_users  : dict
                    Active and inactive employees with 'Success' string

    """

    @login_required
    def post(self):
        try:
            # collecting data from request
            dataframelist = request.form
            imd = ImmutableMultiDict(dataframelist)
            imd1 = imd.to_dict(flat=False)

            users = get_users()
            # Admin can't edit his own details
            if str(current_user.Email) == str(imd1['email']):
                flash("Admin can't update his own details")
                return {
                        "result": "success",
                        "internal_users": users,
                        "count": len(users),
                        "error": None
                        }

            # Filtering Employee by giving empolyee_id
            user = Users.query.filter_by(Email=imd1['email'][0]).first()
            if user:
                t = datetime.today()
                # Updating new vaues into employee details
                user.Email = imd1["email"][0]
                user.UserName = imd1["name"][0]
                user.Action_by = current_user.Email
                user.Last_Modified = t.strftime("%d.%m.%Y %H:%M:%S")
                user.Action = "UPDATE"
                user.Role = imd1["role"][0]
                user.Status = imd1["status"][0]
                db.session.commit()
            return {
                    "result": "success",
                    "internal_users": users,
                    "count": len(users),
                    "error": None
                    }
        except Exception as e:
            LOG.error("Exception while updating user details", e)
