from flask import flash, make_response, render_template
from flask_login import current_user, login_required
from flask_restx import Resource

from ... import LOG
from ...models.users import Users
from . import ns


def get_users():

    """Get list of active and inactive employees.

        Parameters:
        -----------
        Parms : None.

        Returns:
        -----------
        response : dict
                Employee details with active and inactive status.
    """
    """ quering employee which don't have status of
    delete' and excluding current logged in user """
    users = Users.query.filter((Users.Email != current_user.Email) & (Users.Status!='DELETE')).all()
    response = []
    for user in users:
        response.append({
            "username": user.UserName,
            "email": user.Email,
            "LastLogin": user.LastLogin,
            "role": user.Role,
            "status": user.Status,
        }
        )
    return response


@ns.route("/admin")
class Admin(Resource):

    """Gets active and inactive employees and render template with same

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Internal_users : dict
                    Render admin.html template with employee details

    """
    @login_required
    def get(self):
        try:
            response = get_users()
            return make_response(render_template(
                "admin.html",
                internal_users=response,
                count=len(response)))
        except Exception as e:
            LOG.error(e)
