from datetime import date

from flask import make_response, render_template, request
from flask_login import current_user, login_required
from flask_restx import Resource
from sqlalchemy import func, text
from werkzeug.datastructures import ImmutableMultiDict

from ... import LOG
from ...models import db
from ...models.monthly_reports import MultiPolicy
from . import ns

today_date = date.today()

@ns.route("/search_customer")
class ViewIur(Resource):

    """Gets policy details

        returns:
        -----------
        Records : dict
                Render dashboard.html template with policy details.

    """
    @login_required
    def get(self):
        try:
            records = []
            dataframelist = request.args
            imd = ImmutableMultiDict(dataframelist)
            imd1 = imd.to_dict(flat=False)
            client_id = imd1['client_id'][0]
            client_name = imd1['client_name'][0]
            lastupdateby = imd1['updated_by'][0]
            page = imd1['page'][0]
            offset = imd1['offset'][0]
            limit = imd1['limit'][0]
            if lastupdateby == '':
                lastupdateby = None
            if client_name == '':
                client_name = None
            if client_id =='':
                client_id = None
            queries = []

            if page == 'Dashboard':
                queries = db.session.query(MultiPolicy.ClientId, MultiPolicy.ClientName, func.count(MultiPolicy.ClientId),
                                func.sum(MultiPolicy.CoverageLevelSumInsured_Reporting)).filter(
                                    (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))

            elif page == 'History':
                queries = db.session.query(MultiPolicy.ClientId, MultiPolicy.ClientName, func.count(MultiPolicy.ClientId),
                                func.sum(MultiPolicy.CoverageLevelSumInsured_Reporting)).filter(
                                    (MultiPolicy.Status=='COMPLETED')  & ((func.datediff(text('day'),
                                MultiPolicy.LastUpdatedDate, today_date)<30)))
            if client_id:
                queries = queries.filter(MultiPolicy.ClientId.ilike(f'%{client_id}%'))
            if client_name:
                queries = queries.filter(MultiPolicy.ClientName.ilike(f'%{client_name}%'))
            if lastupdateby:
                queries = queries.filter(MultiPolicy.LastUpdatedBy.ilike(f'%{lastupdateby}%'))
            total_record_count = queries.group_by(MultiPolicy.ClientId, MultiPolicy.ClientName).count()
            queries = queries.group_by(MultiPolicy.ClientId, MultiPolicy.ClientName).order_by(MultiPolicy.ClientId).offset(offset).limit(limit).all()

            count = len(queries)
            for rec in queries:
                other_data = risk_iur_count(rec, page)
                records.append({
                    "ClientId":int(rec[0]),
                    "ClientName":rec[1],
                    "records_count":rec[2],
                    "gt_600k": "Yes" if rec[3] > 600000 else "No",
                    "Status":other_data[5],
                    "LastUpdatedBy":other_data[2],
                    "LastUpdatedDate":other_data[3],
                    "EntryDate":other_data[4],
                    "Risk_Count" :other_data[0],
                    "Iur_Count": other_data[1]
                })

            if page=="Dashboard":
                return make_response(render_template('dashboard.html', records=records, count = count,
                                        total_record_count = total_record_count))
            else:
                return make_response(render_template('history.html', records=records, count = count,
                                        total_record_count = total_record_count))
        except Exception as e:
            LOG.error(e)


def risk_iur_count(rec,page):
    try:
        if page == 'History':
            iur_records = db.session.query(MultiPolicy.RiskAddressId,
                        MultiPolicy.ItemNumber).filter((MultiPolicy.ClientId == int(rec[0])) & (
                        MultiPolicy.Status =='COMPLETED')).all()

            lastupdated = db.session.query(MultiPolicy.LastUpdatedBy, MultiPolicy.LastUpdatedDate,
                            MultiPolicy.EntryDate,MultiPolicy.Status).filter((
                            MultiPolicy.ClientId == int(rec[0])) & (MultiPolicy.Status =='COMPLETED')).first()

            iur_count = db.session.query(MultiPolicy.IUR_Number).filter((
                            MultiPolicy.ClientId == int(rec[0])) & (MultiPolicy.Status =='COMPLETED')).distinct().count()

        if page == 'Dashboard':
            iur_records = db.session.query(MultiPolicy.RiskAddressId,
                        MultiPolicy.ItemNumber).filter((MultiPolicy.ClientId == int(rec[0])) & (
                        (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).all()

            lastupdated = db.session.query(MultiPolicy.LastUpdatedBy, MultiPolicy.LastUpdatedDate,
                            MultiPolicy.EntryDate,MultiPolicy.Status).filter((
                            MultiPolicy.ClientId == int(rec[0])) & (
                            (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).first()

            iur_count = db.session.query(MultiPolicy.IUR_Number).filter((
                            MultiPolicy.ClientId == int(rec[0])) & (
                            (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).distinct().count()

        risk = len(set(iur_records))
        if lastupdated.LastUpdatedBy:
            LastUpdatedBy=lastupdated.LastUpdatedBy
        else:
            LastUpdatedBy=''
        if lastupdated.LastUpdatedDate:
            LastUpdatedDate=lastupdated.LastUpdatedDate
        else:
            LastUpdatedDate=''

        return (risk, iur_count, LastUpdatedBy, LastUpdatedDate,
                lastupdated.EntryDate, lastupdated.Status)

    except Exception as e:
        LOG.error(e)