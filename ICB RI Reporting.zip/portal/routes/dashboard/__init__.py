from ...api import api

ns = api.namespace('dashboard')
