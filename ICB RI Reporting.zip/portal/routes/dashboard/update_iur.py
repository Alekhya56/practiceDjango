from datetime import date

from flask import flash, redirect, request, url_for
from flask_login import current_user, login_required
from flask_restx import Resource

from ... import LOG
from ...models import db
from ...models.iur_history import IurHistory
from ...models.monthly_reports import MultiPolicy
from . import ns


@ns.route("/update_iur")
class UpdateIur(Resource):

    """ Updates iur value

        returns:
        -----------
        IUR : dict
            Updates IUR and and render to iur page.

    """
    @login_required
    def post(self):
        try:
            today_date = date.today()
            new_iur = []
            clientid = request.form.get('clientid')
            new_iur.append(clientid)
            new_iur.append(request.form.get('iurdecimal'))
            new_iur = "-".join(new_iur)
            # storing RiskAddresId of latest IURnumber
            latest_risk_ids = db.session.query(MultiPolicy.RiskAddressId).filter(
            (MultiPolicy.IUR_Number == new_iur) &
            ((MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).all()

            list_latest_risk_id = []
            for record in latest_risk_ids:
                list_latest_risk_id.append(record.RiskAddressId)
            list_latest_risk_id = set(list_latest_risk_id)
            list_latest_risk_id = ','.join(list_latest_risk_id)

            from sqlalchemy.orm import load_only

            fields = ['ClientId','PolicyNumber', 'RiskAddress', 'RiskAddressId','SubProductDescription', 'IUR_Number']
            all_records = db.session.query(MultiPolicy).options(load_only(*fields)).filter(
                (MultiPolicy.RiskAddressId==request.form.get('myRiskAddress')) & (
                (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).all()

            # storing RiskAddresId of old IURnumber
            list_prev_risk_id = []
            old_iur = set()
            for record in all_records:
                old_iur.add(record.IUR_Number)
                list_prev_risk_id.append(record.RiskAddressId)

            list_prev_risk_id = set(list_prev_risk_id)
            list_prev_risk_id = ','.join(list_prev_risk_id)

            for record in all_records:
                record.IUR_Number = new_iur
                db.session.add(record)
                db.session.commit()

            all_clients = db.session.query(MultiPolicy).options(load_only(*fields)).filter((MultiPolicy.ClientId == clientid)
            & ((MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).all()
            for record in all_clients:
                record.LastUpdatedDate = today_date
                record.LastUpdatedBy = current_user.UserName
                db.session.add(record)
                db.session.commit()

            # storing updated records into IurHistory table
            record_info = all_records[0]
            # print("record_info:",old_iur[:])
            new_record = IurHistory(
                PrevIurNumber = next(iter(old_iur)),
                LatestIurNumber= new_iur,
                ClientId=record_info.ClientId,
                PolicyNumber =record_info.PolicyNumber,
                RiskLine = record_info.RiskLine,
                RiskAddress = record_info.RiskAddress,
                LatestRiskAddressId = list_latest_risk_id,
                PrevRiskAddressId = list_prev_risk_id,
                SubProductDescription = record_info.SubProductDescription,
                LastUpdatedBy = current_user.UserName,
                LastUpdatedDate = today_date,)
            db.session.add(new_record)
            db.session.commit()

            flash('IUR Updated Successfully')
            return redirect(url_for('api.dashboard_view_iur'))
        except Exception as e:
            LOG.error(e)
