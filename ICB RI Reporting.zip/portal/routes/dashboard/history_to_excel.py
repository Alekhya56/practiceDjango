from os import remove

from flask_login import login_required
from flask_restx import Resource

from ... import APP
from . import ns
from .download_to_excel import excel


@ns.route("/history_to_excel")
class DownloadToExcel(Resource):

    """Gets policy details

        returns:
        -----------
        File : Iur_data_history.xlsx
                Downloads a excel file with current data in 'history page'.
    """

    @login_required
    def post(self):
        try:
            page = 'history'
            save_path = excel(page)
            def generate():
                with open(save_path,'rb') as f:
                    yield from f
                remove(save_path)

            r = APP.response_class(generate(), mimetype='text/csv')
            r.headers.set('Content-Disposition', 'attachment', filename=f'Iur_data_history.xlsx')
            return r
        except Exception as e:
            print(e)
