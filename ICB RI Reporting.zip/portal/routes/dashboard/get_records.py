from datetime import date

from flask import make_response, render_template, request
from flask_login import current_user, login_required
from flask_restx import Resource
from sqlalchemy import func, text
from werkzeug.datastructures import ImmutableMultiDict

from ... import LOG
from ...models import db
from ...models.monthly_reports import MultiPolicy
from . import ns

today_date = date.today()

@ns.route("/view_iur")
class ViewIur(Resource):

    """Gets policy details

        returns:
        -----------
        Records : dict
                Render dashboard.html template with policy details.

    """
    @login_required
    def get(self):
        try:
            try:
                dataframelist = request.args
                imd = ImmutableMultiDict(dataframelist)
                imd1 = imd.to_dict(flat=False)
                offset = imd1['offset'][0]
                limit = imd1['limit'][0]
            except:
                offset = request.form.get('offset',0)
                limit = request.form.get('limit',10)
            page = 'Dashboard'
            records = dashboard(page,offset,limit)
            return make_response(render_template('dashboard.html', records=records[0], count = records[1], total_record_count = records[2]))
        except Exception as e:
            LOG.error(e)
    def post(self):
        try:
            dataframelist = request.form
            imd = ImmutableMultiDict(dataframelist)
            imd1 = imd.to_dict(flat=False)
            if imd1['status'][0] != 'HOLD':
                status = None
            else:
                status = imd1['status'][0]

            # update status,lastupdated details by fetching with clientid
            db.session.query(MultiPolicy).filter((MultiPolicy.ClientId == imd1['client_id'][0])
            & ((MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).update(
                {'Status': status,'LastUpdatedDate':today_date,'LastUpdatedBy':current_user.UserName})
            db.session.commit()
        except Exception as e:
            LOG.error(e)

def dashboard(page,offset,limit):
        try:
            records = []
            # Grouping values of clientid, client name
            if page == 'Dashboard':
                total_record_count = db.session.query(MultiPolicy.ClientId).filter(
                                        (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None))).group_by(
                                        MultiPolicy.ClientId,MultiPolicy.ClientName).count()

                record = db.session.query(MultiPolicy.ClientId,MultiPolicy.ClientName,func.count(MultiPolicy.ClientId),
                                    func.sum(MultiPolicy.CoverageLevelSumInsured_Reporting)).filter(
                                        (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None))).group_by(
                                        MultiPolicy.ClientId,MultiPolicy.ClientName,
                                        ).order_by(MultiPolicy.ClientId).offset(offset).limit(limit).all()

            elif page == 'History':
                total_record_count =  db.session.query(MultiPolicy.ClientId).filter_by(Status='COMPLETED').group_by(
                                        MultiPolicy.ClientId,MultiPolicy.ClientName).count()

                record = db.session.query(MultiPolicy.ClientId,MultiPolicy.ClientName,func.count(MultiPolicy.ClientId),
                                    func.sum(MultiPolicy.CoverageLevelSumInsured_Reporting)).filter((
                                        MultiPolicy.Status=='COMPLETED') & (func.datediff(text('day'),
                                MultiPolicy.LastUpdatedDate, today_date)<30)).group_by(
                                        MultiPolicy.ClientId,MultiPolicy.ClientName,
                                        ).order_by(MultiPolicy.ClientId).offset(offset).limit(limit).all()
            count = len(record)
            for rec in record:
                other_data = risk_iur_count(rec,page)
                records.append({
                    "ClientId":int(rec[0]) ,
                    "ClientName":rec[1] ,
                    "records_count":rec[2],
                    "gt_600k": "Yes" if rec[3] > 600000 else "No",
                    "Status":other_data[5],
                    "LastUpdatedBy":other_data[2],
                    "LastUpdatedDate":other_data[3],
                    "EntryDate":other_data[4],
                    "Risk_Count" :other_data[0],
                    "Iur_Count": other_data[1]
                })

            return records, count, total_record_count

        except Exception as e:
            LOG.error(e)

def risk_iur_count(rec,page):
    try:
        if page == 'History':
            # fetching records to calculate 'RiskAddressId'
            iur_records = db.session.query(MultiPolicy.RiskAddressId,
                        MultiPolicy.ItemNumber).filter((MultiPolicy.ClientId == int(rec[0])) & (
                        MultiPolicy.Status =='COMPLETED')).all()

            # fetching records to get lastupdated details
            lastupdated = db.session.query(MultiPolicy.LastUpdatedBy, MultiPolicy.LastUpdatedDate,
                            MultiPolicy.EntryDate,MultiPolicy.Status).filter((
                            MultiPolicy.ClientId == int(rec[0])) & (MultiPolicy.Status =='COMPLETED')).first()

            # fetching records to get count of IURnumber
            iur_count = db.session.query(MultiPolicy.IUR_Number).filter((
                            MultiPolicy.ClientId == int(rec[0])) & (MultiPolicy.Status =='COMPLETED')).distinct().count()

        if page == 'Dashboard':
            iur_records = db.session.query(MultiPolicy.RiskAddressId,
                        MultiPolicy.ItemNumber).filter((MultiPolicy.ClientId == int(rec[0])) & (
                        (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).all()

            lastupdated = db.session.query(MultiPolicy.LastUpdatedBy, MultiPolicy.LastUpdatedDate,
                            MultiPolicy.EntryDate,MultiPolicy.Status).filter((
                            MultiPolicy.ClientId == int(rec[0])) & (
                            (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).first()

            iur_count = db.session.query(MultiPolicy.IUR_Number).filter((
                            MultiPolicy.ClientId == int(rec[0])) & (
                            (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).distinct().count()

        risk = len(set(iur_records))
        if lastupdated.LastUpdatedBy:
            LastUpdatedBy=lastupdated.LastUpdatedBy
        else:
            LastUpdatedBy=''
        if lastupdated.LastUpdatedDate:
            LastUpdatedDate=lastupdated.LastUpdatedDate
        else:
            LastUpdatedDate=''

        return (risk, iur_count, LastUpdatedBy, LastUpdatedDate,
                lastupdated.EntryDate, lastupdated.Status)

    except Exception as e:
        LOG.error(e)