from flask import make_response, render_template, request
from flask_login import login_required
from flask_restx import Resource
from werkzeug.datastructures import ImmutableMultiDict

from ... import LOG
from . import ns
from .get_records import dashboard


@ns.route("/iur_history")
class ViewIur(Resource):

    """Gets policy details

        returns:
        -----------
        Records : dict
                Render dashboard.html template with policy details with the status of 'RELEASE'.

    """
    @login_required
    def get(self):
        try:
            try:
                dataframelist = request.args
                imd = ImmutableMultiDict(dataframelist)
                imd1 = imd.to_dict(flat=False)
                # print(imd1)
                offset = imd1['offset'][0]
                limit = imd1['limit'][0]
            except:
                offset = request.form.get('offset',0)
                limit = request.form.get('limit',10)
            page = 'History'
            records = dashboard(page,offset,limit)
            return make_response(render_template('history.html', records=records[0], count = records[1], total_record_count = records[2]))
        except Exception as e:
            LOG.error(e)
