from datetime import datetime

from flask import request
from flask_login import current_user, login_required
from flask_restx import Resource

from ... import LOG
from ...models import db
from ...models.monthly_reports import MultiPolicy
from . import ns


@ns.route("/get_view_values")
class GetViewValues(Resource):

    """Gets policy details for clientid
        returns:
        -----------
        Policy_details : dict
                    Return records.

    """
    @login_required
    def post(self):
        try:
            current_records = []
            prev_records = []
            res = set()
            riskaddressids = set()
            prev_records =[]
            prev_records_count =None
            today = datetime.now()
            page = request.form.get('page')
            if page == 'Dashboard':
                # fetches the records which have status of not 'COMPLETE'
                current_iur_records = MultiPolicy.query.filter((MultiPolicy.ClientId == request.form.get('clientid'))&(
                    (MultiPolicy.Status == 'HOLD') | (MultiPolicy.Status.is_(None)))).all()
                prev_iur_records = MultiPolicy.query.filter_by(ClientId = request.form.get('clientid'), Status='COMPLETED').all()

                # Updates lastupdatedDate when open view/edit mode
                MultiPolicy.query.filter((MultiPolicy.ClientId == request.form.get('clientid'))&
                    (MultiPolicy.Status != 'COMPLETED')).update(
                    {'LastUpdatedDate':today,'LastUpdatedBy':current_user.UserName})
                db.session.commit()

                prev_records_count = len(prev_iur_records)

                for prev_record in prev_iur_records:
                    prev_records.append({
                        "RiskAddress":prev_record.RiskAddress ,
                        "RiskAddressId":prev_record.RiskAddressId ,
                        "TransactionType":prev_record.TransactionType,
                        "IUR_Number": prev_record.IUR_Number ,
                        "SubProductDescription":prev_record.SubProductDescription ,
                        "PolicyNumber":prev_record.PolicyNumber ,
                        "ItemNumber": prev_record.ItemNumber
                    })

                # getting unique dicts
                prev_records = list({(record['RiskAddress'], record['RiskAddressId'],record['TransactionType'], record['IUR_Number'], \
                    record['SubProductDescription'], record['PolicyNumber'], record['ItemNumber']):record \
                        for record in prev_records}.values())

                # prev_records = list({(record['LastUpdatedDate']):record for record in prev_records}.values())
                prev_records_count = len(prev_records)
            elif page == 'History':
                current_iur_records = MultiPolicy.query.filter((MultiPolicy.ClientId == request.form.get('clientid'))&(
                    MultiPolicy.Status == 'COMPLETED')).order_by(MultiPolicy.IUR_Number).all()
            current_records_count = len(current_iur_records)
            for iur_record in current_iur_records:
                def IcbShare(coverage_premium,ri):
                    if ri is None or ri == 0:
                        return f"{coverage_premium:,}"
                    else:
                        return f"{(coverage_premium*(ri/100)):,}"
                current_records.append({
                "ClientId":iur_record.ClientId,
                "ClientName":iur_record.ClientName,
                "RiskAddress":iur_record.RiskAddress ,
                "RiskAddressId":iur_record.RiskAddressId ,
                "TransactionType":iur_record.TransactionType,
                "RecordId":iur_record.id ,
                "IUR_Number": iur_record.IUR_Number ,
                "SubProductDescription":iur_record.SubProductDescription ,
                "PolicyNumber":iur_record.PolicyNumber ,
                "ItemNumber": iur_record.ItemNumber ,
                "CoverageDEscription" : iur_record.CoverageDescription ,
                "CoverageLevelSumInsured": IcbShare(iur_record.CoverageLevelSumInsured_Reporting, iur_record.RI),
                "CoveragePremium": IcbShare(iur_record.CoveragePremium, iur_record.RI)
                    })
                res.add(iur_record.IUR_Number)
                riskaddressids.add(iur_record.RiskAddressId)
            ## This function that takes a string, and returns its last letter.
            ## This will be the key function (takes in 1 value, returns 1 value).
            def SplitNumber(record):
                # record = record['IUR_Number']
                return int(record.split('-')[1])

            ## Now pass key=MyFn to sorted() to sort by the last letter:
            # current_records = sorted(current_records, key=SplitNumber)
            # prev_records = sorted(current_records, key=SplitNumber)
            res = sorted(res,key=SplitNumber)
            res = list(res)
            p = str(res[len(res)-1]).split('-')
            return {"records":current_records,"prev_records":prev_records ,"current_records_count":current_records_count,
             "prev_records_count":prev_records_count, "max_value":p[1], "unique_val":res,'risk_address_ids':list(riskaddressids)}
        except Exception as e:
            LOG.error(e)
