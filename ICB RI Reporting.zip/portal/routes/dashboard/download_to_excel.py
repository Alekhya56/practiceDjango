from os import remove,path
from datetime import date
from sqlalchemy import func, text
from flask_login import login_required
from flask_restx import Resource
from openpyxl import load_workbook
from openpyxl.styles.borders import Border, Side

from ... import APP
from ...models import db
from ...models.monthly_reports import MultiPolicy
from . import ns

today_date = date.today()
@ns.route("/download_to_excel")
class DownloadToExcel(Resource):

    """Gets policy details

        returns:
        -----------
        File : Iur_data.xlsx
                Downloads a excel file with current data in 'IUR data validation page'.

    """
    @login_required
    def post(self):
        try:
            page = 'dashboard'
            save_path = excel(page)
            def generate():
                with open(save_path,'rb') as f:
                    yield from f
                remove(save_path)

            r = APP.response_class(generate(), mimetype='text/csv')
            r.headers.set('Content-Disposition', 'attachment', filename=f'Iur_data.xlsx')
            return r
        except Exception as e:
            print(e)

def excel(page):
        try:
            file_name = f'download_records.xlsx'
            excel_url = APP.config['EXCEL_URL']
            temp_url = APP.config['TEMP_URL']
            file_path = path.abspath(path.join(excel_url, file_name))

            if page == 'dashboard':
                save_path = path.abspath(path.join(temp_url, "Iur_data.xlsx"))
                rows = MultiPolicy.query.filter((MultiPolicy.Status=='HOLD')|MultiPolicy.Status.is_(None)).all()
            else:
                save_path = path.abspath(path.join(temp_url, "Iur_data_history.xlsx"))
                rows = MultiPolicy.query.filter((MultiPolicy.Status=='COMPLETE') & (func.datediff(text('day'),
                                MultiPolicy.LastUpdatedDate, today_date)<30)).all()

            sheet_name ="Sheet1"
            thin_border = Border(left=Side(style='thin'),
                        right=Side(style='thin'),
                        top=Side(style='thin'),
                        bottom=Side(style='thin'))
            wb = load_workbook(file_path)
            sheet= wb.active
            row=3

            if sheet_name in wb.sheetnames:
                #to check whether sheet you need already exists
                for r in rows:
                    sheet.cell(row=row, column=1).value = r.ClientId
                    sheet.cell(row=row, column=2).value = r.ClientName
                    sheet.cell(row=row, column=3).value = r.IUR_Number
                    sheet.cell(row=row, column=4).value = r.RiskAddress
                    sheet.cell(row=row, column=5).value = r.RiskLine
                    sheet.cell(row=row, column=6).value = r.SubProductDescription
                    sheet.cell(row=row, column=7).value = r.PolicyNumber
                    sheet.cell(row=row, column=8).value = r.ItemNumber
                    sheet.cell(row=row, column=9).value = r.CoverageDescription
                    sheet.cell(row=row, column=10).value = r.CoverageLevelSumInsured_Reporting
                    sheet.cell(row=row, column=11).value = r.CoveragePremium
                    sheet.cell(row=row, column=12).value = r.EntryDate
                    sheet.cell(row=row, column=13).value = r.LastUpdatedDate
                    sheet.cell(row=row, column=14).value = r.LastUpdatedBy
                    sheet.cell(row=row, column=15).value = r.Status

                    for i in range(1,16):
                        sheet.cell(row=row, column=i).border = thin_border

                    row +=1
            wb.save(save_path)
            return save_path

        except Exception as e:
            print(e)
