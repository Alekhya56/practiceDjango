from flask import make_response, render_template
from flask_login import login_required, logout_user
from flask_restx import Resource
from werkzeug.exceptions import InternalServerError

from ... import LOG
from . import ns


@ns.route("/logout")
class Logout(Resource):
    """Employee logs out and redirect to login page.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirects : html page
                Redirects to login page
    """

    @login_required
    def get(self):
        try:
            logout_user()
            return make_response(render_template("index.html"))
        except Exception as e:
            LOG.error(e)
            raise InternalServerError()
