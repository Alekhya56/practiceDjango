from datetime import datetime

from flask import (flash, make_response, redirect, render_template, request,
                   url_for)
from flask_login import current_user, login_required
from flask_restx import Resource
from werkzeug.datastructures import ImmutableMultiDict
from werkzeug.exceptions import UnprocessableEntity

from ... import LOG
from ...encryption import Encryption
from ...models import db
from ...models.users import Users
from . import ns


@ns.route("/change")
class PasswordChange(Resource):
    """Updates old password with requested new password.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirect : url
                Redirects to login page.

    """

    @login_required
    def post(self):
        try:
            # collecting data from request
            dataframelist = request.form
            imd = ImmutableMultiDict(dataframelist)
            imd1 = imd.to_dict(flat=False)
            old_pass = imd1["oldpassword"][0]
            new_pass = imd1["newpassword"][0]

            #  Filters the employee with email who is currently logged in.
            user = Users.query.filter_by(Email=current_user.Email).first()
            if user is None:
                flash('Username is not valid')
                raise UnprocessableEntity('Username is not valid')
            # Checks for if old password is correct or not.
            if user.Password != Encryption().encrypt(old_pass):
                flash("Entered Old password is incorrect")
                return make_response(
                    render_template(
                        "index.html",
                        temp="temppass"))
            # Encrypts and updates new password
            new_password = Encryption().encrypt(new_pass)
            user.Password = new_password
            if user.LastThreePasswords is None:
                user.LastThreePasswords = new_password
            else:
                pass_list = (user.LastThreePasswords).split(",")
                if new_password in pass_list:
                    flash("Your current password cannot be \
                    same as your last 3 passwords")
                    return make_response(
                        render_template(
                            "index.html",
                            temp="temppass"))
                if len(pass_list) >= 3:
                    pass_list.pop(0)
                pass_list.append(new_password)
                user.LastThreePasswords = ",".join(pass_list)
            user.TemporaryPassword = False
            today = datetime.today().replace(microsecond=0)
            user.LastPasswordChanged = today.strftime('%Y-%m-%d %H:%M:%S')
            user.Action = "Reset Password"
            db.session.commit()
            flash("Your password has been successfully reset")
            return redirect(url_for('api.auth_login'))
        except Exception as e:
            LOG.error(e)
