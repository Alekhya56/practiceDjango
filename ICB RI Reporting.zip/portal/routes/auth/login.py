from datetime import datetime

from flask import (flash, make_response, redirect, render_template, request,
                   url_for)
from flask_login import login_user
from flask_restx import Resource
from werkzeug.datastructures import ImmutableMultiDict
from werkzeug.exceptions import InternalServerError

from ... import LOG
from ...encryption import Encryption
from ...models import db
from ...models.users import Users
from . import ns


@ns.route('/login')
class Login(Resource):

    """Only Active employees can login, employee
    redirect to respective pages based on their roles.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirects : html page
                Redirects respective page
    """
    index_template = "index.html"
    def get(self):
        return make_response(render_template(self.index_template))

    def post(self):
        try:
            # collecting data from request
            dataframelist = request.form
            imd = ImmutableMultiDict(dataframelist)
            imd1 = imd.to_dict(flat=False)
            email = imd1['email'][0]
            password = imd1['password'][0]
            remember = False
            encrypt_password = Encryption().encrypt(password)

            # Checks given username and password correct or not.
            user = Users.query.filter_by(Email=email,
                                         Password=encrypt_password).first()
            if user is None:
                LOG.debug("Auth failed. Email (%s) or \
                    Password is wrong", email)
                flash("Email Id or Password is incorrect")
                return redirect(url_for('api.auth_login'))

            # Checks if user status Active or not.
            if (user.Status == "INACTIVE"):
                flash("Currently User is INACTIVE, \
                    Please Contact admin for more Information")
                LOG.debug("Auth failed. User is Inactive. \
                            Username:%s, status:%s, role:%s"
                          % (user.UserName, user.Status, user.Role))
                return redirect(url_for('api.auth_login'))
            # Checks if user status DELETE or not.
            if (user.Status == "DELETE"):
                flash("Your account has been disable. Please contact your administrator")
                LOG.debug("Auth failed. User disabled. \
                            Username:%s, status:%s, role:%s"
                          % (user.UserName, user.Status, user.Role))
                return redirect(url_for('api.auth_login'))

            login_user(user, remember=remember)
            today = datetime.today().replace(microsecond=0)
            user.LastLogin = today.strftime('%Y-%m-%d %H:%M:%S')
            db.session.commit()
            # Checks if user.LastPasswordChanged exceeds 90 days or not.
            if user.Role != "Admin" and user.LastPasswordChanged is not None:
                passwordchange = datetime.strptime(
                    user.LastPasswordChanged, '%Y-%m-%d %H:%M:%S')
                if int((today - passwordchange).days)+1 == 89:
                    flash("Your password will expire in 1 day")
                if int((today - passwordchange).days)+1 >= 90:
                    flash("Your password is going expire today")
                    return make_response(render_template(
                        self.index_template, timetoreset="reset"))

            if user.TemporaryPassword:
                return make_response(render_template(
                    self.index_template, temp="temppass"))
            # if user.Role == "Admin":
            #     return redirect(url_for("api.admin_admin"))

            return redirect(url_for('api.dashboard_view_iur'))

        except Exception as e:
            LOG.error('Exception happened during authenticating user: %s', e)
            raise InternalServerError(e)
