from ...api import api

ns = api.namespace('auth')

