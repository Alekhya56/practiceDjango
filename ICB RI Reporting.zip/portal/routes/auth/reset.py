from flask import flash, request
from flask_restx import Resource
from werkzeug.datastructures import ImmutableMultiDict
from werkzeug.exceptions import InternalServerError

from ... import LOG
from ...encryption import Encryption
from ...helpers import random_string_with_digits_and_symbols, send_email
from ...models import db
from ...models.users import Users
from . import ns


def _change_password(user):
    try:
        password = random_string_with_digits_and_symbols()
        pass_encrypt = Encryption().encrypt(password)
        user.Password = pass_encrypt
        user.TemporaryPassword = True
        message = f'<p>Dear {user.UserName}</p>' + \
                  f'<p>We have received a request to reset\
                       your password <p>' + \
                  f'<p>Please use this below temporary password to \
                      set up a new password to your account. <p>' + \
                  f'<p>Password: <b style="color:red">{password}</b></p>'
        db.session.commit()
        flash("Email with temporary password has been \
            successsfully sent to your registered email Id")
        cc = []
        send_email(
                    body=message,
                    subject='Password Setup',
                    cc=cc,
                    to_address=[user.Email]
                    )
        return {"result": "Success"}

    except Exception as e:
        LOG.error('Unexpected error happened during \
            changing password: %s', e)
        raise InternalServerError(e)


@ns.route("/reset")
class PasswordReset(Resource):
    """A new temporary password will send to the given mail.

        returns:
        -----------
        Redirects : success
                send mail to given email id.

    """
    def post(self):
        try:
            dataframelist = request.form
            imd = ImmutableMultiDict(dataframelist)
            imd1 = imd.to_dict(flat=False)

            user = Users.query.filter(Users.Email == imd1['email'][0]).first()
            if user is None:
                flash("User doesn't exists with this email")
                return {
                    "result": "failure",
                    "error": "User doesn't exists with this email"}
            if user.Status == "INACTIVE":
                flash("User is Inactive. Please conatct admin for more information")
                return {"result": "failure", "error": "User is Inactive"}

            if "resetradiono" in imd1 and imd1['resetradiono'][0] == 'no' and imd1['password'] != ['']:
                user.TemporaryPassword = False
                user.Password = Encryption().encrypt(imd1['password'][0])
                db.session.commit()
                flash("Your password has been updated")
                return {"result": "Success"}
            else:
                return _change_password(user)

        except Exception as e:
            LOG.error('Unexpected error happened during \
                changing password: %s', e)
