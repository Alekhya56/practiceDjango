def init_app(app):
    from .auth import login,logout,reset,change
    from .admin import admin,update,create,delete
    from .dashboard import (get_records, update_iur, get_view_values,
                            download_to_excel, history, history_to_excel,search_customer)
    from .reports import get_reports
    app.logger.info("Initialized routes")