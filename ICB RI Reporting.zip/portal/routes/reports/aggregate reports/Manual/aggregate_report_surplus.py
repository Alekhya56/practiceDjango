import pandas as pd
from configobj import ConfigObj
import xlrd
import xlwt
import openpyxl
import datetime
import requests
import pyodbc
import win32
import subprocess
import os
from openpyxl import load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows
import configparser
import math
import xlsxwriter
from io import StringIO
import numpy as np


#config file 
config_links = configparser.ConfigParser()
config_links.read('config_links.ini')

pd.set_option('display.max_rows',500)
pd.set_option('display.max_columns',500)
pd.set_option('display.width',10000)

        
cnxn = pyodbc.connect(Driver=config_links['sql configuration']['Driver'],Server=config_links['sql configuration']['Server'],Database=config_links['sql configuration']['Database'])

cur = cnxn.cursor()


#generating IUR number
appended_data1 = pd.DataFrame()
#single policies
cur.execute("SELECT  distinct(ClientId),COUNT(*) AS SUM FROM  AggregateReport2 group by ClientId HAVING COUNT(*)=1")
onePolicy = cur.fetchall()
cur.commit()
for each in onePolicy:
    df_singlePolicy = pd.read_sql("SELECT  * from  AggregateReport2 where  ClientId = %s"%(each[0]), cnxn)
    df_singlePolicy['IUR Number']=str(each[0])+'-'+str(0)
    appended_data1=appended_data1.append(df_singlePolicy)


appended_data2 = pd.DataFrame()
#multiple Policies
cur = cnxn.cursor()

cur.execute("SELECT  distinct(ClientId),COUNT(*) AS SUM FROM  AggregateReport2 group by ClientId HAVING COUNT(*)>1 ")
multiPolicy = cur.fetchall()
for each in multiPolicy:
    df = pd.read_sql("SELECT  * from AggregateReport2 where  ClientId = %s"%(each[0]), cnxn)
    df1=df['RiskAddressId'].unique()
    for eachl in range(len(df1)):
        df2=df.loc[df['RiskAddressId'] == df1[eachl]]
        df2['IUR Number']=str(each[0])+'-'+str(eachl)
        appended_data2=appended_data2.append(df2)

appended_data2=appended_data2.append(appended_data1)
appended_data2.to_excel(config_links['links']['excel1'],sheet_name='SinglePolicy',index=False)
    

#RI computations

#removingfile
if os.path.exists(config_links['links']['dir1']):
            os.remove(config_links['links']['dir1'])

header = [
    "TransactionType"	,
"Island"	,
"Broker"	,
"PolicyNumber"	,
"SubProductDesc"	,
"SubProduct"	,
"InceptionDate"	,
"ExpiryDate"	,
"InvoiceDate"	,
"ClientId"	,
"ListName"	,
"ItemNo"	,
"CvgeTypeCode"	,
"CoverageTypeDesc"	,
"SumInsured"	,
"Premium"	,
"Rate"	,
"RI"	,
"IC"	,
"Branch"	,
"ProductDescription"	,
"SubProductDescription"	,
"RiskAddressId"	,
"IUR Number","Sum Insured Share-Retention","Sum Insured Share-Quota share","Sum Insured Share-Surplus1","Premium Share-Retention","Premium Share-Quota Share","Premium Share-Surplus1","Sum Insured Share-Surplus2","Premium Share-Surplus2"	


]


excel_file = config_links['links']['excel1']
df = pd.read_excel(excel_file)

 
config = configparser.ConfigParser()
config.read('config_QSsurplus.ini')
liablityTreatyTax=config['Liability Treaty Allocation']['Liability Treaty Allocation']
truksPremiumTax=config['Premium Tax']['TruksPremium Tax']
nottruksPremiumTax=config['Premium Tax']['NotTruksPremium Tax']



#split by treaty
def riSIShareComputationbyTreaty(sumInsuredfinal,premDed,reportRow,liaprem):
    limit=float(config['Limits']['Retention Limit'])
    surplus1limit=float(config['Limits']['Surplus line1'])
    surplus2limit=float(config['Limits']['Surplus line2'])
    icbper=float(config['Retention Percentage']['ICB'])
    qsPer=float(config['Retention Percentage']['Quota Share'])
##    print(sumInsuredfinal[0])
##    print(premDed)
    if ((sumInsuredfinal[0])<=limit):
        icbRetvalue=round(((icbper/100)*sumInsuredfinal[0]),2)
        qsRetvalue=round(((qsPer/100)*sumInsuredfinal[0]),2)
        icbRetper=round(float((icbRetvalue/sumInsuredfinal[0])*100),2)
        qsRetper=round(float((qsRetvalue/sumInsuredfinal[0])*100),2)
        surplusPer1=0
        surplusPer2=0
        lenn=[" " for x in range(len(reportRow)-1)]
        lipre=[str(liaprem)]+lenn
        
        reportRow["Property RI Premium (less Liability Allocation)"]=lipre
        premd=[str(premDed)]+lenn
        reportRow["Property RI Premium (Premium less Premium Tax)"]=premd
        si=[str(sumInsuredfinal[0])]+lenn
        reportRow["Sum Insured"]=si
        
        spr=[str(icbRetper)]+lenn
        reportRow["Share Percentage-Retention"]=spr
        spq=[str(qsRetper)]+lenn
        reportRow["Share Percentage-Quota share"]=spq
        
        sps1=[str(0)]+lenn
        reportRow["Share Percentage-Surplus1"]=sps1
        sps2=[str(0)]+lenn
        reportRow["Share Percentage-Surplus2"]=sps2
        sir=[str(icbRetvalue)]+lenn
        reportRow["Sum Insured Share-Retention"]=sir
        siq=[str(qsRetvalue)]+lenn
        reportRow["Sum Insured Share-Quota share"]=siq
        sis1=[str(0)]+lenn
        reportRow["Sum Insured Share-Surplus1"]=sis1
        sis2=[str(0)]+lenn
        reportRow["Sum Insured Share-Surplus2"]=sis2
        
    elif (((sumInsuredfinal[0])>limit) & ((sumInsuredfinal[0])<=surplus1limit)):
        icbRetvalue=round(((icbper/100)*limit),2)
        qsRetvalue=round(((qsPer/100)*limit),2)
        surplusValue1=sumInsuredfinal[0]-limit
        surplusValue2=0
        icbRetper=round(float((icbRetvalue/sumInsuredfinal[0])*100),2)
        qsRetper=round(float((qsRetvalue/sumInsuredfinal[0])*100),2)
        surplusPer1=round(float((surplusValue1/sumInsuredfinal[0])*100),2)
        surplusPer2=0
        lenn=[" " for x in range(len(reportRow)-1)]
        lipre=[str(liaprem)]+lenn
        reportRow["Property RI Premium (less Liability Allocation)"]=lipre
        premd=[str(premDed)]+lenn
        reportRow["Property RI Premium (Premium less Premium Tax)"]=premd
        si=[str(sumInsuredfinal[0])]+lenn
        reportRow["Sum Insured"]=si
        
        spr=[str(icbRetper)]+lenn
        reportRow["Share Percentage-Retention"]=spr
        spq=[str(qsRetper)]+lenn
        reportRow["Share Percentage-Quota share"]=spq
        
        sps1=[str(round(surplusPer1,2))]+lenn
        reportRow["Share Percentage-Surplus1"]=sps1
        sps2=[str(round(surplusPer2,2))]+lenn
        reportRow["Share Percentage-Surplus2"]=sps2
        sir=[str(icbRetvalue)]+lenn
        reportRow["Sum Insured Share-Retention"]=sir
        siq=[str(qsRetvalue)]+lenn
        reportRow["Sum Insured Share-Quota share"]=siq
        sis1=[str(round((surplusPer1/100)*sumInsuredfinal[0],2))]+lenn
        reportRow["Sum Insured Share-Surplus1"]=sis1
        sis2=[str(0)]+lenn
        reportRow["Sum Insured Share-Surplus2"]=sis2
    
    elif ((sumInsuredfinal[0])>surplus1limit):
        
         #calculation for values from SI
        icbRetvalue=round(((icbper/100)*limit),2)
        qsRetvalue=round(((qsPer/100)*limit),2)
        surplusValue1=surplus1limit-limit
        surplusValue2=sumInsuredfinal[0]-surplusValue1-qsRetvalue-icbRetvalue
        #calculation for percentages from SI
        icbRetper=round(float((icbRetvalue/sumInsuredfinal[0])*100),2)
        qsRetper=round(float((qsRetvalue/sumInsuredfinal[0])*100),2)
        
        surplusPer1=round(float((surplusValue1/sumInsuredfinal[0])*100),2)
        surplusPer2=round(float((surplusValue2/sumInsuredfinal[0])*100),2)

        #code to show value only in first record
        lenn=[" " for x in range(len(reportRow)-1)]
        
        lipre=[str(round(liaprem,2))]+lenn

        #printing values
        reportRow["Property RI Premium (less Liability Allocation)"]=lipre
        premd=[str(round(premDed,2))]+lenn
        reportRow["Property RI Premium (Premium less Premium Tax)"]=premd
        si=[str(round(sumInsuredfinal[0],2))]+lenn
        reportRow["Sum Insured"]=si
        
        spr=[str(round(icbRetper,2))]+lenn
        reportRow["Share Percentage-Retention"]=spr
        spq=[str(round(qsRetper,2))]+lenn
        reportRow["Share Percentage-Quota share"]=spq
        sps1=[str(round(surplusPer1,2))]+lenn
        reportRow["Share Percentage-Surplus1"]=sps1
        sps2=[str(round(surplusPer2,2))]+lenn
        reportRow["Share Percentage-Surplus2"]=sps2
        sir=[str(round((icbRetper/100)*sumInsuredfinal[0],2))]+lenn
        reportRow["Sum Insured Share-Retention"]=sir
        siq=[str(round((qsRetper/100)*sumInsuredfinal[0],2))]+lenn
        reportRow["Sum Insured Share-Quota share"]=siq
        sis1=[str(round((surplusPer1/100)*sumInsuredfinal[0],2))]+lenn
        reportRow["Sum Insured Share-Surplus1"]=sis1
        sis2=[str(round((surplusPer2/100)*sumInsuredfinal[0],2))]+lenn
        reportRow["Sum Insured Share-Surplus2"]=sis2
    return sumInsuredfinal[0],premDed,icbRetper,qsRetper,surplusPer1,surplusPer2



def riPremiumShareComputationbyTreaty(sumInsuredfinal,premDed,icbRetper,qsRetper,surplusPer1,surplusPer2):
       
        sumInsuredfinal=sumInsuredfinal
        premDed=premDed
        icbRetPrem=round((premDed * (icbRetper/100)),2)
        qsPrem=round((premDed * (qsRetper/100)),2)
        surplusPrem1=round((premDed * (surplusPer1/100)),2)
        surplusPrem2=round((premDed * (surplusPer2/100)),2)
        return sumInsuredfinal,premDed,icbRetPrem,qsPrem,surplusPrem1,surplusPrem2


def RICommissionComputationbyTreaty(sumInsuredfinal,subprod_prem,qsRetper,surplusPer1,surplusPer2):
    limit=float(config['Limits']['Retention Limit'])
    surplus1limit=float(config['Limits']['Surplus line1'])
    surplus2limit=float(config['Limits']['Surplus line2'])
    commQsperFP=float(config['QS commissionPercentage']['Full Peril Policies'])
    commQsperExc=float(config['QS commissionPercentage']['Ex - CAT Policies'])
    commQspercar=float(config['QS commissionPercentage']['CAR Policies'])
    commSs1perFP=float(config['SS commissionPercentage']['Full Peril Policies'])
    commSs1perExc=float(config['SS commissionPercentage']['Ex - CAT Policies'])
    commSs1percar=float(config['SS commissionPercentage']['CAR Policies'])
    commSs2perFP=float(config['SS2 commissionPercentage']['Full Peril Policies'])
    commSs2perExc=float(config['SS2 commissionPercentage']['Ex - CAT Policies'])
    commSs2percar=float(config['SS2 commissionPercentage']['CAR Policies'])

    commqsval=[]
    commss1val=[]
    commss2val=[]

    if (sumInsuredfinal<=limit):
        for x in subprod_prem:
            x = x.split(',')
            premComm_qs=round((float(x[0])* (qsRetper/100)),2)
            subproddesc=str(x[1]).strip("['']")
            if '-' in subproddesc:
                subproddesc=subproddesc.split("-")
           
            try:
                try:
                    
                    if config.get('Full Peril Policies list',subproddesc[0].rstrip() ):
                        commqsper=config['QS commissionPercentage']['Full Peril Policies']
                        commss1per=0
                        commss2per=0
                except:
                    try:
                        if config.get('Ex - CAT Policies list', subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['Ex - CAT Policies']
                            commss1per=0
                            commss2per=0
                    except:
                        if config.get('CAR Policies list', subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['CAR Policies']
                            commss1per=0
                            commss2per=0
                            
            except:
                
                commqsper=0
                commss1per=0
                commss2per=0
            
            commqsdedval=round((premComm_qs * (float(commqsper)/100)),2)
            commss1dedval=0
            commss2dedval=0
            commqsval.append(commqsdedval)
            commss1val.append(commss1dedval)
            commss2val.append(commss2dedval)
            

            
        
    elif (((sumInsuredfinal)>limit) & ((sumInsuredfinal)<=surplus1limit)):
        #print(subprod_prem)
        for x in subprod_prem:
            x = x.split(',')
            subproddesc=str(x[1]).strip("['']")
            if '-' in subproddesc:
                subproddesc=subproddesc.split("-")
           # print(x[0])
            premComm_qs=round((float(x[0])* (qsRetper/100)),2)
            premComm_ss1=round((float(x[0])* (surplusPer1/100)),2)
            #print(x[1])
            try:
    
                try:
                    if config.get('Full Peril Policies list', subproddesc[0].rstrip()):
                        commqsper=config['QS commissionPercentage']['Full Peril Policies']
                        commss1per=config['SS commissionPercentage']['Full Peril Policies']
                        commss2per=0
                except:
                    try:
                        
                       if config.get('Ex - CAT Policies list',subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['Ex - CAT Policies']
                            commss1per=config['SS commissionPercentage']['Ex - CAT Policies']
                            commss2per=0
                    except:
                        if config.get('CAR Policies list', subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['CAR Policies']
                            commss1per=config['SS commissionPercentage']['CAR Policies']
                            commss2per=0
            except:
                commqsper=0
                commss1per=0
                commss2per=0
            commqsdedval=round((premComm_qs * (float(commqsper)/100)),2)
            commss1dedval=round((premComm_ss1 * (float(commss1per)/100)),2)
            commss2dedval=0
            commqsval.append(commqsdedval)
            commss1val.append(commss1dedval)
            commss2val.append(commss2dedval)

    elif ((sumInsuredfinal)>surplus1limit):
        #print(subprod_prem)
        for x in subprod_prem:
            x = x.split(',')
            subproddesc=str(x[1]).strip("['']")
            if '-' in subproddesc:
                subproddesc=subproddesc.split("-")
           # print(x[0])
            premComm_qs=round((float(x[0])* (qsRetper/100)),2)
            premComm_ss1=round((float(x[0])* (surplusPer1/100)),2)
            premComm_ss2=round((float(x[0])* (surplusPer2/100)),2)
            #print(x[1])
            try:
    
                try:
                    if config.get('Full Peril Policies list', subproddesc[0].rstrip()):
                        commqsper=config['QS commissionPercentage']['Full Peril Policies']
                        commss1per=config['SS commissionPercentage']['Full Peril Policies']
                        commss2per=config['SS2 commissionPercentage']['Full Peril Policies']
                except:
                    try:
                        
                       if config.get('Ex - CAT Policies list',subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['Ex - CAT Policies']
                            commss1per=config['SS commissionPercentage']['Ex - CAT Policies']
                            commss2per=config['SS2 commissionPercentage']['Ex - CAT Policies']
                    except:
                        if config.get('CAR Policies list', subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['CAR Policies']
                            commss1per=config['SS commissionPercentage']['CAR Policies']
                            commss2per=config['SS2 commissionPercentage']['CAR Policies']
            except:
                commqsper=0
                commss1per=0
                commss2per=0
            commqsdedval=round((premComm_qs * (float(commqsper)/100)),2)
            commss1dedval=round((premComm_ss1 * (float(commss1per)/100)),2)
            commss2dedval=round((premComm_ss2 * (float(commss2per)/100)),2)
            commqsval.append(commqsdedval)
            commss1val.append(commss1dedval)
            commss2val.append(commss2dedval)    
    
    return sum(commqsval), sum(commss1val),sum(commss2val),commqsper,commss1per,commss2per
        

    
        

#premium computation
def grossRetainedPremiumComputation(clientID):
##    df['SumInsured'] = df['SumInsured'].replace(['0'],'0.0000001')
    df['Rate'] = df['Rate'].replace(np.nan, 0)
    df['RI'] = df['RI'].replace(np.nan, 0)
    
    data=df[df['ClientId'] == clientID]
    
    #checking how many IURs does a client hav one or more than one
    iur=data['IUR Number'].unique()
   
    for each in iur:
        #print("============================================================================")
        #stores premium after deduction of liability
        ltpremded=[]
        #stores coverrage level premium of every row
        premDed=[]
        #stores coverrage level si of every row
        sumInsuredfinal=[]
        #stores premium , subproduct of every row
        subprod_prem=[]
        
        reportRow=data[(data['IUR Number']==each)]
        #print(each)
        row=data[(data['IUR Number']==each) & (data['CoverageTypeDesc'] != "Public Liability") & (data['CoverageTypeDesc'] != "Public Liability 250k - 5M")  ]
        #row=row[(row['RI'] == 0.0) | (row['RI'] == "Insurance Co. of The Bahamas Ltd.") ]
        
        for record in row.index:
            
            eachrow=row.loc[[record]]          
            branch=eachrow[['Branch']].values
            Product=eachrow['ProductDescription'].values
            ri=eachrow['Rate'].values
            subProd=eachrow['SubProductDescription'].values
            
            sumInsured=eachrow['SumInsured'].values
            premium=eachrow[['Premium']].values
            

            
            
            
            
            sumInsuredfinal.append(sumInsured)
            #check branch
            if ((branch=='Turks and Caicos') or (branch=='Turks and Caicos (Fidelity)') or (branch=='Turks and Caicos (Acordia)') ):
                
                
                
                #check Product
                if ((Product=='Home - ICB') or (Product=='Contractors All Risks ICB')):
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(liablityTreatyTax)]+lenn
                    reportRow["LiablityTreatyTax"]=Ltt
                    #tax to report
                    ptt=[str(truksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    
                    liablityTreatyAmt=(round((float(liablityTreatyTax) / 100)*float(premium),2))
                    afterDedprem=round(float(premium)-float(liablityTreatyAmt),2)
                    ltpremded.append(afterDedprem)
                    truksPremiumAmt=(round((float(truksPremiumTax) / 100)*float(afterDedprem),2))
##                    print(truksPremiumAmt)
##                    print(liablityTreatyAmt)
                    afterDedprem=round(afterDedprem-float(truksPremiumAmt),2)
##                    print(afterDedprem)
                    #print(afterDedprem)
                    
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))
                
                else:
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(0)]+lenn
                    reportRow["LiablityTreatyTax"]=Ltt
                    #tax to report
                    ptt=[str(truksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    ltpremded.append(round(float(premium),2))
                    afterDedprem=round(float(premium)-((float(truksPremiumTax) / 100)*float(premium)),2)
##                    print(afterDedprem)
                    #print(afterDedprem)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))
                
            else:
                
                #check Product
                if ((Product=='Home - ICB') or (Product=='Contractors All Risks ICB')):
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(liablityTreatyTax)]+lenn
                    reportRow["LiablityTreatyTax"]=Ltt
                    #tax to report
                    ptt=[str(nottruksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    liablityTreatyAmt=(round((float(liablityTreatyTax) / 100)*float(premium),2))
                    afterDedprem=round(float(premium)-float(liablityTreatyAmt),2)
                    ltpremded.append(afterDedprem)
                    nottruksPremiumAmt=(round((float(nottruksPremiumTax) / 100)*float(afterDedprem),2))
                    
##                    print(nottruksPremiumAmt)
##                    print(liablityTreatyAmt)
                    
                    afterDedprem=round(float(afterDedprem)-float(nottruksPremiumAmt),2)
##                    print(afterDedprem)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))
                else:
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(0)]+lenn
                    reportRow["LiablityTreatyTax"]=Ltt
                    #tax to report
                    ptt=[str(nottruksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    ltpremded.append(round(float(premium),2))

                    afterDedprem=round(float(premium)-((float(nottruksPremiumTax) / 100)*float(premium)),2)
##                    print(afterDedprem)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))

            #print(premDed)
        sumInsuredfinal,premDed,icbRetper,qsRetper,surplusPer1,surplusPer2=riSIShareComputationbyTreaty(sum(sumInsuredfinal),(sum(premDed)),reportRow,(sum(ltpremded)))
        sumInsuredfinal,premDed,icbRetPrem,qsPrem,surplusPrem1,surplusPrem2=riPremiumShareComputationbyTreaty(sumInsuredfinal,premDed,icbRetper,qsRetper,surplusPer1,surplusPer2)
        commqsval,commss1val,commss2val,commqsper,commss1per,commss2per=RICommissionComputationbyTreaty(sumInsuredfinal,subprod_prem,qsRetper,surplusPer1,surplusPer2)
        lenn=[" " for x in range(len(reportRow)-1)]
        psr=[str(icbRetPrem)]+lenn
        reportRow["Premium Share-Retention"]=psr
        psq=[str(qsPrem)]+lenn
        reportRow["Premium Share-Quota Share"]=psq   
        pssu=[str(surplusPrem1)]+lenn
        reportRow["Premium Share-Surplus1"]=pssu
        pssu2=[str(surplusPrem2)]+lenn
        reportRow["Premium Share-Surplus2"]=pssu2
        comqsper=[str(commqsper)]+lenn

        reportRow["Premium"]=[str(icbRetPrem+qsPrem+surplusPrem1+surplusPrem2)]+lenn
        
        reportRow["Commission-Quota Share%"]=comqsper
        comqs=[str(commqsval)]+lenn
        reportRow["Commission-Quota Share"]=comqs
        commss1per=round(float(commss1per),2)
        comss1per=[str(commss1per)]+lenn
        reportRow["Commission-Surplus1%"]=comss1per


        commss1val=round(float(commss1val),2)
        comss1=[str(commss1val)]+lenn
        reportRow["Commission-Surplus1"]=comss1

        commss2per=round(float(commss2per),2)
        comss2per=[str(commss2per)]+lenn
        reportRow["Commission-Surplus2%"]=comss2per

        commss2val=round(float(commss2val),2)
        comss2=[str(commss2val)]+lenn
        reportRow["Commission-Surplus2"]=comss2


        
        reportRow.to_csv(config_links['links']['excel2'],columns = header, mode = 'a',index=False,header=False)
        
                
clients=df['ClientId'].unique()
dfheader = pd.DataFrame({'col':header})
dfheader.transpose().to_csv(config_links['links']['excel2'], mode = 'a',index=False,header=False)
for client in clients:
    grossRetainedPremiumComputation(client)




    



        

config = ConfigObj('config.ini')

# #reading data from excel
df = pd.read_excel(config_links['links']['excel3'], sheet_name="rawdata")

book=xlrd.open_workbook(config['exceltemppath']['path'])

fs=book.sheet_by_index(0)
wb = openpyxl.load_workbook(filename=config['exceltemppath']['path'])

fsw=wb['Dataset']
for r in dataframe_to_rows(df, index=False, header=True):
    fsw.append(r)


fsw=wb['Aggregate Summary']
row=5
col=1
gl = {
'new providence' :{"New Providence", "Nassau", "Paradise Island","Lyford Cay"},
'new providence - albany' :{"New Providence - Albany"},
'grand bahama' :{"Grand Bahama","Freeport City","Freeport","Eight Mile Rock","West End","GB","Freeport, Grand Bahama"},
'abaco' :{"Abaco","Spring City","Marsh Harbour","Murphy Town","Green Turtle Cay","Cherokee Sound","Hope Town","Treasure Cay",
     "Bahama Palm","Sandy Point","Dundas Town","Cooper's Town","Coopers Town"},
'great guana cay' :{"Great Guana Cay"},
'acklins':{"Acklins"},
'andros':{"Andros","Morgans Bluff","Kemps Bay The Bluff","Congo Town","San Andros","Staniard Creek","Nicholls Town"},
'berry islands':{"Berry Islands","Great Harbour Cay","Bullocks Harbour"},
'bimini':{"Bimini","Alice Town","Cat Cay"},
'crooked island ':{"Crooked Island"},
'cat island':{"Cat Island","New Bight","Orange Creek","Arthurs Town"},
'eleuthera':{"Eleuthera","Rock Sound","Current","Tarpum Bay","Gregory Town","EL","Governors Harbour",
         "Hatchet Bay","Russell Island","Savannah Sound","Cape Eleuthera","South Palmetto Point","Windermere","Current Settlement","James Cistern"},
'exuma':{"Exuma","Bahama Sound","Georgetown","Tar Bay","Staniel Cay","Hoopers Bay","Farmers Hill","GEORGE TOWN","Georgetown, Tar Bay","Georgetown","Georgetown,","Stevenson"},
'great inagua':{"Inagua","Matthew Town","Matthews Town"},
'harbour island':{"Harbour Island","Dunmore Town"},
'long island':{"Long Island","Cape Santa Maria","Clarence Town","Hamiltons","Stella Maris","Seymours"},
'mayaguana':{"Mayaguana"},
'rum cay':{"Rum Cay"},
'san salvador':{"San Salvador","Cockburn Town"},
'spanish wells':{"Spanish Wells"},
'turks & caicos':{"Turks & Caicos","Providenciales","Grand Turk","North Caicos","South Caicos","Middle Caicos","Parrot Cay"}
}

for each in range(row,26):
 m_val=fsw['B'+str(each)].value
 m_lval=m_val.lower()

 if m_lval in gl.keys():
     homecatSI = homefireSI = commcatSI = commfireSI = conscatSI = consfireSI = contcatSI = contfireSI = 0
     for val in gl[m_lval]:
         lval = val.lower()
         cval = val.upper()
        
         # home 
         homecatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['SumInsured'].sum(),2)
         fsw['C'+str(each)]= homecatSI 
         homefireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['SumInsured'].sum(),2)
         fsw['D'+str(each)]= homefireSI

         # comm
         commcatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['SumInsured'].sum(),2)
         fsw['E'+str(each)]=commcatSI
         commfireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['SumInsured'].sum(),2)
         fsw['F'+str(each)]=commfireSI
    
         # cons
         conscatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['SumInsured'].sum(),2)
         fsw['G'+str(each)]=conscatSI
         consfireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['SumInsured'].sum(),2)
         fsw['H'+str(each)]=consfireSI
    
         # cont
         contcatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['SumInsured'].sum(),2)
         fsw['I'+str(each)]=contcatSI
         contfireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['SumInsured'].sum(),2)
         fsw['J'+str(each)]=contfireSI
                    
row=34
col=1
for each in range(row,55):
 m_val=fsw['B'+str(each)].value
 m_lval=m_val.lower()

 if m_lval in gl.keys():
     homecatP = homefireP = commcatP = commfireP = conscatP = consfireP = contcatP = contfireP = 0
     for val in gl[m_lval]:
         lval = val.lower()
         cval = val.upper()

         # home
         homecatP += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Premium'].sum(),2)
         fsw['C'+str(each)]= homecatP
         homefireP += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Premium'].sum(),2)
         fsw['D'+str(each)]= homefireP

         # comm
         commcatP += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Premium'].sum(),2)
         fsw['E'+str(each)]=commcatP
         commfireP += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Premium'].sum(),2)
         fsw['F'+str(each)]=commfireP

         # cons
         conscatP += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Premium'].sum(),2)
         fsw['G'+str(each)]=conscatP
         consfireP += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Premium'].sum(),2)
         fsw['H'+str(each)]=consfireP

         # cont
         contcatP += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Premium'].sum(),2)
         fsw['I'+str(each)]=contcatP
         contfireP += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Premium'].sum(),2)
         fsw['J'+str(each)]=contfireP


col=1
row=63
df1f = pd.read_excel(config_links['links']['excel1'], sheet_name="SinglePolicy")
for each in range(row,84):
 m_val=fsw['B'+str(each)].value
 m_lval=m_val.lower()

 if m_lval in gl.keys():
     homecatR = homefireR = commcatR = commfireR = conscatR = consfireR = contcatR = contfireR = 0
     for val in gl[m_lval]:
         lval = val.lower()
         cval = val.upper()
         print(cval)
         #homecat
         homcat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))
         print(homcat['IUR Number'].nunique())
         homecatR += homcat['IUR Number'].nunique()
         print(homecatR,"?*")
         fsw['C'+str(each)]=homecatR

         #homefire
         homfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))
         homefireR += homfire['IUR Number'].nunique()
         fsw['D'+str(each)]=homefireR

         #commcat
         commcat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))
         commcatR += commcat['IUR Number'].nunique()
         fsw['E'+str(each)]=commcatR
    
         #commfire
         commfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))
         commfireR += commfire['IUR Number'].nunique()
         fsw['F'+str(each)]=commfireR

         #conscat
         conscat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))
         conscatR += conscat['IUR Number'].nunique()
         fsw['G'+str(each)]=conscatR

         #consfire
         consfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))
         consfireR += consfire['IUR Number'].nunique()
         fsw['H'+str(each)]=consfireR

         #contfire
         contfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))
         contfireR += contfire['IUR Number'].nunique()
         fsw['J'+str(each)]=contfireR

         #contcat
         contcat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))
         contcatR += contcat['IUR Number'].nunique()
         fsw['I'+str(each)]=contcatR
                
fsw['B2']= "100% GROSS PROPERTY AGGREGATES "#AS AT 31st March,2021"
fsw['B31']= "100% GROSS PROPERTY PREMIUMS "#AS AT 31st March,2021"
fsw['B60']= "RISK COUNT "#AS AT 31st March,2021"
fsw['B89']= "AVERAGE RATES "#AS AT 31st March,2021"
fsw['B118']= "AVERAGE SUMS INSURED "#AS AT 31st March,2021"
fsw['B147']= "QUOTA SHARE, SURPLUS  & NET RETENTION AGGREGATES"# AS AT 31st March,2021"
fsw['B180']= "QUOTA SHARE, SURPLUS  & NET RETENTION PREMIUMS "#AS AT 31st March,2021"


#####building,contents split

fsw=wb['Aggregate Summary_By B&C']
fsw['B2']= "100% GROSS PROPERTY AGGREGATES "#AS AT 31st March,2021"
fsw['B32']= "100% GROSS PROPERTY PREMIUMS "#AS AT 31st March,2021"
fsw['B62']= "RISK COUNT SPLIT BY BUILDINGS & CONTENTS "#AS AT 31st March,2021"
fsw['B92']= "AVERAGE RATES"# AS AT 31st March,2021"
fsw['B122']= "AVERAGE SUMS INSURED "#AS AT 31st March,2021"
fsw['B152']= "POLICY COUNT SPLIT"# AS AT 31st March,2021"
row=6
col=1
for each in range(row,27):
 m_val=fsw['B'+str(each)].value
 m_lval=m_val.lower()
 if m_lval in gl.keys():
     homecatb = homecatc = homecatSI = homefireb = homefirec = homefireSI = 0
     commcatb = commcatc = commcatSI = commfireb = commfirec = commfireSI = 0
     conscatb = conscatc = conscatSI = consfireb = consfirec = consfireSI = 0
     contcatb = contcatc = contcatSI = contfireb = contfirec = contfireSI = 0
     for val in gl[m_lval]:
         lval = val.lower()
         cval = val.upper()

         # homebuilding
         homecatb+=round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+'  and SubProduct in '+str(config['Home']['catastrophe']))['SumInsured'].sum(),2)
         fsw['C'+str(each)]= homecatb
         homefireb+=round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['Home']['fire']))['SumInsured'].sum(),2)
         fsw['F'+str(each)]= homefireb

         # homecontents
         homecatc+=round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['Home']['catastrophe']))['SumInsured'].sum(),2)
         fsw['D'+str(each)]= homecatc
         homefirec += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['Home']['fire']))['SumInsured'].sum(),2)
         fsw['G'+str(each)]= homefirec
##        
##         # homecombined
##         homecatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['SumInsured'].sum(),2)
##         fsw['E'+str(each)]= homecatSI
##         homefireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['SumInsured'].sum(),2)
##         fsw['H'+str(each)]= homefireSI

         # commBuilding
         commcatb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['SumInsured'].sum(),2)
         fsw['I'+str(each)]=commcatb
         commfireb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['Commercial']['fire']))['SumInsured'].sum(),2)
         fsw['L'+str(each)]=commfireb

         # commcontents
         commcatc += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['SumInsured'].sum(),2)
         fsw['J'+str(each)]=commcatc
         commfirec += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['Commercial']['fire']))['SumInsured'].sum(),2)
         fsw['M'+str(each)]=commfirec

##         # commcombined
##         commcatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['SumInsured'].sum(),2)
##         fsw['K'+str(each)]=commcatSI
##         commfireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['SumInsured'].sum(),2)
##         fsw['N'+str(each)]=commfireSI


         # consbuilding
         conscatb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['SumInsured'].sum(),2)
         fsw['O'+str(each)]=conscatb
         consfireb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['SumInsured'].sum(),2)
         fsw['R'+str(each)]=consfireb
         # conscontents
         conscatc += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['SumInsured'].sum(),2)
         fsw['P'+str(each)]=conscatc
         consfirec += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['SumInsured'].sum(),2)
         fsw['S'+str(each)]=consfirec

##         # conscombined
##         conscatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['SumInsured'].sum(),2)
##         fsw['Q'+str(each)]=conscatSI
##         consfireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['SumInsured'].sum(),2)
##         fsw['T'+str(each)]=consfireSI

         # contbuilding
         contcatb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['SumInsured'].sum(),2)
         fsw['U'+str(each)]=contcatb
         contfireb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['SumInsured'].sum(),2)
         fsw['X'+str(each)]=contfireb
         # contcontent
         contcatc += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['SumInsured'].sum(),2)
         fsw['V'+str(each)]=contcatc
         contfirec += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['SumInsured'].sum(),2)
         fsw['Y'+str(each)]=contfirec

##         # contcombined
##         contcatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['SumInsured'].sum(),2)
##         fsw['W'+str(each)]=contcatSI
##         contfireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['SumInsured'].sum(),2)
##         fsw['Z'+str(each)]=contfireSI

row=36
col=1
for each in range(row,57):
    m_val=fsw['B'+str(each)].value
    m_lval=m_val.lower()
    if m_lval in gl.keys():
         homecatb = homecatc = homecatSI = homefireb = homefirec = homefireSI = 0
         commcatb = commcatc = commcatSI = commfireb = commfirec = commfireSI = 0
         conscatb = conscatc = conscatSI = consfireb = consfirec = consfireSI = 0
         contcatb = contcatc = contcatSI = contfireb = contfirec = contfireSI = 0
         for val in gl[m_lval]:
             lval = val.lower()
             cval = val.upper() 

             # homebuilding
             homecatb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+'  and SubProduct in '+str(config['Home']['catastrophe']))['Premium'].sum(),2)
             fsw['C'+str(each)]= homecatb
             homefireb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['Home']['fire']))['Premium'].sum(),2)
             fsw['F'+str(each)]= homefireb

             # homecontents
             homecatc += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['Home']['catastrophe']))['Premium'].sum(),2)
             fsw['D'+str(each)]= homecatc
             homefirec += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['Home']['fire']))['Premium'].sum(),2)
             fsw['G'+str(each)]= homefirec
##            
##             # homecombined
##             homecatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Premium'].sum(),2)
##             fsw['E'+str(each)]= homecatSI
##             homefireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Premium'].sum(),2)
##             fsw['H'+str(each)]= homefireSI

             # commBuilding
             commcatb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Premium'].sum(),2)
             fsw['I'+str(each)]=commcatb
             commfireb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['Commercial']['fire']))['Premium'].sum(),2)
             fsw['L'+str(each)]=commfireb

             # commcontents
             commcatc+=round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Premium'].sum(),2)
             fsw['J'+str(each)]=commcatc
             commfirec+=round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['Commercial']['fire']))['Premium'].sum(),2)
             fsw['M'+str(each)]=commfirec

##             # commcombined
##             commcatSI+=round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Premium'].sum(),2)
##             fsw['K'+str(each)]=commcatSI
##             commfireSI+=round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Premium'].sum(),2)
##             fsw['N'+str(each)]=commfireSI

             # consbuilding
             conscatb+=round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Premium'].sum(),2)
             fsw['O'+str(each)]=conscatb
             consfireb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Premium'].sum(),2)
             fsw['R'+str(each)]=consfireb

             # conscontents
             conscatc += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Premium'].sum(),2)
             fsw['P'+str(each)]=conscatc
             consfirec += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Premium'].sum(),2)
             fsw['S'+str(each)]=consfirec

##             # conscombined
##             conscatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Premium'].sum(),2)
##             fsw['Q'+str(each)]=conscatSI
##             consfireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Premium'].sum(),2)
##             fsw['T'+str(each)]=consfireSI

             # contbuilding
             contcatb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Premium'].sum(),2)
             fsw['U'+str(each)]=contcatb
             contfireb += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Buildings'])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Premium'].sum(),2)
             fsw['X'+str(each)]=contfireb
            
             # contcontent
             contcatc += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Premium'].sum(),2)
             fsw['V'+str(each)]=contcatc
             contfirec += round(df.query('Island in'+str([val,lval,cval])+' and CoverageTypeDesc in '+str(config['covGroup']['Contents'])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Premium'].sum(),2)
             fsw['Y'+str(each)]=contfirec

##             # contcombined
##             contcatSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Premium'].sum(),2)
##             fsw['W'+str(each)]=contcatSI
##             contfireSI += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Premium'].sum(),2)
##             fsw['Z'+str(each)]=contfireSI


col=1
row=155
df1f = df
for each in range(row,176):
 m_val=fsw['B'+str(each)].value
 m_lval=m_val.lower()

 if m_lval in gl.keys():
     homecatR = homefireR = commcatR = commfireR = conscatR = consfireR = contcatR = contfireR = 0
     for val in gl[m_lval]:
         lval = val.lower()
         cval = val.upper()
         print(cval)
         #homecat
         homcat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))
         
         for each_ in homcat['PolicyNumber'].unique():
             
             polno=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe'])+' and PolicyNumber=="'+str(each_)+'"')
             if polno['ListName'].nunique()==1:
                 checkPolno=df1f.query('SubProduct in '+str(config['Home']['catastrophe'])+' and PolicyNumber=="'+str(each_)+'"')
                 if checkPolno['ListName'].nunique()==1:

                     if checkPolno['Island'].nunique()==1:
                         homecatR +=1
                     else:
                         
                         groupIsland= pd.DataFrame(checkPolno.groupby('Island')['SumInsured'].sum())
                         column = groupIsland["SumInsured"]
                         max_index = column.idxmax()
                         
                         if cval==max_index or lval==max_index or val==max_index:
                             homecatR +=1  
                     
                 else:
                     homecatR +=1
                     
                 
                 
             else:
                 homecatR +=polno['ListName'].nunique()
         
         fsw['C'+str(each)]=homecatR

         #homefire
         homfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))
         for each_ in homfire['PolicyNumber'].unique():
             polno=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire'])+' and PolicyNumber=="'+str(each_)+'"')
             if polno['ListName'].nunique()==1:
                 checkPolno=df1f.query('SubProduct in '+str(config['Home']['fire'])+' and PolicyNumber=="'+str(each_)+'"')
                 if checkPolno['ListName'].nunique()==1:

                     if checkPolno['Island'].nunique()==1:
                         homefireR +=1
                     else:
                         
                         groupIsland= pd.DataFrame(checkPolno.groupby('Island')['SumInsured'].sum())
                         column = groupIsland["SumInsured"]
                         max_index = column.idxmax()
                         
                         if cval==max_index or lval==max_index or val==max_index:
                             homefireR +=1  
                     
                 else:
                     homefireR +=1
                     
                 
                 
             else:
                 homefireR +=polno['ListName'].nunique()
         fsw['D'+str(each)]=homefireR

         #commcat
         commcat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))
         for each_ in commcat['PolicyNumber'].unique():
             polno=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe'])+' and PolicyNumber=="'+str(each_)+'"')
             if polno['ListName'].nunique()==1:
                 checkPolno=df1f.query('SubProduct in '+str(config['Commercial']['catastrophe'])+' and PolicyNumber=="'+str(each_)+'"')
                 if checkPolno['ListName'].nunique()==1:

                     if checkPolno['Island'].nunique()==1:
                         commcatR +=1
                     else:
                         
                         groupIsland= pd.DataFrame(checkPolno.groupby('Island')['SumInsured'].sum())
                         column = groupIsland["SumInsured"]
                         max_index = column.idxmax()
                         
                         if cval==max_index or lval==max_index or val==max_index:
                             commcatR +=1  
                     
                 else:
                     commcatR +=1
                     
                 
                 
             else:
                 commcatR +=polno['ListName'].nunique()
         fsw['E'+str(each)]=commcatR
    
         #commfire
         commfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))
         for each_ in commfire['PolicyNumber'].unique():
             polno=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire'])+' and PolicyNumber=="'+str(each_)+'"')
             if polno['ListName'].nunique()==1:
                 checkPolno=df1f.query('SubProduct in '+str(config['Commercial']['fire'])+' and PolicyNumber=="'+str(each_)+'"')
                 if checkPolno['ListName'].nunique()==1:

                     if checkPolno['Island'].nunique()==1:
                         commfireR +=1
                     else:
                         
                         groupIsland= pd.DataFrame(checkPolno.groupby('Island')['SumInsured'].sum())
                         column = groupIsland["SumInsured"]
                         max_index = column.idxmax()
                         
                         if cval==max_index or lval==max_index or val==max_index:
                             commfireR +=1  
                     
                 else:
                     commfireR +=1
                     
                 
                 
             else:
                 commfireR +=polno['ListName'].nunique()
         fsw['F'+str(each)]=commfireR

         #conscat
         conscat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))
         for each_ in conscat['PolicyNumber'].unique():
             polno=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe'])+' and PolicyNumber=="'+str(each_)+'"')
             if polno['ListName'].nunique()==1:
                 checkPolno=df1f.query('SubProduct in '+str(config['ConsequentialLoss']['catastrophe'])+' and PolicyNumber=="'+str(each_)+'"')
                 if checkPolno['ListName'].nunique()==1:

                     if checkPolno['Island'].nunique()==1:
                         conscatR +=1
                     else:
                         
                         groupIsland= pd.DataFrame(checkPolno.groupby('Island')['SumInsured'].sum())
                         column = groupIsland["SumInsured"]
                         max_index = column.idxmax()
                         
                         if cval==max_index or lval==max_index or val==max_index:
                             conscatR +=1  
                     
                 else:
                     conscatR +=1
                     
                 
                 
             else:
                 conscatR +=polno['ListName'].nunique()
         fsw['G'+str(each)]=conscatR

         #consfire
         consfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))
         for each_ in consfire['PolicyNumber'].unique():
             polno=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire'])+' and PolicyNumber=="'+str(each_)+'"')
             if polno['ListName'].nunique()==1:
                 checkPolno=df1f.query('SubProduct in '+str(config['ConsequentialLoss']['fire'])+' and PolicyNumber=="'+str(each_)+'"')
                 if checkPolno['ListName'].nunique()==1:

                     if checkPolno['Island'].nunique()==1:
                         consfireR +=1
                     else:
                         
                         groupIsland= pd.DataFrame(checkPolno.groupby('Island')['SumInsured'].sum())
                         column = groupIsland["SumInsured"]
                         max_index = column.idxmax()
                         
                         if cval==max_index or lval==max_index or val==max_index:
                             consfireR +=1  
                     
                 else:
                     consfireR +=1
                     
                 
                 
             else:
                 consfireR +=polno['ListName'].nunique()
         fsw['H'+str(each)]=consfireR

         #contfire
         contfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))
         for each_ in contfire['PolicyNumber'].unique():
             polno=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire'])+' and PolicyNumber=="'+str(each_)+'"')
             if polno['ListName'].nunique()==1:
                 checkPolno=df1f.query('SubProduct in '+str(config['ContractorsAllRisk']['fire'])+' and PolicyNumber=="'+str(each_)+'"')
                 if checkPolno['ListName'].nunique()==1:

                     if checkPolno['Island'].nunique()==1:
                         contfireR +=1
                     else:
                         
                         groupIsland= pd.DataFrame(checkPolno.groupby('Island')['SumInsured'].sum())
                         column = groupIsland["SumInsured"]
                         max_index = column.idxmax()
                         
                         if cval==max_index or lval==max_index or val==max_index:
                             contfireR +=1  
                     
                 else:
                     contfireR +=1
                     
                 
                 
             else:
                 contfireR +=polno['ListName'].nunique()
         fsw['J'+str(each)]=contfireR

         #contcat
         contcat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))
         for each_ in contcat['PolicyNumber'].unique():
             polno=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe'])+' and PolicyNumber=="'+str(each_)+'"')
             if polno['ListName'].nunique()==1:
                 checkPolno=df1f.query('SubProduct in '+str(config['ContractorsAllRisk']['catastrophe'])+' and PolicyNumber=="'+str(each_)+'"')
                 if checkPolno['ListName'].nunique()==1:

                     if checkPolno['Island'].nunique()==1:
                         contcatR +=1
                     else:
                         
                         groupIsland= pd.DataFrame(checkPolno.groupby('Island')['SumInsured'].sum())
                         column = groupIsland["SumInsured"]
                         max_index = column.idxmax()
                         
                         if cval==max_index or lval==max_index or val==max_index:
                             contcatR +=1  
                     
                 else:
                     contcatR +=1
                     
                 
                 
             else:
                 contcatR +=polno['ListName'].nunique()
         fsw['I'+str(each)]=contcatR
    
row=66
col=1
df1f = pd.read_excel(config_links['links']['excel1'], sheet_name="SinglePolicy")
for each in range(row,87):
 m_val=fsw['B'+str(each)].value
 m_lval=m_val.lower()
 if m_lval in gl.keys():
     homecatbuild = homecatcomb = homecatcont = homefirebuild = homefirecomb = homefirecont = 0
     commcatbuild = commcatcomb = commcatcont = commfirebuild = commfirecomb = commfirecont = 0
     conscatbuild = conscatcomb = conscatcont = consfirebuild = consfirecomb = consfirecont = 0
     contcatbuild = contcatcomb = contcatcont = contfirebuild = contfirecomb = contfirecont = 0
     for val in gl[m_lval]:
         lval = val.lower()
         cval = val.upper() 

         #homecat
         homcat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))
         iurunique=homcat['IUR Number'].unique()
         build = 0
         cont = 0
         
         for each1 in iurunique:
             records=homcat[(homcat['IUR Number']==each1)]
             if records['CoverageTypeDesc'].isin(config['covGroup']['Buildings']).any()==True:
                 build+=1
             if records['CoverageTypeDesc'].isin(config['covGroup']['Contents']).any()==True:
                 cont+=1

         
         homecatbuild += build
         homecatcont += cont
    
         # #homefire
         homefire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))
         iurunique=homefire['IUR Number'].unique()
         build=0
         cont=0
         
         for each1 in iurunique:
             records=homefire[(homefire['IUR Number']==each1)]
             if records['CoverageTypeDesc'].isin(config['covGroup']['Buildings']).any()==True:
                 build+=1
             if records['CoverageTypeDesc'].isin(config['covGroup']['Contents']).any()==True:
                 cont+=1
         
         homefirebuild += build
         homefirecont += cont
    
         #commcat
         commcat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))
         iurunique=commcat['IUR Number'].unique()
         build=0
         cont=0
         
         for each1 in iurunique:
             records=commcat[(commcat['IUR Number']==each1)]
             if records['CoverageTypeDesc'].isin(config['covGroup']['Buildings']).any()==True:
                 build+=1  
             if records['CoverageTypeDesc'].isin(config['covGroup']['Contents']).any()==True:
                 cont+=1
         
         commcatbuild += build
         commcatcont += cont
    
         #commfire
         commfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))
         iurunique=commfire['IUR Number'].unique()
         build=0
         cont=0
         
         for each1 in iurunique:
             records=commfire[(commfire['IUR Number']==each1)]
             if records['CoverageTypeDesc'].isin(config['covGroup']['Buildings']).any()==True:
                build+=1
             if records['CoverageTypeDesc'].isin(config['covGroup']['Contents']).any()==True:
                cont+=1
         
         commfirebuild += build
         commfirecont += cont
        
         #conscat
         conscat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))
         iurunique=conscat['IUR Number'].unique()
         build=0
         cont=0
         
         for each1 in iurunique:
             records=conscat[(conscat['IUR Number']==each1)]
             if records['CoverageTypeDesc'].isin(config['covGroup']['Buildings']).any()==True:
                build+=1
             if records['CoverageTypeDesc'].isin(config['covGroup']['Contents']).any()==True:
                cont+=1
         
         conscatbuild += build
         conscatcont += cont
        
         #cosnfire
         cosnfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))
         iurunique=cosnfire['IUR Number'].unique()
         build=0
         cont=0
         
         for each1 in iurunique:
             records=cosnfire[(cosnfire['IUR Number']==each1)]
             if records['CoverageTypeDesc'].isin(config['covGroup']['Buildings']).any()==True:
                 build+=1
             if records['CoverageTypeDesc'].isin(config['covGroup']['Contents']).any()==True:
                 cont+=1
         
         consfirebuild += build
         consfirecont += cont
       
         #contcat
         contcat=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))
         iurunique=contcat['IUR Number'].unique()
         build=0
         cont=0
         
         for each1 in iurunique:
             records=contcat[(contcat['IUR Number']==each1)]
             if records['CoverageTypeDesc'].isin(config['covGroup']['Buildings']).any()==True:
                 build+=1
             if records['CoverageTypeDesc'].isin(config['covGroup']['Contents']).any()==True:
                 cont+=1
         
         contcatbuild += build
         contcatcont += cont

         #contfire
         contfire=df1f.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))
         iurunique=contfire['IUR Number'].unique()
         build=0
         cont=0
         
         for each1 in iurunique:
             records=contfire[(contfire['IUR Number']==each1)]
             if records['CoverageTypeDesc'].isin(config['covGroup']['Buildings']).any()==True:
                 build+=1
             if records['CoverageTypeDesc'].isin(config['covGroup']['Contents']).any()==True:
                 cont+=1
         
         contfirebuild += build
         contfirecont += cont

     fsw['C'+str(each)]=homecatbuild
     fsw['D'+str(each)]=homecatcont
     
     fsw['F'+str(each)]=homefirebuild
     fsw['G'+str(each)]=homefirecont
    
     fsw['I'+str(each)]=commcatbuild
     fsw['J'+str(each)]=commcatcont
  
     fsw['L'+str(each)]=commfirebuild
     fsw['M'+str(each)]=commfirecont
     
     fsw['O'+str(each)]=conscatbuild
     fsw['P'+str(each)]=conscatcont
     
     fsw['R'+str(each)]=consfirebuild
     fsw['S'+str(each)]=consfirecont
     
     fsw['U'+str(each)]=contcatbuild
     fsw['V'+str(each)]=contcatcont
     
     fsw['X'+str(each)]=contfirebuild
     fsw['Y'+str(each)]=contfirecont
    

df = pd.read_csv(config_links['links']['excel2'], na_filter= False)
df['Sum Insured Share-Quota share']=pd.to_numeric(df['Sum Insured Share-Quota share'],errors='coerce')
df['Sum Insured Share-Surplus1']=pd.to_numeric(df['Sum Insured Share-Surplus1'],errors='coerce')
df['Sum Insured Share-Surplus2']=pd.to_numeric(df['Sum Insured Share-Surplus2'],errors='coerce')
df['Sum Insured Share-Retention']=pd.to_numeric(df['Sum Insured Share-Retention'],errors='coerce')


df['Premium Share-Quota Share']=pd.to_numeric(df['Premium Share-Quota Share'],errors='coerce')
df['Premium Share-Retention']=pd.to_numeric(df['Premium Share-Retention'],errors='coerce')
df['Premium Share-Surplus1']=pd.to_numeric(df['Premium Share-Surplus1'],errors='coerce')
df['Premium Share-Surplus2']=pd.to_numeric(df['Premium Share-Surplus2'],errors='coerce')
fsw=wb['Aggregate Summary']
row=150
col=1
for each in range(row,171):
 m_val=fsw['B'+str(each)].value
 m_lval=m_val.lower()
 if m_lval in gl.keys():
     homecatSIQS = homecatSISS1 =homecatSISS2 = homecatSIRet = homefireSIQS = homefireSISS1=homefireSISS2 = homefireSIRet = 0
     commcatSIQS = commcatSISS1 = commcatSISS2 = commcatSIRet = commfireSIQS = commfireSISS1 = commfireSISS2 = commfireSIRet = 0
     conscatSIQS = conscatSISS1 = conscatSISS2 = conscatSIRet = consfireSIQS = consfireSISS1 =consfireSISS2 = consfireSIRet = 0
     contcatSIQS = contcatSISS1=contcatSISS2 = contcatSIRet = contfireSIQS = contfireSISS1=contfireSISS2 = contfireSIRet = 0

     for val in gl[m_lval]:
         lval = val.lower()
         cval = val.upper() 
         # home
         homecatSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Sum Insured Share-Quota share'].sum(),2)
         fsw['C'+str(each)]= homecatSIQS
         homecatSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Sum Insured Share-Surplus1'].sum(),2)
         fsw['D'+str(each)]= homecatSISS1
         homecatSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Sum Insured Share-Surplus2'].sum(),2)
         fsw['E'+str(each)]= homecatSISS2
         homecatSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Sum Insured Share-Retention'].sum(),2)
         fsw['F'+str(each)]= homecatSIRet
        
         homefireSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Sum Insured Share-Quota share'].sum(),2)
         fsw['H'+str(each)]= homefireSIQS
         homefireSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Sum Insured Share-Surplus1'].sum(),2)
         fsw['I'+str(each)]= homefireSISS1
         homefireSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Sum Insured Share-Surplus2'].sum(),2)
         fsw['J'+str(each)]= homefireSISS2
         homefireSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Sum Insured Share-Retention'].sum(),2)
         fsw['K'+str(each)]= homefireSIRet

         # comm
         commcatSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Sum Insured Share-Quota share'].sum(),2)
         fsw['M'+str(each)]= commcatSIQS
         commcatSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Sum Insured Share-Surplus1'].sum(),2)
         fsw['N'+str(each)]= commcatSISS1
         commcatSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Sum Insured Share-Surplus2'].sum(),2)
         fsw['O'+str(each)]= commcatSISS2
         commcatSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Sum Insured Share-Retention'].sum(),2)
         fsw['P'+str(each)]= commcatSIRet
        
         commfireSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Sum Insured Share-Quota share'].sum(),2)
         fsw['R'+str(each)]= commfireSIQS
         commfireSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Sum Insured Share-Surplus1'].sum(),2)
         fsw['S'+str(each)]= commfireSISS1
         commfireSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Sum Insured Share-Surplus2'].sum(),2)
         fsw['T'+str(each)]= commfireSISS2
         commfireSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Sum Insured Share-Retention'].sum(),2)
         fsw['U'+str(each)]= commfireSIRet

         # cons
         conscatSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Sum Insured Share-Quota share'].sum(),2)
         fsw['W'+str(each)]= conscatSIQS
         conscatSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Sum Insured Share-Surplus1'].sum(),2)
         fsw['X'+str(each)]= conscatSISS1
         conscatSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Sum Insured Share-Surplus2'].sum(),2)
         fsw['Y'+str(each)]= conscatSISS2
         conscatSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Sum Insured Share-Retention'].sum(),2)
         fsw['Z'+str(each)]= conscatSIRet
        
         consfireSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Sum Insured Share-Quota share'].sum(),2)
         fsw['AB'+str(each)]= consfireSIQS
         consfireSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Sum Insured Share-Surplus1'].sum(),2)
         fsw['AC'+str(each)]= consfireSISS1
         consfireSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Sum Insured Share-Surplus2'].sum(),2)
         fsw['AD'+str(each)]= consfireSISS2
         consfireSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Sum Insured Share-Retention'].sum(),2)
         fsw['AE'+str(each)]= consfireSIRet

         # cont
         contcatSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Sum Insured Share-Quota share'].sum(),2)
         fsw['AG'+str(each)]= contcatSIQS
         contcatSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Sum Insured Share-Surplus1'].sum(),2)
         fsw['AH'+str(each)]= contcatSISS1
         contcatSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Sum Insured Share-Surplus2'].sum(),2)
         fsw['AI'+str(each)]= contcatSISS2
         contcatSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Sum Insured Share-Retention'].sum(),2)
         fsw['AJ'+str(each)]= contcatSIRet
        
         contfireSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Sum Insured Share-Quota share'].sum(),2)
         fsw['AL'+str(each)]= contfireSIQS
         contfireSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Sum Insured Share-Surplus1'].sum(),2)
         fsw['AM'+str(each)]= contfireSISS1
         contfireSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Sum Insured Share-Surplus2'].sum(),2)
         fsw['AN'+str(each)]= contfireSISS2
         contfireSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Sum Insured Share-Retention'].sum(),2)
         fsw['AO'+str(each)]= contfireSIRet

row=183
col=1
for each in range(row,204):
 m_val=fsw['B'+str(each)].value
 m_lval=m_val.lower()

 if m_lval in gl.keys():
     homecatSIQS = homecatSISS1 =homecatSISS2 = homecatSIRet = homefireSIQS = homefireSISS1=homefireSISS2 = homefireSIRet = 0
     commcatSIQS = commcatSISS1 = commcatSISS2 = commcatSIRet = commfireSIQS = commfireSISS1 = commfireSISS2 = commfireSIRet = 0
     conscatSIQS = conscatSISS1 = conscatSISS2 = conscatSIRet = consfireSIQS = consfireSISS1 =consfireSISS2 = consfireSIRet = 0
     contcatSIQS = contcatSISS1=contcatSISS2 = contcatSIRet = contfireSIQS = contfireSISS1=contfireSISS2 = contfireSIRet = 0

     for val in gl[m_lval]:
         lval = val.lower()
         cval = val.upper() 
        
         # home
         homecatSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Premium Share-Quota Share'].sum(),2)
         fsw['C'+str(each)]= homecatSIQS
         homecatSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Premium Share-Surplus1'].sum(),2)
         fsw['D'+str(each)]= homecatSISS1
         homecatSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Premium Share-Surplus2'].sum(),2)
         fsw['E'+str(each)]= homecatSISS2
         homecatSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['catastrophe']))['Premium Share-Retention'].sum(),2)
         fsw['F'+str(each)]= homecatSIRet
        
         homefireSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Premium Share-Quota Share'].sum(),2)
         fsw['H'+str(each)]= homefireSIQS
         homefireSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Premium Share-Surplus1'].sum(),2)
         fsw['I'+str(each)]= homefireSISS1
         homefireSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Premium Share-Surplus2'].sum(),2)
         fsw['J'+str(each)]= homefireSISS2
         homefireSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Home']['fire']))['Premium Share-Retention'].sum(),2)
         fsw['K'+str(each)]= homefireSIRet

         # comm
         commcatSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Premium Share-Quota Share'].sum(),2)
         fsw['M'+str(each)]= commcatSIQS
         commcatSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Premium Share-Surplus1'].sum(),2)
         fsw['N'+str(each)]= commcatSISS1
         commcatSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Premium Share-Surplus2'].sum(),2)
         fsw['O'+str(each)]= commcatSISS2
         commcatSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['catastrophe']))['Premium Share-Retention'].sum(),2)
         fsw['P'+str(each)]= commcatSIRet
        
         commfireSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Premium Share-Quota Share'].sum(),2)
         fsw['R'+str(each)]= commfireSIQS
         commfireSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Premium Share-Surplus1'].sum(),2)
         fsw['S'+str(each)]= commfireSISS1
         commfireSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Premium Share-Surplus2'].sum(),2)
         fsw['T'+str(each)]= commfireSISS2
         commfireSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['Commercial']['fire']))['Premium Share-Retention'].sum(),2)
         fsw['U'+str(each)]= commfireSIRet

         # cons
         conscatSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Premium Share-Quota Share'].sum(),2)
         fsw['W'+str(each)]= conscatSIQS
         conscatSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Premium Share-Surplus1'].sum(),2)
         fsw['X'+str(each)]= conscatSISS1
         conscatSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Premium Share-Surplus2'].sum(),2)
         fsw['Y'+str(each)]= conscatSISS2
         conscatSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['catastrophe']))['Premium Share-Retention'].sum(),2)
         fsw['Z'+str(each)]= conscatSIRet
        
         consfireSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Premium Share-Quota Share'].sum(),2)
         fsw['AB'+str(each)]= consfireSIQS
         consfireSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Premium Share-Surplus1'].sum(),2)
         fsw['AC'+str(each)]= consfireSISS1
         consfireSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Premium Share-Surplus2'].sum(),2)
         fsw['AD'+str(each)]= consfireSISS2
         consfireSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ConsequentialLoss']['fire']))['Premium Share-Retention'].sum(),2)
         fsw['AE'+str(each)]= consfireSIRet

         # cont
         contcatSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Premium Share-Quota Share'].sum(),2)
         fsw['AG'+str(each)]= contcatSIQS
         contcatSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Premium Share-Surplus1'].sum(),2)
         fsw['AH'+str(each)]= contcatSISS1
         contcatSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Premium Share-Surplus2'].sum(),2)
         fsw['AI'+str(each)]= contcatSISS2
         contcatSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['catastrophe']))['Premium Share-Retention'].sum(),2)
         fsw['AJ'+str(each)]= contcatSIRet
        
         contfireSIQS += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Premium Share-Quota Share'].sum(),2)
         fsw['AL'+str(each)]= contfireSIQS
         contfireSISS1 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Premium Share-Surplus1'].sum(),2)
         fsw['AM'+str(each)]= contfireSISS1
         contfireSISS2 += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Premium Share-Surplus2'].sum(),2)
         fsw['AN'+str(each)]= contfireSISS2
         contfireSIRet += round(df.query('Island in'+str([val,lval,cval])+' and SubProduct in '+str(config['ContractorsAllRisk']['fire']))['Premium Share-Retention'].sum(),2)
         fsw['AO'+str(each)]= contfireSIRet


wb.save(config_links['links']['output'])










