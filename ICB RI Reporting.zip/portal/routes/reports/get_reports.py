import os
from subprocess import Popen

import dateparser
from flask import (flash, make_response, redirect, render_template, request,
                   send_file, url_for)
from flask_login import login_required
from flask_restx import Resource
from openpyxl import load_workbook
from openpyxl.styles.borders import Border, Side

from ... import APP, LOG
from ...models.monthly_reports import MultiPolicy
from . import ns


@ns.route("/get_reports")
class GetReports(Resource):

    """Download Reports of specificied date

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Download : .xlsx
            Download zip file with multiple .xlsx files,unless one single .xlsx file will download.

    """
    @login_required
    def get(self):
        return make_response(render_template('reports.html'))

    def post(self):
        try:
            fromdate = request.form.get('fromdate')
            todate = request.form.get('todate')
            typeofreport = request.form.get('report')
            print(typeofreport)

            if fromdate != "":
                fromdate = dateparser.parse(fromdate)
                fromdate = str(fromdate.strftime('%Y-%m-%d'))

            if todate != "":
                t = dateparser.parse(todate)
                todate = str(t.strftime('%Y-%m-%d'))

            Excel = APP.config['EXCEL_URL']
            savefile = r"C:\Manomay\RetentionReport\Reports"
            filename =r"C:\Manomay\RetentionReport\Reports\Retention_Report.xlsx"

            if typeofreport == "Modeling":
                file_path = os.path.join(Excel,f'ModelingReport_{fromdate}-{todate}.xlsx')
                if not os.path.exists(file_path):
                    flash("File not found")
                    return redirect(url_for('api.reports_get_reports'))
                return send_file(file_path, as_attachment=True)

            if typeofreport == "Aggregation":
                file_path = os.path.join(Excel,f'Aggregate_Report_{fromdate}-{todate}.xlsx')
                if not os.path.exists(file_path):
                    flash("File not found")
                    return redirect(url_for('api.reports_get_reports'))
                return send_file(file_path, as_attachment=True)

            if typeofreport == "Policy Transaction Report":
                rows = MultiPolicy.query.filter(MultiPolicy.TransactionDate.between(fromdate, todate+' 23:59:59')).all()
                savefile = os.path.join(savefile,f'Retention_Report_{fromdate}_to_{todate}.xlsx')
                sheet_name ="Sheet1"
                thin_border = Border(left=Side(style='thin'), 
                            right=Side(style='thin'), 
                            top=Side(style='thin'), 
                            bottom=Side(style='thin'))
                wb = load_workbook(filename)
                sheet= wb.active
                row=2
                if sheet_name in wb.sheetnames:
                    #to check whether sheet you need already exists
                    for r in rows:
                        sheet.cell(row=row, column=1).value = r.TransactionType
                        sheet.cell(row=row, column=2).value = r.PolicyNumber
                        sheet.cell(row=row, column=3).value = r.OrderID
                        sheet.cell(row=row, column=4).value = r.TransactionDate
                        sheet.cell(row=row, column=5).value = r.PolicyStartDate
                        sheet.cell(row=row, column=6).value = r.PolicyEndDate
                        sheet.cell(row=row, column=7).value = r.RiskLine
                        sheet.cell(row=row, column=8).value = r.ProductCode
                        sheet.cell(row=row, column=9).value = r.ProductDescription
                        sheet.cell(row=row, column=10).value = r.SubProductcode
                        sheet.cell(row=row, column=11).value = r.SubProductDescription
                        sheet.cell(row=row, column=12).value = r.ClientId
                        sheet.cell(row=row, column=13).value = r.ClientName
                        sheet.cell(row=row, column=14).value = r.RiskAddress
                        sheet.cell(row=row, column=15).value = r.RiskAddressId
                        sheet.cell(row=row, column=16).value = r.ItemNumber
                        sheet.cell(row=row, column=17).value = r.CoverageDescription
                        sheet.cell(row=row, column=18).value = r.CoverageLevelSumInsured_Reporting
                        sheet.cell(row=row, column=19).value = r.CoveragePremium
                        sheet.cell(row=row, column=20).value = r.Branch
                        sheet.cell(row=row, column=21).value = r.RI
                        sheet.cell(row=row, column=22).value = r.RiId
                        sheet.cell(row=row, column=23).value = r.TransactionType
                        sheet.cell(row=row, column=24).value = r.CoverageLevelSumInsured
                        sheet.cell(row=row, column=25).value = r.Currency
                        sheet.cell(row=row, column=26).value = r.Island
                        sheet.cell(row=row, column=27).value = r.SpecialIndicator
                        sheet.cell(row=row, column=28).value = r.IUR_Number

                        for i in range(1,28):
                            sheet.cell(row=row, column=i).border = thin_border

                        row +=1
                wb.save(savefile)
                LOG.debug("****")
                path_name = os.path.abspath(os.path.join(os.path.abspath(__file__),"..\\retention_report\Automatic","RIComputation_v_7_surplus.py"))
                #path_name=r"C:\\inetpub\\wwwroot\\ICB%20RI%20Reporting\\portal\\routes\\reports\\retention_report\\Automatic\\RIComputation_v_7_surplus.py"
                LOG.debug(path_name)
                os.system('"C:\Program Files (x86)\Python37-32\python.exe" C:\\inetpub\\wwwroot\\ICB%20RI%20Reporting\\portal\\routes\\reports\\retention_report\\Automatic\\RIComputation_v_7_surplus.py ' +f'Retention_Report_{fromdate}_to_{todate}.xlsx')
                #Popen(['python',path_name]+[f'Retention_Report_{fromdate}_to_{todate}.xlsx'])
                LOG.debug(path_name)
                LOG.debug('"C:\Program Files (x86)\Python37-32\python.exe" C:\\inetpub\\wwwroot\\ICB%20RI%20Reporting\\portal\\routes\\reports\\retention_report\\Automatic\\RIComputation_v_7_surplus.py ' +f'Retention_Report_{fromdate}_to_{todate}.xlsx')
                LOG.debug("****")
                return redirect(url_for('api.reports_get_reports'))
        except Exception as e:
            LOG.error(e)

