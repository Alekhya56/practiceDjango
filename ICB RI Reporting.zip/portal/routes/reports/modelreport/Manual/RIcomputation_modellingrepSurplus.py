import configparser
import pandas as pd
import math
import xlsxwriter
from openpyxl import load_workbook
from io import StringIO
import numpy as np
import xlrd
import xlwt
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles.borders import Border, Side
import pyodbc
import os
import time

#config file 
config_links = configparser.ConfigParser()
config_links.read('config_links.ini')


#removing  file
if os.path.exists(config_links['links']['dir1']):    #Pls change
    os.remove(config_links['links']['dir1'])#Pls change
pd.set_option('display.max_rows',500)
pd.set_option('display.max_columns',500)
pd.set_option('display.width',1000)


header = ["Branch",
"Insurer",
"Company?",
"CompanyName/Surname",
"Forename(s)",
"MailAddress",
"Island",
"Country",
"Product",
"InsuredName",
"ClientCode",
"PolicyNo",
"InceptionDate",
"ExpiryDate",
"Currency",
"RiskAddressId",
"RiskAddress",
"RiskSettlement",
"RiskIsland",
"RiskCountry",
"Area",
"IUR ID",
"YearBuilt",
"NoOfStoreys",
"DistanceSea",
"HeightAboveSea",
"OccupancyClass",
"RoofType",
"WallConstruction",
"CvgTypeCode",
"CvgDescription",
"SumInsured",

"DeductibleAmount",
"DeductionRate",
"RIBRoker",
"RIRate",
"GPSLat",
"GPSLong",
"GPSDesc",
"SettlementGPS",
"TurksGPS",
"CaymanGPS",
"AccExe",
"Retention%",
"QS %",
"SS1 %",
"SS2 %",
"Retention SI",
"QS SI",
"SS1 SI",
"SS2 SI",          
"Total SI"
]

#Pls change
cnxn = pyodbc.connect(Driver=config_links['sql configuration']['Driver'],Server=config_links['sql configuration']['Server'],Database=config_links['sql configuration']['Database'])

cur = cnxn.cursor()


    
    
    
appended_data1 = pd.DataFrame()
#single policies
cur.execute("SELECT  distinct(ClientCode),COUNT(*) AS SUM FROM  ModellingRep  group by ClientCode HAVING COUNT(*)=1")#Pls change 
onePolicy = cur.fetchall()
cur.commit()
for each in onePolicy:
    if ((each[0]==None) or (each[0]=='-')):
        time.sleep(1)
    else:
        df_singlePolicy = pd.read_sql("SELECT  * from  ModellingRep where   ClientCode = %s"%(each[0]), cnxn)#Pls change
        df_singlePolicy['IUR ID']=str(each[0])+'-'+str(0)
        appended_data1=appended_data1.append(df_singlePolicy)


appended_data2 = pd.DataFrame()
#multiple Policies
cur = cnxn.cursor()
cur.execute("SELECT  distinct(ClientCode),COUNT(*) AS SUM FROM  ModellingRep  group by ClientCode HAVING COUNT(*)>1 ")#Pls change
multiPolicy = cur.fetchall()
for each in multiPolicy:
    if ((each[0]==None) or (each[0]=='-')):
        time.sleep(1)
    else:
        
        print(each[0])
        df = pd.read_sql("SELECT  * from ModellingRep where  ClientCode = %s"%(each[0]), cnxn)#Pls change
        df1=df['RiskAddressId'].unique()
        for eachl in range(len(df1)):
            
            df2=df.loc[df['RiskAddressId'] == df1[eachl]]
            df2['IUR ID']=str(each[0])+'-'+str(eachl)
            appended_data2=appended_data2.append(df2)

appended_data2=appended_data2.append(appended_data1)

appended_data2.to_excel(config_links['links']['excel1'],sheet_name='SinglePolicy',index=False)#Pls change
    



excel_file = config_links['links']['excel1']#Pls change
df = pd.read_excel(excel_file)


config = configparser.ConfigParser()
config.read('config_surplus.ini')
liablityTreatyTax=config['Liability Treaty Allocation']['Liability Treaty Allocation']
truksPremiumTax=config['Premium Tax']['TruksPremium Tax']
nottruksPremiumTax=config['Premium Tax']['NotTruksPremium Tax']


#split by treaty
def riSIShareComputationbyTreaty(sumInsuredfinal,premDed,reportRow,liaprem):
    limit=float(config['Limits']['Retention Limit'])
    surplus1limit=float(config['Limits']['Surplus line1'])
    surplus2limit=float(config['Limits']['Surplus line2'])
    icbper=float(config['Retention Percentage']['ICB'])
    qsPer=float(config['Retention Percentage']['Quota Share'])
    if ((sumInsuredfinal[0])<=limit):
        icbRetvalue=round(((icbper/100)*sumInsuredfinal[0]),2)
        qsRetvalue=round(((qsPer/100)*sumInsuredfinal[0]),2)
        icbRetper=round(float((icbRetvalue/sumInsuredfinal[0])*100),4)
        qsRetper=round(float((qsRetvalue/sumInsuredfinal[0])*100),4)
        surplusPer1=0
        surplusPer2=0
        lenn=[" " for x in range(len(reportRow)-1)]
        lipre=[str(round(liaprem,2))]+lenn
        
        reportRow["Premium Less Liability"]=lipre
        premd=[str(round(premDed,2))]+lenn
        reportRow["Premium Less Liability Less Premium Tax"]=premd
        si=[str(round(sumInsuredfinal[0],2))]+lenn
        reportRow["Total SI"]=si
        
        spr=[str(round(icbRetper,2))]+lenn
        reportRow["Retention%"]=spr
        spq=[str(round(qsRetper,2))]+lenn
        reportRow["QS %"]=spq
        
        sps1=[str(0)]+lenn
        reportRow["SS1 %"]=sps1
        sps2=[str(0)]+lenn
        reportRow["SS2 %"]=sps2
        
        sir=[str(round(icbRetvalue,2))]+lenn
        reportRow["Retention SI"]=sir
        siq=[str(round(qsRetvalue,2))]+lenn
        reportRow["QS SI"]=siq
        sis1=[str(0)]+lenn
        reportRow["SS1 SI"]=sis1
        sis2=[str(0)]+lenn
        reportRow["SS2 SI"]=sis2
        
    elif (((sumInsuredfinal[0])>limit) & ((sumInsuredfinal[0])<=surplus1limit)):
        
        icbRetvalue=round(((icbper/100)*limit),2)
        qsRetvalue=round(((qsPer/100)*limit),2)
        surplusValue1=sumInsuredfinal[0]-limit
        surplusValue2=0
        icbRetper=round(float((icbRetvalue/sumInsuredfinal[0])*100),4)
        qsRetper=round(float((qsRetvalue/sumInsuredfinal[0])*100),4)
        surplusPer1=round(float((surplusValue1/sumInsuredfinal[0])*100),4)
        surplusPer2=0
        lenn=[" " for x in range(len(reportRow)-1)]
        lipre=[str(round(liaprem,2))]+lenn
        reportRow["Premium Less Liability"]=lipre
        premd=[str(round(premDed,2))]+lenn
        reportRow["Premium Less Liability Less Premium Tax"]=premd
        si=[str(round(sumInsuredfinal[0],2))]+lenn
        reportRow["Total SI"]=si
        
        spr=[str(round(icbRetper,2))]+lenn
        reportRow["Retention%"]=spr
        spq=[str(round(qsRetper,2))]+lenn
        reportRow["QS %"]=spq
        
        sps1=[str(round(surplusPer1,2))]+lenn
        reportRow["SS1 %"]=sps1
        sps2=[str(0)]+lenn
        reportRow["SS2 %"]=sps2
        
        sir=[str(round(icbRetvalue,2))]+lenn
        reportRow["Retention SI"]=sir
        siq=[str(round(qsRetvalue,2))]+lenn
        reportRow["QS SI"]=siq
        sis1=[str(round(surplusValue1,2))]+lenn
        reportRow["SS1 SI"]=sis1
        sis2=[str(0)]+lenn
        reportRow["SS2 SI"]=sis2
    elif ((sumInsuredfinal[0])>surplus1limit):
        icbRetvalue=round(((icbper/100)*limit),2)
        qsRetvalue=round(((qsPer/100)*limit),2)
        surplusValue1=surplus1limit-limit
        surplusValue2=sumInsuredfinal[0]-surplusValue1-qsRetvalue-icbRetvalue
        icbRetper=round(float((icbRetvalue/sumInsuredfinal[0])*100),4)
        qsRetper=round(float((qsRetvalue/sumInsuredfinal[0])*100),4)
        surplusPer1=round(float((surplusValue1/sumInsuredfinal[0])*100),4)
        surplusPer2=round(float((surplusValue2/sumInsuredfinal[0])*100),4)
        lenn=[" " for x in range(len(reportRow)-1)]
        lipre=[str(round(liaprem,2))]+lenn
        reportRow["Premium Less Liability"]=lipre
        premd=[str(round(premDed,2))]+lenn
        reportRow["Premium Less Liability Less Premium Tax"]=premd
        si=[str(round(sumInsuredfinal[0],2))]+lenn
        reportRow["Total SI"]=si
        
        spr=[str(round(icbRetper,2))]+lenn
        reportRow["Retention%"]=spr
        spq=[str(round(qsRetper,2))]+lenn
        reportRow["QS %"]=spq
        
        sps1=[str(round(surplusPer1,2))]+lenn
        reportRow["SS1 %"]=sps1
        sps2=[str(round(surplusPer2,2))]+lenn
        reportRow["SS2 %"]=sps2
        
        sir=[str(round(icbRetvalue,2))]+lenn
        reportRow["Retention SI"]=sir
        siq=[str(round(qsRetvalue,2))]+lenn
        reportRow["QS SI"]=siq
        sis1=[str(round(surplusValue1,2))]+lenn
        reportRow["SS1 SI"]=sis1
        sis2=[str(round(surplusValue2,2))]+lenn
        reportRow["SS2 SI"]=sis2
        
    
    return sumInsuredfinal[0],premDed,icbRetper,qsRetper,surplusPer1,surplusPer2




#premium computation
def grossRetainedPremiumComputation(clientID):
    df['RIRate'] = df['RIRate'].replace(np.nan, 0)
    df['RIBRoker'] = df['RIBRoker'].replace(np.nan, 0)
    
    data=df[df['ClientCode'] == clientID]
    #checking how many IURs does a client hav one or more than one
    iur=data['IUR ID'].unique()
    for each in iur:
        #stores premium after deduction of liability
        ltpremded=[]
        #stores coverrage level premium of every row
        premDed=[]
        #stores coverrage level si of every row
        sumInsuredfinal=[]
        #stores premium , subproduct of every row
        subprod_prem=[]
    
        reportRow=data[(data['IUR ID']==each)]
        row=data[(data['IUR ID']==each) & (data['CvgDescription'] != "Public Liability") & (data['CvgDescription'] != "Public Liability 250k - 5M")  ]
        row=row[(row['RIBRoker'] == 0.0) | (row['RIBRoker'] == "Insurance Co. of The Bahamas Ltd.") | (row['RIBRoker'] == 23.0) ]
        
        for record in row.index:
            
            eachrow=row.loc[[record]]          
            branch=eachrow[['Branch']].values
            Product=eachrow['ProductDescription'].values
            ri=eachrow['RIRate'].values
            subProd=eachrow['SubProductDescription'].values
            
            sumInsured=eachrow['SumInsured'].values
            premium=eachrow[['Premium']].values
            
            sumInsuredfinal.append(sumInsured)
            #check branch
            if ((branch=='Turks and Caicos') or (branch=='Turks and Caicos (Fidelity)') or (branch=='Turks and Caicos (Acordia)') ):
                #check Product
                if ((Product=='Home - ICB') or (Product=='Contractors All Risks ICB')):
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(liablityTreatyTax)]+lenn
                    reportRow["LiablityTreaty%"]=Ltt
                    #tax to report
                    ptt=[str(truksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    
                    liablityTreatyAmt=(round((float(liablityTreatyTax) / 100)*float(premium),2))
                    afterDedprem=round(float(premium)-float(liablityTreatyAmt),2)
                    ltpremded.append(afterDedprem)
                    truksPremiumAmt=(round((float(truksPremiumTax) / 100)*float(afterDedprem),2))
                    afterDedprem=round(afterDedprem-float(truksPremiumAmt),2)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))
                
                else:
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(0)]+lenn
                    reportRow["LiablityTreaty%"]=Ltt
                    #tax to report
                    ptt=[str(truksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    ltpremded.append(round(float(premium),2))
                    afterDedprem=round(float(premium)-((float(truksPremiumTax) / 100)*float(premium)),2)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))
                
            else:
                #check Product
                if ((Product=='Home - ICB') or (Product=='Contractors All Risks ICB')):
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(liablityTreatyTax)]+lenn
                    reportRow["LiablityTreaty%"]=Ltt
                    #tax to report
                    ptt=[str(nottruksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    liablityTreatyAmt=(round((float(liablityTreatyTax) / 100)*float(premium),2))
                    afterDedprem=round(float(premium)-float(liablityTreatyAmt),2)
                    ltpremded.append(afterDedprem)
                    nottruksPremiumAmt=(round((float(nottruksPremiumTax) / 100)*float(afterDedprem),2))
                    afterDedprem=round(float(afterDedprem)-float(nottruksPremiumAmt),2)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))
                else:
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(0)]+lenn
                    reportRow["LiablityTreaty%"]=Ltt
                    #tax to report
                    ptt=[str(nottruksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    ltpremded.append(round(float(premium),2))
                    afterDedprem=round(float(premium)-((float(nottruksPremiumTax) / 100)*float(premium)),2)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))

        
        sumInsuredfinal,premDed,icbRetper,qsRetper,surplusPer1,surplusPer2=riSIShareComputationbyTreaty(sum(sumInsuredfinal),(sum(premDed)),reportRow,(sum(ltpremded)))
        
        reportRow.to_csv(config_links['links']['excel2'], columns = header,mode = 'a',index=False,header=False) #Pls change

clients=df['ClientCode'].unique()
dfheader = pd.DataFrame({'col':header})
dfheader.transpose().to_csv(config_links['links']['excel2'], mode = 'a',index=False,header=False)#Pls change

for client in clients:
    grossRetainedPremiumComputation(client)


##df = pd.read_excel(r"C:\Users\MANOMAY\Desktop\icb\modelreport\Singleoutput.xlsx")#Pls change
##
##book=xlrd.open_workbook(r"C:\Users\MANOMAY\Desktop\icb\modelreport\model_report.xlsx")#Pls change
##
##fs=book.sheet_by_index(0)
##wb = openpyxl.load_workbook(filename=r"C:\Users\MANOMAY\Desktop\icb\modelreport\model_report.xlsx")#Pls change

##fsw=wb['Dataset']
##for r in dataframe_to_rows(df, index=False, header=True):
##    fsw.append(r)
##
##    
##df = pd.read_csv(r"C:\Users\MANOMAY\Desktop\icb\modelreport\modelRep.csv")#Pls change
##
##fsw=wb['Modelling Report']
##for r in dataframe_to_rows(df, index=False, header=False):
##    fsw.append(r)
##
##    
##wb.save(r"C:\Users\MANOMAY\Desktop\icb\modelreport\ModellingSummaryReport.xlsx")#Pls change
##
##
##wb = openpyxl.load_workbook(r"C:\Users\MANOMAY\Desktop\icb\modelreport\ModellingSummaryReport.xlsx")#Pls change
##ws = wb['Modelling Report']
##for each in ws['AF']:
##    val=each.value
##    if val=='Coverage SI' or val=='QS SI' or val=='Retention SI' or val=='SS SI' or val=='Total SI' or val==' ' or val==None:
##        each.value
##    else:
##        
##        ws[each.coordinate].number_format= "#,##0.00"
##        ws[each.coordinate]=float(val)
##for each in ws['AU']:
##    val=each.value
##    if val=='Coverage SI' or val=='QS SI' or val=='Retention SI' or val=='SS SI' or val=='Total SI' or val==' ' or val==None:
##        each.value
##    else:
##        
##        ws[each.coordinate].number_format= "#,##0.00"
##        ws[each.coordinate]=float(val)
##for each in ws['AV']:
##    val=each.value
##    if val=='Coverage SI' or val=='QS SI' or val=='Retention SI' or val=='SS SI' or val=='Total SI' or val==' ' or val==None:
##        each.value
##    else:
##        
##        ws[each.coordinate].number_format= "#,##0.00"
##        ws[each.coordinate]=float(val)
##for each in ws['AW']:
##    val=each.value
##    if val=='Coverage SI' or val=='QS SI' or val=='Retention SI' or val=='SS SI' or val=='Total SI' or val==' ' or val==None :
##        each.value
##    else:
##        
##        ws[each.coordinate].number_format= "#,##0.00"
##        ws[each.coordinate]=float(val)
##for each in ws['AX']:
##    val=each.value
##    if val=='Coverage SI' or val=='QS SI' or val=='Retention SI' or val=='SS SI' or val=='Total SI' or val==' ' or val==None:
##        each.value
##    else:
##        
##        ws[each.coordinate].number_format= "#,##0.00"
##        ws[each.coordinate]=float(val)
##        
##        
##
##ws.freeze_panes = 'A3'
##black_border = Border(left=Side(style='thin'), 
##                     right=Side(style='thin'), 
##                     top=Side(style='thin'), 
##                     bottom=Side(style='thin'))
##row_num=ws.max_row
##for label in ["A",	"B",	"C",	"D",	"E",	"F",	"G",	"H",	"I",	"J",	"K",	"L",	"M",	"N",	"O",	"P",	"Q",	"R",	"S",	"T",	"U",	"V",	"W",	"X",	"Y",	"Z",	"AA",	"AB",	"AC",	"AD",	"AE",	"AF",	"AG",	"AH",	"AI",	"AJ",	"AK",	"AL",	"AM",	"AN",	"AO",	"AP",	"AQ",	"AR",	"AS",	"AT",	"AU",	"AV",	"AW",	"AX"]: 
##    for col_idx in range(row_num): 
##        idx = label + str(col_idx + 1)  
##        ws[idx].border = black_border
##        
##    
##wb.save(r"C:\Users\MANOMAY\Desktop\icb\modelreport\ModellingSummaryReport.xlsx")#Pls change
##
##



    
