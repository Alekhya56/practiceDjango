import configparser
import pandas as pd
import math
import xlrd
import xlwt
import openpyxl
import xlsxwriter
from openpyxl import load_workbook
from io import StringIO
import numpy as np
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles.borders import Border, Side
import os
import pyodbc
import time
import subprocess
from sqlalchemy import create_engine
import urllib
import  sys
import logging
from datetime import datetime
logging.basicConfig(filename=r"C:\inetpub\wwwroot\log.txt", filemode='a', format='%(message)s')

#config file 
config_links = configparser.ConfigParser()
#config_links.read('config_links.ini')
config_links.read_file(open(os.path.join(os.path.dirname(__file__),"config_links.ini")))

#creating directory

if os.path.exists(config_links['links']['dir1']):
            os.remove(config_links['links']['dir1'])

#sql config
cnxn = pyodbc.connect(Driver=config_links['sql configuration']['Driver'],Server=config_links['sql configuration']['Server'],Database=config_links['sql configuration']['Database'])


logging.warning("Deleting")
cur = cnxn.cursor()
cur.execute("delete from RowsReductionLogic ")
filename = "C:/Manomay/RetentionReport/Reports/" + sys.argv[1] 

logging.warning("Deleted")

quoted = urllib.parse.quote_plus(
    "DRIVER={SQL Server};SERVER=" + config_links['sql configuration']['Server'] + ";DATABASE=" +
    config_links['sql configuration']['Database'])
engine = create_engine('mssql+pyodbc:///?odbc_connect={}'.format(quoted))
datasetfromui = pd.read_excel(filename)

del datasetfromui['IUR Number']
cur.execute("delete from RowsReductionLogic ")
cur.commit()


logging.warning("Inserting data")
datasetfromui.to_sql('RowsReductionLogic', engine,

                     if_exists='append', index=False)

logging.warning("Inserted data")

#making covSI to zero which has cancelled policies and not making si to zero which has re-nb-can
cur.execute("select distinct(PolicyNumber)  from RowsReductionLogic where TransactionType2='A'")


canPol = cur.fetchall()

for eachpol in canPol:
    #print(eachpol)
    reNbCan=pd.read_sql("SELECT  * from RowsReductionLogic where PolicyNumber = '"+eachpol[0]+"'", cnxn)
    
    if ((reNbCan['TransactionType'] == 'RN').any()==True and (reNbCan['TransactionType2'] == 'A').any()==True and (reNbCan['TransactionType'] == 'NB').any()==True):
        reorderid=reNbCan['OrderID'].where(reNbCan['TransactionType'] == 'RN').max()
        nborderid=reNbCan['OrderID'].where(reNbCan['TransactionType'] == 'NB').max()
        if nborderid>reorderid:
            
            print("yes its re-nb-can "+eachpol[0])
            print(reorderid)
            print(nborderid)
        else:
            cur.execute("select distinct(RiskAddressId)  from RowsReductionLogic where PolicyNumber=? and TransactionType2='A'",eachpol[0])
            canitem = cur.fetchall()
            for eachitem in canitem:
                print(eachitem)
                records=pd.read_sql(" select *  from RowsReductionLogic where PolicyNumber= '%s' and RiskAddressId='%d'"%(eachpol[0],eachitem[0]), cnxn)
                print((records['TransactionType2'] == 'NULL').any())
                if (((records['TransactionType2'] == 'NULL').any()) or ((records['TransactionType2'] == 'C').any() ))==True:
                    if ((records['TransactionType2'] == 'RE').any())!=True:
                        cur.execute("update RowsReductionLogic set CoverageLevelSumInsured=0 where PolicyNumber= ? and RiskAddressId=?",eachpol[0],eachitem[0])
    else:
        time.sleep(0)
        #print("no"+eachpol[0])
        cur.execute("select distinct(RiskAddressId)  from RowsReductionLogic where PolicyNumber=? and TransactionType2='A'",eachpol[0])
        canitem = cur.fetchall()
        for eachitem in canitem:
            print(eachitem)
            records=pd.read_sql(" select *  from RowsReductionLogic where PolicyNumber= '%s' and RiskAddressId='%d'"%(eachpol[0],eachitem[0]), cnxn)
            print((records['TransactionType2'] == 'NULL').any())
            if (((records['TransactionType2'] == 'NULL').any()) or ((records['TransactionType2'] == 'C').any() ))==True:
                if ((records['TransactionType2'] == 'RE').any())!=True:
                    cur.execute("update RowsReductionLogic set CoverageLevelSumInsured=0 where PolicyNumber= ? and RiskAddressId=?",eachpol[0],eachitem[0])
        
cur.commit()


#select unique policy nos with endrosements for assigning there NB values to zero
cur.execute("select distinct PolicyNumber from RowsReductionLogic where TransactionType2='C'")
policies = cur.fetchall()
for policy in policies:
    cur.execute("select distinct(ItemNumber)  from RowsReductionLogic where PolicyNumber=? and TransactionType2='C'",policy)
    items = cur.fetchall()
    for item in items:
        cur.execute("update RowsReductionLogic set CoverageLevelSumInsured=0 where PolicyNumber='"+str(policy[0])+"' and (TransactionType2=null or TransactionType2='NULL' or TransactionType2 is null) and  ItemNumber=?",str(item[0]))
cur.commit()

cur = cnxn.cursor()

appended_data1 = pd.DataFrame()


#clients with single policies
cur.execute("SELECT  distinct(ClientId),COUNT(*) AS SUM FROM RowsReductionLogic group by ClientId HAVING COUNT(*)=1")
onePolicy = cur.fetchall()
for each in onePolicy:
    df_singlePolicy = pd.read_sql("SELECT  * from RowsReductionLogic where ClientId = %s"%(each[0]), cnxn)
    #assigning IUR no
    df_singlePolicy['IUR Number']=str(each[0])+'-'+str(0)
    #appending data 
    appended_data1=appended_data1.append(df_singlePolicy)



    
appended_data2 = pd.DataFrame()

cur = cnxn.cursor()

#clients with multiple Policies
cur.execute("SELECT  distinct(ClientId),COUNT(*) AS SUM FROM RowsReductionLogic group by ClientId HAVING COUNT(*)>1 ")
multiPolicy = cur.fetchall()
for each in multiPolicy:
    df = pd.read_sql("SELECT  * from RowsReductionLogic where ClientId = %s"%(each[0]), cnxn)
    df1=df['RiskAddressId'].unique()
    for eachl in range(len(df1)):
        df2=df.loc[df['RiskAddressId'] == df1[eachl]]
        #assigning IUR no
        df2['IUR Number']=str(each[0])+'-'+str(eachl)
        #appending data 
        appended_data2=appended_data2.append(df2)
        
#appending complete data of single and multiple policies        
appended_data2=appended_data2.append(appended_data1)

#sending IUR no appended data to excel  
appended_data2.to_excel(config_links['links']['excel1'],sheet_name='SinglePolicy',index=False)    

#changing IUR's
dfromui = pd.read_excel(filename)
dfromsql= pd.read_excel(config_links['links']['excel1'])
apd_data = pd.DataFrame()
nums=dfromui['RiskAddressId'].unique()
for each in nums:
    af3=dfromui[(dfromui['RiskAddressId']==each)]
    iur_num=af3['IUR Number'].head(1)
    af4=dfromsql[(dfromsql['RiskAddressId']==each)]
    iur_num2=af4['IUR Number'].head(1)
    if iur_num.values[0] != iur_num2.values[0]:
        af4['IUR Number']=af4['IUR Number'].replace(iur_num2.values[0],iur_num.values[0])
        apd_data=apd_data.append(af4)
    else:
        apd_data=apd_data.append(af4)

apd_data.to_excel(config_links['links']['excel1'],sheet_name='SinglePolicy',index=False)

        











#showing max lenth data on console
pd.set_option('display.max_rows',500)
pd.set_option('display.max_columns',500)
pd.set_option('display.width',1000)

#header as per report
header = ["ClientId","ClientName","TransactionType","OrderID","Branch","Island", "SubProductcode","Currency","SubProductDescription","PolicyNumber","PolicyStartDate","PolicyEndDate","RiskAddressId", "RiskAddress", "IUR Number","CoverageLevelSumInsured","CoverageDEscription","Sum Insured","Premium","LiablityTreatyTax","Property RI Premium (less Liability Allocation)","PremiumTax","Property RI Premium (Premium less Premium Tax)","Share Percentage-Retention","Share Percentage-Quota share","Share Percentage-Surplus1",
"Share Percentage-Surplus2","Sum Insured Share-Retention","Sum Insured Share-Quota share","Sum Insured Share-Surplus1","Sum Insured Share-Surplus2","Premium Share-Retention","Premium Share-Quota Share","Premium Share-Surplus1","Premium Share-Surplus2","Commission-Quota Share%","Commission-Quota Share","Commission-Surplus1%","Commission-Surplus1","Commission-Surplus2%","Commission-Surplus2","TransactionType2","SpecialIndicator" ]


#input file with IUR no
excel_file = config_links['links']['excel1']


#reading and converting data into dataframe from excel
df = pd.read_excel(excel_file)


#changing null/nan values to 0
df['RI'] = df['RI'].replace(np.nan, 0)
df['RiId'] = df['RiId'].replace(np.nan, 0)

#selecting records only if it has ICb/0/23 codes
df=df[((df['ProductDescription'].str.contains('ICB')) & (df['RiId'] == 0.0 )) |  (df['RiId'] == 23.0)  ]

##df=df[(df['CoverageDEscription'] != "Public Liability") & (df['CoverageDEscription'] != "Public Liability 250k - 5M")
##                 & (df['CoverageDEscription'] != "Public Liability 500K")
##                 & (df['CoverageDEscription'] != "Public Liability 5M")
##                 & (df['CoverageDEscription'] != "Public Liability 100K")
##                 & (df['CoverageDEscription'] != "Public Liability 1M")
##                 & (df['CoverageDEscription'] != "Public Liability 250K")]


nums=df['IUR Number'].unique()
CovSI = pd.DataFrame()
for each in nums:
    af=df[(df['IUR Number']==each)]

    polnums=af['PolicyNumber'].unique()
    for rec in polnums:
        af2=af[(af['PolicyNumber']==rec)]
        
        inums=af2['ItemNumber'].unique()
        for inum in inums:
            af3=af2[(af2['ItemNumber']==inum)]
            sivalue=af3['CoverageLevelSumInsured'].max()
            
            print("si"+str(sivalue))
            af3.loc[af3['CoverageLevelSumInsured'] == af3['CoverageLevelSumInsured'].max(), ['CoverageLevelSumInsured']] = 0
          
            if ((af3['TransactionType2'] == 'RE').any())==True:
                af3.loc[af3['CoverageLevelSumInsured'] == -(sivalue), ['CoverageLevelSumInsured']] = 0
                
            af3['CoverageLevelSumInsured'].iloc[0] = sivalue
            CovSI=CovSI.append(af3)
            print(CovSI)

df=pd.DataFrame()
df=df.append(CovSI)

   
#df.to_csv(r"C:\Users\MANOMAY\Desktop\icb\icb_old\ICB\retention report\retentiontem22.csv",index=False,header=True)

#config file 
config = configparser.ConfigParser()
#config.read('config_surplus.ini')
config.read_file(open(os.path.join(os.path.dirname(__file__),"config_surplus.ini")))
#reading values from config file
liablityTreatyTax=config['Liability Treaty Allocation']['Liability Treaty Allocation']
truksPremiumTax=config['Premium Tax']['TruksPremium Tax']
nottruksPremiumTax=config['Premium Tax']['NotTruksPremium Tax']



#split by treaty
def riSIShareComputationbyTreaty(sumInsuredfinal,premDed,reportRow,liaprem,sumInsuredfinal2):
    limit=float(config['Limits']['Retention Limit'])
    surplus1limit=float(config['Limits']['Surplus line1'])
    surplus2limit=float(config['Limits']['Surplus line2'])
    

    icbper=float(config['Retention Percentage']['ICB'])
    qsPer=float(config['Retention Percentage']['Quota Share'])
    print(sumInsuredfinal[0])
    sumInsuredfinal[0]=abs(sumInsuredfinal[0])
   
    
    
        
    #checking if total SI is less or equal to limit 
    if ((sumInsuredfinal[0])<=limit):

        #calculation for values from SI
        icbRetvalue=round(((icbper/100)*sumInsuredfinal[0]),2)
        qsRetvalue=round(((qsPer/100)*sumInsuredfinal[0]),2)
        #calculation for percentages from SI
        icbRetper=(icbRetvalue/sumInsuredfinal[0])*100
        
        qsRetper=(qsRetvalue/sumInsuredfinal[0])*100
        if math.isnan(icbRetper):
            icbRetper=0
        if math.isnan(qsRetper):
            qsRetper=0
        surplusPer1=0
        surplusPer2=0

        #code to show value only in first record
        lenn=[" " for x in range(len(reportRow)-1)]
        lipre=[str(round(liaprem,2))]+lenn

        #printing values
        reportRow["Property RI Premium (less Liability Allocation)"]=lipre
        premd=[str(round(premDed,2))]+lenn
        reportRow["Property RI Premium (Premium less Premium Tax)"]=premd
        si=[str(round(sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured"]=si
        
        spr=[str(round(icbRetper,2))]+lenn
        reportRow["Share Percentage-Retention"]=spr
        spq=[str(round(qsRetper,2))]+lenn
        reportRow["Share Percentage-Quota share"]=spq
        sps1=[str(0)]+lenn
        reportRow["Share Percentage-Surplus1"]=sps1
        sps2=[str(0)]+lenn
        reportRow["Share Percentage-Surplus2"]=sps2
        sir=[str(round((icbRetper/100)*sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured Share-Retention"]=sir
        siq=[str(round((qsRetper/100)*sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured Share-Quota share"]=siq
        sis1=[str(0)]+lenn
        reportRow["Sum Insured Share-Surplus1"]=sis1
        sis2=[str(0)]+lenn
        reportRow["Sum Insured Share-Surplus2"]=sis2
        
    elif (((sumInsuredfinal[0])>limit) & ((sumInsuredfinal[0])<=surplus1limit)):
        #calculation for values from SI
        icbRetvalue=round(((icbper/100)*limit),2)
        qsRetvalue=round(((qsPer/100)*limit),2)
        surplusValue1=sumInsuredfinal[0]-limit
        surplusValue2=0
        #calculation for percentages from SI
        icbRetper=(icbRetvalue/sumInsuredfinal[0])*100
        qsRetper=(qsRetvalue/sumInsuredfinal[0])*100
        if math.isnan(icbRetper):
            icbRetper=0
        if math.isnan(qsRetper):
            qsRetper=0
        surplusPer1=(surplusValue1/sumInsuredfinal[0])*100
        surplusPer2=0

        #code to show value only in first record
        lenn=[" " for x in range(len(reportRow)-1)]
        
        lipre=[str(round(liaprem,2))]+lenn

        #printing values
        reportRow["Property RI Premium (less Liability Allocation)"]=lipre
        premd=[str(round(premDed,2))]+lenn
        reportRow["Property RI Premium (Premium less Premium Tax)"]=premd
        si=[str(round(sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured"]=si
        
        spr=[str(round(icbRetper,2))]+lenn
        reportRow["Share Percentage-Retention"]=spr
        spq=[str(round(qsRetper,2))]+lenn
        reportRow["Share Percentage-Quota share"]=spq
        sps1=[str(round(surplusPer1,2))]+lenn
        reportRow["Share Percentage-Surplus1"]=sps1
        sps2=[str(round(surplusPer2,2))]+lenn
        reportRow["Share Percentage-Surplus2"]=sps2
        sir=[str(round((icbRetper/100)*sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured Share-Retention"]=sir
        siq=[str(round((qsRetper/100)*sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured Share-Quota share"]=siq
        sis1=[str(round((surplusPer1/100)*sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured Share-Surplus1"]=sis1
        sis2=[str(0)]+lenn
        reportRow["Sum Insured Share-Surplus2"]=sis2



    elif ((sumInsuredfinal[0])>surplus1limit):
         #calculation for values from SI
        icbRetvalue=round(((icbper/100)*limit),2)
        qsRetvalue=round(((qsPer/100)*limit),2)
        surplusValue1=surplus1limit-limit
        surplusValue2=sumInsuredfinal[0]-surplusValue1-qsRetvalue-icbRetvalue
        #calculation for percentages from SI
        icbRetper=(icbRetvalue/sumInsuredfinal[0])*100
        qsRetper=(qsRetvalue/sumInsuredfinal[0])*100
        if math.isnan(icbRetper):
            icbRetper=0
        if math.isnan(qsRetper):
            qsRetper=0
        surplusPer1=(surplusValue1/sumInsuredfinal[0])*100
        surplusPer2=(surplusValue2/sumInsuredfinal[0])*100

        #code to show value only in first record
        lenn=[" " for x in range(len(reportRow)-1)]
        
        lipre=[str(round(liaprem,2))]+lenn

        #printing values
        reportRow["Property RI Premium (less Liability Allocation)"]=lipre
        premd=[str(round(premDed,2))]+lenn
        reportRow["Property RI Premium (Premium less Premium Tax)"]=premd
        si=[str(round(sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured"]=si
        
        spr=[str(round(icbRetper,2))]+lenn
        reportRow["Share Percentage-Retention"]=spr
        spq=[str(round(qsRetper,2))]+lenn
        reportRow["Share Percentage-Quota share"]=spq
        sps1=[str(round(surplusPer1,2))]+lenn
        reportRow["Share Percentage-Surplus1"]=sps1
        sps2=[str(round(surplusPer2,2))]+lenn
        reportRow["Share Percentage-Surplus2"]=sps2
        sir=[str(round((icbRetper/100)*sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured Share-Retention"]=sir
        siq=[str(round((qsRetper/100)*sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured Share-Quota share"]=siq
        sis1=[str(round((surplusPer1/100)*sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured Share-Surplus1"]=sis1
        sis2=[str(round((surplusPer2/100)*sumInsuredfinal2[0],2))]+lenn
        reportRow["Sum Insured Share-Surplus2"]=sis2

    return sumInsuredfinal[0],premDed,icbRetper,qsRetper,surplusPer1,surplusPer2


def riPremiumShareComputationbyTreaty(sumInsuredfinal,premDed,icbRetper,qsRetper,surplusPer1,surplusPer2):
       
        sumInsuredfinal=sumInsuredfinal
        premDed=premDed

        #premium cal based on percentage
        icbRetPrem=round((premDed * (icbRetper/100)),2)
        qsPrem=round((premDed * (qsRetper/100)),2)
        surplusPrem1=round((premDed * (surplusPer1/100)),2)
        surplusPrem2=round((premDed * (surplusPer2/100)),2)
        return sumInsuredfinal,premDed,icbRetPrem,qsPrem,surplusPrem1,surplusPrem2

def RICommissionComputationbyTreaty(sumInsuredfinal,subprod_prem,qsRetper,surplusPer1,surplusPer2):

    #reading values from config
    limit=float(config['Limits']['Retention Limit'])
    surplus1limit=float(config['Limits']['Surplus line1'])
    surplus2limit=float(config['Limits']['Surplus line2'])
    commQsperFP=float(config['QS commissionPercentage']['Full Peril Policies'])
    commQsperExc=float(config['QS commissionPercentage']['Ex - CAT Policies'])
    commQspercar=float(config['QS commissionPercentage']['CAR Policies'])
    commSs1perFP=float(config['SS commissionPercentage']['Full Peril Policies'])
    commSs1perExc=float(config['SS commissionPercentage']['Ex - CAT Policies'])
    commSs1percar=float(config['SS commissionPercentage']['CAR Policies'])
    commSs2perFP=float(config['SS2 commissionPercentage']['Full Peril Policies'])
    commSs2perExc=float(config['SS2 commissionPercentage']['Ex - CAT Policies'])
    commSs2percar=float(config['SS2 commissionPercentage']['CAR Policies'])

    commqsval=[]
    commss1val=[]
    commss2val=[]


    
    if (sumInsuredfinal<=limit):
        for x in subprod_prem:
            x = x.split(',')
            premComm_qs=round((float(x[0])* (qsRetper/100)),2)
            subproddesc=str(x[1]).strip("['']")
            if '-' in subproddesc:
                subproddesc=subproddesc.split("-")
           
            try:
                try:
                    
                    if config.get('Full Peril Policies list',subproddesc[0].rstrip() ):
                        commqsper=config['QS commissionPercentage']['Full Peril Policies']
                        commss1per=0
                        commss2per=0
                except:
                    try:
                        if config.get('Ex - CAT Policies list', subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['Ex - CAT Policies']
                            commss1per=0
                            commss2per=0
                    except:
                        if config.get('CAR Policies list', subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['CAR Policies']
                            commss1per=0
                            commss2per=0
                            
            except:
                
                commqsper=0
                commss1per=0
                commss2per=0
            
            commqsdedval=round((premComm_qs * (float(commqsper)/100)),2)
            commss1dedval=0
            commss2dedval=0
            commqsval.append(commqsdedval)
            commss1val.append(commss1dedval)
            commss2val.append(commss2dedval)
            

            
        
    elif (((sumInsuredfinal)>limit) & ((sumInsuredfinal)<=surplus1limit)):
        #print(subprod_prem)
        for x in subprod_prem:
            x = x.split(',')
            subproddesc=str(x[1]).strip("['']")
            if '-' in subproddesc:
                subproddesc=subproddesc.split("-")
           # print(x[0])
            premComm_qs=round((float(x[0])* (qsRetper/100)),2)
            premComm_ss1=round((float(x[0])* (surplusPer1/100)),2)
            #print(x[1])
            try:
    
                try:
                    if config.get('Full Peril Policies list', subproddesc[0].rstrip()):
                        commqsper=config['QS commissionPercentage']['Full Peril Policies']
                        commss1per=config['SS commissionPercentage']['Full Peril Policies']
                        commss2per=0
                except:
                    try:
                        
                       if config.get('Ex - CAT Policies list',subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['Ex - CAT Policies']
                            commss1per=config['SS commissionPercentage']['Ex - CAT Policies']
                            commss2per=0
                    except:
                        if config.get('CAR Policies list', subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['CAR Policies']
                            commss1per=config['SS commissionPercentage']['CAR Policies']
                            commss2per=0
            except:
                commqsper=0
                commss1per=0
                commss2per=0
            commqsdedval=round((premComm_qs * (float(commqsper)/100)),2)
            commss1dedval=round((premComm_ss1 * (float(commss1per)/100)),2)
            commss2dedval=0
            commqsval.append(commqsdedval)
            commss1val.append(commss1dedval)
            commss2val.append(commss2dedval)

    elif ((sumInsuredfinal)>surplus1limit):
        #print(subprod_prem)
        for x in subprod_prem:
            x = x.split(',')
            subproddesc=str(x[1]).strip("['']")
            if '-' in subproddesc:
                subproddesc=subproddesc.split("-")
           # print(x[0])
            premComm_qs=round((float(x[0])* (qsRetper/100)),2)
            premComm_ss1=round((float(x[0])* (surplusPer1/100)),2)
            premComm_ss2=round((float(x[0])* (surplusPer2/100)),2)
            #print(x[1])
            try:
    
                try:
                    if config.get('Full Peril Policies list', subproddesc[0].rstrip()):
                        commqsper=config['QS commissionPercentage']['Full Peril Policies']
                        commss1per=config['SS commissionPercentage']['Full Peril Policies']
                        commss2per=config['SS2 commissionPercentage']['Full Peril Policies']
                except:
                    try:
                        
                       if config.get('Ex - CAT Policies list',subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['Ex - CAT Policies']
                            commss1per=config['SS commissionPercentage']['Ex - CAT Policies']
                            commss2per=config['SS2 commissionPercentage']['Ex - CAT Policies']
                    except:
                        if config.get('CAR Policies list', subproddesc[0].rstrip()):
                            commqsper=config['QS commissionPercentage']['CAR Policies']
                            commss1per=config['SS commissionPercentage']['CAR Policies']
                            commss2per=config['SS2 commissionPercentage']['CAR Policies']
            except:
                commqsper=0
                commss1per=0
                commss2per=0
            commqsdedval=round((premComm_qs * (float(commqsper)/100)),2)
            commss1dedval=round((premComm_ss1 * (float(commss1per)/100)),2)
            commss2dedval=round((premComm_ss2 * (float(commss2per)/100)),2)
            commqsval.append(commqsdedval)
            commss1val.append(commss1dedval)
            commss2val.append(commss2dedval)    
    
    return sum(commqsval), sum(commss1val),sum(commss2val),commqsper,commss1per,commss2per
        

#premium computation
def grossRetainedPremiumComputation(clientID):
    
    
    data=df[df['ClientId'] == clientID]
    
    #checking how many IURs does a client hav one or more than one
    iur=data['IUR Number'].unique()
    
   
    for each in iur:
       
        
        #stores premium after deduction of liability
        ltpremded=[]
        #stores coverrage level premium of every row
        premDed=[]
        #stores coverrage level si of every row
        sumInsuredfinal=[]
        #stores transaction si
        sumInsuredfinal2=[]
        #stores premium , subproduct of every row
        subprod_prem=[]
        acPrem=[]
        reportRow=data[(data['IUR Number']==each)]
        #removes records which has below liabilities
        row=data[(data['IUR Number']==each)]
##                 & (data['CoverageDEscription'] != "Public Liability") & (data['CoverageDEscription'] != "Public Liability 250k - 5M")
##                 & (data['CoverageDEscription'] != "Public Liability 500K")
##                 & (data['CoverageDEscription'] != "Public Liability 5M")
##                 & (data['CoverageDEscription'] != "Public Liability 100K")
##                 & (data['CoverageDEscription'] != "Public Liability 1M")
##                 & (data['CoverageDEscription'] != "Public Liability 250K")]








##        row=row[((row['ProductCode'].str.contains('ICB')) & (row['RiId'] == 0.0 )) |  (row['RiId'] == 23.0)  ]
        print("*************")
        print(row['IUR Number'])
        for record in row.index:
            
            eachrow=row.loc[[record]]          
            branch=eachrow[['Branch']].values
            Product=eachrow['ProductDescription'].values
            ri=eachrow['RI'].values
            subProd=eachrow['SubProductDescription'].values

            
            if  (ri == 0)  :
                sumInsured=eachrow['CoverageLevelSumInsured'].values
            else:
                cls=eachrow['CoverageLevelSumInsured'].values
                sumInsured=(cls*(ri / 100))

                
            if  (ri == 0)  :
                sumInsured2=eachrow["CoverageLevelSumInsured_Reporting"].values
            else:
                cls2=eachrow["CoverageLevelSumInsured_Reporting"].values
                sumInsured2=(cls2*(ri / 100))

            if  (ri == 0)  :
                premium=eachrow['CoveragePremium'].values
            else:
                clp=eachrow['CoveragePremium'].values
                premium=(clp*(ri / 100))
           
                
            acPrem.append(premium)   
            sumInsuredfinal.append(sumInsured)
            sumInsuredfinal2.append(sumInsured2)
            subproductcode=eachrow['SubProductcode'].values
            #check branch
            if ((branch=='Turks and Caicos') or (branch=='Turks and Caicos (Fidelity)') or (branch=='Turks and Caicos (Acordia)') ):
                
                
               
                #check Product
                
                if ((subproductcode[0][:2]=='HM') or (subproductcode[0][:2]=='CR')):
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(liablityTreatyTax)]+lenn
                    reportRow["LiablityTreatyTax"]=Ltt
                    #tax to report
                    ptt=[truksPremiumTax]+lenn
                    reportRow["PremiumTax"]=ptt
                    
                    liablityTreatyAmt=(round((float(liablityTreatyTax) / 100)*float(premium),2))
                    afterDedprem=round(float(premium)-float(liablityTreatyAmt),2)
                    ltpremded.append(afterDedprem)
                    truksPremiumAmt=(round((float(truksPremiumTax) / 100)*float(afterDedprem),2))
##                    print(truksPremiumAmt)
##                    print(liablityTreatyAmt)
                    afterDedprem=round(afterDedprem-float(truksPremiumAmt),2)
##                    print(afterDedprem)
                    #print(afterDedprem)
                    
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))
                
                else:
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(0)]+lenn
                    reportRow["LiablityTreatyTax"]=Ltt
                    #tax to report
                    ptt=[str(truksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    ltpremded.append(round(float(premium),2))
                    afterDedprem=round(float(premium)-((float(truksPremiumTax) / 100)*float(premium)),2)
##                    print(afterDedprem)
                    #print(afterDedprem)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))
                
            else:
                
                
                #check Product
                if ((subproductcode[0][:2]=='HM') or (subproductcode[0][:2]=='CR')):
                    
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(liablityTreatyTax)]+lenn
                    reportRow["LiablityTreatyTax"]=Ltt
                    #tax to report
                    ptt=[str(nottruksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    liablityTreatyAmt=(round((float(liablityTreatyTax) / 100)*float(premium),2))
                    afterDedprem=round(float(premium)-float(liablityTreatyAmt),2)
                    ltpremded.append(afterDedprem)
                    nottruksPremiumAmt=(round((float(nottruksPremiumTax) / 100)*float(afterDedprem),2))
                    
##                    print(nottruksPremiumAmt)
##                    print(liablityTreatyAmt)
                    
                    afterDedprem=round(float(afterDedprem)-float(nottruksPremiumAmt),2)
##                    print(afterDedprem)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))
                else:
                    print("not tc")
                    print("not hm or cr")
                    lenn=[" " for x in range(len(reportRow)-1)]
                    #tax to report
                    Ltt=[str(0)]+lenn
                    reportRow["LiablityTreatyTax"]=Ltt
                    #tax to report
                    ptt=[str(nottruksPremiumTax)]+lenn
                    reportRow["PremiumTax"]=ptt
                    ltpremded.append(round(float(premium),2))

                    afterDedprem=round(float(premium)-((float(nottruksPremiumTax) / 100)*float(premium)),2)
##                    print(afterDedprem)
                    premDed.append(afterDedprem)
                    subprod_prem.append(str(afterDedprem)+','+str(subProd))

            #print(premDed)
        sumInsuredfinal,premDed,icbRetper,qsRetper,surplusPer1,surplusPer2=riSIShareComputationbyTreaty(sum(sumInsuredfinal),(sum(premDed)),reportRow,(sum(ltpremded)),sum(sumInsuredfinal2))
        sumInsuredfinal,premDed,icbRetPrem,qsPrem,surplusPrem1,surplusPrem2=riPremiumShareComputationbyTreaty(sumInsuredfinal,premDed,icbRetper,qsRetper,surplusPer1,surplusPer2)
        commqsval,commss1val,commss2val,commqsper,commss1per,commss2per=RICommissionComputationbyTreaty(sumInsuredfinal,subprod_prem,qsRetper,surplusPer1,surplusPer2)
        lenn=[" " for x in range(len(reportRow)-1)]

        acPrem=sum(acPrem)
        acPrem=round(acPrem[0],2)
        reportRow["Premium"]=[str(acPrem)]+lenn

        if ((icbRetPrem==0) and  (qsPrem==0) and (surplusPrem1==0) and (surplusPrem2==0)):
            
            psr=[str(premDed)]+lenn
            reportRow["Premium Share-Retention"]=psr
            psq=[str(qsPrem)]+lenn
            reportRow["Premium Share-Quota Share"]=psq   
            pssu=[str(surplusPrem1)]+lenn
            reportRow["Premium Share-Surplus1"]=pssu
            pssu2=[str(surplusPrem2)]+lenn
            reportRow["Premium Share-Surplus2"]=pssu2

            commqsper=round(float(commqsper),2)
            comqsper=[str(commqsper)]+lenn


        else:
            psr=[str(icbRetPrem)]+lenn
            reportRow["Premium Share-Retention"]=psr
            psq=[str(qsPrem)]+lenn
            reportRow["Premium Share-Quota Share"]=psq   
            pssu=[str(surplusPrem1)]+lenn
            reportRow["Premium Share-Surplus1"]=pssu
            pssu2=[str(surplusPrem2)]+lenn
            reportRow["Premium Share-Surplus2"]=pssu2
            commqsper=round(float(commqsper),2)
            comqsper=[str(commqsper)]+lenn

        
        
        reportRow["Commission-Quota Share%"]=comqsper

        commqsval=round(float(commqsval),2)
        comqs=[str(commqsval)]+lenn
        reportRow["Commission-Quota Share"]=comqs
        
        
        commss1per=round(float(commss1per),2)
        comss1per=[str(commss1per)]+lenn
        reportRow["Commission-Surplus1%"]=comss1per


        commss1val=round(float(commss1val),2)
        comss1=[str(commss1val)]+lenn
        reportRow["Commission-Surplus1"]=comss1

        commss2per=round(float(commss2per),2)
        comss2per=[str(commss2per)]+lenn
        reportRow["Commission-Surplus2%"]=comss2per

        commss2val=round(float(commss2val),2)
        comss2=[str(commss2val)]+lenn
        reportRow["Commission-Surplus2"]=comss2



        
        #reportRow.to_csv(r"C:\Users\MANOMAY\Desktop\icb\icb_old\ICB\retention report\retentiontem.csv", mode = 'a',index=False,header=True)
        reportRow.to_csv(config_links['links']['excel2'], columns = header,mode = 'a',index=False,header=False)
        
                
clients=df['ClientId'].unique()
dfheader = pd.DataFrame({'col':header})
dfheader.transpose().to_csv(config_links['links']['excel2'], mode = 'a',index=False,header=False)

for client in clients:

    grossRetainedPremiumComputation(client)







 #reading data from excel


    

df = pd.read_excel(config_links['links']['excel1'])

book=xlrd.open_workbook(config_links['links']['excel3'])

fs=book.sheet_by_index(0)
wb = openpyxl.load_workbook(filename=config_links['links']['excel3'])

fsw=wb['Dataset']
for r in dataframe_to_rows(df, index=False, header=True):
    fsw.append(r)

    
df = pd.read_csv(config_links['links']['excel2'])
notZero= pd.DataFrame()
isZero= pd.DataFrame()
unqiurs=df['IUR Number'].unique()
for unqiur in unqiurs:
    recs=df[(df['IUR Number']==unqiur)]
    rec=recs.head(1)
    si=rec['Sum Insured'].iloc[0]
    indica=rec['SpecialIndicator'].iloc[0]
    trantyp=rec['TransactionType2'].iloc[0]
    if ((float(si)==0) & (indica=='SI') & (trantyp!='A')):
        isZero=isZero.append(recs)
    else:
        notZero=notZero.append(recs)
del notZero["TransactionType2"]
del notZero["SpecialIndicator"]
if isZero.empty:
    time.sleep(0)
else:
    del isZero["TransactionType2"]
    del isZero["SpecialIndicator"]

df= pd.DataFrame()
df=notZero


fsw=wb['Policy Transaction Report']
for r in dataframe_to_rows(df, index=False, header=False):
    fsw.append(r)

dateexcep=sys.argv[1]
excepquery="select * from ExceptionsRetention where [Transaction Date] between '"+dateexcep[17:27]+"' and '"+dateexcep[31:41]+"'" 
exceptiondata=pd.read_sql(excepquery,cnxn)
del exceptiondata["Entry Date"]

fsw=wb['Exceptions'] 
for r in dataframe_to_rows(exceptiondata, index=False, header=False):
    fsw.append(r)
wb.save(config_links['links']['output']+str("{:%Y_%m_%d_%H_%M_%S}".format(datetime.now()))+".xlsx")

