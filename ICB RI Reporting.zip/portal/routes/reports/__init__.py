from ...api import api

ns = api.namespace('reports')