import pandas as pd
import logging
import RIComputation_v_4_surplus_claims
import pyodbc
import configparser
import numpy as np
import time
import os

#config file 
config_links = configparser.ConfigParser()
config_links.read('config_links.ini')

if os.path.exists(config_links['links']['dir1']):
                os.remove(config_links['links']['dir1'])
if os.path.exists(config_links['links']['dir2']):
                os.remove(config_links['links']['dir2'])
logging.basicConfig(filename=config_links['links']['dir1'], filemode='a', format='%(message)s')


#config file 
config_links = configparser.ConfigParser()
config_links.read('config_links.ini')
#sql config
cnxn = pyodbc.connect(Driver=config_links['sql configuration']['Driver'],Server=config_links['sql configuration']['Server'],Database=config_links['sql configuration']['Database'])



#showing max lenth data on console
pd.set_option('display.max_rows',500)
pd.set_option('display.max_columns',500)
pd.set_option('display.width',1000)
appended_data1 = pd.DataFrame()
#retData = pd.read_excel(r"C:\Users\Manomay\Desktop\icb\claims\TransactionalReportClaims_26Apr21.xlsx", sheet_name="Transactional Report for Claims")
clmData = pd.read_excel(config_links['links']['excel1'],sheet_name="Sheet1")

riCompdata=pd.read_excel(config_links['links']['excel1'],sheet_name="Retentiondata")
nums=riCompdata['PolicyNumber'].unique()   
for each in nums:
    af=riCompdata[(riCompdata['PolicyNumber']==each)]
    column = af["ItemNumber"]
    max_value = column.max()
    if max_value>1:
        time.sleep(0)
    elif max_value==1:
        clmData.loc[clmData['PolicyNo'] == each, ['ItemNumber']] = 1
        
        
clmData.to_excel(config_links['links']['excel2'],sheet_name='SinglePolicy',index=False) 
clmData=clmData[(clmData['Movement_Type'] != "Liability")]
clmrecs=clmData['Claim_Number'].unique()
deleted_data = pd.DataFrame()
for eachclm in  clmrecs:
    try:
        print(eachclm)
        clmspecificdata=clmData.loc[clmData['Claim_Number'] == eachclm]
        #taking firstrow polno, eefective date from claims data
        cPolno_eff=clmData.loc[clmData['Claim_Number'] == eachclm]
        cPolno=cPolno_eff["PolicyNo"].head(1).values[0]
        clossdate=cPolno_eff["Claim_Loss_Date"].head(1).values[0]
        new_df = riCompdata[((riCompdata['PolicyNumber'] == cPolno) & (riCompdata['Entry_Date'] == str(clossdate)[0:10]))]
        print(new_df)
        cur = cnxn.cursor()
        new_df.to_excel(config_links['links']['excel3'], sheet_name='Sheet1', index=False)
        cur.execute("""delete from RowsReductionLogic_claims""")
        # Insert DataFrame recrds one by one.
        for i,row in new_df.iterrows():
            row=row.replace(np.NaN, 0)
            #print(i,row)
            cur.execute("""INSERT INTO [dbo].[RowsReductionLogic_claims]
           ([TransactionType]
           ,[PolicyNumber]
           ,[OrderID]
           ,[TransactionDate]
           ,[PolicyStartDate]
           ,[PolicyEndDate]
           ,[RiskLine]
           ,[ProductCode]
           ,[ProductDescription]
           ,[SubProductcode]
           ,[SubProductDescription]
           ,[ClientId]
           ,[ClientName]
           ,[RiskAddress]
           ,[RiskAddressId]
           ,[ItemNumber]
           ,[CoverageDEscription]
           ,[CoverageLevelSumInsured_Reporting]
           ,[CoveragePremium]
           ,[Branch]
           ,[RI]
           ,[RiId]
           ,[TransactionType2]
           ,[CoverageLevelSumInsured]
           ,[Currency]
           ,[island]
           ,[IncludingPremiumAdjustment]
           ,[Entry_Date]) VALUES(?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?,	?
)""", row['TransactionType'],	row['PolicyNumber'],	round(row['OrderID'],0),	row['TransactionDate'],	row['PolicyStartDate'],	row['PolicyEndDate'],	row['RiskLine'],	row['ProductCode'],	row['ProductDescription'],	row['SubProductcode'],	row['SubProductDescription'],	round(row['ClientId'],0),	row['ClientName'],	row['RiskAddress'],	round(row['RiskAddressId'],0),	row['ItemNumber'],	row['CoverageDEscription'],	round(row['CoverageLevelSumInsured_Reporting'],2),	round(row['CoveragePremium'],2),	row['Branch'],	row['RI'],	row['RiId'],	row['TransactionType2'],	round(row['CoverageLevelSumInsured'],2),	row['Currency'],	row['island'],	round(row['IncludingPremiumAdjustment'],2),	row['Entry_Date'])

        # the connection is not autocommitted by default, so we must commit to save our changes
        cnxn.commit()

        
        print(eachclm+" 1")
        RIComputation_v_4_surplus_claims.claimsretention()
        print(eachclm+" 2")
        
        
        #print(clmspecificdata)
        i=clmspecificdata.head(1).index.values[0]
        riCompdata2=pd.read_csv(config_links['links']['excel4'])
        appended_data1=riCompdata2.loc[(riCompdata2['PolicyNumber']==clmData.loc[i,"PolicyNo"]) & (riCompdata2['ItemNumber']==clmData.loc[i,"ItemNumber"]) & (riCompdata2['ClientId']==clmData.loc[i,"ClientId"]) ,["IUR Number"]]#,'Share Percentage-Retention','Share Percentage-Quota share','Share Percentage-Surplus'
        #print(eachclm+" 3")
        #print(appended_data1)
        firstrowiur=appended_data1["IUR Number"].head(1).values
        #print(firstrowiur)
        firstrowiur=str(firstrowiur)[2:-2]
        
        #to get first row of iur
        firow=riCompdata2.loc[riCompdata2['IUR Number'] == firstrowiur]
        firow=firow.replace(np.NaN, 0)
        #'IUR no'
        iurno=appended_data1["IUR Number"].head(1).values
        if iurno.size == 0:
            iurno=0
            clmData.loc[i,'IUR Number']=iurno
        else:
            clmData.loc[i,'IUR Number']=iurno[0]
        
        #Reserve Amount less Liability
        ra=clmspecificdata['ClaimAmountminusDED'].head(1).values
        try:
            prdt=firow['SubProductcode'].head(1).values[0]
            
        except:
            prdt=firow['SubProductcode'].head(1).values
            
            
        if len(prdt) == 0:
            prd=0
            clmData.loc[i,'Reserve Amount less Liability']=prd
            
        elif ((prdt[:2]=='HM') or (prdt[:2]=='CR')):
            prd=(ra-((ra/100)*2.5))
            clmData.loc[i,'Reserve Amount less Liability']=prd
            

        elif ((prdt[:2]!='HM') or (prdt[:2]!='CR')):
            clmData.loc[i,'Reserve Amount less Liability']=ra
            
        
        #print(eachclm+" 4")    
        #Share Percentage-Retention
        try:
            spr=firow["Share Percentage-Retention"].head(1).values[0]
        except:
            spr=firow["Share Percentage-Retention"].head(1).values
            
        if '[' in str(spr):
            spr=str(spr)[2:-2]
            spr=float(spr)
        clmData.loc[i,"Share Percentage-Retention"]=spr
        #'Share Percentage-Quota share'
        spq=firow['Share Percentage-Quota share'].head(1).values[0]
        if '[' in str(spq):
            spq=str(spq)[2:-2]
            spq=float(spq)
        clmData.loc[i,'Share Percentage-Quota share']=spq    	

        #'Share Percentage-Surplus1'
        sps1=firow['Share Percentage-Surplus1'].head(1).values[0]
        if '[' in str(sps1):
            
            sps1=str(sps1)[2:-2]
            sps1=float(sps1)
        clmData.loc[i,'Share Percentage-Surplus1']=sps1
        #'Share Percentage-Surplus2'
        sps2=firow['Share Percentage-Surplus2'].head(1).values[0]
        #print(sps2)
        if '[' in str(sps2):
            sps2=str(sps2)[2:-2]
            sps2=float(sps2)
        clmData.loc[i,'Share Percentage-Surplus2']=sps2

        #print(eachclm+" 5")
        if str(clmspecificdata['Reins. %'].head(1).values[0])=='nan':
            #ri single roe
            rireserve=clmspecificdata['ClaimAmountminusDED'].head(1).values
            ripaid=clmspecificdata['PaidAmount'].head(1).values
            riclaimstatus=clmspecificdata['OutstandingAmount'].head(1).values


        else:
            per = clmspecificdata[clmspecificdata['RIID'].isin([23, 0,163048])]
            per=per['Reins. %'].head(1).values
            print("ri"+str(per))
            #ri single row
            rireserve=(((clmspecificdata['ClaimAmountminusDED'].head(1).values)/100)*per)
            ripaid=(((clmspecificdata['PaidAmount'].head(1).values)/100)*per)
            riclaimstatus=(((clmspecificdata['OutstandingAmount'].head(1).values)/100)*per)


##        #ri sums 
##        rireserve=clmspecificdata[' RI Reserve'].sum()
##        ripaid=clmspecificdata['RI Paid'].sum()
##        riclaimstatus=clmspecificdata['RI Claim Balance'].sum()
##
        #Retention Reserve Share
        rrs=(float(rireserve/100)*float(spr))
        clmData.loc[i,"Retention Reserve Share"]=rrs
        
        #QS Reserve Share
        qsrs=(float(rireserve/100)*float(spq))
        clmData.loc[i,"QS Reserve Share"]=qsrs
        #SS1 Reserve Share
        ssrs1=(float(rireserve/100)*float(sps1))
        clmData.loc[i,"SS1 Reserve Share"]=ssrs1

        #SS2 Reserve Share
        ssrs2=(float(rireserve/100)*float(sps2))
        clmData.loc[i,"SS2 Reserve Share"]=ssrs2

        
        #Retention Claims Paid Share
        rcps=(float(ripaid/100)*float(spr))
        clmData.loc[i,"Retention Claims Paid Share"]=rcps
        #QS Claims Paid Share
        qscps=(float(ripaid/100)*float(spq))
        clmData.loc[i,"QS Claims Paid Share"]=qscps
        #SS1 Claims Paid Share
        sscps1=(float(ripaid/100)*float(sps1))
        clmData.loc[i,"SS1 Claims Paid Share"]=sscps1
        #SS2 Claims Paid Share
        sscps2=(float(ripaid/100)*float(sps2))
        clmData.loc[i,"SS2 Claims Paid Share"]=sscps2


        
        #Retention Claims Balance Share
        rcbs=(float(riclaimstatus/100)*float(spr))
        clmData.loc[i,"Retention Claims Balance Share"]=rcbs
        #QS Claims Balance Share
        qscbs=(float(riclaimstatus/100)*float(spq))
        clmData.loc[i,"QS Claims Balance Share"]=qscbs
        #SS1 Claims Balance Share
        sscbs1=(float(riclaimstatus/100)*float(sps1))
        clmData.loc[i,"SS1 Claims Balance Share"]=sscbs1
        #SS2 Claims Balance Share
        sscbs2=(float(riclaimstatus/100)*float(sps2))
        clmData.loc[i,"SS2 Claims Balance Share"]=sscbs2

        iland=firow['island'].head(1).values[0]
        clmData.loc[i,"Island"]=iland
        #print(eachclm+" 6")
        
        SevExcep=riCompdata[(riCompdata['PolicyNumber']==clmspecificdata['PolicyNo'].head(1).values[0])]
        colSevExcep = SevExcep["ItemNumber"]
        max_valSevExcep = colSevExcep.max()
        
        address=firow['RiskAddress'].head(1).values[0]
        print("address "+str(address).lower())
        reason=""
        #send rows to exception which hits surplus 2 , #sending rows to exception which is greater than 7m and single policy
        if ((firow['Surplus2'].head(1).values[0]=='Yes') or ((firow['SI_forexception'].head(1).values[0]>7000000) and (max_valSevExcep==1)) or(('albany') in str(address).lower()) or ((firow['SI_forexception'].head(1).values[0]>10200000) and (firow['SI_forexception'].head(1).values[0]<14400000))):
            if ((firow['SI_forexception'].head(1).values[0]>10200000) and (firow['SI_forexception'].head(1).values[0]<14400000)): 
                if reason=="" :
                    reason="ICB SI greater than $10.2M"
                elif reason != "":
                    reason=reason+", ICB SI greater than $10.2M"
            if ((firow['SI_forexception'].head(1).values[0]>7000000) and (max_valSevExcep==1)):
                 
                if reason=="" :
                    reason="Single risk policy with ICB SI greater than $7M"
                elif reason != "":
                    reason=reason+", Single risk policy with ICB SI greater than $7M"



            if (firow['Surplus2'].head(1).values[0]=='Yes'): 
                if reason=="" :
                    reason="ICB SI greater than $14.4M"
                elif reason != "":
                    reason=reason+", ICB SI greater than $14.4M"


           

            if (('albany') in str(address).lower()): 
                if reason=="" :
                    reason="Risk at Albany"
                elif reason != "":
                    reason=reason+", Risk at Albany"

            clmData.loc[i,"Exception Reason"]=reason
            index_names = clmData[ clmData['Claim_Number'] == eachclm ].index
            deleted_data = deleted_data.append(clmData[ clmData['Claim_Number'] == eachclm ])
            drop=clmData.drop(index_names, inplace = True)
        #print(eachclm+" 7")   
    except:
        logging.warning("**************")
        logging.exception(eachclm)
        reason="Data Descrepancies"
        clmData.loc[i,"Exception Reason"]=reason
        index_names = clmData[ clmData['Claim_Number'] == eachclm ].index
        deleted_data = deleted_data.append(clmspecificdata)
        clmData.drop(index_names, inplace = True)
        

    

    
    


    
   
    
    
        

#print(clmData)
writer = pd.ExcelWriter(config_links['links']['output'], engine='xlsxwriter')
del clmData["Exception Reason"]
clmData.to_excel(writer, sheet_name='Sheet1', index=False)
deleted_data.to_excel(writer, sheet_name='Exceptions', index=False)
writer.save()
##clmData.to_excel(r"C:\Users\Manomay\Desktop\icb\claims\claims.xlsx",sheet_name='Sheet1',index=False)    
##deleted_data.to_excel(r"C:\Users\Manomay\Desktop\icb\claims\claims.xlsx",sheet_name='Sheet2',index=False)  
