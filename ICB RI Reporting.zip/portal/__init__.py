import os
import logging
from logging import Formatter
from logging.handlers import RotatingFileHandler
from flask import Flask
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix
from .helpers import get_config_file_path
from flask_material import Material
from flask_wtf.csrf import CSRFProtect
csrf = CSRFProtect()

APP = None
LOG = logging
WORKER_ID = 0

def init_logger(app):
    global LOG
    log_file = os.path.join(app.config['LOG_DIR'], 'backend.log')

    log_level =  app.config['LOG_LEVEL']
    log_format = Formatter(f"[%(asctime)s][worker-{WORKER_ID}][%(levelname)s] %(message)s")

    TWO_MEGABYTE = 2_000_000
    file_handler = RotatingFileHandler(filename=log_file, maxBytes=TWO_MEGABYTE, backupCount=3)
    file_handler.setLevel(log_level)
    file_handler.setFormatter(log_format)
    app.logger.addHandler(file_handler)

    LOG = app.logger
    LOG.info('Initialized logger with level %s for worker %s', log_level, WORKER_ID)


def init_cors(app):
    CORS(app=app,)
    # CORS(app=app, origins=app.config['CORS_ORIGIN_WHITELIST'], allow_headers=app.config['CORS_HEADERS'])
    LOG.info('Initialized CORS')


def init_app():
    global APP

    if APP is not None:
        return APP

    APP = Flask(__name__, static_url_path='/static')

    csrf.init_app(APP)
    APP.debug = True
    Material(APP)


    config_file_path = get_config_file_path()
    if config_file_path is not None:
        if isinstance(config_file_path, dict):
            APP.config.update(config_file_path)
        elif config_file_path.endswith('.py'):
            APP.config.from_pyfile(config_file_path)

    init_logger(APP)
    try:
        from . import routes, models, api
        api.init_app(APP)
        models.init_app(APP)
        routes.init_app(APP)
        init_cors(APP)
    except Exception as e:
        LOG.error('An error happened during initializing app components: %s', e)
        raise

    APP.logger.info('App Initialization is finished successfully')
    return APP

