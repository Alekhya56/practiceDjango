
import datetime
from . import db

class IurHistory(db.Model):
    __tablename__ = 'IurHistory'
    id = db.Column(db.Integer, primary_key=True)
    PrevIurNumber = db.Column(db.String(100))
    LatestIurNumber = db.Column(db.String(100))
    ClientId = db.Column(db.String(500))
    PolicyNumber = db.Column(db.String(500))
    PrevRiskAddressId = db.Column(db.String(500))
    LatestRiskAddressId = db.Column(db.String(500))
    RiskAddress = db.Column(db.String(1000))
    RiskLine = db.Column(db.String(500))    
    SubProductDescription = db.Column(db.String(500))
    LastUpdatedBy = db.Column(db.String(255))
    LastUpdatedDate = db.Column(db.Date, default=datetime.datetime.now)