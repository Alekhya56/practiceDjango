from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate

db = SQLAlchemy()

def init_app(app):

    db.init_app(app)
    # app.logger.info("initialized models")
    with app.app_context():
        migrate = Migrate(app,db,compare_type=True)
        from .users import Users
        from .monthly_reports import MultiPolicy
        from .iur_history import IurHistory
        login_manager = LoginManager()
        login_manager.login_view = 'api.auth_login'
        login_manager.init_app(app)
        @login_manager.user_loader
        def load_user(user_id):
            # since the user_id is just the primary key of our user table, use it in the query for the user
            return Users.query.get(int(user_id))
        db.create_all()
        db.session.commit()
        # app.logger.info('All the tables are created')