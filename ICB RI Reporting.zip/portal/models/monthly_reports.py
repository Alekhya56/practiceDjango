
import datetime

import jwt
from flask import current_app as app

from . import db

class MultiPolicy(db.Model):
    __tablename__ = 'MultiPolicy'
    id = db.Column(db.Integer, primary_key=True)
    TransactionType = db.Column("TransactionType", db.String(30), unique=False, nullable=True)
    PolicyNumber = db.Column("PolicyNumber", db.String(500) )
    OrderID = db.Column("OrderID", db.Integer)
    TransactionDate = db.Column("TransactionDate", db.Date())
    PolicyStartDate = db.Column("PolicyStartDate", db.Date())
    PolicyEndDate = db.Column("PolicyEndDate", db.Date())
    RiskLine = db.Column("RiskLine", db.String(500) )
    ProductCode = db.Column("ProductCode", db.String(100) )
    ProductDescription = db.Column("ProductDescription", db.String(500) )
    SubProductcode = db.Column("SubProductcode", db.String(100) )
    SubProductDescription = db.Column("SubProductDescription", db.String(500) )
    ClientId = db.Column("ClientId", db.String(500) )
    ClientName = db.Column("ClientName", db.String(500) )
    RiskAddress = db.Column("RiskAddress", db.String(1000))
    RiskAddressId = db.Column("RiskAddressId", db.String(1000))
    ItemNumber = db.Column("ItemNumber", db.Integer)
    CoverageDescription = db.Column("CoverageDEscription", db.String(500) )
    CoverageLevelSumInsured_Reporting = db.Column("CoverageLevelSumInsured_Reporting", db.Float())
    CoveragePremium = db.Column("CoveragePremium", db.Float())
    Branch = db.Column("Branch", db.String(100) )
    RI = db.Column("RI", db.Float())
    RiId = db.Column("RiId", db.String(100))
    TransactionType2 = db.Column("TransactionType2", db.String(50) )
    CoverageLevelSumInsured = db.Column("CoverageLevelSumInsured", db.Float())
    Currency = db.Column("Currency", db.String(50) )
    Island = db.Column("Island", db.String(500) )
    SpecialIndicator = db.Column("SpecialIndicator", db.String(100) )
    IUR_Number = db.Column("IUR Number", db.String(100) )
    Status = db.Column(db.String(255))
    LastUpdatedBy = db.Column(db.String(255))
    LastUpdatedDate = db.Column(db.Date, default=datetime.datetime.now)
    EntryDate = db.Column(db.Date)