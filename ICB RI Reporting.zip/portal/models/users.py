from flask_login import UserMixin
from . import db
# from flask_script import Manager
# from flask_migrate import Migrate, MigrateCommand, migrate
"""
Schema stores Employee details

returns: Employee Name

"""

class Users(UserMixin, db.Model):
    __tablename__ = "Users"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    UserName = db.Column(db.String(50), unique=False, nullable=False)
    Password = db.Column(db.String(150),nullable=False)
    Email	= db.Column(db.String(50), unique=True, nullable=True)
    Role = db.Column(db.String(150), nullable=False)
    Status = db.Column(db.String(150), nullable=False)
    TemporaryPassword= db.Column(db.Boolean, unique=False, nullable=True)
    LastLogin = db.Column(db.String(100), unique=False, nullable=True)
    Action_by = db.Column(db.String(100), unique=False, nullable=True)
    LastThreePasswords = db.Column(db.String(500), unique=False, nullable=True)
    LastPasswordChanged = db.Column(db.String(100), unique=False, nullable=True)
    Last_Modified = db.Column(db.String(100), unique=False, nullable=True)
    Action = db.Column(db.String(100), unique=False, nullable=True)
         
    def __repr__(self):
        return f"User('{self.UserName}')"

