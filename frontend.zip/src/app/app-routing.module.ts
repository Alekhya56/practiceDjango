import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { FeaturesModule } from './features/features.module';
import { CoreModule } from 'src/app/core/core.module';
const routes: Routes = [
{
    path: 'login',
    loadChildren: () => import ('src/app/core/core.module').then ( (m) => m.CoreModule),
  },

  {
    path: '',
    loadChildren: () => import ('src/app/core/core.module').then ( (m) => m.CoreModule),
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes),CoreModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
