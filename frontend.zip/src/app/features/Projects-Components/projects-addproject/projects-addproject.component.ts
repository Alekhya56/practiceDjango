import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { Projectadd } from '../../FormGroups/project-add';
import { AddProject } from '../../Interfaces/addproject';
import { DatePipe } from '@angular/common';
import { AddprojectService } from '../../services/addproject.service';
import { GetemployeesProjectsmanagersService } from '../../../shared/api-services/getemployees-projectsmanagers.service';
import { Observable } from 'rxjs';
import { Employee } from '../../Interfaces/getProjectDescription';

import { Status, status } from 'src/app/shared/classes/get-status';
import { GetDefaultvaluesService } from '../../../shared/api-services/get-defaultvalues.service';
import { SuccessComponent } from '../../../shared/splash_screens/success/success.component';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';

import { PrimeNGConfig } from 'primeng/api';
import { GetProjectEmployees } from '../../../shared/classes/get-project-managers';
import { Employees } from '../../../shared/classes/employees';
import { SecurelsService } from '../../../core/services/securels.service';
import { MatRadioChange } from '@angular/material/radio';
import { projectType, typeproject } from 'src/app/shared/classes/project-type';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
@Component({
  selector: 'app-projects-addproject',
  templateUrl: './projects-addproject.component.html',
  styleUrls: ['./projects-addproject.component.scss'],
})
export class ProjectsAddprojectComponent extends Projectadd {
  max_date!: Date;
  constructor(
    private securels: SecurelsService,
    private toastr: ToastrService,
    private primengConfig: PrimeNGConfig,
    private dialogRef: MatDialogRef<ProjectsAddprojectComponent>,
    private router: Router,
    private dialog: MatDialog,
    private getstatuservice: GetDefaultvaluesService,
    private getemp_projectManagers: GetemployeesProjectsmanagersService,
    private datepipe: DatePipe,
    private addproject: AddprojectService
  ) {
    super();
  }
  project_managers$!: Employees[];
  status$!: status[];
  project_type$!: typeproject[];

  ngOnInit(): void {
    console.log('Projct add component');
    this.getStatus();
    this.getProjectManagers();
    this.getProjectType();
    // console.log('Karthikeyan project Type',this.project_type$)
    console.log(this.status$);
    console.log(this.projectadd_form.get('project_name')?.value);
  }
  getStatus() {
    this.getstatuservice.get_status_values().subscribe((res) => {
      console.log(res['work_status']);
      this.status$ = res['work_status'];
    });
  }
  getProjectType() {
    this.getstatuservice.get_project_type().subscribe((res) => {
      // console.log(res['project_type']);
      this.project_type$ = res['project_type'];
    });
  }
  getProjectManagers() {
    this.getemp_projectManagers.get_ProjectManagers().subscribe((res) => {
      console.log(res);
      this.project_managers$ = res['project_managers'];
    });
  }
  deviatons_radiochange(event: MatRadioChange) {
    console.log(event);
    if (event['value'] == "NO") {
      this.projectadd_form.get("reason_for_deviation")?.setValue("None")
      this.projectadd_form.get("reason_for_deviation")?.disable()
    } else {
      this.projectadd_form.get("reason_for_deviation")?.enable()
     this.projectadd_form.get("reason_for_deviation")?.reset()
    }

  }
  //Add project details to backend
  Add_Project() {
    console.log("project add form",this.projectadd_form)
    type lists = { [key: string]: any };
    const list: lists = {};
    for (const fields in this.projectadd_form.controls) {
      const value = this.projectadd_form.get(fields)?.value;

      if (fields == 'start_date' || fields == 'end_date') {
        list[fields] = this.datepipe.transform(value, 'YYYY/MM/dd') || '';
      } else {
        list[fields] = value;
      }
      let updatedby = localStorage.getItem('user_name')!;
      updatedby = this.securels.securedecrypt(updatedby);
      list['updated_by'] = updatedby;
    }
    console.log(list);
    this.addproject.add_project(list).subscribe((res) => {
      console.warn('Karthikeyan -addproject', res);

      if (res['result'] == 'success') {
        this.toastr.success('Project Added Successfully', 'Success');
        setTimeout(() => {
          this.dialogRef.close();
          let currentUrl = this.router.url;
          this.router.navigateByUrl('/Projects');
          window.location.reload();
          this. router. navigate([currentUrl]);
        }, 500);
      } else if (res['result'] == 'error') {
        this.toastr.error('Project Added was Unsuccessfully', 'Failed');
        // setTimeout(() => {
        //   this.dialogRef.close();
        //   this.router.navigateByUrl('/Projects');
        //   window.location.reload();
        // }, 500);
      }else {

        this.toastr.error("Please fill mandatory fields")
      }
    });
  }

  projectStartDate(type: string, event: MatDatepickerInputEvent<Date>) {
    // console.log(event,event['value']?.getFullYear()!)
    let newyear:Date=new Date()
    console.log('last date:',newyear)
    newyear.setFullYear(event['value']?.getFullYear()!)
    // console.log(newyear)
    this.max_date=newyear
    // console.log(this.min_date)

  }
}
