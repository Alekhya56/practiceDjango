import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectsAddprojectComponent } from './projects-addproject.component';

describe('ProjectsAddprojectComponent', () => {
  let component: ProjectsAddprojectComponent;
  let fixture: ComponentFixture<ProjectsAddprojectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectsAddprojectComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjectsAddprojectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
