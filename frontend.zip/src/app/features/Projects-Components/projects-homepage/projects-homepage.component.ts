import { SecurelsService } from './../../../core/services/securels.service';
import { ProjectsAddprojectComponent } from './../projects-addproject/projects-addproject.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Table } from 'primeng/table';
import {  projectobject } from '../../Interfaces/Project_Records';
import { Router, ActivatedRoute } from '@angular/router';
import { GetProjectService } from 'src/app/shared/api-services/get-project.service';
import { Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';
import { GetemployeesProjectsmanagersService } from '../../../shared/api-services/getemployees-projectsmanagers.service';
import { SuccessComponent } from '../../../shared/splash_screens/success/success.component';
import { Title } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-projects-homepage',
  templateUrl: './projects-homepage.component.html',
  styleUrls: ['./projects-homepage.component.scss']
})
export class ProjectsHomepageComponent implements OnInit {

  @ViewChild('project') project!:Table
url!:string
projects$!:Observable<projectobject[any]>
  cols!: any[];

project_data!:any[]
project_managers$!:Observable<string[]>
  constructor(private securels:SecurelsService,private toastr: ToastrService,private titleService: Title,private route: ActivatedRoute,private getemp_projectManagers:GetemployeesProjectsmanagersService,private projectservice:GetProjectService,private matdialog:MatDialog,public router:Router) {

  }

  ngOnInit(): void {

    console.log('sakthi')
    this.projects$=this.projectservice.get_project()
    console.log(this.projects$)




  }
  applyfilterGlobal($event:any,value:string){
    console.log(event,value)
  this.project.filterGlobal((event?.target as HTMLInputElement).value,value)
  }

  openProjectAddForm(){
    if (
      this.securels.securedecrypt(localStorage.getItem('role')!) ===
        'Project Manager' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'HR' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'CEO'
    ) {
    this.matdialog.open(ProjectsAddprojectComponent,{height:'90%'});
    }else {
      this.toastr.warning("Sorry You don't have permissions to add new Employee");
    }
  }
  navigate_to(name:string,id:string)
  {
    console.log(name)

    localStorage.setItem("name",this.securels.secureencrypt(name))
    localStorage.setItem("projectid",this.securels.secureencrypt(id))

    this.titleService.setTitle(this.route.snapshot.data[name]);
  }
encryptid(id:string){
 let encryptid=encodeURIComponent(id)
console.log(this.url)
return encryptid
}

}
