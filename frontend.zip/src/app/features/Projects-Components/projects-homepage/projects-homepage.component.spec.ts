import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectsHomepageComponent } from './projects-homepage.component';

describe('ProjectsHomepageComponent', () => {
  let component: ProjectsHomepageComponent;
  let fixture: ComponentFixture<ProjectsHomepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectsHomepageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjectsHomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
