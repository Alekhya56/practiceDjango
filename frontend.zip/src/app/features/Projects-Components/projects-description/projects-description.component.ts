import { LoaderserviceService } from './../../../core/services/loaderservice.service';
import { UpdateProjectinfoService } from './../../services/update-projectinfo.service';
import { Component, OnInit } from '@angular/core';
import { ProjectsAddemployeeComponent } from './projects-addemployee/projects-addemployee.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteScreenComponent } from 'src/app/shared/splash_screens/delete-screen/delete-screen.component';
import { ActivatedRoute } from '@angular/router';
import { GetProjectDescriptionService } from '../../services/get-project-description.service';
import { ProjectDescription } from '../../FormGroups/project_description';
import {
  Description,
  getProjectDescription,
  Documents,
  Employee,
  Details,
} from '../../Interfaces/getProjectDescription';
import { DatePipe } from '@angular/common';
import { UpdateProject } from '../../Interfaces/update-project';
import { project } from '../../Interfaces/Project_Records';
import { Status, status } from '../../../shared/classes/get-status';
import { GetDefaultvaluesService } from '../../../shared/api-services/get-defaultvalues.service';
import { Observable } from 'rxjs';
import { GetemployeesProjectsmanagersService } from '../../../shared/api-services/getemployees-projectsmanagers.service';
import { ToastrService } from 'ngx-toastr';
import { SecurelsService } from '../../../core/services/securels.service';
import { Employees } from 'src/app/shared/classes/employees';
import { typeproject } from 'src/app/shared/classes/project-type';
import { MAT_SLIDE_TOGGLE_DEFAULT_OPTIONS } from '@angular/material/slide-toggle';
@Component({
  selector: 'app-projects-description',
  templateUrl: './projects-description.component.html',
  styleUrls: ['./projects-description.component.scss'],
})
export class ProjectsDescriptionComponent
  extends ProjectDescription
  implements OnInit
{
  splink: any;
  Repo_link: any;
  status$!: status[];
  project_type$!: typeproject[];
  loader: boolean = true;
  description!: Description;
  Labels: string[] = ['Description', 'Document Repos'];
  cols!: any[];
  emps!: Employee[];
  links!: Documents[];
  project_manager!: string;
  project_managers!: Employees[];
  project_details!: Details[];
  isInputDisable: boolean = false;
  link!: any;
  show: boolean = true;
  constructor(
    private securels: SecurelsService,
    public loaderService: LoaderserviceService,
    private toastr: ToastrService,
    private getprojectmanagers: GetemployeesProjectsmanagersService,
    private getstatuservice: GetDefaultvaluesService,
    private update_projectdetails: UpdateProjectinfoService,
    private datepipe: DatePipe,
    private getproject: GetProjectDescriptionService,
    private route: ActivatedRoute,
    private matdialog: MatDialog
  ) {
    super();
  }
  isDocRepoDisable = true;
  ngOnInit(): void {
    this.show = true;
    this.loader = true;
    
    this.Repo_link = this.projectrepo_linkform.get('docs_repo')?.value!;

    this.getStatus();
    this.getProjectType();
    let projectid = this.securels.securedecrypt(
      localStorage.getItem('projectid')!
    );
    let projectname = this.securels.securedecrypt(
      localStorage.getItem('name')!
    );
    this.projectlist_form.get('project_id')?.setValue(projectid);
    this.get_project_Desc(projectid);

    this.disableInput();
    this.getProjectManagers();
    setTimeout(() => {
      this.loader = false;
    }, 2000);
  }

  // onClick() {
  //   console.log(this.splink);
  //   location.href = this.splink;
  // }

  getStatus() {
    this.getstatuservice.get_status_values().subscribe((res: Status) => {
      this.status$ = res['work_status'];
    });
  }
  getProjectManagers() {
    this.getprojectmanagers.get_ProjectManagers().subscribe((res) => {
      console.log(res);

      this.project_managers = res['project_managers'];
    });
  }
  getProjectType() {
    this.getstatuservice.get_project_type().subscribe((res) => {
      // console.log(res['project_type']);
      this.project_type$ = res['project_type'];
    });
  }
  // geting project description details from backend using getproject description service
  get_project_Desc(projectid: string) {
    this.getproject
      .get_project_description(projectid)
      .subscribe((res: getProjectDescription) => {
        debugger;
        this.links = res['docs_repo']!;
        this.description = res['description']!;
        this.emps = res['Project_Team']!;
        this.project_details = res['detail']!;
        if (this.description['revised_project_end_date'] == null) {
          this.description['revised_project_end_date'] = '';
        } else if (this.description['support_start_date'] == null) {
          this.description['support_start_date'] = '';
        }
        this.set_Values();
      });
  }
  openProjectEmpAddForm() {
    if (
      this.securels.securedecrypt(localStorage.getItem('role')!) ===
        'Project Manager' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'HR' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'CEO'
    ) {
    this.matdialog.open(ProjectsAddemployeeComponent, {
      height: '90%',
      data: { disable: false, project: this.project_details, showDiv: '1' },
    });
  }else {
    this.toastr.warning("Sorry You don't have permissions to add Employee to Project");
  }
  }
  showEmpForm(emp: Employee) {
    console.log(emp);
    this.matdialog.open(ProjectsAddemployeeComponent, {
      height: '90%',
      data: {
        disable: true,
        project: this.project_details,
        showDiv: '3',
        Emp: emp,
        value: 'DisableInput',
      },
    });
  }
  editEmpForm(emp: Employee) {
    this.matdialog.open(ProjectsAddemployeeComponent, {
      height: '90%',
      data: {
        disable: false,
        project: this.project_details,
        showDiv: '2',
        Emp: emp,
        value: 'EnableInput',
      },
    });
  }
  deleteProjectEmp(emp: Employee) {
    let employee_id = emp.employee_id;

    if (
      this.securels.securedecrypt(localStorage.getItem('role')!) ===
        'Project Manager' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'HR' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'CEO'
    ) {
      let project_id = this.securels.securedecrypt(
        localStorage.getItem('projectid')!
      );
      let updated_by: string = this.securels.securedecrypt(
        localStorage.getItem('user_name')!
      );
      console.log(employee_id);
      this.matdialog.open(DeleteScreenComponent, {
        data: {
          project_id: project_id,
          employee_id: employee_id,
          updated_by: updated_by,
          message: 'Delete Emp from the project',
        },
      });
    } else {
      this.toastr.warning("Sorry You don't have permissions to Delete");
    }
  }
  enableInput() {
    if (
      this.securels.securedecrypt(localStorage.getItem('role')!) ===
        'Project Manager' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'HR' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'CEO'
    ) {
      this.isInputDisable = true;
      this.projectdesc_form.enable();
      // this.projectlist_form.enable();
      this.projectrepo_linkform.enable();
    } else {
      this.toastr.warning("Sorry You don't have permissions to Edit");
    }
    this.show = false;
  }
  disableInput() {
    this.isInputDisable = false;
    this.projectdesc_form.disable();
    this.projectlist_form.disable();
    this.projectrepo_linkform.disable();
    this.show = true;
  }
  deleteProject() {
    if (
      this.securels.securedecrypt(localStorage.getItem('role')!) ===
        'Project Manager' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'HR' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'CEO'
    ) {
      let project_id = this.securels.securedecrypt(
        localStorage.getItem('projectid')!
      );
      let updated_by: string = this.securels.securedecrypt(
        localStorage.getItem('user_name')!
      );
      console.log('projectid', project_id);
      this.matdialog.open(DeleteScreenComponent, {
        data: {
          project_id: project_id,
          updated_by: updated_by,
          message: 'DeleteProject',
        },
      });
    } else {
      this.toastr.warning("Sorry You don't have permissions to Delete");
    }
  }
  documentRepoEdit() {
    this.isDocRepoDisable = !this.isDocRepoDisable;
  }
  save_projectinfo() {
    let data: { [key: string]: UpdateProject[] } = {};
    for (const control in this.projectdesc_form.controls) {
      console.log(control);
      data[control] = this.projectdesc_form.get(control)?.value;
    }
    for (const control in this.projectlist_form.controls) {
      data[control] = this.projectlist_form.get(control)?.value;
    }
    for (const control in this.projectrepo_linkform.controls) {
      data[control] = this.projectrepo_linkform.get(control)?.value;
    }
    // console.log('Karthikeyan',data);
    this.update_projectdetails.update_projectdetails(data).subscribe((res) => {
      console.log(res);
      console.error(res);
      if (res['result'] == 'success') {
        this.toastr.success(
          'Project Details are Updated Successfully',
          'Message'
        );
        setTimeout(() => {
          window.location.reload();
        }, 500);
      } else if (res['result'] == 'error') {
        this.toastr.error('Project Details are unable to update', 'Failed');
        setTimeout(() => {
          window.location.reload();
        }, 500);
      }
    });
    this.disableInput();
  }

  discardChanges() {
    this.toastr.warning("No changes are done in the Project Details");
    this.set_Values();
    this.disableInput(); 
  }

  save_repoinfo() {}
  set_Values() {
    console.error('description', this.description);
    for (const fields in this.projectlist_form.controls) {
      this.projectlist_form
        .get(fields)
        ?.setValue(
          this.project_details[fields as keyof typeof this.project_details]
        );
    }
    for (const control in this.projectrepo_linkform.controls) {
      this.splink = this.projectrepo_linkform
        .get(control)
        ?.setValue(this.links);
    }
    for (const fields in this.projectdesc_form.controls) {
      if (
        fields == 'start_date' ||
        fields == 'end_date' ||
        fields == 'revised_project_end_date' ||
        fields == 'support_start_date'
      ) {
        let value = this.datepipe.transform(
          this.description[fields as keyof typeof this.description].toString(),
          'YYYY-MM-dd'
        );
        this.projectdesc_form.get(fields)?.setValue(value);
      } else {
        this.projectdesc_form
          .get(fields)
          ?.setValue(this.description[fields as keyof typeof this.description]);
      }
    }
    localStorage.setItem(
      'currentroute',
      this.projectlist_form.get('customer_name')?.value!
    );
    /*  this.projectdesc_form.disable();
    this.projectlist_form.disable();
    this.projectrepo_linkform.disable(); */
    this.disableInput();
  }

  // this.Repo_link = this.projectrepo_linkform.get('docs_repo')?.value!;
  // console.log(Repo_link)

  redirect() {
    this.link = this.projectrepo_linkform.get('docs_repo')?.value!;

    // // window.location.href='https://www.google.com/search?q=google&oq=google&aqs'
    window.open(this.link);
    // return window.location.href = link;
  }
}
