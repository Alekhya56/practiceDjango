import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectsAddemployeeComponent } from './projects-addemployee.component';

describe('ProjectsAddemployeeComponent', () => {
  let component: ProjectsAddemployeeComponent;
  let fixture: ComponentFixture<ProjectsAddemployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectsAddemployeeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjectsAddemployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
