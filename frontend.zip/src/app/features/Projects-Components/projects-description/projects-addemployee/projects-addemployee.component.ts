import { projectEmp } from './../../../FormGroups/ProjectEmp';
import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators,FormArray } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EditProjectEmployee } from 'src/app/features/Interfaces/edit_ProjectEmployee';
import { SELECTBUTTON_VALUE_ACCESSOR } from 'primeng/selectbutton';
import { MAT_BOTTOM_SHEET_DATA } from '@angular/material/bottom-sheet';
import { AddUpdate_Emp_To_Project, Details, Employee } from '../../../Interfaces/getProjectDescription';
import { SaveProjectEmpDetailsService } from 'src/app/features/services/save-project-emp-details.service';
import { GetemployeesProjectsmanagersService } from '../../../../shared/api-services/getemployees-projectsmanagers.service';
import { Observable } from 'rxjs';
;
import { ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Status,status } from '../../../../shared/classes/get-status';
import { GetDefaultvaluesService } from '../../../../shared/api-services/get-defaultvalues.service';
import { MatSelectChange } from '@angular/material/select';
import { ToastrService } from 'ngx-toastr';
import { Employees } from '../../../../shared/classes/employees';
import { SecurelsService } from '../../../../core/services/securels.service';
import { Designation } from 'src/app/shared/classes/designation';
import { designation } from '../../../../shared/classes/designation';
import { workType } from 'src/app/shared/classes/work-type';
import { statusofwork, StatusOfWork } from 'src/app/shared/classes/get-status-of-work';

@Component({
  selector: 'app-projects-addemployee',
  templateUrl: './projects-addemployee.component.html',
  styleUrls: ['./projects-addemployee.component.scss']
})
export class ProjectsAddemployeeComponent extends projectEmp implements OnInit {
  isFormDisable:boolean=false
  isShowDiv?:string;
  empData:Employee={}
  project_details!:Details
  employee_list!: Employees[]
  projectmanagers_list!:Employees[]
  status!:status[]
  designations!: designation[]
  work_type!: workType[]
  status_of_work!: statusofwork[]
  constructor(private securels: SecurelsService, private dialogRef: MatDialogRef<ProjectsAddemployeeComponent>,
    private getemp_projectManagers: GetemployeesProjectsmanagersService, private toastr: ToastrService,
    private getstatuservice: GetDefaultvaluesService, private datepipe: DatePipe, private route: ActivatedRoute,
    private getProject_Employee: GetemployeesProjectsmanagersService,
    @Inject(MAT_DIALOG_DATA) public data: EditProjectEmployee,
    private saveempprojectdetails: SaveProjectEmpDetailsService) {
    super();
   }

  ngOnInit(): void {
    console.log(this.data,this.route.snapshot.params['projectid'])
    console.log(this.data)
  this.getStatus()
  this.getEmployees()
    this.getDesignations()
    this.getWorkType()
    this.getStatusOfWork()
  this.isFormDisable=this.data.disable;
    console.log(this.data['Emp']!)
    if(this.data['Emp']!=undefined){
    this.empData=this.data['Emp']!}
console.log(this.empData)
    this.project_details=this.data['project']!
    this.isShowDiv=this.data.showDiv;
    if(this.isShowDiv=='3'){
      this.Project_EmpForm.disable()
      this.set_Data_edit_form()
    }
    else if(this.isShowDiv=='2'){
      this.set_Data_edit_form()
    }
  }
  getDesignations(){
    this.getstatuservice.get_designations().subscribe((res)=>{
    console.log(res)
    this.designations=res
    })
  }
  getWorkType(){
    this.getstatuservice.get_work_type().subscribe((res)=>{
      console.log(res)
      this.work_type= res['work_type']
    })
  }
  getStatus(){
    this.getstatuservice.get_status_values().subscribe(res=>{
    console.log(res['work_status'])
    this.status=res['work_status']
  })
}
getEmployees(){
this.getemp_projectManagers.get_Employees().subscribe(res=>{
  console.log(res)

  this.employee_list=res['employee_names']
})
  }
  getStatusOfWork() {
    this.getstatuservice.get_status_of_work().subscribe(res => {
      // console.error('Status of work',res['status_of_work'])
      // this.status = res['status_of_work']
      this.status_of_work = res['status_of_work']
    })
  }
  someMethod(event:string){
console.log(event)
this.empData['employee_id']=event
  }
  set_Data_edit_form(){
    console.log(this.empData)
    for(const fields in this.Project_EmpForm.controls){

      this.Project_EmpForm.get(fields)?.setValue(this.empData[fields as keyof typeof this.empData])
    }
  }
  save_EmpDetails(){
let data:any = {};

for(const control in this.Project_EmpForm.controls){
   console.log(control)
   if(control!="employee_name"){
   if(control=="release_date"){
    data[control]=this.datepipe.transform(this.Project_EmpForm.get(control)?.value,"YYYY/MM/dd") ||  ''
   }
   else{
   data[control]=this.Project_EmpForm.get(control)?.value}
}}
console.log(data)
data['project_id']=this.project_details['project_id']
data['employee_id']=this.empData['employee_id']
console.log(data)
 let updatedby=localStorage.getItem("user_name")!
 updatedby=this.securels.securedecrypt(updatedby)
 data['updated_by']=updatedby

this.saveempprojectdetails.save_empprojectDetails(data).subscribe(res=>{
  console.log(res)
  if(res['result']=="success"){
    this.toastr.success("Added Employee Successfully to Project", "Message")
    this.dialogRef.close()
    window.location.reload();
  }
  else if(res['result']=="error"){
    this.toastr.error("Failed to add employee to Project","Failed")
}   this.dialogRef.close()
})
  }
  // formDisable(state:any){
  //   if(state='add'){
  //     this.isFormDisable=false;
  //   }
  //   else if (state='edit'){
  //     this.isFormDisable=false;
  //   }
  //   else{
  //     this.isFormDisable=true;
  //   }
  // }

}
