import { Description, Details } from './getProjectDescription';
export interface UpdateProject{
project_desc?:Description[]
project?:Details[]
docs_repo?:Document[]
  result?: string
  // revised_project_end_date?: any
  // type_of_support_contract?: any
}
