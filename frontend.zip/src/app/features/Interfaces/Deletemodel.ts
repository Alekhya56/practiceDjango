import { Employee } from './getProjectDescription';
export interface DeleteEmployee_Skill{
  skill_id?:string
  employee_id?:string
  result?:string
}
export interface DeleteEmployee{
  employee_id?:string
  updated_by?:string
  result?:string
}

export interface DeleteProject{
  project_id?: string
  result?:string
}
export interface DeleteEmpProject{
  employee_id?:string
  project_id?: string
  result?:string
}
