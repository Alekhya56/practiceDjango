export interface ProjectList{
phase:string
project_id:string
project_name:string
role:string
status_of_work:string

}
