export interface SkillList{
  skill_description:string
  skill_name:string
  skill_id: string
}
