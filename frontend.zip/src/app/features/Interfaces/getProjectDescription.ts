import { project } from './Project_Records';

export interface getProjectDescription {
  description: Description;
  docs_repo?: Documents[];
  Project_Team?: Employee[];
  detail?: Details[];
}
export interface Details {
  customer_name?: string;
  project_id?: string;
  project_description?: string;
}
export interface Description {
  phase: string;
  scope: string;
  status: string;
  start_date: Date;
  end_date: Date;
  deviations: string;
  reason_For_deviation: string;
  est_need_for_team: string;
  project_manager: string;
  docs_repo: string;
  project_type: string;
  revised_project_end_date: string;
  type_of_support_contract: string;
  support_start_date: string;
}
export interface Documents {
  docs_repo?: string;
}
export interface Employee {
  employee_name?: string;
  role?: string;
  status_of_work?: string;
  release_date?: string;
  employee_id?: string;
  phase?: string;
  est_work?: number;
  expected_hours_per_day?: number;
  result?: string;
  updated_by?: string;
  work_type?: string;
  start_date?: string;
  billable?: string;
}

export interface DeleteProject {
  project_id?: Details;
  result?: string;
}
export interface AddUpdate_Emp_To_Project {
  project_id?: string;
  employee_id?: string;
  role?: string;
  status_of_work?: string;
  phase?: string;
  project_description?: string;
  est_work?: string;
  release_date?: Date;
  employee_designation?: string;
  expected_hours_per_day?: number;
  work_type?: string;
  start_date?: string;
  billable?: string;
  updated_by?: string;
  result?: string;
}
