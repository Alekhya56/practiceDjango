import { Employee, Details } from './getProjectDescription';
export interface EditProjectEmployee{
  Emp?:Employee,
  disable:boolean,
  value?:string
  showDiv?:string,
  project?:Details
}
