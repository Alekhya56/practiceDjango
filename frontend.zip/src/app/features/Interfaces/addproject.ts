import { Time } from "@angular/common";

export interface AddProject{
  project_id?:string;
  project_name?:string;
  customer_name?:string;
  project_description?:string;
  phase?:string;
  scope?:string;
  status?:string;
  sub_status?:string;
  project_manager?:string;
  start_date?:string
  end_date?:string;
  time_need?:string
  docs_repo?:string
  deviations?:string
  result?:string
  updated_by?:string
  reason_for_deviation?: string
  project_type?: string
  type_of_support_contract?: string
  revised_project_end_date?: string
  support_start_date?: string
}
