

export interface projectobject{
/* project_id:string;
  project_name:string;
  phase:string;
  start_date:string;
  end_date:string;
  status:string; */
  [key:string]:any
}
export interface project{
 project_id?:string;
  project_name?:string;
  phase?:string;
  start_date?:Date;
  end_date?:Date
}
