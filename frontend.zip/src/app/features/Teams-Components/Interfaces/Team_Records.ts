export interface Team_Records {
  Id?: string;
  Name?: string;
  Designation?: string;
  Department?: string;
  Email?: string;
}
export interface EmployeeRecords {
  [key: string]: any;
}
