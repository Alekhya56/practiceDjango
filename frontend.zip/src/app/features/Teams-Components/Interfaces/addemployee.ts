export interface Addemployee {
  employee_id?:                  string;
  employee_name?:                string;
  employee_designation?:         string;
  employee_dept?:                string;
  employee_dob?:                 string;
  employee_doj?:                 string;
  employee_previous_experience?: string;
  employee_contact_number?:      string;
  employee_email?:               string;
  project_manager?:              boolean;
  reporting_manager?:            string;
  updated_by?:                   string;
  result?: string;
  cluster_lead?: string;

}
