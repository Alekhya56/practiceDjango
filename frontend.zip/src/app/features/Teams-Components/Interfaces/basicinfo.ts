import { ProjectList } from "../../Interfaces/project-list";
import { SkillList } from '../../Interfaces/skill-list';
import { Employee } from '../../Interfaces/getProjectDescription';

export class Employee_BasicInfo{
  employee_dept?: string;
  employee_dob?: Date;
  employee_doj?: Date;
  employee_contact_number?: string;
  employee_email?: string;
  employee_previous_experience?: number;
  project_manager?: boolean;
  project_manger_access?:string
  employee_designation?: string
  cluster_lead?: string;
}

export class Employee_Data{
  employee_id?: string;
  employee_designation?: string;
}
export interface Employee_Details{
detail:Employee_Data[]
  employee_list:Employee_BasicInfo[]
  project_list:ProjectList[]
  skill_list:SkillList[]
}

