
export class AddSkills{
  skill_name?: string;
  skill_description?: string;
  result?: string;
}
