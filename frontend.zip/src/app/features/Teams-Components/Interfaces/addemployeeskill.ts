
export class AddEmployeeSkills{
  skill_name?: string;
  skill_description?: string;
  skill_level?: string;
}


