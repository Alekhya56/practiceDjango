import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { DeleteScreenComponent } from 'src/app/shared/splash_screens/delete-screen/delete-screen.component';
import { EmployeeAddskillsComponent } from '../employee-addskills/employee-addskills.component';
import { EmployeeBasicInfo } from '../FormGroups/employee-basicinfo';

import { EmployeeBasicinfoService } from '../services/employee-basicinfo.service';

import { GetEmployeeDataService } from '../../services/get-employee-data.service';
import { Employee_Data, Employee_BasicInfo } from '../Interfaces/basicinfo';
import { ProjectList } from '../../Interfaces/project-list';
import { SkillList } from '../../Interfaces/skill-list';
import { SecurelsService } from '../../../core/services/securels.service';
import { Employee } from '../../Interfaces/getProjectDescription';

import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { department } from '../../../shared/classes/department';
import { GetDefaultvaluesService } from 'src/app/shared/api-services/get-defaultvalues.service';
import { MatListOption } from '@angular/material/list';
import { GetemployeesProjectsmanagersService } from '../../../shared/api-services/getemployees-projectsmanagers.service';
import { Employees } from '../../../shared/classes/employees';
import { designation } from 'src/app/shared/classes/designation';

@Component({
  selector: 'app-teams-employeename',
  templateUrl: './teams-employeename.component.html',
  styleUrls: ['./teams-employeename.component.scss'],
})
export class TeamsEmployeenameComponent extends EmployeeBasicInfo {
  Labels: string[] = ['Basic Info', 'Projects', 'Skills'];
  cols!: any[];
  loader: boolean = true;
  skill_name$!: SkillList[];
  skill_cols!: any[];
  cluster_lead!:department[]
  showbasicbutton: boolean = true;
  showskillbutton: boolean = true;
  addemployee: boolean = false;
  isInputDisable: boolean = true;
  showBtn: boolean = false;
  employee_data!:Employee_Data
  employee_list!:Employee_BasicInfo
  project_list!:ProjectList[]
  skill_list!:SkillList[]
  employee_id!: string
  role!:string
  departments!: department[]

  designations!:designation[]
  reporting_managers!:Employees[]
  constructor(private getemp_projectManagers: GetemployeesProjectsmanagersService,private toastr: ToastrService, private getdesignations_departments: GetDefaultvaluesService, private primengConfig: PrimeNGConfig, private router: Router, private securels: SecurelsService, private getempsdataservice: GetEmployeeDataService, private route: ActivatedRoute, private matdialog: MatDialog, private datepipe: DatePipe, private employeeUpdateService: EmployeeBasicinfoService) {
    super();
   }

  ngOnInit(): void {
    this.loader = true;
   this.employee_id=this.securels.securedecrypt(localStorage.getItem("employeeid")!)
    this.employeebasicinfo_form.disable()
    this.employeebasicinfo_form.get('cluster_lead')?.disable()
   this.employeebasicinfoheader_form.disable()
   this.role=this.securels.securedecrypt(localStorage.getItem("role")!)
   console.log(this.role)
    this.set_EmpDetails(this.employee_id)
    this.getdepartments()
    this.getdesignations()
    this.getreporting_managers()
    setTimeout(() => {
      this.loader = false;
    }, 2000);
  }
set_EmpDetails(empid:string){
 this.getempsdataservice.get_Employee_Data(empid).subscribe(res=>{
  console.log(res)
  this.employee_data=res['detail']['0']!
  this.employee_list=res['employee_list']['0']!
  this.project_list=res['project_list']!
  this.skill_list=res['skill_list']!
  console.log(this.skill_list)
  this.set_EmpData()
 })
}
getreporting_managers(){
this.getemp_projectManagers.get_Employees().subscribe(res=>{
  console.log(res)

  this.reporting_managers=res['employee_names']
})
}
set_EmpData(){
 for(const control in this.employeebasicinfoheader_form.controls){
  this.employeebasicinfoheader_form.get(control)?.setValue(this.employee_data[control as keyof typeof this.employee_data])
 }
for(const control in this.employeebasicinfo_form.controls){
   if(control=="employee_dob" || control=="employee_doj"){
     let value=this.datepipe.transform(this.employee_list[control as keyof typeof this.employee_list]?.toString(),"YYYY-MM-dd")
     this.employeebasicinfo_form.get(control)?.setValue(value)
    }else{

  this.employeebasicinfo_form.get(control)?.setValue(this.employee_list[control as keyof typeof this.employee_list])
}}
}

  getdepartments(){
  this.getdesignations_departments.get_departments().subscribe(res=>{
    console.log(res)
    this.departments = res
    this.cluster_lead=res
  })

  }
  getdesignations(){
 this.getdesignations_departments.get_designations().subscribe(res=>{
    console.log(res)
 this.designations=res
  })
  }
  get_cluster_lead() {

  }
  isEditable() {
    this.employeebasicinfo_form.enable()
    this.employeebasicinfo_form.get('cluster_lead')?.disable()
    this.employeebasicinfo_form.get('project_manager_access')?.disable()
   this.employeebasicinfoheader_form.enable()
    this.isInputDisable = false;
    this.showBtn = true;
  }

  Delete_skill(skill_id:string,empid:string) {
console.log(skill_id)
 if((this.securels.securedecrypt(localStorage.getItem("role")!)==="Employee" && (this.securels.securedecrypt(localStorage.getItem("loginid")!))==empid) ||this.securels.securedecrypt(localStorage.getItem("role")!)==="Project Manager"|| this.securels.securedecrypt(localStorage.getItem("role")!)==="HR" || this.securels.securedecrypt(localStorage.getItem("role")!)==="CEO"){
 this.matdialog.open(DeleteScreenComponent,{data:{skill_id:skill_id,employee_id:this.employee_id,"message":"DeleteSkill From Employee"}});
}else{
  this.toastr.warning("You dont have permissions to delete")
}


  }
 DeleteUser(empid:string){
  if((this.securels.securedecrypt(localStorage.getItem("role")!)==="Employee" && (this.securels.securedecrypt(localStorage.getItem("loginid")!))==empid) ||this.securels.securedecrypt(localStorage.getItem("role")!)==="Project Manager"|| this.securels.securedecrypt(localStorage.getItem("role")!)==="HR" || this.securels.securedecrypt(localStorage.getItem("role")!)==="CEO"){
   let updatedby:string=this.securels.securedecrypt(localStorage.getItem("user_name")!)
    this.matdialog.open(DeleteScreenComponent,{data:{employee_id:this.employee_id,"updated_by":updatedby,"message":"Delete Employee"}});
  }else{
    this.toastr.warning("You dont have permissions to delete")
  }
 }





  openDelete(){

  }

  openAddForm() {
    this.matdialog.open(EmployeeAddskillsComponent, {data:{employee_id:this.employeebasicinfoheader_form.get('employee_id')?.value},
      width: '30%',
      height: '340px',
    });
  }

  onTabChanged(event: any) {
    console.log(event);
    if (event['index'] == 0) {
      this.showbasicbutton = true;
      this.showskillbutton = true;
      this.addemployee = false;
    }
    else if (event['index'] == 1) {
      this.showbasicbutton = false;
      this.showskillbutton = false;
      this.addemployee = false;
    }
    else if (event['index'] == 2) {
      this.addemployee = true;
      this.showbasicbutton = false;
      this.showskillbutton = false;
    }
  }



  update_BasicInfo() {
    type lists = { [key: string]: any };
    const list: lists = {};
    for (const fields in this.employeebasicinfo_form.controls) {
      const value = this.employeebasicinfo_form.get(fields)?.value;
      if(fields=="project_manager_access"){
        if(value=="YES"){
        list[fields]=true
        }else{
          list[fields]=false
        }
      }else{
 list[fields] = value;
      }
      }
      console.log(this.employeebasicinfo_form.get("employee_email")?.value)
     for (const fields in this.employeebasicinfoheader_form.controls) {
      const value = this.employeebasicinfoheader_form.get(fields)?.value;
      if(fields=="employee_id"){
        list[fields]=this.employeebasicinfoheader_form.get(fields)?.value
      }

    }
    list['updated_by']=this.securels.securedecrypt(localStorage.getItem("user_name")!)
    console.log(list);
    this.employeeUpdateService.add_basicinfo(list).subscribe((res: any) => {
      console.log(res);
      if(res['result']=="success"){
        this.toastr.success("Employee detail is updated Successfully","Success")
        setTimeout(() => {
          window.location.reload()
          // this.router.navigateByUrl('Employees/:empid/:employeename')
        }, 500);
      }
      else if(res['result']=="error"){
        this.toastr.error("Employee detail is unable to Update","Error")
        setTimeout(() => {
          window.location.reload()
          // this.router.navigateByUrl('Employees/:empid/:employeename')
        }, 500);
      }
    });
  }
  select_clusterlead(value: string) {

    let clusterlead:any= this.departments.filter(res => {
      return res.department == value
    }
    )
    console.warn(clusterlead)
    this.employeebasicinfo_form.get('cluster_lead')?.setValue(clusterlead['0']['cluster_lead'])
    this.employeebasicinfo_form.get('cluster_lead')?.disable()
    }
  discardChanges(){
    this.toastr.warning("No changes are done in the Employee Details");
    this.employeebasicinfo_form.disable()
   this.employeebasicinfoheader_form.disable()
    this.isInputDisable = true;
    this.showBtn = false;
    this.set_EmpData();
  }
}
