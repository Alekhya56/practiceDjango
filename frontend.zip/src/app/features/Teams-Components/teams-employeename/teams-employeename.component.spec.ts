import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamsEmployeenameComponent } from './teams-employeename.component';

describe('TeamsEmployeenameComponent', () => {
  let component: TeamsEmployeenameComponent;
  let fixture: ComponentFixture<TeamsEmployeenameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeamsEmployeenameComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeamsEmployeenameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
