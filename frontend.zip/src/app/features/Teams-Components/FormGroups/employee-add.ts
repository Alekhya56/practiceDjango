import { FormControl, FormGroup, Validators } from '@angular/forms';
export class Employeeadd {
  public employeeadd_form = new FormGroup({
    employee_id:new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(4),Validators.pattern("^[0-9_+,-]{4}")]),
    employee_name:new FormControl('',[Validators.required,Validators.pattern(/^[a-zA-Z\s]*$/)]),
    employee_designation:new FormControl('',Validators.required),
    employee_dept:new FormControl('',Validators.required),
    employee_dob:new FormControl('',Validators.required),
    employee_doj:new FormControl('',Validators.required),
    employee_previous_experience:new FormControl('',Validators.required),
    employee_contact_number:new FormControl('+91',[Validators.required, Validators.pattern("^[0-9_+,-]{13}")]),
    employee_email:new FormControl('',[Validators.required,Validators.email,Validators.pattern('^.+@manomay.biz$')]),
    project_manager:new FormControl(''),
    reporting_manager: new FormControl('',Validators.required),
    cluster_lead: new FormControl('', Validators.required)
  })
}
