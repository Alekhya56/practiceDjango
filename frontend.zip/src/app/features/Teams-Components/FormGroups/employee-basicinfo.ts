import { FormControl, FormGroup, Form } from '@angular/forms';

export class EmployeeBasicInfo {
  public employeebasicinfo_form = new FormGroup({
    employee_dept: new FormControl(''),
    employee_dob: new FormControl(''),
    employee_doj: new FormControl(''),
    employee_previous_experience: new FormControl(''),
    employee_contact_number: new FormControl(''),
    employee_email: new FormControl(''),
    project_manager: new FormControl(''),
    reporting_manager:new FormControl(''),
    project_manager_access:new FormControl(''),
    employee_designation: new FormControl(''),
    cluster_lead: new FormControl(''),
  })

  public employeebasicinfoheader_form = new FormGroup({
    employee_id: new FormControl(''),
    employee_designation: new FormControl('')
  })

}
