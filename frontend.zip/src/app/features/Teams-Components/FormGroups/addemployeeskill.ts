import { FormControl, FormGroup } from '@angular/forms'
export class AddEmployeeskill {
  public addemployeeskill_form = new FormGroup({
    skill_id: new FormControl(''),
    skill_description: new FormControl(''),
    skill_level: new FormControl(''),
  })
}
