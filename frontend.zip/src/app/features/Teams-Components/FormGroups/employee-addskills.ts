import { FormControl, FormGroup } from '@angular/forms'
export class Employeeaddskills {
  public employeeaddskills_form = new FormGroup({
    skill_name: new FormControl(''),
    skill_description: new FormControl(''),

  })
}
