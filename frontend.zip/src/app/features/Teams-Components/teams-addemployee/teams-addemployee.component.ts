import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Employeeadd } from '../FormGroups/employee-add';
import { Addemployee } from '../Interfaces/addemployee';
import { AddemployeeService } from '../services/addemployee.service';
import { SkillList } from '../../Interfaces/skill-list';
import { GetSkillsService } from '../../services/get-skills.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { PrimeNGConfig } from 'primeng/api';
import { GetemployeesProjectsmanagersService } from '../../../shared/api-services/getemployees-projectsmanagers.service';
import { Employees } from '../../../shared/classes/employees';
import { GetDefaultvaluesService } from '../../../shared/api-services/get-defaultvalues.service';
import { designation } from 'src/app/shared/classes/designation';
import { department } from '../../../shared/classes/department';
import { SecurelsService } from '../../../core/services/securels.service';
import { LoaderserviceService } from '../../../core/services/loaderservice.service';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { clusterLead } from 'src/app/shared/classes/get-cluster-lead';
import { throwDialogContentAlreadyAttachedError } from '@angular/cdk/dialog';
import { Validators } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';

@Component({
  selector: 'app-teams-addemployee',
  templateUrl: './teams-addemployee.component.html',
  styleUrls: ['./teams-addemployee.component.scss'],
})
export class TeamsAddemployeeComponent extends Employeeadd {
  skill$!: SkillList[];
  reporting_managers!: Employees[];
  designations!: designation[];
  departments!: department[];
  cluster_lead!: clusterLead[];
  iscluster_lead: boolean = false;
  min_date!:Date;
  maxDate = Date.now();
  skill_level: string[] = ['Beginner', 'Intermediate', 'Advanced'];
  // employeeID!:string;
  constructor(
    public loaderService: LoaderserviceService,
    private securels: SecurelsService,
    private getdesignations_departments: GetDefaultvaluesService,
    private getemp_projectManagers: GetemployeesProjectsmanagersService,
    private toastr: ToastrService,
    private primengConfig: PrimeNGConfig,
    private dialogRef: MatDialogRef<TeamsAddemployeeComponent>,
    private router: Router,
    private dialog: MatDialog,
    private getskills: GetSkillsService,
    private datepipe: DatePipe,
    private addemployee: AddemployeeService
  ) {
    super();
  }

  ngOnInit(): void {
    this.getskills.get_skils().subscribe((res) => {
      console.log(res);
      this.skill$ = res;
    });
    this.get_designations();
    this.get_departments();
    this.getProjectManagersEmployee();
    // this.getClusterLead();
  }
  get_designations() {
    this.getdesignations_departments.get_designations().subscribe((res) => {
      console.log(res);
      this.designations = res;
    });
  }
  get_departments() {
    this.getdesignations_departments.get_departments().subscribe((res) => {
      console.log(res);
      this.departments = res;
      this.cluster_lead = res;

    });
  }
  getProjectManagersEmployee() {
    this.getemp_projectManagers.get_Employees().subscribe((res) => {
      console.log(res);

      this.reporting_managers = res['employee_names'];
    });
  }

  select_clusterlead(value: string) {

    let clusterlead:any= this.departments.filter(res => {
      return res.department == value
    }
    )
    console.warn(clusterlead)
    this.employeeadd_form.get('cluster_lead')?.setValue(clusterlead['0']['cluster_lead'])
    this.employeeadd_form.get('cluster_lead')?.disable()
    }

    // let dateOfBirth= this.employeeadd_form.get('employee_dob')?.value;
    addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
      // console.log(event,event['value']?.getFullYear()!)
      let newyear:Date=new Date()
      console.log(newyear)
      newyear.setFullYear(event['value']?.getFullYear()!+18)
      console.log(newyear)
      this.min_date=newyear
      console.log(this.min_date)
    }

  Add_Employee() {
    let employeeID = this.employeeadd_form.get('employee_id')?.value!;
        console.warn('Employee id printing',employeeID);
        let sumOfEmployee= employeeID .toString().split('')
            .map(Number)
            .reduce(function (a, b) {
              return a + b;
                  }, 0);
        console.log(sumOfEmployee);

    if(sumOfEmployee>0){
      if (this.employeeadd_form.valid) {
        let list: Addemployee = {};
        for (const fields in this.employeeadd_form.controls) {
          let value = this.employeeadd_form.get(fields)?.value;
          if (fields == 'employee_dob' || fields == 'employee_doj') {
            const res = this.datepipe.transform(
              value.toDateString(),
              'YYYY/MM/dd'
            )!;
            list[fields] = res;
          } else {
            list[fields as keyof typeof list] = value;
          }
          // let employeeID = this.employeeadd_form.get('employee_id')?.value;
          // console.log(employeeID);
          // let e_id = employeeID?.toString()
          // if(employeeID/10){
          // }


        }
        list['updated_by'] = this.securels.securedecrypt(
          localStorage.getItem('user_name')!
        );
        console.log(list);
        this.addemployee.add_employee(list).subscribe((res) => {
          console.warn('Karthikeyan',res);

          if (res['result'] == 'success') {
            this.toastr.success('Employee Added Successfully', 'Message');
            setTimeout(() => {
              this.dialogRef.close();
              window.location.reload();
              this.router.navigateByUrl('/Employees');
            }, 500);
          } else if (res['result'] == 'error') {
            this.toastr.error('Employee detail is already exist', 'Error');
            // setTimeout(() => {
            //   this.dialogRef.close();
            //   this.router.navigateByUrl('/Employees');
            // }, 500);
          }
        });
      } else {
        this.toastr.error("Please fill mandatory fields")
      }
    }
    else{
      this.toastr.error('Invalid Employee ID, Enter valid employee ID');
    }
}
}
