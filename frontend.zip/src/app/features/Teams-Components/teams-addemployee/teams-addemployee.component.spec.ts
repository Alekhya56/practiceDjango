import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamsAddemployeeComponent } from './teams-addemployee.component';

describe('TeamsAddemployeeComponent', () => {
  let component: TeamsAddemployeeComponent;
  let fixture: ComponentFixture<TeamsAddemployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeamsAddemployeeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeamsAddemployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
