import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Addemployee } from '../Interfaces/addemployee';
const addemployee = environment.URL + "/v1/dashboard/add_employee";

@Injectable({
  providedIn: 'root'
})
export class AddemployeeService {

  constructor(private http: HttpClient) { }
    add_employee(data: Addemployee){
      return this.http.post<Addemployee>(addemployee,data).pipe(catchError(this.handleError))
    }
    public handleError = (error: HttpErrorResponse | any) => {

      return throwError(error);
      }

}
