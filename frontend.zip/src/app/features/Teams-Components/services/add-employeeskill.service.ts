import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { AddEmployeeSkills } from '../Interfaces/addemployeeskill';

const addemployeeskill = environment.URL + "/v1/dashboard/add_employee_skills";

@Injectable({
  providedIn: 'root'
})
export class AddEmployeeskillService {

  constructor(private http: HttpClient) { }
    add_employeeskill(data: AddEmployeeSkills){
      return this.http.post<AddEmployeeSkills>(addemployeeskill,data).pipe(catchError(this.handleError))
    }
    public handleError = (error: HttpErrorResponse | any) => {

      return throwError(error);
    }
}
