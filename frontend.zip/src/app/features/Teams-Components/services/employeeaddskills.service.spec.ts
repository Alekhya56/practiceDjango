import { TestBed } from '@angular/core/testing';

import { EmployeeaddskillsService } from './employeeaddskills.service';

describe('EmployeeaddskillsService', () => {
  let service: EmployeeaddskillsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeeaddskillsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
