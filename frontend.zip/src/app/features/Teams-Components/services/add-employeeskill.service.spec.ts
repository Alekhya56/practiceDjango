import { TestBed } from '@angular/core/testing';

import { AddEmployeeskillService } from './add-employeeskill.service';

describe('AddEmployeeskillService', () => {
  let service: AddEmployeeskillService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddEmployeeskillService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
