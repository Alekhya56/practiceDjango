import { TestBed } from '@angular/core/testing';

import { EmployeeBasicinfoService } from './employee-basicinfo.service';

describe('EmployeeBasicinfoService', () => {
  let service: EmployeeBasicinfoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeeBasicinfoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
