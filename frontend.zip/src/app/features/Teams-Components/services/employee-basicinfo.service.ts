import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';


const updateemployee= environment.URL + "/v1/dashboard/update_employees";

@Injectable({
  providedIn: 'root'
})
export class EmployeeBasicinfoService {

  constructor(private http: HttpClient) { }

  // add_basicinfoheader(data: BasicInfoHeader){
  //   return this.http.post<BasicInfoHeader>(updateemployee,{data}).pipe(catchError(this.handleError))
  // }

  add_basicinfo(data: any){
   return this.http.post<any>(updateemployee,data).pipe(catchError(this.handleError))
   }

  public handleError = (error: HttpErrorResponse | any) => {
    return throwError(error);
  }
}
