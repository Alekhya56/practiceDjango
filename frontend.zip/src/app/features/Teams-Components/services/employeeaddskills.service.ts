import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { AddSkills } from '../Interfaces/employee-addskills';
const addskills = environment.URL + '/v1/dashboard/add_skills';

@Injectable({
  providedIn: 'root'
})
export class EmployeeaddskillsService {

  constructor(private http: HttpClient) {}
  add_skills(data: AddSkills): Observable<AddSkills> {
    ;
    console.log(data);
    return this.http
      .post<AddSkills>(addskills, data)
      .pipe(catchError(this.handleError));
  }
  public handleError = (error: HttpErrorResponse | any) => {
    return throwError(error);
  };
}
