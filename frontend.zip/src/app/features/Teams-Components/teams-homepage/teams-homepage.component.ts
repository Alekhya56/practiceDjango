import { Component, OnInit, ViewChild } from '@angular/core';
import { TabbedItem } from 'ag-grid-community';
import { EmployeeRecords, Team_Records } from '../Interfaces/Team_Records';
import { MatDialog } from '@angular/material/dialog';
import { Table } from 'primeng/table';
import { TeamsAddemployeeComponent } from '../teams-addemployee/teams-addemployee.component';
import { EmployeeNewskillComponent } from './employee-newskill/employee-newskill.component';
import { GetEmployeeService } from 'src/app/shared/api-services/get-employee.service';
import { Observable } from 'rxjs';
import { Employee } from '../../Interfaces/getProjectDescription';
import { SkillList } from '../../Interfaces/skill-list';
import { GetSkillsService } from '../../services/get-skills.service';
import { SecurelsService } from '../../../core/services/securels.service';
import { GetProjectEmployees } from 'src/app/shared/classes/get-project-managers';
import { Employees } from 'src/app/shared/classes/employees';
import { GetemployeesProjectsmanagersService } from '../../../shared/api-services/getemployees-projectsmanagers.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-teams-homepage',
  templateUrl: './teams-homepage.component.html',
  styleUrls: ['./teams-homepage.component.scss'],
})
export class TeamsHomepageComponent implements OnInit {
  @ViewChild('emp') emp!: Table;
    @ViewChild('skill') skill!: Table;
  team_data!: Team_Records[]; // Table data array
  Labels: string[] = ['Employees', 'Skills'];
  showAddEmployeeButton: boolean = true;
  showAddSkillButton: boolean = false;
  employee_list!:Employees[]
    get_skill!:Observable<any>
  constructor(
    private securels:SecurelsService,
    private getskillservice:GetSkillsService,
    private getemployeeservice: GetEmployeeService,
    private matdialog: MatDialog,
    private toastr: ToastrService,
    private getemp:GetemployeesProjectsmanagersService,
  ) {}

  ngOnInit(): void {
    //
    // console.log("Teams home page")
    /* let  table:Team_Records[]=[
      {Id: "1", Name: 'Employee Name',Designation: "Teams", Department: 'H',Email:"kvch771233@gmail.com"},
      {Id: "2", Name: 'Helium',Designation: "Teams", Department: 'He',Email:"kvch771233@gmail.com"},
      {Id: "3", Name: 'Lithium', Designation: "Teams", Department: 'Li',Email:"kvch771233@gmail.com"},
      {Id: "4", Name: 'Beryllium', Designation: "Teams", Department: 'Be',Email:"kvch771233@gmail.com"},
      {Id: "5", Name:'Boron', Designation: "Teams", Department: 'B',Email:"kvch771233@gmail.com"},
    ]
    this.team_data=table */

    this.getemp.get_Employees().subscribe(res=>{
      console.log(res)
      this.employee_list=res['employee_names']
    })
    this.get_skill = this.getskillservice.get_skils()
    debugger
  }

  // Function is used for filtering values which the user enters
    applyEmpFilter($event: any, value: string) {

    console.log(event, value);

    this.emp.filterGlobal((event?.target as HTMLInputElement).value, value);

  }

  applySkillFilter($event: any, value: string) {

    console.log(event, value);

    this.skill.filterGlobal((event?.target as HTMLInputElement).value, value);

  }

  openAddForm() {
    if (
      this.securels.securedecrypt(localStorage.getItem('role')!) ===
        'Project Manager' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'HR' ||
      this.securels.securedecrypt(localStorage.getItem('role')!) === 'CEO'
    ) {
    this.matdialog.open(TeamsAddemployeeComponent, { height: '90%' });
    }else{
      this.toastr.warning("Sorry You don't have permissions to add New Employee");
    }
  }

  openAddSkillForm() {
    this.matdialog.open(EmployeeNewskillComponent, {
      width: '25%',

    });
  }

  onTabChanged(event: any) {
    console.log(event);
    if (event['index'] == 0) {
      this.showAddEmployeeButton = true;
      this.showAddSkillButton = false;
    } else if (event['index'] == 1) {
      this.showAddEmployeeButton = false;
      this.showAddSkillButton = true;
    }
  }
  navigate_to(name:string,id:string)
  {
    localStorage.setItem("name",this.securels.secureencrypt(name))
    localStorage.setItem("employeeid",this.securels.secureencrypt(id))
  }
}
