import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamsHomepageComponent } from './teams-homepage.component';

describe('TeamsHomepageComponent', () => {
  let component: TeamsHomepageComponent;
  let fixture: ComponentFixture<TeamsHomepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeamsHomepageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeamsHomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
