import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeNewskillComponent } from './employee-newskill.component';

describe('EmployeeNewskillComponent', () => {
  let component: EmployeeNewskillComponent;
  let fixture: ComponentFixture<EmployeeNewskillComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeNewskillComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeNewskillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
