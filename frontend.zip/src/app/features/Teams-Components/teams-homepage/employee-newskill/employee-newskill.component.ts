import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Employeeaddskills } from '../../FormGroups/employee-addskills';
import { AddSkills } from '../../Interfaces/employee-addskills';
import { EmployeeaddskillsService } from '../../services/employeeaddskills.service';
import { GetSkillsService } from '../../../services/get-skills.service';
import { Observable } from 'rxjs';
import { SkillList } from '../../../Interfaces/skill-list';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-newskill',
  templateUrl: './employee-newskill.component.html',
  styleUrls: ['./employee-newskill.component.scss'],
})
export class EmployeeNewskillComponent extends Employeeaddskills {
  addskill: any;
  get_skill!:Observable<SkillList[]>
proficiency = ['Beginner', 'Intermediate', 'Advanced'];
  constructor(
    private getskillservice:GetSkillsService,
    private datepipe: DatePipe,
    private addSkillEmployee: EmployeeaddskillsService,
    private toastr: ToastrService, private primengConfig: PrimeNGConfig, private dialogRef: MatDialogRef<EmployeeNewskillComponent>,
    private router: Router, private dialog: MatDialog,
  ) {
    super();
  }

  ngOnInit(): void {
    console.log("add skill component")
   this.get_skill= this.getskillservice.get_skils()
  }

  Add_Skills() {
    type lists = { [key: string]: AddSkills };
    const list: lists = {};
    if (this.employeeaddskills_form.valid) {
      for (const fields in this.employeeaddskills_form.controls) {
        const value = this.employeeaddskills_form.get(fields)?.value;

        list[fields] = value;
      }

      console.log(list)
      this.addSkillEmployee.add_skills(list).subscribe(res => {
        console.log(res)
        if (res['result'] == "success") {
          this.toastr.success("New Skill Added Successfully", "Message")
          setTimeout(() => {
            this.dialogRef.close()
            this.router.navigateByUrl('/Employees')
            window.location.reload()

          }, 1000);
        } else if (res['result'] == "error") {
          this.toastr.warning("Skill is already present", "Add New Skill")
          setTimeout(() => {
            this.dialogRef.close()
            this.router.navigateByUrl('/Employees')
          }, 1000);
        }
      })
    } else {
      this.toastr.error("Please fill mandatory fields")
    }
}}
