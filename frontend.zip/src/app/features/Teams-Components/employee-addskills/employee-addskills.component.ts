import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { AddEmployeeskill } from '../FormGroups/addemployeeskill';
import { AddEmployeeSkills } from '../Interfaces/addemployeeskill';
import { AddEmployeeskillService } from '../services/add-employeeskill.service';
import { GetSkillsService } from '../../services/get-skills.service';
import { SkillList } from '../../Interfaces/skill-list';


@Component({
  selector: 'app-employee-addskills',
  templateUrl: './employee-addskills.component.html',
  styleUrls: ['./employee-addskills.component.scss']
})
export class EmployeeAddskillsComponent extends AddEmployeeskill{
  showAddSkill: boolean = false;
  skills!:SkillList[];
  optionSkills = ['others'];
  proficiency = ['Beginner', 'Intermediate', 'Advanced'];
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions!: Observable<string[]>;

  addemployeeskill: any;

  constructor(private dialogRef: MatDialogRef<EmployeeAddskillsComponent>,private getskills:GetSkillsService,@Inject(MAT_DIALOG_DATA) public data:any,private matdialog: MatDialog, private toastr: ToastrService, private router:Router, private primengConfig: PrimeNGConfig, private datepipe: DatePipe, private addEmployeeSkill: AddEmployeeskillService) {
    super();
  }

  ngOnInit(): void {
    console.log(this.data)
    this.addemployeeskill_form.get('skill_description')?.disable()
    //   this.filteredOptions = this.myControl.valueChanges.pipe(
    //     startWith(''),
    //     map(value => this._filter(value || '')),
    //   );

    //   this.filteredOptions = this.proficiencyLevel.valueChanges.pipe(
    //     startWith(''),
    //     map(value => this._filter(value || '')),
    //   );
  this.getskills.get_skils().subscribe(res=>{
    console.log(res)
    this.skills=res
  })
  }

  // private _filter(value: string): string[] {
  //   const filterValue = value.toLowerCase();
  //   return this.skills.filter(skill => skill.toLowerCase().includes(filterValue));
  // }

  // addSkill() {
  //   this.showAddSkill = !this.showAddSkill;
  // }
select_description(value:string){
let skill_data:SkillList[]=this.skills.filter(res=>{
  return res.skill_id==value
}
)
this.addemployeeskill_form.get('skill_description')?.setValue(skill_data['0']['skill_description'])
    this.addemployeeskill_form.get('skill_description')?.disable()
}
Add_Employeeskill(){
    type lists = { [key: string]: AddEmployeeSkills };
  const list: lists = {};
  if (this.addemployeeskill_form.valid) {
    for (const fields in this.addemployeeskill_form.controls) {
      const value = this.addemployeeskill_form.get(fields)?.value;
      list[fields] = value;

    }
    console.log(list);
    list['employee_id'] = this.data['employee_id']
    this.addEmployeeSkill.add_employeeskill(list).subscribe((res: any) => {
      console.log(res);
      if (res['result'] == "success") {
        this.toastr.success("Skill Added Successfully")
        setTimeout(() => {
          this.dialogRef.close()
          this.router.navigateByUrl('/Employees/:empid/:employeename')
          window.location.reload()
        }, 1000);
      }
      else if (res['result'] == "error") {
        this.toastr.warning(res['message'])
      }
    });
  } else {
    console.log(this.addemployeeskill_form)
    this.toastr.error("please fill mandatory fields")
  }
  }



}
