import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeAddskillsComponent } from './employee-addskills.component';

describe('EmployeeAddskillsComponent', () => {
  let component: EmployeeAddskillsComponent;
  let fixture: ComponentFixture<EmployeeAddskillsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeAddskillsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeAddskillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
