import { TestBed } from '@angular/core/testing';

import { DeleteprojectService } from './deleteproject.service';

describe('DeleteprojectService', () => {
  let service: DeleteprojectService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DeleteprojectService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
