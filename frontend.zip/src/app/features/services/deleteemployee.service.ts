import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators'
import { environment } from '../../../environments/environment';
import { DeleteEmployee } from '../Interfaces/Deletemodel';
const deleteempurl=environment.URL+"/v1/dashboard/delete_employee"
@Injectable({
  providedIn: 'root'
})
export class DeleteemployeeService {

 constructor(private http:HttpClient) { }
   deleteemployee(data:DeleteEmployee ):Observable<DeleteEmployee>{
 return this.http.post<DeleteEmployee>(deleteempurl,data).pipe(catchError(this.handleError))
  }
  public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }
}
