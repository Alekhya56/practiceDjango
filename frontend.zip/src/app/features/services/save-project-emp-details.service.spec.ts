import { TestBed } from '@angular/core/testing';

import { SaveProjectEmpDetailsService } from './save-project-emp-details.service';

describe('SaveProjectEmpDetailsService', () => {
  let service: SaveProjectEmpDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SaveProjectEmpDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
