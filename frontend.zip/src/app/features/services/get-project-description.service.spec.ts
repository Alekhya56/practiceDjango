import { TestBed } from '@angular/core/testing';

import { GetProjectDescriptionService } from './get-project-description.service';

describe('GetProjectDescriptionService', () => {
  let service: GetProjectDescriptionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetProjectDescriptionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
