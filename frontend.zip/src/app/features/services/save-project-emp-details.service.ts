import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators'
import { environment } from '../../../environments/environment';
import { Employee } from '../Interfaces/getProjectDescription';
const saveprojectdetailsurl=environment.URL+"/v1/dashboard/add_or_update_employee_to_project"
@Injectable({
  providedIn: 'root'
})

export class SaveProjectEmpDetailsService {

  constructor(private http:HttpClient) { }
  save_empprojectDetails(data:Employee):Observable<Employee>{
console.log(data)
  return this.http.post<Employee>(saveprojectdetailsurl,data).pipe(catchError(this.handleError))

}
public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }
}
