import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Employee } from '../../shared/classes/get-employee';
import { Employee_Data, Employee_Details } from '../Teams-Components/Interfaces/basicinfo';
const getemployeedataurl=environment.URL+"/v1/dashboard/get_employee_project_skills"
@Injectable({
  providedIn: 'root'
})
export class GetEmployeeDataService {

  constructor(private http:HttpClient) { }

  get_Employee_Data(empid:string):Observable<Employee_Details>{
    return this.http.post<Employee_Details>(getemployeedataurl,{employee_id:empid}).pipe(catchError(this.handleError))
  }
   public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }
}
