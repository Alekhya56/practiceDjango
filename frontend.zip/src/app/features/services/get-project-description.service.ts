import { getProjectDescription } from '../Interfaces/getProjectDescription';
import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
  HttpRequest,
} from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators';

import { environment } from '../../../environments/environment';

const getprojectdescurl =
  environment.URL + '/v1/dashboard/get_employee_project_description';
@Injectable({
  providedIn: 'root',
})
export class GetProjectDescriptionService {
  constructor(private http: HttpClient) {}
  get_project_description(id: string): Observable<getProjectDescription> {
    const data = {
      project_id: id,
    };
    return this.http
      .post<getProjectDescription>(getprojectdescurl, { project_id: id })
      .pipe(catchError(this.handleError));
  }
  public handleError = (error: HttpErrorResponse | any) => {
    return throwError(error);
  };
}
