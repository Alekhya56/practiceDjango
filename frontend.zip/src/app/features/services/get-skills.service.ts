
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { SkillList } from '../Interfaces/skill-list';


const getskilsurl=environment.URL+"/v1/dashboard/get_skills"
@Injectable({
  providedIn: 'root'
})
export class GetSkillsService {

  constructor(private http:HttpClient) { }
  get_skils():Observable<SkillList[]>{
    return this.http.get<SkillList[]>(getskilsurl).pipe(catchError(this.handleError))
  }
   public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }
}
