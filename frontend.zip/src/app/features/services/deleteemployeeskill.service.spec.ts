import { TestBed } from '@angular/core/testing';

import { DeleteemployeeskillService } from './deleteemployeeskill.service';

describe('DeleteemployeeskillService', () => {
  let service: DeleteemployeeskillService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DeleteemployeeskillService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
