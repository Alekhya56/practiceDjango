import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators'
import { environment } from '../../../environments/environment';
import { DeleteEmpProject } from '../Interfaces/Deletemodel';

const delete_Empprojecturl=environment.URL+"/v1/dashboard/delete_project_employee"
@Injectable({
  providedIn: 'root'
})
export class DeleteEmpFromProjectService {

  constructor(private http:HttpClient) { }


  delete_Emp(data:any):Observable<DeleteEmpProject>{
    console.log(data)
 return this.http.post<DeleteEmpProject>(delete_Empprojecturl,data).pipe(catchError(this.handleError))
  }
  public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }
}
