import { TestBed } from '@angular/core/testing';

import { UpdateProjectinfoService } from './update-projectinfo.service';

describe('UpdateProjectinfoService', () => {
  let service: UpdateProjectinfoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UpdateProjectinfoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
