import { TestBed } from '@angular/core/testing';

import { DeleteEmpFromProjectService } from './delete-emp-from-project.service';

describe('DeleteEmpFromProjectService', () => {
  let service: DeleteEmpFromProjectService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DeleteEmpFromProjectService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
