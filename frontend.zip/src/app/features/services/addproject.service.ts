import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { AddProject } from '../Interfaces/addproject';
const addproject=environment.URL+"/v1/dashboard/add_project"
@Injectable({
  providedIn: 'root'
})
//sending new project details to backend.
export class AddprojectService {

constructor(private http:HttpClient) {
   }
   //add project methods takes arguement data from project-add component
   add_project(data:AddProject){
  return this.http.post<AddProject>(addproject,data).pipe(catchError(this.handleError))

}
public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }
}
