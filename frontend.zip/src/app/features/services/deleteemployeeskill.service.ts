import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators'
import { environment } from '../../../environments/environment';
import { DeleteEmployee_Skill } from '../Interfaces/Deletemodel';
const deleteempskillurl=environment.URL+"/v1/dashboard/delete_employee_skill"

@Injectable({
  providedIn: 'root'
})
export class DeleteemployeeskillService {

 constructor(private http:HttpClient) { }
   deleteEmp_skill(data:DeleteEmployee_Skill ):Observable<DeleteEmployee_Skill>{
 return this.http.post<DeleteEmployee_Skill>(deleteempskillurl,data).pipe(catchError(this.handleError))
  }
  public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }
}
