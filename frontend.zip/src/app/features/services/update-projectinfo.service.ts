import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators'
import { environment } from '../../../environments/environment';
import { Description, Employee, Details } from '../Interfaces/getProjectDescription';
import { UpdateProject } from '../Interfaces/update-project';
const updateprojecturl=environment.URL+"/v1/dashboard/update_project_details"
@Injectable({
  providedIn: 'root'
})
//updating projectdetails and document repo details to backend
export class UpdateProjectinfoService {

  constructor(private http:HttpClient) { }
//this method accepts argument data from getproject description component
  update_projectdetails(data:UpdateProject):Observable<UpdateProject>{

 return this.http.post<UpdateProject>(updateprojecturl,data).pipe(catchError(this.handleError))
  }

public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }}
