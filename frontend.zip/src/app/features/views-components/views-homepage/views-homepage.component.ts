import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-views-homepage',
  templateUrl: './views-homepage.component.html',
  styleUrls: ['./views-homepage.component.scss']
})
export class ViewsHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
