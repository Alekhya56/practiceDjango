import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewsHomepageComponent } from './views-homepage.component';

describe('ViewsHomepageComponent', () => {
  let component: ViewsHomepageComponent;
  let fixture: ComponentFixture<ViewsHomepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewsHomepageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewsHomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
