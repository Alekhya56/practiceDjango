import { ProjectsDescriptionComponent } from './Projects-Components/projects-description/projects-description.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProjectsHomepageComponent } from './Projects-Components/projects-homepage/projects-homepage.component';
import { TeamsEmployeenameComponent } from './Teams-Components/teams-employeename/teams-employeename.component';
import { TeamsHomepageComponent } from './Teams-Components/teams-homepage/teams-homepage.component';
import { SkillsHomepageComponent } from './Skills-Components/skills-homepage/skills-homepage.component';
import { ViewsHomepageComponent } from './views-components/views-homepage/views-homepage.component';
import { SuccessComponent } from '../shared/splash_screens/success/success.component';
import { AuthGuard } from '../core/guards/auth.guard';
const routes: Routes = [
  {path:'Employees',component:TeamsHomepageComponent,canActivate:[AuthGuard]},
  { path: 'Employees/:empid/:employeename', component: TeamsEmployeenameComponent,canActivate:[AuthGuard]},
  {path:'Projects',component:ProjectsHomepageComponent,data: {title: 'Projects'},canActivate:[AuthGuard]},
  {path: 'Projects/:projectid/:projectname', component: ProjectsDescriptionComponent,canActivate:[AuthGuard]},
  {path:'Skills',component:SkillsHomepageComponent,canActivate:[AuthGuard]},
  {path:'Views',component:ViewsHomepageComponent,canActivate:[AuthGuard]},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FeaturesRoutingModule { }
