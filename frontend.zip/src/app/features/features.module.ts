import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FeaturesRoutingModule } from './features-routing.module';
import { TeamsHomepageComponent } from './Teams-Components/teams-homepage/teams-homepage.component';
import { TeamsAddemployeeComponent } from './Teams-Components/teams-addemployee/teams-addemployee.component';
import { PrimeNGModule } from '../shared/primeNg/primeng.module';
import { TeamsEmployeenameComponent } from './Teams-Components/teams-employeename/teams-employeename.component';
import { ProjectsAddprojectComponent } from './Projects-Components/projects-addproject/projects-addproject.component';
import { ProjectsHomepageComponent } from './Projects-Components/projects-homepage/projects-homepage.component';
import { ProjectsDescriptionComponent } from './Projects-Components/projects-description/projects-description.component';
import { EmployeeAddskillsComponent } from './Teams-Components/employee-addskills/employee-addskills.component';
import { MaterialModule } from '../shared/Material/material.module';
import { SkillsHomepageComponent } from './Skills-Components/skills-homepage/skills-homepage.component';
import { ProjectsAddemployeeComponent } from './Projects-Components/projects-description/projects-addemployee/projects-addemployee.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeNewskillComponent } from './Teams-Components/teams-homepage/employee-newskill/employee-newskill.component';
import { GetProjectDescriptionService } from './services/get-project-description.service';
import { AddprojectService } from './services/addproject.service';
import { ViewsHomepageComponent } from './views-components/views-homepage/views-homepage.component';
import { SuccessComponent } from '../shared/splash_screens/success/success.component';
import { ToastrModule } from 'ngx-toastr';
@NgModule({
  declarations: [
      TeamsHomepageComponent,
      TeamsAddemployeeComponent,
      TeamsEmployeenameComponent,
      ProjectsAddprojectComponent,
      ProjectsHomepageComponent,
      ProjectsDescriptionComponent,
      ProjectsHomepageComponent,
      EmployeeAddskillsComponent,
      SkillsHomepageComponent,
      ProjectsAddemployeeComponent,
      EmployeeNewskillComponent,
      ViewsHomepageComponent
  ],
  imports: [
    MaterialModule,
    PrimeNGModule,
    CommonModule,
    FeaturesRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,

  ],
  providers:[
    DatePipe,SuccessComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class FeaturesModule { }
