import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SkillsHomepageComponent } from './skills-homepage.component';

describe('SkillsHomepageComponent', () => {
  let component: SkillsHomepageComponent;
  let fixture: ComponentFixture<SkillsHomepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SkillsHomepageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SkillsHomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
