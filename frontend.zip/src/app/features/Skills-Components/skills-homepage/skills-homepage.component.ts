import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Table } from 'primeng/table';
import { EmployeeAddskillsComponent } from '../../Teams-Components/employee-addskills/employee-addskills.component';
import { Skills_Records } from '../Interfaces/skills_Records';
import { SkillList } from '../../Interfaces/skill-list';
import { GetSkillsService } from '../../services/get-skills.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-skills-homepage',
  templateUrl: './skills-homepage.component.html',
  styleUrls: ['./skills-homepage.component.scss']
})
export class SkillsHomepageComponent implements OnInit {

  @ViewChild('emp') emp!:Table
  team_data!:Skills_Records[] // Table data array
  get_skill!:Observable<any>
  constructor(    private getskillservice:GetSkillsService,private matdialog:MatDialog) { }

  ngOnInit(): void {
  this.get_skill= this.getskillservice.get_skils()
  }

  // Function is used for filtering values which the user enters
  applyfilterGlobal($event:any,value:string){
    console.log(event,value)
    this.emp.filterGlobal((event?.target as HTMLInputElement).value,value)
  }

  openAddForm(){
    this.matdialog.open(EmployeeAddskillsComponent ,{width:'30%',height:'50%'});
  }
}
