import { FormControl, FormGroup, Validators } from '@angular/forms';

export class projectEmp {
  Project_EmpForm = new FormGroup({
    employee_name: new FormControl('', Validators.required),
    role: new FormControl('' ,Validators.required),
    status_of_work: new FormControl('' ,Validators.required),
    phase: new FormControl('' ,Validators.required),
    est_work: new FormControl('' ,Validators.required),
    expected_hours_per_day: new FormControl(''),
    release_date: new FormControl('' ,Validators.required),
    work_type: new FormControl('', Validators.required),
    start_date: new FormControl('', Validators.required),
    billable: new FormControl('', Validators.required),
  });
}
