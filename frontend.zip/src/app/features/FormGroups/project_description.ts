import { FormControl, FormGroup, Validators } from '@angular/forms'
export class ProjectDescription{
  public projectdesc_form = new FormGroup({

    phase: new FormControl('', Validators.required),
    scope: new FormControl('', Validators.required),
    status: new FormControl('', Validators.required),
    sub_status: new FormControl('', Validators.required),
    start_date: new FormControl('', Validators.required),
    end_date: new FormControl('', Validators.required),
    est_need_for_team: new FormControl('', Validators.required),
    deviations: new FormControl('', Validators.required),
    reason_for_deviation: new FormControl('', Validators.required),
    project_manager: new FormControl('', Validators.required),
    project_status: new FormControl('', Validators.required),
    project_type: new FormControl('', Validators.required),
    revised_project_end_date: new FormControl('', Validators.required),
    type_of_support_contract: new FormControl(''),
    support_start_date: new FormControl('', Validators.required)

})
public projectrepo_linkform=new FormGroup({
docs_repo:new FormControl('' ,Validators.required),
})
public projectlist_form=new FormGroup({
project_id:new FormControl('' ,Validators.required),
project_description:new FormControl('' ,Validators.required),
customer_name:new FormControl('' ,Validators.required),
})
}
