import { FormControl, FormGroup, Validators } from '@angular/forms';
export class Projectadd {
  public projectadd_form = new FormGroup({
    customer_name: new FormControl('', Validators.required),
    project_id: new FormControl('', [Validators.required, Validators.pattern("^[a-zA-Z0-9 ]+$")]),
    project_name: new FormControl('' ,[Validators.required, Validators.pattern("^[a-zA-Z0-9 ]+$")]),
    project_manager: new FormControl('' ,Validators.required),
    phase: new FormControl('' ,Validators.required),
    scope: new FormControl(''),
    start_date: new FormControl('' ,Validators.required),
    end_date: new FormControl('' ,Validators.required),
    docs_repo: new FormControl(''),
    status: new FormControl('' ,Validators.required),
    sub_status: new FormControl(''),
    est_need_for_team: new FormControl('' ,Validators.required),
    project_description: new FormControl('' ,Validators.required),
    deviations: new FormControl(''),
    reason_for_deviation: new FormControl('', Validators.required),
    project_type: new FormControl('', Validators.required),
    type_of_support_contract: new FormControl(''),
    revised_project_end_date: new FormControl(''),
    support_start_date: new FormControl('', Validators.required)
  });
}
