import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedRoutingModule } from './shared-routing.module';
import { CoreRoutingModule } from '../core/core-routing.module';
import { MaterialModule } from './Material/material.module';
import { LayoutPageComponent } from './components/layout-page/layout-page.component';
import { CardsComponent } from './components/cards/cards.component';
import { RouterModule } from '@angular/router';
import { DeleteScreenComponent } from './splash_screens/delete-screen/delete-screen.component';
import { SuccessComponent } from './splash_screens/success/success.component';
import { GetProjectService } from './api-services/get-project.service';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
@NgModule({
  declarations: [
    LayoutPageComponent,
    CardsComponent,
    DeleteScreenComponent,
    SuccessComponent
  ],
  imports: [

    RouterModule,
    CommonModule,
    MaterialModule,
    SharedRoutingModule,
    CoreRoutingModule,
    HttpClientModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[LayoutPageComponent],
  providers:[GetProjectService,]
})
export class SharedModule { }
