import { TeamsHomepageComponent } from './../../../features/Teams-Components/teams-homepage/teams-homepage.component';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { map } from 'rxjs/internal/operators/map';
import { DeleteProject } from '../../../features/Interfaces/getProjectDescription';
import { DeleteEmpFromProjectService } from '../../../features/services/delete-emp-from-project.service';
import { DeleteemployeeskillService } from '../../../features/services/deleteemployeeskill.service';
import { DeleteemployeeService } from '../../../features/services/deleteemployee.service';
import { DeleteEmployee } from 'src/app/features/Interfaces/Deletemodel';
import { DeleteprojectService } from '../../../features/services/deleteproject.service';
import { ToastrService } from 'ngx-toastr';
import { DeleteEmployee_Skill } from '../../../features/Interfaces/Deletemodel';
import { Router } from '@angular/router';
import { EmployeeAddskillsComponent } from '../../../features/Teams-Components/employee-addskills/employee-addskills.component';
import { ProjectsAddemployeeComponent } from 'src/app/features/Projects-Components/projects-description/projects-addemployee/projects-addemployee.component';
import { ProjectsDescriptionComponent } from '../../../features/Projects-Components/projects-description/projects-description.component';

@Component({
  selector: 'app-delete-screen',
  templateUrl: './delete-screen.component.html',
  styleUrls: ['./delete-screen.component.scss'],
})
export class DeleteScreenComponent implements OnInit {
  deleteemployee!: DeleteEmployee;
  delete_projectid!: DeleteProject;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private toastr: ToastrService,
    private deleteproject: DeleteprojectService,
    private deletemeployeeservice: DeleteemployeeService,
    private deleteempskillservice: DeleteemployeeskillService,
    private deleteemp: DeleteEmpFromProjectService,
    private router: Router,
    private deleteemployeeskilldialogRef: MatDialogRef<EmployeeAddskillsComponent>,
    private deleteemployeedialogRef: MatDialogRef<TeamsHomepageComponent>,
    private deleteemployeeprojectdialogRef: MatDialogRef<ProjectsAddemployeeComponent>,
            private deleteprojectdialogRef: MatDialogRef<ProjectsDescriptionComponent>
  ) {}

  ngOnInit(): void {
    console.log(this.data);
  }
  deleteEmp_Project(data: any) {
    this.deleteemp.delete_Emp(data).subscribe((res) => {
      console.log(res);
      if (res['result'] == "success") {
this.toastr.success('Employee from project  is deleted successfully');
        setTimeout(() => {
       this.deleteemployeeskilldialogRef.close()

          window.location.reload()
          this.router.navigateByUrl('/Projects/:projectid/:projectname')
        },1000)
      }
    });
  }
  delete() {
    if (this.data['message'] == 'DeleteProject') {
      let data: any = {};
      data['project_id'] = this.data['project_id'];
      data['updated_by'] = this.data['updated_by'];
      console.log('delete project', data);
      this.delete_project(data);
    } else if (this.data['message'] == 'Delete Emp from the project') {
      console.log(this.data);
      let data: any = {};
      data['employee_id'] = this.data['employee_id'];
      data['project_id'] = this.data['project_id'];
      data['updated_by'] = this.data['updated_by'];
      this.deleteEmp_Project(data);
    } else if (this.data['message'] == 'DeleteSkill From Employee') {
      let data: DeleteEmployee_Skill = {};
      data['employee_id'] = this.data['employee_id'];
      data['skill_id'] = this.data['skill_id'];
      this.deleteemployee_skill(this.data);
    } else if (this.data['message'] == 'Delete Employee') {
      let data: DeleteEmployee = {};
      data['employee_id'] = this.data['employee_id'];
      data['updated_by'] = this.data['updated_by'];
      this.delete_employee(data);
    }
  }
  deleteemployee_skill(data: any) {
    this.deleteempskillservice.deleteEmp_skill(data).subscribe((res) => {
      console.log(res);
      if (res['result'] == 'success') {

        this.toastr.success('Employee skill is deleted successfully');
        setTimeout(() => {
       this.deleteemployeeskilldialogRef.close()

          window.location.reload()
          this.router.navigateByUrl('/Employees/:empid/:employeename')
        },1000)
      }
    });
  }
  delete_employee(data: DeleteEmployee) {
    this.deletemeployeeservice.deleteemployee(data).subscribe((res) => {
      console.log(res);
      if (res['result'] == 'success') {
        this.toastr.success('Employee is deleted successfully');
         setTimeout(() => {
          this.deleteemployeedialogRef.close()
           debugger

           this.router.navigateByUrl('/Employees')

        },1000)

      }
    });
  }
  delete_project(data: DeleteProject) {
    this.deleteproject.delete_project(data).subscribe((res) => {
      console.log(res);

if (res['result']== 'success') {
        this.toastr.success('Project is deleted successfully');
         setTimeout(() => {
          this.deleteprojectdialogRef.close()
           debugger
 localStorage.removeItem("project_id")
           this.router.navigateByUrl('/Projects')

        },1000)

      }

    });
  }
}
