import { ViewEncapsulation } from '@angular/compiler';
import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.scss'],

})
export class SuccessComponent implements OnInit {


  public isVisible: boolean = false;
  public y_isVisible: boolean = false;
  public r_isVisible: boolean = false;
  public emp_isVisible: boolean = false;
  public project_isVisible: boolean = false;

  constructor(@Inject(MAT_DIALOG_DATA) public data:any) { }

  ngOnInit(): void {
console.log("loadded")
if(this.data['project_successfully_added']==true){
  this.project_isVisible=true
}
  }

  saved_success() : void {
    if (this.isVisible) {
      return;
    }
    this.isVisible = true;
    setTimeout(()=> this.isVisible = false,1500)
  }

  not_saved_success() : void {
    if (this.y_isVisible) {
      return;
    }
    this.y_isVisible = true;
    setTimeout(()=> this.y_isVisible = false,1500)
  }

  deleted_success() : void {
    if (this.r_isVisible) {
      return;
    }
    this.r_isVisible = true;
    setTimeout(()=> this.r_isVisible = false,1500)
  }

  emp_added_success(): void {
    if (this.emp_isVisible) {
      return;
    }
    this.emp_isVisible = true;
    setTimeout(()=> this.emp_isVisible = false,1500)
  }

  project_added_success(value:boolean) {


    this.project_isVisible = true;
    setTimeout(()=> this.project_isVisible = false,1500)
  }


}
