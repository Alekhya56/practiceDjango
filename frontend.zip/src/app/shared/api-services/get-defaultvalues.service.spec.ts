import { TestBed } from '@angular/core/testing';

import { GetDefaultvaluesService } from './get-defaultvalues.service';

describe('GetDefaultvaluesService', () => {
  let service: GetDefaultvaluesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetDefaultvaluesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
