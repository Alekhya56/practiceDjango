import { TestBed } from '@angular/core/testing';

import { GetemployeeSkillnameService } from './getemployee-skillname.service';

describe('GetemployeeSkillnameService', () => {
  let service: GetemployeeSkillnameService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetemployeeSkillnameService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
