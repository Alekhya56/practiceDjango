import { EmployeeRecords } from './../../features/Teams-Components/Interfaces/Team_Records';

import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { Injectable } from '@angular/core';

import { Observable, throwError } from 'rxjs';

import { catchError } from 'rxjs/operators';


import { environment } from 'src/environments/environment';

import { Employee } from '../classes/get-employee';

const get_employeedetails = environment.URL + '/v1/dashboard/get_employees';

@Injectable({
  providedIn: 'root',
})
export class GetEmployeeService {
  constructor(private http: HttpClient) {}

  //Get Employee Details From Backend

  get_employees(): Observable<EmployeeRecords> {
    return this.http
      .get<EmployeeRecords>(get_employeedetails)
      .pipe(catchError(this.handleError));
  }

  public handleError = (error: HttpErrorResponse | any) => {
    return throwError(error);
  };
}
