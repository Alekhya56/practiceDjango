import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { Observable, of, throwError } from 'rxjs';

import { catchError } from 'rxjs/operators';

import { environment } from 'src/environments/environment';
import { Status } from '../classes/get-status';
import { TitleStrategy } from '@angular/router';
import { Designation, designation } from '../classes/designation';
import { department } from '../classes/department';
import { projectType } from '../classes/project-type';
import { WorkType, workType } from '../classes/work-type';
import { StatusOfWork } from '../classes/get-status-of-work';
const get_employeedetailsurl =
  environment.URL + '/v1/dashboard/get_drop_down_values';
const get_desginationsurl =
  environment.URL + '/v1/dashboard/get_employee_designations';
const get_deparmentsurl =
  environment.URL + '/v1/dashboard/get_employee_departments';
const get_projecttypeurl = environment.URL + '/v1/dashboard/get_drop_down_values';
const get_worktypeurl = environment.URL + '/v1/dashboard/get_drop_down_values';
const get_statusofworkurl = environment.URL + '/v1/dashboard/get_drop_down_values';

@Injectable({
  providedIn: 'root',
})
export class GetDefaultvaluesService {
  status$!: Observable<Status[]>;
  workType!: Observable<WorkType[]>;
  projectType$!: Observable<projectType[]>;
  statusOfWork$!: Observable<StatusOfWork[]>;
  constructor(private http: HttpClient) {}
  get_status_values(): Observable<Status> {
    console.log('status service');
    return this.http
      .get<Status>(get_employeedetailsurl)
      .pipe(catchError(this.handleError));
  }
  get_designations(): Observable<designation[]> {
    return this.http
      .get<designation[]>(get_desginationsurl)
      .pipe(catchError(this.handleError));
  }
  get_departments(): Observable<department[]> {
    return this.http
      .get<department[]>(get_deparmentsurl)
      .pipe(catchError(this.handleError));
  }
  get_project_type(): Observable<projectType> {
    return this.http
      .get<projectType>(get_projecttypeurl)
      .pipe(catchError(this.handleError));
  }
  get_work_type(): Observable<WorkType> {
    return this.http
      .get<WorkType>(get_worktypeurl)
      .pipe(catchError(this.handleError));
  }
  get_status_of_work(): Observable<StatusOfWork> {
    return this.http
      .get<StatusOfWork>(get_statusofworkurl)
      .pipe(catchError(this.handleError));
  }

  public handleError = (error: HttpErrorResponse | any) => {
    return throwError(error);
  };
}
