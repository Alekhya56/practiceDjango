import { TestBed } from '@angular/core/testing';

import { GetemployeesProjectsmanagersService } from './getemployees-projectsmanagers.service';

describe('GetemployeesProjectsmanagersService', () => {
  let service: GetemployeesProjectsmanagersService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetemployeesProjectsmanagersService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
