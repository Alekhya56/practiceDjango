import { Employee } from './../classes/get-employee';
import { GetProjectEmployees } from './../classes/get-project-managers';
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { BehaviorSubject, Observable, throwError, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { KeySkill } from '../classes/get-key-skill';

const get_Employee_Key_skill=environment.URL+"/v1/dashboard/get_skills"
@Injectable({
  providedIn: 'root'
})
export class GetemployeeSkillnameService {

  constructor(private http:HttpClient) { }

  //method for getting employees and project managers
    get_Employee_Key_skill():Observable<KeySkill>{
    return this.http.get<KeySkill>(get_Employee_Key_skill).pipe(catchError(this.handleError))

  }


  public handleError = (error: HttpErrorResponse | any) => {
    return throwError(error);
    }
}
