import { Employee } from './../classes/get-employee';
import { GetProjectEmployees } from './../classes/get-project-managers';
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { BehaviorSubject, Observable, throwError, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

const getProjectsmanagersurl=environment.URL+"/v1/dashboard/get_project_managers"
const getemployeesurl=environment.URL+"/v1/dashboard/get_employees"
@Injectable({
  providedIn: 'root'
})

//this service is used to get list of project managers and employees from backend

export class GetemployeesProjectsmanagersService {

  constructor(private http:HttpClient) { }

  //method for getting employees and project managers
    get_ProjectManagers():Observable<GetProjectEmployees>{
    return this.http.get<GetProjectEmployees>(getProjectsmanagersurl).pipe(catchError(this.handleError))

  }
 get_Employees():Observable<GetProjectEmployees>{
    return this.http.get<GetProjectEmployees>(getemployeesurl).pipe(catchError(this.handleError))

  }

  public handleError = (error: HttpErrorResponse | any) => {
    return throwError(error);
    }
}
