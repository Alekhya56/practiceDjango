import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { throwError, Observable, of, BehaviorSubject } from 'rxjs';
import { map, filter, catchError, mergeMap, retry, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { project, projectobject } from 'src/app/features/Interfaces/Project_Records';
const get_projectdetails=environment.URL+"/v1/dashboard/get_project_details"
@Injectable({
  providedIn: 'root'
})
//Getting list of projects details from backend and using this service in home screen
export class GetProjectService {

  constructor(private http:HttpClient) {
   }
//Get Project Details From Backend
get_project():Observable<projectobject[any]>{
  console.log(typeof( this.http.get<projectobject[]>(get_projectdetails)))
  return this.http.get<projectobject[any]>(get_projectdetails).pipe(catchError(this.handleError))

}
public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }
}
