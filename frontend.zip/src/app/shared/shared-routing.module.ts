import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeaturesModule } from '../features/features.module';
import { CoreModule } from '../core/core.module';
import { LayoutPageComponent } from './components/layout-page/layout-page.component';
import { SuccessComponent } from './splash_screens/success/success.component';
import { LoginPageComponent } from '../core/components/login-page/login-page.component';
import { AuthGuard } from '../core/guards/auth.guard';


const routes: Routes = [

{

  path:'home',component:LayoutPageComponent,canActivate:[AuthGuard],data: {title: 'Home'},
 children:[ {
    path: 'Employees',
    loadChildren: () => import ('src/app/features/features.module').then ( (m) => m.FeaturesModule),
  },
  {
    path: 'Projects',
    loadChildren: () => import ('src/app/features/features.module').then ( (m) => m.FeaturesModule),
  },
   {
    path: 'Views',
     loadChildren: () => import('src/app/features/features.module').then((m) => m.FeaturesModule),

  },
  {
    path: 'changepassword',
    loadChildren: () => import ('src/app/core/core.module').then ( (m) => m.CoreModule),
  },
  { path: 'home', redirectTo: 'home', pathMatch: 'full' },
  {path:'',redirectTo:'login',pathMatch:'full'}
 ],


},

// {path:'login', loadChildren: () => import ('src/app/core/core.module').then ( (m) => m.CoreModule)},

];

@NgModule({
  imports: [RouterModule.forChild(routes),],
  exports: [RouterModule]
})
export class SharedRoutingModule { }
