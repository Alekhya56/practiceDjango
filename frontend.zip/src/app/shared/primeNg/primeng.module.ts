import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {CalendarModule} from 'primeng/calendar';
import {ProgressBarModule} from 'primeng/progressbar';

import {
    NgModule
  } from '@angular/core';


@NgModule({
    exports: [

      TableModule,
      ButtonModule,
ProgressBarModule,
      CalendarModule
    ]
  })
  export class PrimeNGModule {}
