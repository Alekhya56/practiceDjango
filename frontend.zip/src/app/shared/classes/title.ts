export class Title{

  title!:string

  setTitle(title:string){
    this.title=title
  }
  getTitle(){
    return this.title
  }
}
