export interface projectType {
  [key: string]: typeproject[];
}
export interface typeproject {
  key: string;
  value: string;
}
