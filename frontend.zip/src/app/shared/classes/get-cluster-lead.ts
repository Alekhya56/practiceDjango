
export interface clusterLead{
  cluster_lead?: string

}
