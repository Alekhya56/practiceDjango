export interface KeySkill{
  [key:string]:keySkill[]

}
export interface keySkill{
  key:string
  value:string
}
