import { project } from 'src/app/features/Interfaces/Project_Records';

export interface Project{
phase?:string
project_id?:string
project_name?:string
start_date?:string
status?:string
project_value?:string

}
