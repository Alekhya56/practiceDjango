export interface StatusOfWork {
  [key: string]: statusofwork[];
}

export interface statusofwork{
  key:string
  value:string
}
