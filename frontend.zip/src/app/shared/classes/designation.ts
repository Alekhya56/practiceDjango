


export interface Designation{
  [key:string]:designation[]

}
export interface designation{
  status:string
  designation:string
}
