

export interface department{
  department?: string
  cluster_lead?: string
}
