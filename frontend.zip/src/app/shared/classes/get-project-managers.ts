import { Employees } from './employees';

export interface GetProjectEmployees{
  project_managers:Employees[]
  employee_names:Employees[]
}
