export interface Employee{
 employee_id?:string
 employee_name?:string
 employee_dept?:string
 role?:string
 employee_designation?:string

}

