export interface Employees{
employee_id:string
employee_name:string
}
