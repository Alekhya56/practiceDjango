import { Observable } from 'rxjs';

export interface Status{
  [key:string]:status[]

}
export interface status{
  key:string
  value:string
}
