export interface WorkType {
  [key: string]: workType[];
}

export interface workType{
  key:string
  value:string
}
