import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of} from 'rxjs';
import {  switchMap , delay} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LoadingHandlerService {
  private isLoading = new BehaviorSubject(false);
  Loading: Observable<boolean> = this.isLoading.pipe(
    switchMap(value => {
      if(!value){
      return of(false);
    }
    return of(true).pipe(delay(5000));
    })
  )
  constructor() { }


  start() {
    this.isLoading.next(true);
  }

  finish() {
    this.isLoading.next(false);
  }

}
