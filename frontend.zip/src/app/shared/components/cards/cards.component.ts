import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { AfterViewInit, Component,ElementRef,Input,OnInit,Renderer2, ViewChild} from '@angular/core';
import {GetProjectService} from './../../api-services/get-project.service'
import { map, Observable } from 'rxjs';
import { Project } from '../../classes/get-project';
import { GetEmployeeService } from '../../api-services/get-employee.service';
import { ThisReceiver } from '@angular/compiler';
import { Employee } from '../../classes/get-employee';
import { PageEvent } from '@angular/material/paginator';
import { LoaderserviceService } from '../../../core/services/loaderservice.service';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.scss']
})
export class CardsComponent implements AfterViewInit {
  [x: string]: any;
  styleelement!:HTMLElement
  colors : Array<string> = ["#ff00ff", "#00ff00","#0099CC","#008B8B"];
 projects_observable!:Project[]
 views_observable!:string[]
 employee_observable!:Employee[]
color:string="red"
project_recordslength!:number
employee_recordslength!:number
employee_records!:Employee[]
project_records!:Project[]
next_projects:number=0;
prev_projects:number=0;
page_records:number=4;
next_emp:number=0;
prev_emp:number=0;
isprev_projectpage:boolean=false
pageEvent!: PageEvent;
 @ViewChild('progress') progress!: ElementRef;
  status='In Implementation';
  deadline = '25-09-2022';

  cards = this.breakpointObserver.observe([Breakpoints.Handset,Breakpoints.Tablet,Breakpoints.TabletLandscape,Breakpoints.Medium,Breakpoints.WebPortrait]).pipe(
    map(({ matches }) => {
      if (matches) {
        return [
          { title: 'Projects', field:'one', cols: 3, rows: 1 },
          { title: 'Views', cols: 3, rows: 1 },
          { title: 'Employees', cols: 3, rows: 1 },
        ];
      }

      return [
        { title: 'Projects', field:'Deadline', cols: 1, rows: 1 },
        { title: 'Views', cols: 1, rows: 1 },
        { title: 'Employees', cols: 1, rows: 1 },
      ];
    })
  );

  projects = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      if (matches) {
        return [
          { title: 'Project 1', value:'70', date:'21-09-2022', status:'In Implementation', cols: 3, rows: 1 },
          { title: 'Project 2', value:'90', date:'07-07-2022', status:'In Maintenance', cols: 3, rows: 1 },
          { title: 'Project 3', value:'20', date:'18-12-2022', status:'In Prep. & Planning', cols: 3, rows: 1 },
          { title: 'Project 4', value:'100', date:'10-05-2022', status:'Completed', cols: 3, rows: 1 },
        ];
      }

      return [
        { title: 'Project 1', value:'70', date:'21-09-2022', status:'In Implementation', cols: 1, rows: 1 },
        { title: 'Project 2', value:'90', date:'07-07-2022', status:'In Maintenance', cols: 1, rows: 1 },
        { title: 'Project 3', value:'20', date:'18-12-2022', status:'In Prep. & Planning', cols: 1, rows: 1 },
        { title: 'Project 4', value:'100', date:'10-05-2022', status:'Completed', cols: 1, rows: 1 },
      ];
    })
  );

  views = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      if (matches) {
        return [
          { title: 'ProjectEmployees_View',cols: 3, rows: 1 },

        ];
      }

      return [
        { title: 'ProjectEmployees_View', cols: 1, rows: 1 },


      ];
    })
  );

  employees = this.breakpointObserver.observe(Breakpoints.Handset ).pipe(
    map(({ matches }) => {
      if (matches) {
        return [
          { title: 'Employee Name 1',role:'Project Manager', cols: 3, rows: 1 },
          { title: 'Employee Name 2',role:'Sr. Business Analyst', cols: 3, rows: 1 },
          { title: 'Employee Name 3',role:'Sr. Software Engineer', cols: 3, rows: 1 },
          { title: 'Employee Name 4',role:'Sr. Quality Analyst', cols: 3, rows: 1 },
        ];
      }

      return [
        { title: 'Employee Name 1',role:'Project Manager', cols: 1, rows: 1 },
        { title: 'Employee Name 2',role:'Sr. Business Analyst', cols: 1, rows: 1 },
        { title: 'Employee Name 3',role:'Sr. Software Engineer', cols: 1, rows: 1 },
        { title: 'Employee Name 4',role:'Sr. Quality Analyst', cols: 1, rows: 1 },
      ];
    })
  );

  constructor(public loaderService: LoaderserviceService,private getEmployeesservice:GetEmployeeService,private render:Renderer2,private apiservice:GetProjectService,private breakpointObserver: BreakpointObserver) {}
ngOnInit(): void {


}
ngAfterViewInit(): void {
  //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
  //Add 'implements AfterViewInit' to the class.


 this.apiservice.get_project().subscribe(res=>{
  console.log(res)
  this.project_records=res
  this.project_recordslength=Object.keys(this.project_records).length
  console.log( Object.keys(this.project_records).length,res.length)
  this.projects_observable=this.project_records.slice(0,4)
 })
  console.log(this.projects_observable)
/* this.apiservice.get_project().subscribe(res=>{
  console.log(res)
})

*/
this.getEmployeesservice.get_employees().subscribe(res=>{
  console.log(res)

  this.employee_records=res['employee_names']
  this.employee_recordslength=Object.keys(this.employee_records).length
  this.employee_observable=this.employee_records.slice(0,4)
})
}
load_prevProjectRecords(prev:number,next:number,pagerecords:number){

  if(this.next_projects>=1){
let pageindex=next-1
let startrecords=pagerecords*pageindex
let endrecords=pagerecords*pageindex+pagerecords

this.prev_projects=pageindex
this.next_projects=pageindex
this.projects_observable=this.project_records.slice(startrecords,endrecords)

console.log("prev page",pageindex,startrecords,endrecords,this.next_projects,this.project_recordslength)}
}
  load_nextProjectRecords(prev: number, next: number, pagerecords: number) {
    // if(this.project_recordslength %  2 == 0){
    //   if (this.project_recordslength % this.projects_observable.length > 0) {
    //     let pageindex = next + 1
    //     let startrecords = pagerecords * pageindex
    //     let endrecords = pagerecords * pageindex + pagerecords
    //     this.next_projects = pageindex
    //     this.projects_observable = this.project_records.slice(startrecords, endrecords)
    //     console.log("next page", pageindex, startrecords, endrecords, this.next_projects, this.project_recordslength)
    //   } else if(this.project_recordslength % this.projects_observable.length == 0){
    //     let pageindex = next + 1
    //     let startrecords = pagerecords * pageindex
    //     let endrecords = pagerecords * pageindex + pagerecords
    //     this.next_projects = pageindex
    //     this.projects_observable = this.project_records.slice(startrecords, endrecords)
    //   }
    // }
    // if(this.project_recordslength % 2 == 1){
    //   if (this.project_recordslength % this.projects_observable.length > 0) {
    //     let pageindex = next + 1
    //     let startrecords = pagerecords * pageindex
    //     let endrecords = pagerecords * pageindex + pagerecords
    //     this.next_projects = pageindex
    //     this.projects_observable = this.project_records.slice(startrecords, endrecords)
    //     console.log("next page", pageindex, startrecords, endrecords, this.next_projects, this.project_recordslength)
    //   } else if(this.project_recordslength % this.projects_observable.length == 0){
    //     let pageindex = next + 1
    //     let startrecords = pagerecords * pageindex
    //     let endrecords = pagerecords * pageindex + pagerecords
    //     this.next_projects = pageindex
    //     this.projects_observable = this.project_records.slice(startrecords, endrecords)
    //   }
    // }
    if ((this.project_recordslength % this.projects_observable.length >= 0) &&  (this.projects_observable.length >= 1)) {
      let pageindex = next + 1 
      let startrecords = pagerecords * pageindex
      let endrecords = pagerecords * pageindex + pagerecords
      this.next_projects = pageindex
      this.projects_observable = this.project_records.slice(startrecords, endrecords)
      console.log("next page", pageindex, startrecords, endrecords, this.next_projects, this.project_recordslength)
    }
    
  }
  
load_prevEmpRecords(prev:number,next:number,pagerecords:number){

 if(this.next_emp>=1){
let pageindex=next-1
let startrecords=pagerecords*pageindex
let endrecords=pagerecords*pageindex+pagerecords

this.prev_emp=pageindex
this.next_emp=pageindex

 this.employee_observable=this.employee_records.slice(startrecords,endrecords)
}}
load_nextEmpRecords(prev:number,next:number,pagerecords:number){
/* this.employee_observable=this.getEmployeesservice.get_ */
 if((this.employee_recordslength % this.employee_observable.length>= 0)){
let pageindex=next+1
let startrecords=pagerecords*pageindex
let endrecords=pagerecords*pageindex+pagerecords
this.next_emp=pageindex
this.employee_observable=this.employee_records.slice(startrecords,endrecords)


console.log("next page",pageindex,startrecords,endrecords,this.next_projects,this.project_recordslength)}else{



}
}
load_prevViewRecords(prev:number,next:number,pagerecords:number){


}
load_nextViewRecords(prev:number,next:number,pagerecords:number){


}
}



