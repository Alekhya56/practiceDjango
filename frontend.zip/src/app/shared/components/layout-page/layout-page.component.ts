import { GetDefaultvaluesService } from './../../api-services/get-defaultvalues.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ActivationStart, ActivationEnd, NavigationEnd } from '@angular/router';

import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { DatePipe } from '@angular/common';
import { GetProjectService } from '../../api-services/get-project.service';
import {of} from 'rxjs'
import { AuthenticationService } from '../../../core/services/authentication.service';
import { GetemployeesProjectsmanagersService } from '../../api-services/getemployees-projectsmanagers.service';
import { SuccessComponent } from '../../splash_screens/success/success.component';
import { LoaderserviceService } from '../../../core/services/loaderservice.service';
import { MessageService } from 'primeng/api';
import { ToastrService } from 'ngx-toastr';
import { Title } from '../../classes/title';
import { SecurelsService } from '../../../core/services/securels.service';
@Component({
  selector: 'app-layout-page',
  templateUrl: './layout-page.component.html',
  styleUrls: ['./layout-page.component.scss'],

})
export class LayoutPageComponent  implements OnInit {
  title='';
  header='Hello';
  designation=''
  today: string | null;
  navlist: string[] = ['Home', 'Projects', 'Teams', 'Views'];
  projects_Data!:Observable<string>
  employee_Data!:Observable<string>
  views_Data!:Observable<string>
  username:string=""

isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
    constructor(private securels:SecurelsService,public router:Router,private route:ActivatedRoute,private toastrService:ToastrService,public loaderService: LoaderserviceService,private getstatusservice:GetDefaultvaluesService,private getprojectmanagers_employees:GetemployeesProjectsmanagersService,private authservice:AuthenticationService,private apiservice:GetProjectService,public datepipe: DatePipe, private breakpointObserver: BreakpointObserver) {

 this.today = this.datepipe.transform((new Date), 'dd-MMM-yyyy');

    }

  ngOnInit(): void {
    /*  this.toastrService.error('Message Error!', 'Title Error!',{ onActivateTick: true }); */
    console.log(this.router.url)
    this.username=this.securels.securedecrypt(localStorage.getItem("user_name")!)
    this.designation=this.securels.securedecrypt(localStorage.getItem("role")!)
this.title="Hi "+this.username
 this.router.events.subscribe((event) => {


     console.log(event);
     let ans=""
let currenturl=""
if(event instanceof NavigationEnd){
currenturl=event['url']
  if(currenturl=="/home"){
    this.title="Hi "+this.username
  }
  else if(currenturl=="/Projects"){
    this.title="Projects"
  }
  else if(currenturl=="/Employees"){
    this.title="Employees"
  }
  else if(this.router.url==currenturl && currenturl.includes("/Projects")){
    console.log("includes")
    console.log(ans)
        let decryptvalue=this.securels.securedecrypt(localStorage.getItem("name")!)
    this.title="Projects"+"  >  "+decryptvalue
    console.log(this.title)
  }
 else if(this.router.url==currenturl && currenturl.includes("/Employees")){
    console.log("includes")
    console.log(ans)
    let decryptvalue=this.securels.securedecrypt(localStorage.getItem("name")!)
    console.log(decryptvalue)
    this.title="Employees"+"  >  "+decryptvalue
    console.log(this.title)
  }}
   });

   this.getstatusservice.get_status_values()

  }
  toolbar(tb:number){
    if(tb==1){
      this.title = 'Hi '+this.username;
    }else if(tb==2){
      this.title = 'Projects';
    }else if(tb==3){
      this.title = 'Employees';
    }
    else{
      this.title='Views';
    }

    this.projects_Data=of("projects")
    this.views_Data=of("views")
    this.employee_Data=of("employee")


  }


  navigate_to(value:string):void{
    console.log(value)
    this.router.navigateByUrl(value)
  }
  navigate_tochangepassword(){
    this.router.navigateByUrl('/changepassword')
  }
  logout(){
this.authservice.logout()

  }
}
