import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginPageComponent } from './login-page.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ToastrService, ToastrModule } from 'ngx-toastr';
import { AuthenticationService } from '../../services/authentication.service';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { By } from '@angular/platform-browser';
import {DebugElement} from '@angular/core'
fdescribe('LoginPageComponent', () => {
  let component: LoginPageComponent;
  let fixture: ComponentFixture<LoginPageComponent>;
  let dl:DebugElement
  let el:HTMLElement

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginPageComponent ],
      imports:[MatSnackBarModule,HttpClientModule,ReactiveFormsModule,FormsModule,RouterModule,ToastrModule.forRoot({timeOut: 1000, // 15 seconds
      positionClass:'toast-top-center'})],


      providers:[  AuthenticationService,ToastrService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginPageComponent);
    dl=fixture.debugElement.query(By.css('form'))
    el=dl.nativeElement
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  //checking if we give empty values whether the the form is submitting
  it('form should not valid if we give empty values',()=>{
      component.loginForm.setValue({
        "empid":"",
          "password":""
      })
      expect(component.loginForm.valid).toBe(false) //test case result will be false
  })
  it('form should not valid if we give email empty value',()=>{
    component.loginForm.setValue({
        "empid":"",
        "password":"awsdfsascdvfsdfd"
    })
    expect(component.loginForm.valid).toBe(false)//test case result will be false
})
it('form should not valid if we give password empty value',()=>{
  component.loginForm.setValue({
      "empid":"1001",
      "password":""
  })
  expect(component.loginForm.valid).toBe(false)//test case result will be false
})
it('form should be valid if we give both email and password values',()=>{
  component.loginForm.setValue({
      "empid":"1001",
      "password":"qwedrfgfsdf"
  })
  expect(component.loginForm.valid).toBe(true)//test case result will be true
})
it('check when we click on login whether  loginsubmit function is calling.',()=>{
  component.loginForm.setValue({
    "empid":"1086",
    "password":"dsdfvdsfvddf"

  })
  fixture.detectChanges()
  spyOn(component,'loginSubmit').and.callThrough()
  dl=fixture.debugElement.query(By.css('.login_btn'))
  el=dl.nativeElement
  console.log(el)
  el.click()

  expect(component.loginSubmit).toHaveBeenCalled()



})//when we click on login login submit function is calling
it('check when we click on forgot password whether the forgotpassword  function is calling.',()=>{

  fixture.detectChanges()
  spyOn(component,'navigate_Toforgotpass').and.callThrough()
  dl=fixture.debugElement.query(By.css('.forgot_btn'))
  el=dl.nativeElement
  console.log(el)
  el.click()

  expect(component.navigate_Toforgotpass).toHaveBeenCalled()



})
});
