import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
  Form,
  UntypedFormArray,
} from '@angular/forms';
import { AuthenticationService } from '../../services/authentication.service';
import { first, catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { LoaderserviceService } from '../../services/loaderservice.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss'],
})
export class LoginPageComponent implements OnInit {
  public loginForm!: FormGroup; //Login Form Group
  empId!: string;
  password!: string;
  isHide = true; //hiding entered password;
  constructor(
    public loaderservice: LoaderserviceService,
    private router: Router,
    private fb: FormBuilder,
    private authService: AuthenticationService
  ) {
    this.loginForm = this.fb.group({
      empid: new FormControl('', [Validators.required]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(8)
      ]),
    });
  }

  ngOnInit(): void {
    //on init method
  }
  //loginSubmit function for sending login details to authentication service..
  loginSubmit() {
    try {
      debugger;
      if (this.loginForm.valid) {
        this.empId = this.loginForm.get('empid')?.value;
        this.password = this.loginForm.get('password')?.value;

        console.log(this.empId, this.password);
        console.log(this.loginForm);
        this.authService.login(this.empId, this.password);
      }
    } catch (e) {
      console.error(e);
    }
  }
  //navigate_toforgotpass function is used for,when user click forgot password then user will navigate to forgot password screen
  // Component:ForgotPassword component
  navigate_Toforgotpass() {
    try {
      this.router.navigateByUrl('/forgotpassword');
    } catch (e) {
      console.error(e);
    }
  }
}
