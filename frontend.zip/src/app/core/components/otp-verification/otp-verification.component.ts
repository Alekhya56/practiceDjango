import { Component, OnInit } from '@angular/core';
import { OtpVerification } from '../../FormGroups/otpverification';
import { VerifyotpService } from '../../services/verifyotp.service';
import { SendotpService } from '../../services/sendotp.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { SecurelsService } from '../../services/securels.service';


@Component({
  selector: 'app-otp-verification',
  templateUrl: './otp-verification.component.html',
  styleUrls: ['./otp-verification.component.scss']
})
export class OtpVerificationComponent extends OtpVerification implements OnInit {
//here we inherited otpverifcation form from otpverifcation class
email!:string
isResendDisable: boolean = true;

  constructor(private securels: SecurelsService,private sendotpservice: SendotpService, private verifyotpservice: VerifyotpService, private toastr: ToastrService,
  private router: Router) {
super();
  }

  ngOnInit(): void {
    setTimeout(() => {
      this.isResendDisable= false ;
    }, 500000);
    // this.isResendDisable= false;
  }

change_email(){
  this.router.navigateByUrl('/forgotpassword')
}
//verify otp function is used for verifying otp using otpverifcations service
verify_otp(){
  try{
  let email=this.securels.securedecrypt(localStorage.getItem("mailid")!)
  let otp:string="";
  for(const control in this.otp_verficationForm.controls){
otp+=this.otp_verficationForm.get(control)?.value
    }
    console.log(email,otp)
this.verifyotpservice.verify_otp(email,otp).subscribe((res:any)=>{
  console.log(res)
  if(res['result']=="failure"){
    this.toastr.error(res['message'],"Error")
        }
        else if(res['result']=="success"){
        this.router.navigateByUrl('/newpassword')
        }
})}
catch(e){
  console.error(e)
}
}
resend_otp(){
  window.location.reload(); 
  try {
  let email=this.securels.securedecrypt(localStorage.getItem("mailid")!)
  this.sendotpservice.send_otp(email).subscribe((res: any) => {
    console.log(res);
    if (res["result"] == "failure") {
      this.toastr.error(res["message"], "Error");
    } else if (res["result"] == "Success") {
    
    }
  });}
 catch (e) {
  console.error(e);
}
}
// resendDisable(){

// }
}
