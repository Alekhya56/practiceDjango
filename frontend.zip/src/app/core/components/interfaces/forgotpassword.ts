export interface ForgotPassword{

  newpassword?:string

  email?:string
  result?:string

}
