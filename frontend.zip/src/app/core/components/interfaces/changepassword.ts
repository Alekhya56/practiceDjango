import { Employee } from '../../../features/Interfaces/getProjectDescription';
export interface ChangePassword{
  oldPassword?:string
  newPassword?:string
  confirmPassword?:string
  employee_id?:Employee
  result?:string

}

