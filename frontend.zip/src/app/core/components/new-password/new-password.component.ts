import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, Form } from '@angular/forms';
import { AuthenticationService } from '../../services/authentication.service';
import { Router } from '@angular/router';
import { SecurelsService } from '../../services/securels.service';
import { ChangePasswordService } from '../../services/change-password.service';


@Component({
  selector: 'app-new-password',
  templateUrl: './new-password.component.html',
  styleUrls: ['./new-password.component.scss']
})
export class NewPasswordComponent implements OnInit {
  public newForm: FormGroup; //new form group consists of password and confirm password
  empId:any;
  password!:string;
  confirmPassword!:string;
  strong: boolean = false;
  check: boolean = false;
  compared: boolean = false;
  hide = true;//boolean variable for hiding password
  hide1 = true;//boolean variable for hiding password
  constructor(private toastr: ToastrService,private changepassword:ChangePasswordService,private securels:SecurelsService,private router:Router,private fb: FormBuilder, private authService: AuthenticationService) {
    this.newForm = this.fb.group({
      password: new FormControl('', [Validators.required,Validators.minLength(8)]),
      confirmPassword: new FormControl('', [Validators.required,Validators.minLength(8)])
    })
  }

  ngOnInit(): void {
  //on init method
  }

//new password submit function for sending password and confirm password details to backend using changepassword service
//when user click on forgotpassoword after successfull opt verification we get this component.

  newPasswordSubmit(){
    try{
    let password=this.newForm.get("password")?.value
    let confirmpassword=this.newForm.get("confirmPassword")?.value
    if(this.newForm.valid){
    if(password===confirmpassword){
    let data:any={}
    data['newpassword']=password
    data['email']=this.securels.securedecrypt(localStorage.getItem("mailid")!)
  this.changepassword.forgot_password(data).subscribe(res=>{
    console.log(res)
    if(res['result']=="success"){
            this.toastr.success("Password changed successfully,Please again login","Dismiss")
  setTimeout(() => {
  this.router.navigateByUrl("/login")
      },1500);
}

  })
  }}


  }
  catch(e){
    console.error(e)
  }
  }

  //
  clearPasswordBtn(){
    this.newForm.reset();
  }

  strongPassword(){
     if(this.newForm.get('password')?.value === this.newForm.get('confirmPassword')?.value){
        this.strong = true;
     }
  }

  compare(){
    console.log(this.compared);
    this.compared = true;
  }


}
