import { Component, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ForgotPassword } from "../../FormGroups/forgotpassword";
import { SendotpService } from "../../services/sendotp.service";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";
import { SecurelsService } from "../../services/securels.service";

@Component({
  selector: "app-forgot-password",
  templateUrl: "./forgot-password.component.html",
  styleUrls: ["./forgot-password.component.scss"],
})
export class ForgotPasswordComponent extends ForgotPassword implements OnInit {
  //Extending forgot password formgroup from formgroup folder..

  constructor(
    private securels: SecurelsService,
    private router: Router,
    private sendotpservice: SendotpService,
    private toastr: ToastrService
  ) {
    super();
  }

  ngOnInit(): void {
    //Onint method..
  }

  //resetpassword function is used to send email address to backend for otp purpose,using sentotp service..
  reset_password() {
    try {
      let email: string = this.Forgot_PasswordForm.get("email")?.value!;
      console.log(email);

      localStorage.setItem("mailid", this.securels.secureencrypt(email));
      this.sendotpservice.changeemail(email);
      this.sendotpservice.send_otp(email).subscribe((res: any) => {
        console.log(res);
        if (res["result"] == "failure") {
          this.toastr.error(res["message"], "Error");
        } else if (res["result"] == "Success") {
          this.router.navigateByUrl("/otpverification");
        }
      });
    } catch (e) {
      console.error(e);
    }
  }
}
