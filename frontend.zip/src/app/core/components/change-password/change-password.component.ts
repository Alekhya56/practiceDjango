import { ChangePasswordService } from './../../services/change-password.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormControl, FormGroup } from '@angular/forms';
import { ChangePassword } from '../interfaces/changepassword';
import { SecurelsService } from '../../services/securels.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

 public change_passwordForm!: FormGroup; // change password group with three elements oldpassword,new password,confirmpassword
  empId!:string;
  password!: string;
  oldPassword!: string;
  newPassword!: string;
  confirmPassword!: string;
  hide = true;//boolean variable for hiding oldpassword
  hide1 = true;//boolean variable for hiding new password
  hide2 = true;//boolean variable for hiding confirm password
  constructor(private toastr: ToastrService,private securels:SecurelsService,private changepasswordservice:ChangePasswordService,private router:Router,private fb: FormBuilder) {
    this.change_passwordForm = this.fb.group({
      oldPassword: new FormControl('', [Validators.required,Validators.minLength(8)]),
      newPassword: new FormControl('', [Validators.required,Validators.minLength(8)]),
      confirmPassword: new FormControl('', [Validators.required,Validators.minLength(8)])
    })
  }
 ngOnInit(): void {
  //on init method
  }

//change password function is used for when employee clicks on changepassword which is present inside usericon,to change password of new employee,that employee need to change password
//sending employeeid ,new password and old password to backend using changepassword service
change_password(){
  try{
    let empid:string=localStorage.getItem("id")!
    let id:string=this.securels.securedecrypt(empid)

    let newpassword=this.change_passwordForm.get('newPassword')?.value
    let confirmpassword=this.change_passwordForm.get('confirmPassword')?.value
    let oldpassword=this.change_passwordForm.get('oldPassword')?.value
    let data:any={}

      data['newpassword']=newpassword
      data['oldpassword']=oldpassword
      data['employee_id']=id
      console.log(id)
  console.log(newpassword,confirmpassword,oldpassword,data['employee_id'])

    if(this.change_passwordForm.valid){
      console.log("validated")
      if(newpassword===confirmpassword){
        console.log(data)
        this.changepasswordservice.change_password(data).subscribe(res=>{
          console.log(res)
          if(res['result']=="success"){
            this.toastr.success("Password changed successfully,Please again login","Dismiss")
            setTimeout(() => {
            this.router.navigateByUrl("/login")
                },500);
          }
        })
      }
    }

  }

  catch(e){
    console.error(e)
  }}

}
