import { FormGroup, FormControl, Form } from '@angular/forms';
export class OtpVerification{
  //otp verifcation formgroup
   otp_verficationForm= new FormGroup({
number1:new FormControl(''),
number2:new FormControl(''),
number3:new FormControl(''),
number4:new FormControl('')
})}
