import { FormGroup, FormControl, Validators } from '@angular/forms';
export class ForgotPassword{
  //forgot password form group
  Forgot_PasswordForm= new FormGroup({
email:new FormControl('',[Validators.required, Validators.email, Validators.pattern('^.+@manomay.biz$')])
})}
