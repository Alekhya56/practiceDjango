import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../shared/Material/material.module';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { CoreRoutingModule } from './core-routing.module';
import { LoginPageComponent } from './components/login-page/login-page.component';
import { AuthenticationService } from './services/authentication.service';
// import { ProjectsDescriptionComponent } from './features/Projects-Components/projects-description/projects-description.component';
import { HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';

import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ToastrModule } from 'ngx-toastr';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { OtpVerificationComponent } from './components/otp-verification/otp-verification.component';
import { NewPasswordComponent } from './components/new-password/new-password.component';



@NgModule({
  declarations: [
    // ProjectsDescriptionComponent

    LoginPageComponent,
    ChangePasswordComponent,
    ForgotPasswordComponent,
    OtpVerificationComponent,
    NewPasswordComponent
  ],
  imports: [

    CommonModule,
    CoreRoutingModule,
    MaterialModule,
ReactiveFormsModule,
    FormsModule
  ],
  providers:[
    AuthenticationService,

    ]

})
export class CoreModule { }
