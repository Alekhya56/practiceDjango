import { DOCUMENT } from '@angular/common';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Inject, Injectable, Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { map } from 'rxjs/internal/operators/map';
import { SecurelsService } from './securels.service';
import { environment } from 'src/environments/environment';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { LoaderserviceService } from './loaderservice.service';

const url: string = environment.URL + "/v1/auth/login"


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

 loggedIn = new BehaviorSubject<boolean>(false);
 empid=new BehaviorSubject<string>('')

  constructor(private loaderservice:LoaderserviceService,private toastr: ToastrService,private http: HttpClient, private router: Router, private secure: SecurelsService,
    private snackBar: MatSnackBar,
    @Inject(DOCUMENT) private document: Document) {

  }
loginstatus(){
  return this.loggedIn.asObservable()
}

//login function is used for sending empid and password to backend using authentication service,this function is called in login component
  login(empId: string, password: string) {
try{
this.http.post<any>(url,
      { employee_id: empId, password: password })
    .subscribe(res => {
      console.log(res)

        if(res['result']=="failure"){
        console.log(res['result'])
         this.toastr.error(res['message'],"Dismiss")
      }
      else if(res['data']['temp_password']==true){
        this.router.navigateByUrl('/changepassword')
        localStorage.setItem("id",this.encryptdata("role",res['data']['employee_id']))
        localStorage.setItem("token",this.encryptdata("token",res['user_token']))
        localStorage.setItem("loginid",this.encryptdata("role",res['data']['employee_id']))
      }

        else if (res['result'] == "success") {
           localStorage.setItem("id",this.encryptdata("role",res['data']['employee_id']))
          localStorage.setItem("token",this.encryptdata("token",res['user_token']))
      localStorage.setItem("user_name",this.encryptdata("user_name",res['data']['UserName']))
      localStorage.setItem("role",this.encryptdata("role",res['data']['role']))

      console.log(res)
      this.loggedIn.next(true)
        this.router.navigateByUrl('/home')
      }

      },
        (error: any) => {

          console.log(error);
        },()=>{
          console.log("completed")
        }
        );
}catch(e){
  console.error(e)
}
}

// logout function is used when employee or user clicks logout this function will be called
  logout(){
    try{
    localStorage.clear()
    this.loggedIn.next(false)
    this.router.navigateByUrl('/login')
  }catch(e){
    console.error(e)
  }}


  //encryptdata function is used for encrtyping data using securels service
  encryptdata(key:string,value:string){

    return this.secure.secureencrypt(value)
  }
  //decryptdata function is used for decrypting data using securels service.
  decryptdata(key:string,value:string){

    this.secure.secureencrypt(value)
  }
}
