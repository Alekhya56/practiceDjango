import { Injectable } from "@angular/core";
import * as CryptoJS from "crypto-js";
@Injectable({
  providedIn: "root",
})
export class SecurelsService {
  //secure ls service is used for encrypting data and decrypting data using cryptojs package
  private key: string = "zsxdcfvbvfdsaxdcfvdsa23e4r21q#R$w3$@562";
  constructor() {}
  //encrypt function encrypts data
  private encrypt(txt: string): string {
    return CryptoJS.AES.encrypt(txt, this.key).toString();
  }
  //decrypt function decrypts data
  private decrypt(txtToDecrypt: string) {
    return CryptoJS.AES.decrypt(txtToDecrypt, this.key).toString(
      CryptoJS.enc.Utf8
    );
  }
  //secureencrypt function is called whereever we called this function inside this function we called encrypt function
  public secureencrypt(txt: string) {
    console.log(txt);
    console.log(this.encrypt(txt));
    return this.encrypt(txt);
  }

  //securedecrypt function is called whereever we called this function inside this function we called decrypt function
  public securedecrypt(txt: string) {
    console.log(txt);
    return this.decrypt(txt);
  }
}
