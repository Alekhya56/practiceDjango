import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Inject, } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { map } from 'rxjs/internal/operators/map';
import { SecurelsService } from './securels.service';
import { environment } from 'src/environments/environment';
import {  ChangePassword } from '../components/interfaces/changepassword';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ForgotPassword } from '../components/interfaces/forgotpassword';

const changepasswordurl = environment.URL + "/v1/auth/change_old_password"
const newpasswordurl= environment.URL + "/v1/auth/change_password"
@Injectable({
  providedIn: 'root'
})
export class ChangePasswordService {

  constructor(private http:HttpClient) { }
//change password function is for changing password when new employee is created,is it called in change password component
change_password(data:ChangePassword){
  console.log(data)

return this.http.post<ChangePassword>(changepasswordurl,data).pipe(catchError(this.handleError))

}

//forgotpassword function is for when user clicked on forgot password .it is called in forgotpassword component
forgot_password(data:ForgotPassword):Observable<ForgotPassword>{

  return this.http.post<ForgotPassword>(newpasswordurl,data).pipe(catchError(this.handleError))

}
public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }
}

