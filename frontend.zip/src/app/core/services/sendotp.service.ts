import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.prod';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { throwError, BehaviorSubject } from 'rxjs';
import { catchError } from 'rxjs/operators';
const sendotpurl = environment.URL + "/v1/auth/send_otp"
@Injectable({
  providedIn: 'root'
})
export class SendotpService {
private email= new BehaviorSubject<string>("")
currentemail = this.email.asObservable();

changeemail(email:string){
  this.email.next(email)
}

  constructor(private http:HttpClient) { }
  send_otp(email:string):any{
  return this.http.post<any>(sendotpurl,{email:email}).pipe(catchError(this.handleError))
}
public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
  }


}
