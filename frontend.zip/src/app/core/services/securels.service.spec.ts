import { TestBed } from '@angular/core/testing';

import { SecurelsService } from './securels.service';

describe('SecurelsService', () => {
  let service: SecurelsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SecurelsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
