import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.prod';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
const verifyotpurl = environment.URL + "/v1/auth/verify_otp"
@Injectable({
  providedIn: 'root'
})
export class VerifyotpService {

  constructor(private http:HttpClient) { }
  verify_otp(email:string,otp:string):any{
  return this.http.post<any>(verifyotpurl,{email:email,otp:otp}).pipe(catchError(this.handleError))
}
public handleError = (error: HttpErrorResponse | any) => {

  return throwError(error);
}}
