import { LoginPageComponent } from './components/login-page/login-page.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SuccessComponent } from '../shared/splash_screens/success/success.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { NewPasswordComponent } from './components/new-password/new-password.component';
import { OtpVerificationComponent } from './components/otp-verification/otp-verification.component';

const routes: Routes = [
/*   {
    path:'Login',component:LoginPageComponent
  },
  {
    path:'',component:LoginPageComponent
  } */
   {
    path:'login',component:LoginPageComponent
  },
{
  path:'changepassword',component:ChangePasswordComponent
  },
  {
    path:'forgotpassword',component:ForgotPasswordComponent
  },
  {
    path:'newpassword',component:NewPasswordComponent
  },
  {
    path:'otpverification',component:OtpVerificationComponent
  },
{
  path:'',redirectTo:'login',pathMatch:'full'
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoreRoutingModule { }
