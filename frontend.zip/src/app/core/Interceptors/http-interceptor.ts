import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';
import { finalize, Observable } from 'rxjs';
import { AuthenticationService } from '../services/authentication.service';
import { LoaderserviceService } from '../services/loaderservice.service';
import { SecurelsService } from '../services/securels.service';

@Injectable({
  providedIn: 'root',
})
export class httpInterceptor implements HttpInterceptor {
  constructor(
    private securels: SecurelsService,
    public loaderService: LoaderserviceService,
    private authService: AuthenticationService
  ) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    let token = localStorage.getItem('token')!;

    console.log(token);
    if (token) {
      token = this.securels.securedecrypt(token);
      console.log(token);
      req = req.clone({
        setHeaders: {
          Authorization: `${token}`
        },
      });
    } else {
      return next.handle(req);
    }

    return next.handle(req).pipe(finalize(() => {}));
  }
}
