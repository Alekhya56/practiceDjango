import { Inject, Injectable, Injector } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';


@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

  constructor( @Inject(Injector) private readonly toaster: Injector) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {

    return next.handle(request).pipe(catchError((error:HttpErrorResponse)=>{

      let mssg=""
      if(error.error instanceof ErrorEvent){
        mssg=`Error:$(error.error.message)`
        console.log(mssg)
      }else{
       console.log(error)
        //mssg='Error Code:'+error.status+" ",+'Message:'+error.message;
        mssg="Message:"+error.name
        console.log(mssg)
      }
    this.toastrService.error(mssg, 'Title Error!',{ onActivateTick: true });
      return throwError(error)
    }));
  }
  private get toastrService(): ToastrService {
        return this.toaster.get(ToastrService);
    }
}

