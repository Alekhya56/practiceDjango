import { CUSTOM_ELEMENTS_SCHEMA, LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './shared/Material/material.module';
import { FeaturesModule } from './features/features.module';
import { LayoutPageComponent } from './shared/components/layout-page/layout-page.component';
import { RouterModule } from '@angular/router';
import { DatePipe } from '@angular/common';
import { PrimeNGModule } from './shared/primeNg/primeng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateAdapter } from '@angular/material/core';
import {DateFormat} from './date-format'
import { CoreModule } from './core/core.module';
import { AuthenticationService } from './core/services/authentication.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { httpInterceptor } from './core/Interceptors/http-interceptor';


import { GetDefaultvaluesService } from './shared/api-services/get-defaultvalues.service';
import { ErrorInterceptor } from './core/Interceptors/error.interceptor';
import { ToastrModule } from 'ngx-toastr';
import { ToastrService } from 'ngx-toastr';
import { SecurelsService } from './core/services/securels.service';
import { AuthGuard } from './core/guards/auth.guard';
@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
ToastrModule.forRoot({

      timeOut: 1000, // 15 seconds
positionClass:'toast-top-center'
    }),

    AppRoutingModule,
    BrowserModule,
    RouterModule,
    SharedModule,
    MaterialModule,
    PrimeNGModule,
    BrowserAnimationsModule,
    FeaturesModule,
    ReactiveFormsModule,
    FormsModule,
    CoreModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  providers: [DatePipe,AuthenticationService,AuthGuard ,ToastrService,SecurelsService,
   {provide: LOCALE_ID, useValue: 'en-US',useClass:DateFormat },
   { provide:HTTP_INTERCEPTORS,useClass: httpInterceptor,multi:true},
   {provide:HTTP_INTERCEPTORS,useClass:ErrorInterceptor,multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
