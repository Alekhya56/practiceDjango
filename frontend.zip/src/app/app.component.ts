import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SuccessComponent } from './shared/splash_screens/success/success.component';
import { MessageService } from 'primeng/api';
import { LoaderserviceService } from './core/services/loaderservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],

})
export class AppComponent implements OnInit  {

  title = 'Manomaydashboards-fe';
  url!:string
  constructor(public router:Router,public loaderService: LoaderserviceService){
    this.url=this.router.url

  }

  ngOnInit(): void {
console.log(this.url)

  }

}
