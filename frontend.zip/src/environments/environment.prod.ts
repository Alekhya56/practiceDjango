export const environment = {
  production: true,
    URL: 'http://20.198.94.85:8080',
};
