from . import db

"""
Schema stores Employee Department details

returns: Employee id

"""
class EmployeeDepartments(db.Model):
    __tablename__ = "EmployeeDepartments"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    department= db.Column(db.String(50), unique=False, nullable=False)
    cluster_lead= db.Column(db.String(50), unique=False, nullable=False)
    status = db.Column(db.String(50), nullable=False)

    def __repr__(self):
        return f"EmployeeDepartment('{self.department}')"
