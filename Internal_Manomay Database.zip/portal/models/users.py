from flask_login import UserMixin

from . import db

# from flask_script import Manager
# from flask_migrate import Migrate, MigrateCommand, migrate
"""
Schema stores Employee details

returns: Employee Name

"""

class Users(UserMixin, db.Model):
    __tablename__ = "Users"
    id = db.Column(db.Integer, primary_key=True,nullable=False)
    employee_id = db.Column(db.String(50), db.ForeignKey('Employee.employee_id'), nullable=False)
    UserName = db.Column(db.String(50), unique=False, nullable=False)
    Password = db.Column(db.String(150),nullable=False)
    Email	= db.Column(db.String(50), unique=True, nullable=True)
    Status = db.Column(db.String(150), nullable=False)
    TemporaryPassword= db.Column(db.Boolean, unique=False, nullable=True)
    Otp = db.Column(db.String(100), unique=False, nullable=True)
    permissions = db.Column(db.String(100), unique=False, nullable=True)

    def __repr__(self):
        return f"User('{self.employee_id}')"

