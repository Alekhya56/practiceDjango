from email.policy import default

from sqlalchemy.orm import relationship

from . import db

# Base = declarative_base()

"""
Schema stores Employee details

returns: Employee Name

"""

class Employee(db.Model):
    __tablename__ = "Employee"
    # id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    employee_id = db.Column(db.String(50), primary_key=True, unique = True)
    employee_name = db.Column(db.String(50), unique=False, nullable=False)
    employee_dept = db.Column(db.String(50), unique=False, nullable=False)
    updated_by = db.Column(db.String(100), unique=False, nullable=True)
    employee_dob = db.Column(db.Date)
    employee_doj = db.Column(db.Date)
    employee_previous_experience = db.Column(db.Integer, unique=False, nullable=False)
    updated_date = db.Column(db.Date)
    created_on = db.Column(db.Date)
    employee_contact_number = db.Column(db.String(100), unique=True, nullable=False)
    employee_designation = db.Column(db.String(50), unique=False, nullable=False)
    employee_email = db.Column(db.String(50), unique=True, nullable=False)
    employee_status = db.Column(db.String(50), nullable=False)
    reporting_manager=db.Column(db.String(50), unique=False, nullable=False)
    employee_permissions = db.Column(db.String(100), unique=False, nullable=True,default=True)
    cluster_lead_access= db.Column(db.String(100), unique=False, nullable=True,default=True)
    cluster_lead_value=db.Column(db.String(100), unique=False, nullable=True,default=True)
    employee_skills = relationship("EmployeeSkills",lazy='joined',backref="Employee")
    users = relationship("Users", lazy ='joined', backref="Employee", uselist=False)
    project_employee = relationship("ProjectEmployeeMapping",lazy='joined',backref="Employee")


    def __repr__(self):
        return f"Employee('{self.employee_name}')"
