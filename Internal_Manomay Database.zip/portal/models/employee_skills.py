from portal.models.employee import Employee
from portal.models.skills import Skills

from . import db

"""
Schema stores Employee skill details

returns: Employee id

"""

class EmployeeSkills(db.Model):
    __tablename__ = "EmployeeSkills"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    employee_id = db.Column(db.String(50), db.ForeignKey(Employee.employee_id))
    skill_id = db.Column(db.Integer, db.ForeignKey(Skills.skill_id))
    skill_level = db.Column(db.String(150), nullable=True)
    def __repr__(self):
        return f"EmployeeSkill('{self.id}')"
