from portal.models.employee import Employee
from portal.models.project import Project

from . import db

"""
Schema stores Project Employee details

returns: project id

"""

class ProjectEmployeeMapping(db.Model):
    __tablename__ = "ProjectEmployeeMapping"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    project_id = db.Column(db.String(50), db.ForeignKey(Project.project_id))
    employee_id = db.Column(db.String(50), db.ForeignKey(Employee.employee_id))
    role = db.Column(db.String(50), unique=False, nullable=False)
    status_of_work = db.Column(db.String(50), unique=False, nullable=True)
    updated_by = db.Column(db.String(100), unique=False, nullable=True)
    start_date=db.Column(db.Date)
    release_date = db.Column(db.Date)
    updated_date = db.Column(db.Date)
    phase = db.Column(db.String(100), unique=False, nullable=True)
    est_work = db.Column(db.String(100), unique=False, nullable=False)
    expected_hours_per_day = db.Column(db.String(100), unique=False, nullable=False)
    project_employee_status = db.Column(db.String(100), unique=False, nullable=True)
    created_on = db.Column(db.Date)
    billable= db.Column(db.String(100), unique=False, nullable=False)
    work_type= db.Column(db.String(50), unique=False, nullable=True)



    def __repr__(self):
        return f"ProjectEmployee('{self.project_id}')"
