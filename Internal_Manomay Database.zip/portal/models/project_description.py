from xmlrpc.client import Boolean

from . import db
from .project import Project

"""
Schema stores Project description details

returns: project id

"""

class ProjectDescription(db.Model):
    __tablename__ = "ProjectDescription"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    project_id = db.Column(db.String(50), db.ForeignKey(Project.project_id))
    project_description = db.Column(db.String(500), unique=False, nullable=True)
    phase	= db.Column(db.String(50), unique=False, nullable=True)
    scope = db.Column(db.String(150), nullable=True)
    status = db.Column(db.String(150), nullable=True)
    sub_status = db.Column(db.String(150), nullable=True)
    docs_repo= db.Column(db.String(1000), unique=False, nullable=True)
    updated_by = db.Column(db.String(100), unique=False, nullable=True)
    start_date = db.Column(db.Date)
    project_manager = db.Column(db.String(500), nullable=False)
    end_date = db.Column(db.Date)
    est_need_for_team = db.Column(db.String(500), unique=False, nullable=True)
    reason_for_deviation = db.Column(db.Text, nullable=True)
    deviations = db.Column(db.Text, nullable=True)
    updated_date = db.Column(db.Date)
    created_on = db.Column(db.Date)
    active_project = db.Column(db.Boolean, unique=False, nullable=True)
    project_type= db.Column(db.String(500), unique=False, nullable=True)
    revised_project_end_date= db.Column(db.Date,unique=False, nullable=True)
    type_of_support_contract= db.Column(db.String(500), unique=False, nullable=True)
    support_start_date=db.Column(db.Date,unique=False, nullable=True)

    def __repr__(self):
        return f"ProjectDescription('{self.project_id}')"

