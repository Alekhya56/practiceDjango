from . import db

"""
Schema stores Employee Designation details

returns: Employee id

"""
class EmployeeDesignations(db.Model):
    __tablename__ = "EmployeeDesignations"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    designation = db.Column(db.String(50), unique=False, nullable=False)
    status = db.Column(db.String(50), nullable=False)

    def __repr__(self):
        return f"EmployeeDesignation('{self.designation}')"
