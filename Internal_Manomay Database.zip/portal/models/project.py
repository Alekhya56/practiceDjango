from sqlalchemy.orm import relationship

from . import db

"""
Schema stores Project details

returns: Project Name

"""

class Project(db.Model):
    __tablename__ = "Project"
    # id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    project_id = db.Column(db.String(50), primary_key=True)
    project_name = db.Column(db.String(50), unique=False, nullable=False)
    customer_name = db.Column(db.String(50), unique=False, nullable=False)
    updated_by = db.Column(db.String(100), unique=False, nullable=True)
    created_on = db.Column(db.Date)
    updated_date = db.Column(db.Date)
    project_employee = relationship("ProjectEmployeeMapping",lazy='joined',backref="Project")
    project_description = relationship("ProjectDescription",lazy='joined',backref="Project")

    def __repr__(self):
        return f"Project('{self.project_name}')"

