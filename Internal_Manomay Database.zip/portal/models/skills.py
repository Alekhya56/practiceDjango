from sqlalchemy.orm import relationship

from . import db

"""
Schema stores Employee skill details

returns: Employee skill name

"""

class Skills(db.Model):
    __tablename__ = "Skills"
    skill_id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    skill_name	= db.Column(db.String(50), unique=False, nullable=True)
    skill_description = db.Column(db.String(150), nullable=False)
    employee_skills = relationship("EmployeeSkills",lazy='joined',backref="Skills")

    def __repr__(self):
        return f"Skills('{self.skill_name}')"

