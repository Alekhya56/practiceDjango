from functools import wraps

import jwt
from flask import request

from .. import APP


def login_required(func):
    @wraps(func)
    def decorated(*args, **kwargs):
        user_token = request.headers.get('Authorization')
        if not user_token:
            # return jsonify({"success": False, "message": "Session token is missing"}), 401
            return {"success": False, "message": "Session token is missing"}
        try:
            user_data = jwt.decode(user_token, algorithms='HS256', key=APP.config['JWT_SECRET_KEY'])
        except Exception as e:
            # return jsonify({"success": False, "message": "Invalid user token"}), 401
            return {"success": False, "message": "Invalid user token"}
        return func(*args, **kwargs)
    return decorated
