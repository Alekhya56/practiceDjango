
from portal.routes.dashboard import delete_project


def init_app(app):
    from .admin import admin
    from .auth import (change_old_password, change_password_via_otp, login,
                       logout, send_otp, verify_otp)
    from .dashboard import (add_employee_skills, add_empolyee,
                            add_or_update_employee_to_project, add_project,
                            add_skills, delete_employee, delete_employee_skill,
                            delete_project, delete_project_employee,
                            get_drop_down_values, get_employee_departments,
                            get_employee_designations,
                            get_employee_project_description,
                            get_employee_project_skills, get_employee_skills,
                            get_employees, get_project_details,
                            get_project_managers, get_skills, home,
                            update_employee, update_project_details,
                            update_project_doc_repo)
    app.logger.info("Initialized routes")
