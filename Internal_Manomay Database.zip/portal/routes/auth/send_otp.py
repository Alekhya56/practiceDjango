from flask_restx import Resource, reqparse
from werkzeug.exceptions import InternalServerError

from ... import LOG
from ...encryption import Encryption
from ...helpers import random_digits, send_email
from ...models import db
from ...models.users import Users
from . import ns

parser = reqparse.RequestParser()
parser.add_argument('email', type=str, location='json', required=True)

def _change_password(user):
    try:
        otp = random_digits()
        otp = otp[:4]
        otp_encrypt = Encryption().encrypt(otp)
        user.Otp = otp_encrypt
        user.TemporaryPassword = False
        message = f'<p>Dear {user.UserName}</p>' + \
                  f'<p>We have received a request to reset your password <p>' + \
                  f'<p>Please use this below otp to verify your email. <p>' + \
                  f'<p>Password: <b style="color:red">{otp}</b></p>'
        db.session.commit()
        cc = []
        send_email(
                    body=message,
                    subject='Verify your email',
                    cc=cc,
                    to_address=[user.Email]
                    )
        return {"result": "Success"}

    except Exception as e:
        LOG.error('Unexpected error happened during sending otp: %s', e)
        raise InternalServerError(e)


@ns.route("/send_otp")
class SendOtp(Resource):
    """A new temporary password will send to the given mail.

        returns:
        -----------
        Redirects : success
                send mail to given email id.

    """
    @ns.doc(description='reset',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    def post(self):
        try:
            data = parser.parse_args(strict=False)

            user = Users.query.filter(Users.Email == data['email']).first()
            if user is None:
                return {
                    "result": "failure",
                    "message": "User doesn't exists with this email"}
            if user.Status == "INACTIVE":
                return {"result": "failure", "message": "User is Inactive. Please conatct admin for more information"}

            return _change_password(user)

        except Exception as e:
            LOG.error('Unexpected error happened during \
                changing password: %s', e)
