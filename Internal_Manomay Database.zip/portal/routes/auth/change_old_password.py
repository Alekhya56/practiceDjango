from datetime import datetime

from flask import request
from flask_restx import Resource, reqparse
from werkzeug.exceptions import UnprocessableEntity

from ... import LOG
from ...encryption import Encryption
from ...models import db
from ...models.users import Users
from ..verify_token import login_required
from . import ns

parser = reqparse.RequestParser()
parser.add_argument('oldpassword', type=str, location='json', required=True)
parser.add_argument('newpassword', type=str, location='json', required=True)
parser.add_argument('employee_id', type=str, location='json', required=True)

@ns.route("/change_old_password")
class PasswordOldChange(Resource):
    """Updates old password with requested new password.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirect : url
                Redirects to login page.

    """
    @ns.doc(description='change_old_password',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    @login_required
    def post(self):
        try:
            # collecting data from request
            data = parser.parse_args(strict=False)
            old_pass = data["oldpassword"]
            new_pass = data["newpassword"]
            employee_id = data['employee_id']
            #  Filters the employee with email who is currently logged in.
            user = Users.query.filter_by(employee_id=employee_id).first()
            if user is None:
                raise UnprocessableEntity('Username is not valid')
            # Checks for if old password is correct or not.
            if user.Password != Encryption().encrypt(old_pass):
                return {"temp":"temppass","message":"Entered Old password is incorrect"}
            # Encrypts and updates new password
            new_password = Encryption().encrypt(new_pass)
            user.Password = new_password
            user.TemporaryPassword = False
            today = datetime.today().replace(microsecond=0)
            user.LastPasswordChanged = today.strftime('%Y-%m-%d %H:%M:%S')
            db.session.commit()
            return  {"result":"success","message":"Your password has been successfully reset"}
        except Exception as e:
            LOG.error(e)
