from datetime import datetime

from flask import request
from flask_login import current_user, login_required
from flask_restx import Resource, reqparse
from werkzeug.exceptions import UnprocessableEntity

from ... import LOG
from ...encryption import Encryption
from ...models import db
from ...models.users import Users
from . import ns

parser = reqparse.RequestParser()
parser.add_argument('otp', type=str, location='json', required=True)
parser.add_argument('email', type=str, location='json', required=True)

@ns.route("/verify_otp")
class VerifyOtp(Resource):
    """Updates old password with requested new password.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirect : url
                Redirects to login page.

    """
    @ns.doc(description='verify_otp',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    def post(self):
        try:
            # collecting data from request
            data = request.get_json()
            LOG.error(data)
            otp = data['otp']
            email = data['email']
            #  Filters the employee with email who is currently logged in.
            user = Users.query.filter_by(Email=email).first()
            if user is None:
                raise UnprocessableEntity('Username is not valid')
            # Checks for if otp is correct or not.
            if user.Otp != Encryption().encrypt(otp):
                return {"result":"error","message":"Entered Otp is incorrect"}
            else:
                return  {"result":"success",
                        "user_email":user.Email,
                        "user_id":user.employee_id}
        except Exception as e:
            LOG.error(e)
