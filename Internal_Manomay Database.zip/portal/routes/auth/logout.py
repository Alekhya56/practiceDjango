from flask_login import logout_user
from flask_restx import Resource
from werkzeug.exceptions import InternalServerError

from ... import LOG
from ..verify_token import login_required
from . import ns


@login_required
@ns.route("/logout")
class Logout(Resource):
    """Employee logs out and redirect to login page.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirects : html page
                Redirects to login page
    """

    @login_required
    def get(self):
        try:
            logout_user()
            return {"result":"success"}
        except Exception as e:
            LOG.error(e)
            raise InternalServerError()
