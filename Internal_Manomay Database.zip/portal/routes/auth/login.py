from datetime import datetime, timedelta

import jwt
from flask_login import login_user
from flask_restx import Resource, reqparse
from werkzeug.exceptions import InternalServerError

from ... import APP, LOG
from ...encryption import Encryption
from ...models.users import Users
from . import ns

parser = reqparse.RequestParser()
parser.add_argument('employee_id', type=str, location='json', required=True)
parser.add_argument('password',type=str,location='json', required=True)


@ns.route('/login')
class Login(Resource):

    """Only Active employees can login, employee
    redirect to respective pages based on their roles.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirects : html page
                Redirects respective page
    """
    @ns.doc(description='login',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    def post(self):
        try:
            # collecting data from request
            data = parser.parse_args(strict=False)
            employee_id = data['employee_id']
            password = data['password']
            remember = False
            encrypt_password = Encryption().encrypt(password)
            LOG.error(encrypt_password)

            # Checks given username and password correct or not.
            user = Users.query.filter_by(employee_id=employee_id,
                                         Password=encrypt_password).first()
            

            if user is None:
                LOG.debug("Auth failed. employee_id (%s) or \
                    Password is wrong", employee_id)
                return {"result":"failure","message":"Auth failed. employee_id or Password is wrong"}

            # Checks if user status Active or not.
            if (user.Status == "INACTIVE"):
                LOG.debug("Auth failed. User is Inactive. \
                            Username:%s, status:%s, role:%s"
                          % (user.UserName, user.Status, user.Role))
                return {"result":"failure","message":"Currently User is INACTIVE, \
                    Please Contact admin for more Information"}

            login_user(user, remember=remember)

            user_details = {}
            user_details['employee_id'] = user.employee_id
            user_details['UserName'] = user.UserName
            user_details['permissions'] = user.permissions
            user_details['temp_password'] = user.TemporaryPassword
            login_time = datetime.now()
            session_expiry = login_time + timedelta(hours=1, minutes=0, seconds=0)
            user_token = jwt.encode({"user_data": user_details, "iat": login_time, "exp": session_expiry},
                                        algorithm='HS256', key=APP.config['JWT_SECRET_KEY'])
            user_token = user_token.decode('utf-8')
            return {"result":"success","user_token":user_token,"data":user_details}

        except Exception as e:
            LOG.error('Exception happened during authenticating user: %s', e)
            raise InternalServerError(e)
