from datetime import date

from flask import request
from flask_login import current_user
from flask_restx import Resource, reqparse

from ... import LOG
from ...models import db
from ...models.employee import Employee
from ...models.users import Users
from ..verify_token import login_required
from . import ns
from .get_employees import get_employees

parser = reqparse.RequestParser()
parser.add_argument('employee_id', type=str, location='json', required=True)
parser.add_argument('updated_by', type=str, location='json', required=True)

@ns.route("/delete_employee")
class DeleteEmployee(Resource):
    """delete employees in the portal.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        lists all employees

    """
    @ns.doc(description='delete_employee',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    @login_required
    def post(self):
        try:
            today_date = date.today()
            data = request.get_json()
            
            emp_model = Employee.query.filter_by(employee_id=data['employee_id']).first()
            if emp_model:
                emp_model.employee_status="Inactive"
                emp_model.updated_by=data['updated_by']
            db.session.commit()
            user_model = Users.query.filter_by(employee_id=data['employee_id'])
            if user_model:
                user_model.employee_status="Inactive"
            db.session.commit()
            employees = get_employees()
            
           
            return {
                        "result": "success",
                        "internal_users": employees,
                        "count": len(employees)
                        }
        except Exception as e:
            LOG.error(e)
