from flask import jsonify
from flask_restx import Resource
from sqlalchemy import func

from ... import LOG
from ...models import db
from ...models.project_description import ProjectDescription
from ..verify_token import login_required
from . import ns


def get_project_details():

    """Get list of projects.

        Parameters:
        -----------
        Parms : None.

        Returns:
        -----------
        response : dict
                Project details.
    """
    """ Quering project details """

    sub_projects = db.session.query(func.max(ProjectDescription.id)).group_by(
        ProjectDescription.project_id).subquery()

    projects = db.session.query(ProjectDescription).filter( ProjectDescription.id.in_(sub_projects)).filter(ProjectDescription.active_project == True).all()
    response = []

    for project in projects:
        value=0
        if project.status=="InPrep&Planning":
            value=25
        elif project.status=="InImplementation":
            value=50
        elif project.status=="InMaintenance":
            value=75
        elif project.status=="Completed":
            value=100

        response.append({
            "project_id": project.Project.project_id,
            "project_name": project.Project.project_name,
            "phase": project.phase,
            "start_date": str(project.start_date),
            "end_date": str(project.end_date),
            "status":project.status,
            "project_value":value
        }
        )
    return response


@ns.route("/get_project_details")
class GetProjectDetails(Resource):

    """Gets all projects.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Internal_users : dict
                    Render admin.html template with project details

    """



    @ns.doc(description='get_project_details',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @login_required
    def get(self):
        try:
            response = get_project_details()
            return jsonify(response)
        except Exception as e:
            LOG.error(e)
