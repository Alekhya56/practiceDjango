from datetime import date

from flask import request
from flask_login import current_user, login_required
from flask_restx import Resource, reqparse
from sqlalchemy import func

from ... import LOG
from ...models import db
from ...models.project_description import ProjectDescription
from ..verify_token import login_required
from . import ns
from .get_project_details import get_project_details

parser = reqparse.RequestParser()
parser.add_argument('project_id', type=str, location='json', required=True)
parser.add_argument('updated_by', type=str, location='json', required=True)

@ns.route("/delete_project")
class DeleteProject(Resource):
    """delete project in the portal.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        lists all projects

    """
    @ns.doc(description='delete_project',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    @login_required
    def post(self):
        try:
            today_date = date.today()
            data = request.get_json()
            LOG.error
            sub_projects = db.session.query(func.max(ProjectDescription.id)).filter_by(project_id=data['project_id']).group_by(
            ProjectDescription.project_id).subquery()

            project_model = db.session.query(ProjectDescription).filter( ProjectDescription.id.in_(sub_projects)).filter(ProjectDescription.active_project == True).all()
            
            

            project_model= project_model[0]
            LOG.error(project_model)
            project = ProjectDescription(
                    project_id = project_model.project_id ,
                    phase = project_model.phase ,
                    scope = project_model.scope ,
                    status = project_model.status ,
                    docs_repo = project_model.docs_repo ,
                    project_description = project_model.project_description ,
                    start_date = project_model.start_date ,
                    end_date = project_model.end_date,
                    deviations=project_model.deviations ,
                    reason_for_deviation = project_model.reason_for_deviation ,
                    est_need_for_team = project_model.est_need_for_team ,
                    updated_date = today_date,
                    updated_by = data['updated_by'],
                    project_manager = project_model.project_manager ,
                    sub_status = project_model.sub_status,
                    project_type=project_model.project_type,
                    revised_project_end_date=project_model.revised_project_end_date,
                    type_of_support_contract=project_model.type_of_support_contract,
                    support_start_date=project_model.support_start_date,
                    active_project = False
                    )

            
            db.session.add(project)
            db.session.commit()
                #  Adds and commits Project details
            LOG.error(project_model.active_project)
            LOG.error(project_model)
            
            projects = get_project_details()
            LOG.error(projects)
            return {
                            "result": "success",
                            "internal_users": projects,
                            "count": len(projects)
                            }
        except Exception as e:
            LOG.error(e)
