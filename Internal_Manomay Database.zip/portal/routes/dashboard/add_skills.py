from datetime import date

from flask import request
from flask_login import current_user
from flask_restx import Resource, reqparse

from ... import LOG
from ...models import db
from ...models.skills import Skills
from ..verify_token import login_required
from . import ns
from .get_skills import get_skills

parser = reqparse.RequestParser()
parser.add_argument('skill_name', type=str, location='json', required=True)
parser.add_argument('skill_description',type=str,location='json', required=True)

@ns.route("/add_skills")
class AddSkills(Resource):
    """Add skills.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        lists all skills

    """
    @ns.doc(description='add_skills',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    @login_required
    def post(self):
        try:
            data = parser.parse_args(strict=False)
            skill = Skills.query.filter_by(skill_name=data['skill_name']).first()
            if skill:
                return {"result":"error","message":"skill already added"}

            data_model = Skills(
                skill_name = data['skill_name'],
                skill_description = data['skill_description'],

            )
            #  Adds and commits Project details
            db.session.add(data_model)
            db.session.commit()
            skills = get_skills()
            return {"result": "success",
                    "skills":skills,
                    "count":len(skills)}
        except Exception as e:
            LOG.error(e)
