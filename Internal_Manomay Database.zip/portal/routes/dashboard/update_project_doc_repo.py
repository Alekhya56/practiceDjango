from datetime import date

from flask_restx import Resource, reqparse
from sqlalchemy import func

from ... import LOG
from ...models import db
from ...models.project_description import ProjectDescription
from ..verify_token import login_required
from . import ns
from .get_project_details import get_project_details

parser = reqparse.RequestParser()
parser.add_argument('project_id', type=str, location='json', required=True)
parser.add_argument('docs_repo',type=str,location='json', required=True)

@ns.route("/update_project_docs_repo")
class UpdateProjectDocRepo(Resource):
    """Add projects in the portal.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirect : url
                Redirects.

    """
    @ns.doc(description='update_project_docs_repo',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)

    @login_required
    def post(self):
        try:
            today_date = date.today()
            data = parser.parse_args(strict=False)
            sub_projects = db.session.query(func.max(ProjectDescription.id)).filter_by(project_id=data['project_id']).group_by(
                        ProjectDescription.project_id).subquery()

            project = db.session.query(ProjectDescription).filter(ProjectDescription.id.in_(sub_projects)).all()
            project = project[0]
            project_model = ProjectDescription(
                project_id = data['project_id'],
                phase = project.phase,
                scope = project.scope ,
                status = project.status ,
                docs_repo = data['docs_repo'],
                project_description = project.project_description ,
                start_date = project.start_date ,
                end_date = project.end_date ,
                reason_for_deviation = project.reason_for_deviation ,
                est_need_for_team = project.est_need_for_team ,
                updated_date = today_date,
                project_manager = project.project_manager ,
                sub_status = project.sub_status,
                active_project = True
                )
            #  Adds and commits Project details
            db.session.add(project_model)
            db.session.commit()
            projects = get_project_details()
            return {
                        "result": "success",
                        "internal_users": projects,
                        "count": len(projects)
                        }
        except Exception as e:
            LOG.error(e)
