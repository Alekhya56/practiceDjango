from cgitb import text
from datetime import date, datetime
from distutils.log import Log
from typing import Text

from flask import request
from flask_login import current_user
from flask_restx import Resource, reqparse

from ... import LOG
from ...models import db
from ...models.project import Project
from ...models.project_description import ProjectDescription
from ..verify_token import login_required
from . import ns
from .get_project_details import get_project_details

parser = reqparse.RequestParser()
parser.add_argument('customer_name', type=str, location='json', required=True)
parser.add_argument('project_id', type=str, location='json', required=True)
parser.add_argument('phase',type=str,location='json', required=True)
parser.add_argument('scope',type=str,location='json', required=True)
parser.add_argument('status',type=str,location='json', required=True)
parser.add_argument('docs_repo',type=str,location='json', required=True)
parser.add_argument('project_description',type=str,location='json', required=True)
parser.add_argument('reason_for_deviation',type=str,location='json', required=False)
parser.add_argument('project_manager',type=str,location='json', required=True)
parser.add_argument('sub_status',type=str,location='json', required=False)
parser.add_argument('start_date',type=date,location='json', required=True)
parser.add_argument('end_date',type=date,location='json', required=True)
parser.add_argument('deviations',type=str,location='json', required=True)
parser.add_argument('project_type',type=str,location='json', required=True)
parser.add_argument('type_of_support_contract',type=str,location='json', required=True)
parser.add_argument('est_need_for_team',type=int,location='json', required=True)

@ns.route("/add_project",methods=["POST"])
class AddProject(Resource):
    """Add projects in the portal.

    """

    @ns.doc(description='add_project',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)

    @login_required
    def post(self):

        try:
            today_date = datetime.today()
            data = request.get_json()
            project = Project.query.filter_by(project_id=data['project_id']).first()
            if project:
                return {"result":"error","message":"Project already exists"}
              
            data_model = Project(
                customer_name = data['customer_name'],
                project_id = data['project_id'],
                project_name = data['project_name'],
                updated_by = data['updated_by'],
                updated_date = datetime.today(),
                created_on = datetime.today()
            )

            LOG.warning("project table before comitting")
            
            project_model = ProjectDescription(
                project_id = data['project_id'],
                phase = data['phase'],
                scope = data['scope'],
                status = data['status'],
                docs_repo = data['docs_repo'],
                project_description = data['project_description'],
                start_date = data['start_date'],
                end_date = data['end_date'],
                deviations=data['deviations'],
                reason_for_deviation = data['reason_for_deviation'],
                est_need_for_team = data['est_need_for_team'],
                updated_date = today_date,
                created_on = today_date,
                project_manager = data['project_manager'],
                sub_status = data['sub_status'],
                project_type=data['project_type'],
                type_of_support_contract=data['type_of_support_contract'],
                active_project = True
                )
            LOG.warning("Project table after commiting")
            #  Adds and commits Project details
            db.session.add(data_model)
            db.session.add(project_model)
            db.session.commit()
            projects = get_project_details()
            print(projects)
            return {
                        "result": "success",
                        "internal_users": projects,
                        "count": len(projects)
                        }
        except Exception as e:
            LOG.error(e)
