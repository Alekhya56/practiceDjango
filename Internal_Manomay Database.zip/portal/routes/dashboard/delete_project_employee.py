from datetime import date

from flask import request
from flask_login import current_user
from flask_restx import Resource, reqparse
from sqlalchemy import func
from flask import jsonify
from ... import LOG
from ...models import db
from ...models.project_employee_mapping import ProjectEmployeeMapping
from ..verify_token import login_required
from . import ns
from .get_employee_project_description import get_employee_project_description

parser = reqparse.RequestParser()
parser.add_argument('project_id', type=str, location='json', required=True)
parser.add_argument('employee_id', type=str, location='json', required=True)
parser.add_argument('updated_by', type=str, location='json', required=True)

@ns.route("/delete_project_employee")
class DeleteProjectEmployee(Resource):
    """Add projects in the portal.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirect : url
                Redirects.

    """
    @ns.doc(description='delete_project_employee',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    @login_required
    def post(self):
        try:
            data = request.get_json()
            LOG.error("getting data from frontned",data)
            sub_projects = db.session.query(func.max(ProjectEmployeeMapping.id)).filter_by(project_id=data['project_id'] ).group_by(
            ProjectEmployeeMapping.project_id).subquery()
            LOG.error("sub projects",sub_projects)
            projects = db.session.query(ProjectEmployeeMapping).filter(ProjectEmployeeMapping.id.in_(sub_projects)).all()
            LOG.error("projects",projects)
            today_date = date.today()
            LOG.error("before updating project")
            for project in projects:
                data_model = ProjectEmployeeMapping(
                project_id = data['project_id'],
                updated_date=today_date,
                employee_id = data['employee_id'],
                role = project.role,
                status_of_work = project.status_of_work,
                updated_by = data['updated_by'],
                phase = project.phase,
                est_work = project.est_work,
                release_date = today_date,
                expected_hours_per_day = project.expected_hours_per_day,
                created_on= today_date,
                work_type=project.work_type,
                billable=project.billable,
                project_employee_status='INACTIVE')
            #  Adds and commits project detailsa
            LOG.error(data_model)
            db.session.add(data_model)
            LOG.error(data_model)
            db.session.commit()
            LOG.error("commited")
            LOG.error(data['project_id'])
            projects = get_employee_project_description(data['project_id'])
            LOG.error(projects)
            LOG.error("getting projects from project description")
            response={

                "result":"success",
                "internal_users": projects,
                "count": len(projects),
                
            
            }
            return jsonify(response)
        except Exception as e:
            LOG.error(e)
