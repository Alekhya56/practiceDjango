from flask import jsonify
from flask_restx import Resource

from ... import LOG
from ...models.employee_departments import EmployeeDepartments
from ..verify_token import login_required
from . import ns


def get_employee_departments():

    """Get list of active employees.

        Returns:
        -----------
        response : dict
                Employee details with active status.
    """

    departments = EmployeeDepartments.query.filter(EmployeeDepartments.status!="Inactive").all()
    response = []
    
    for department in departments:
   
             response.append({
            "department": department.department,
            "cluster_lead":department.cluster_lead

        })
             
    return response


@ns.route("/get_employee_departments")
class GetEmployees(Resource):

    """Gets active employees and render template with same

        Required:
        -----------
        login with admin creds
    """

    @ns.doc(description='get_employee_departments',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})

    @login_required
    def get(self):
        try:
            response = get_employee_departments()
            return jsonify(response)
        except Exception as e:
            LOG.error(e)
