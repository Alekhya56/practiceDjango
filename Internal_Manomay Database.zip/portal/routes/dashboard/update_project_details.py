from cgitb import text
from datetime import date
from typing import Text

from flask import request
from flask_login import current_user
from flask_restx import Resource, reqparse

from ... import LOG
from ...models import db
from ...models.project import Project
from ...models.project_description import ProjectDescription
from ..verify_token import login_required
from . import ns
from .get_project_details import get_project_details

parser = reqparse.RequestParser()
parser.add_argument('customer_name', type=str, location='json', required=True)
parser.add_argument('project_id', type=str, location='json', required=True)
parser.add_argument('phase',type=str,location='json', required=True)
parser.add_argument('scope',type=str,location='json', required=True)
parser.add_argument('status',type=str,location='json', required=True)
parser.add_argument('docs_repo',type=str,location='json', required=True)
parser.add_argument('project_description',type=str,location='json', required=True)
parser.add_argument('reason_for_deviation',type=str,location='json', required=True)
parser.add_argument('project_manager',type=str,location='json', required=True)
parser.add_argument('sub_status',type=str,location='json', required=True)
parser.add_argument('start_date',type=date,location='json', required=True)
parser.add_argument('end_date',type=date,location='json', required=True)
parser.add_argument('deviations',type=str,location='json', required=True)
parser.add_argument('est_need_for_team',type=int,location='json', required=True)
parser.add_argument('project_type',type=str,location='json', required=True)
parser.add_argument('revised_project_end_date',type=date,location='json', required=True)
parser.add_argument('type_of_support_contract',type=str,location='json', required=True)
parser.add_argument('support_start_date',type=date,location='json', required=True)


@ns.route("/update_project_details")
class UpdateProjectDetails(Resource):
    """update project description.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        lists all projects

    """
    @ns.doc(description='update_project_details',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)

    @login_required
    def post(self):
        try:
            LOG.info("updated project details")
            today_date = date.today()
            data = request.get_json()
            LOG.info(data)
            LOG.error(data)
            project_model = ProjectDescription(
                project_id = data['project_id'],
                phase = data['phase'],
                scope = data['scope'],
                status = data['status'],
                docs_repo = data['docs_repo'],
                project_description = data['project_description'],
                start_date = data['start_date'],
                end_date = data['end_date'],
                deviations=data['deviations'],
                reason_for_deviation = data['reason_for_deviation'],
                est_need_for_team = data['est_need_for_team'],
                updated_date = today_date,
                project_manager = data['project_manager'],
                sub_status = data['sub_status'],
                project_type=data["project_type"],
                revised_project_end_date=data["revised_project_end_date"],
                type_of_support_contract=data["type_of_support_contract"],
                support_start_date=data["support_start_date"],
                active_project = True
                )
            #  Adds and commits Project details

            db.session.add(project_model)
            db.session.commit()
            projects = get_project_details()
            return {
                        "result": "success",
                        "internal_users": projects,
                        "count": len(projects)
                        }
        except Exception as e:
            LOG.error(e)
