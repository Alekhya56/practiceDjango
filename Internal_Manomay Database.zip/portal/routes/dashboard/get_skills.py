from flask import jsonify
from flask_restx import Resource

from ... import LOG
from ...models.skills import Skills
from ..verify_token import login_required
from . import ns


def get_skills():

    """Get list of active and inactive employee skills.

        Parameters:
        -----------
        Parms : None.

        Returns:
        -----------
        response : dict
                Employee skills of active and inactive status.
    """
    """ quering employee which don't have status of
    delete' and excluding current logged in user """
    skills = Skills.query.all()
    
    response = []
    for skill in skills:
        response.append({
            "skill_id": skill.skill_id,
            "skill_name": skill.skill_name,
            "skill_description": skill.skill_description
        })
    return response


@ns.route("/get_skills")
class GetSkills(Resource):

    """Gets active and inactive employees and render template with same

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Internal_users : dict
                    Render admin.html template with employee details

    """

    @ns.doc(description='get_skills',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @login_required
    def get(self):
        try:
            response = get_skills()
            return jsonify(response)
        except Exception as e:
            LOG.error(e)
