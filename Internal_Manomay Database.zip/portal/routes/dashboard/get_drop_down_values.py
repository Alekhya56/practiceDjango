from flask import jsonify
from flask_restx import Resource

from ... import LOG
from ..verify_token import login_required
from . import ns


def get_drop_down_values():

    """Get list of active employees.

        Returns:
        -----------
        response : dict
                Employee details with active status.
    """

    work_status=[
                {"key":"InPrep&Planning","value":"InPrep&Planning"},
        {"key":"InImplementation","value":"InImplementation"},
        {"key":"InMaintenance","value":"InMaintenance"},
        {"key":"Completed","value":"Completed"}
    ]

    work_type=[
        
            {"key":"Full-Time","value":"Full-Time"},
            {"key":"Part-Time","value":"Part-Time"}

       
    ]

    project_type=[
            {"key":"Consulting","value":"Consulting"},
            {"key":"TechSolutionDev","value":"TechSolutionDev"},
            {"key":"Data","value":"Data"}

    ]

    status_of_work=[ 
        {"key":"Completed","value":"Completed"},
        {"key":"In Progress","value":"In Progress"},
        {"key":"Not Yet Started","value":"Not Yet Started"}
    ]

    cluster_lead=[ 
        {"key":"Business Analysis","value":"Abhishek Dullur"},
        {"key":"Quality Assurance","value":"Krithika Ramesh Kumar"},
        {"key":"Development","value":"N Sai Prakash Dayal"},
        {"key":"HR/Admin","value":"Kriti Badal Kaul"},
        {"key":"Project Manager","value":"Krishna Kumari Datla"},
        {"key":"Business Development","value":"Krishna Kumari Datla"},
        {"key":"Data","value":"Amudala Praneeth"},
        {"key":"AI/ML","value":"Amudala Praneeth"}
    ]
    return {"work_status":work_status,"work_type": work_type,"project_type":project_type,"status_of_work":status_of_work}



@ns.route("/get_drop_down_values")
class GetDropDownValues(Resource):

    """Gets active employees and render template with same

        Required:
        -----------
        login with admin creds
    """

    @ns.doc(description='get_employees_and_project_managers',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})

    @login_required
    def get(self):
        try:
        
            response = get_drop_down_values()
            return jsonify(response)
        except Exception as e:
            LOG.error(e)
