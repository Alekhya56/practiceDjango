from datetime import date

from flask import jsonify, request
from flask_login import current_user
from flask_restx import Resource, reqparse

from ... import LOG
from ...models import db
from ...models.project_employee_mapping import ProjectEmployeeMapping
from ..verify_token import login_required
from . import ns
from .get_employee_project_description import get_employee_project_description

parser = reqparse.RequestParser()
parser.add_argument('project_id', type=str, location='json', required=True)
parser.add_argument('employee_id',type=str,location='json', required=True)
parser.add_argument('role',type=str,location='json', required=True)
parser.add_argument('updated_by',type=str,location='json', required=True)
parser.add_argument('status_of_work',type=str,location='json', required=True)
parser.add_argument('start_date',type=date,location='json', required=True)
parser.add_argument('phase',type=str,location='json', required=True)
parser.add_argument('est_work',type=str,location='json', required=True)
parser.add_argument('release_date',type=date,location='json', required=True)
parser.add_argument('expected_hours_per_day',type=str,location='json', required=True)
parser.add_argument('billable',type=str,location='json', required=True)
parser.add_argument('work_type',type=str,location='json', required=True)

@ns.route("/add_or_update_employee_to_project")
class AddOrUpdateEmployeeToProject(Resource):
    """Assign employees to projects in the portal.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        all employees who are assigned to the project.

    """
    @login_required
    def post(self):
        try:
            
            data = request.get_json()
            
            employees = ProjectEmployeeMapping.query.filter_by(project_id=data["project_id"],employee_id=data["employee_id"]).first()
           
            if employees:
                return {"result":"error","message":"Employee already exists in the Project"}
            
            today_date = date.today()
           
            data_model = ProjectEmployeeMapping(
            project_id = data['project_id'],
            employee_id = data['employee_id'],
            role = data['role'],
            start_date = data['start_date'],
            updated_by = data['updated_by'],
            updated_date =  today_date,
            status_of_work=data['status_of_work'],
            phase = data["phase"],
            est_work = data["est_work"],
            release_date = data['release_date'],
            project_employee_status = 'ACTIVE',
            expected_hours_per_day = data['expected_hours_per_day'],
            billable= data['billable'],
            work_type=data['work_type']
                )
            #  Adds and commits project details
            db.session.add(data_model)
            db.session.commit()
            LOG.error("Committed")
            projects = get_employee_project_description(data['project_id'])
            
        
            response={

                "result":"success",
                "internal_users": projects,
                "count": len(projects),
                
            
            }
            LOG.error(projects)
            LOG.error(response)
            return jsonify(response)
                       
                        
            
        except Exception as e:
            LOG.error(e)
