from datetime import date

from flask import jsonify, request
from flask_login import current_user, login_required
from flask_restx import Resource, reqparse
from portal.models.project import Project
from portal.models.project_description import ProjectDescription
from portal.models.project_employee_mapping import ProjectEmployeeMapping
from sqlalchemy import func

from ... import LOG
from ...models import db
from ...models.employee import Employee
from ...models.employee_skills import EmployeeSkills
from ...models.project import Project
from ..verify_token import login_required
from . import ns

parser = reqparse.RequestParser()
parser.add_argument('employee_id', type=str, location='json', required=True)

def get_employee_project_skills(employee_id):
    """Get list of active employees and projects assigned and their skills.
    """
    employees = Employee.query.filter_by(employee_id=employee_id).all()
    max_id = db.session.query(func.max(ProjectEmployeeMapping.id)).filter_by(employee_id=employee_id).group_by(
        ProjectEmployeeMapping.project_id, ProjectEmployeeMapping.employee_id).subquery()
    projects = db.session.query(ProjectEmployeeMapping).filter(ProjectEmployeeMapping.id.in_(max_id) & (ProjectEmployeeMapping.project_employee_status !="INACTIVE")).all()
  

    skills = EmployeeSkills.query.filter_by(employee_id=employee_id).all()
    detail=[]
    for employee_detail in employees:
        detail.append({
            "employee_id":employee_detail.employee_id,
            "employee_designation": employee_detail.employee_designation
        })

    employee_list = []
    for employee in employees:
        project_manager=''
        if employee.employee_permissions == "Employee":
            project_manager="NO"
        else:
            project_manager="YES"
        def months(d1, d2):
            current_exp = d1.month - d2.month + 12*(d1.year - d2.year)
            # expecting 'employee_previous_experience' in months
            total_exp = employee.employee_previous_experience + current_exp
            return total_exp/12
        employee_list.append({
            "employee_dept": employee.employee_dept,
            "employee_designation": employee.employee_designation,
            "employee_email": employee.employee_email,
            "employee_dob":employee.employee_dob,
            "employee_doj":employee.employee_doj,
            "employee_contact_number":employee.employee_contact_number,
            "employee_previous_experience": employee.employee_previous_experience,
            "employee_total_experience": months(employee.employee_doj,date.today()),
            "reporting_manager": employee.reporting_manager,
            "project_manager_access":project_manager,
            "cluster_lead_access":employee.cluster_lead_access,
            "cluster_lead":employee.cluster_lead_value
        })
        LOG.error(employee_list)

    project_list = []
    for project in projects:
        project_list.append({
            "project_id":project.Project.project_id,
            "project_name": project.Project.project_name,
            "phase":project.phase,
            "role":project.role,
            "status_of_work":project.status_of_work
        })
    LOG.error(project_list)
    skill_list = []
    for skill in skills:
        skill_list.append({
            "skill_id":skill.Skills.skill_id,
            "skill_name":skill.Skills.skill_name,
            "skill_description":skill.Skills.skill_description,
            "skill_level":skill.skill_level
        })
    LOG.error({"detail":detail,"employee_list":employee_list,"project_list":project_list,"skill_list":skill_list})
    return {"detail":detail,"employee_list":employee_list,"project_list":project_list,"skill_list":skill_list}
 
@ns.route("/get_employee_project_skills")
class GetEmployeeProjectSkills(Resource):
    """Gets active and inactive employees and render template with same
        Required:
        -----------
        login with admin creds
        returns:
        -----------
        Internal_users : dict
                    Render admin.html template with employee details
    """
    @ns.doc(description='get_employee_project_skills',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    @login_required
    def post(self):
        try:
            data = parser.parse_args(strict=False)
            response = get_employee_project_skills(data['employee_id'])
            return jsonify(response)
        except Exception as e:
            LOG.error(e)

