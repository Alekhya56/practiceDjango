from flask import jsonify
from flask_restx import Resource

from ... import LOG
from ...models.employee_designations import EmployeeDesignations
from ..verify_token import login_required
from . import ns


def get_employee_designations():

    """Get list of active employees.

        Returns:
        -----------
        response : dict
                Employee details with active status.
    """

    designations = EmployeeDesignations.query.filter(EmployeeDesignations.status!="Inactive").all()
    response = []
    
    for designation in designations:
   
             response.append({
            "designation": designation.designation
            
        })
             
    return response


@ns.route("/get_employee_designations")
class GetEmployees(Resource):

    """Gets active employees and render template with same

        Required:
        -----------
        login with admin creds
    """

    @ns.doc(description='get_employee_designations',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})

    @login_required
    def get(self):
        try:
            response = get_employee_designations()
            return jsonify(response)
        except Exception as e:
            LOG.error(e)
