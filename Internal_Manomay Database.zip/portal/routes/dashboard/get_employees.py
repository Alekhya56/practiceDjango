from flask import jsonify
from flask_restx import Resource

from ... import LOG
from ...models.employee import Employee
from ..verify_token import login_required
from . import ns


def get_employees():

    """Get list of active employees.

        Returns:
        -----------
        response : dict
                Employee details with active status.
    """

    employees = Employee.query.filter(Employee.employee_status!="Inactive").all()
    response = []
    i=0;
    for employee in employees:
            response.append({
            "employee_id": employee.employee_id,
            "employee_name": employee.employee_name,
            "employee_dept": employee.employee_dept,
            "employee_designation": employee.employee_designation,
            "employee_email": employee.employee_email,
            "employee_status": employee.employee_status,
        })
             
    return response


@ns.route("/get_employees")
class GetEmployees(Resource):

    """Gets active employees and render template with same

        Required:
        -----------
        login with admin creds
    """

    @ns.doc(description='get_employees',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})

    @login_required
    def get(self):
        try:
            response = get_employees()
            return {"employee_names":response}
        except Exception as e:
            LOG.error(e)
