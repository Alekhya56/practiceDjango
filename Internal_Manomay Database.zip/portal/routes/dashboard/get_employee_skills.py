from flask import jsonify
from flask_restx import Resource, reqparse

from ... import LOG
from ...models.employee_skills import EmployeeSkills
from ..verify_token import login_required
from . import ns

parser = reqparse.RequestParser()
parser.add_argument('employee_id', type=str, location='json', required=True)

def get_employee_skills():

    """Get list of active employee skills.

        Parameters:
        -----------
        Parms : None.

        Returns:
        -----------
        response : dict
                Employee skills.
    """

    data = parser.parse_args(strict=False)

    employee_skills = EmployeeSkills.query.filter_by(employee_id=data['employee_id']).all()
    employee_skills_list = []
    for employee_skill in employee_skills:
        employee_skills_list.append({
            "employee_skill_name":employee_skill.Skills.skill_name,
            "employee_skill_description":employee_skill.Skills.skill_description,
            "employee_skill_level":employee_skill.skill_level
        })
    return employee_skills_list


@ns.route("/get_employee_skills")
class GetSkills(Resource):

    @ns.doc(description='get_employee_skills',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    @login_required
    def get(self):
        try:
            response = get_employee_skills()
            return jsonify(response)
        except Exception as e:
            LOG.error(e)
