from flask import jsonify, request
from flask_login import current_user, login_required
from flask_restx import Resource, reqparse
from portal.models.project import Project
from sqlalchemy import func

from ... import LOG
from ...models import db
from ...models.project_description import ProjectDescription
from ...models.project_employee_mapping import ProjectEmployeeMapping
from ..verify_token import login_required
from . import ns

parser = reqparse.RequestParser()
parser.add_argument('project_id', type=str, location='json', required=True)

def get_employee_project_description(project_id):

    """Get list of active employees and project details.

        Parameters:
        -----------
        Parms : project_id

        Returns:
        -----------
        response : dict
                project and team details with active.
    """

    project_details=db.session.query(Project).filter_by(project_id=project_id).all()
    LOG.error("called project description function")
    project_ids = db.session.query(func.max(ProjectDescription.id)).filter_by(project_id=project_id).group_by(
        ProjectDescription.project_id).subquery()
    LOG.error(project_ids)
    projects = db.session.query(ProjectDescription).filter(ProjectDescription.id.in_(project_ids)).all()
    LOG.error(projects)
    employee_id = db.session.query(func.max(ProjectEmployeeMapping.id)).filter(ProjectEmployeeMapping.project_id==project_id ).group_by(
        ProjectEmployeeMapping.project_id, ProjectEmployeeMapping.employee_id).subquery()
    LOG.error(employee_id)
    employees = db.session.query(ProjectEmployeeMapping).filter((ProjectEmployeeMapping.id.in_(employee_id)) & (ProjectEmployeeMapping.project_employee_status !="INACTIVE")).all()
    LOG.error(employees)
    description = []
    detail=[]
    for project_detail in project_details:
        detail={
            "project_id":project_detail.project_id,
            "project_description":project_detail.project_name,
            "customer_name":project_detail.customer_name
        }
    for project in projects:
        description={
            
            "project_manager":project.project_manager,
            "phase": project.phase,
            "scope": project.scope,
            "status": project.status,
            "sub_status": project.sub_status,
            "start_date": str(project.start_date),
            "end_date": str(project.end_date),
            "deviations": project.deviations,
            "reason_for_deviation": project.reason_for_deviation,
            "est_need_for_team": project.est_need_for_team,
            "docs_repo": project.docs_repo,
            "project_type":project.project_type,
            "revised_project_end_date":project.revised_project_end_date,
            "type_of_support_contract":project.type_of_support_contract,
            "support_start_date":project.support_start_date
        }
        LOG.error(description)
    
    employee_list=[]
    for employee in employees:
            employee_list.append({
                "employee_id": employee.Employee.employee_id,
                "employee_name": employee.Employee.employee_name,
                "role":employee.role,
                "updated_by":employee.updated_by,
                "work_type":employee.work_type,
                "status_of_work":employee.status_of_work,
                "start_date":str(employee.start_date),
                "release_date": str(employee.release_date),
                "phase":employee.phase,
                "est_work":employee.est_work,
                "billable":employee.billable,
                "expected_hours_per_day":employee.expected_hours_per_day
            })
    LOG.warning(employee_list)
    LOG.error("get employee project desctiption")
    LOG.error({"detail":detail,"description": description,"docs_repo":description['docs_repo'], "Project_Team": employee_list})
    return ({"detail":detail,"description": description,"docs_repo":description['docs_repo'], "Project_Team": employee_list})
@ns.route("/get_employee_project_description")
class GetEmployeeProjectDescription(Resource):

    """Gets active and inactive employees and render template with same

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Internal_users : dict
                    Render admin.html template with employee details

    """
    @ns.doc(description='get_employee_project_description',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)

    #@login_required '''
    def post(self):
        try:
            data = request.get_json()
            response = get_employee_project_description(data['project_id'])
            return jsonify(response)
        except Exception as e:
            LOG.error(e)
