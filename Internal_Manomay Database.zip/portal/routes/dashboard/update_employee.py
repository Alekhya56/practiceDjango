from datetime import date
from traceback import print_tb

from flask import request
from flask_login import current_user
from flask_restx import Resource, reqparse

from ... import LOG
from ...models import db
from ...models.employee import Employee
from ...models.users import Users
from ..verify_token import login_required
from . import ns
from .get_employees import get_employees

parser = reqparse.RequestParser()
parser.add_argument('employee_id', type=str, location='json', required=True)
parser.add_argument('employee_dept',type=str,location='json', required=True)
parser.add_argument('employee_dob',type=date,location='json', required=True)
parser.add_argument('employee_doj',type=date,location='json', required=True)
parser.add_argument('employee_email',type=str,location='json', required=True)
parser.add_argument('employee_dept',type=str,location='json', required=False)
parser.add_argument('employee_contact_number',type=str,location='json', required=True)
parser.add_argument('employee_designation',type=str,location='json', required=True)
parser.add_argument('reporting_manager',type=str,location='json', required=True)
parser.add_argument('project_manager_access',type=str,location='json', required=True)
parser.add_argument('updated_by',type=str,location='json', required=True)
parser.add_argument('cluster_lead',type=str,location='json', required=True)

@ns.route("/update_employees")
class UpdateEmployee(Resource):
    """Add projects in the portal.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirect : url
                Redirects.

    """
    @ns.doc(description='update_employees',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)

    @login_required
    def post(self):
        try:
            data = request.get_json()
            LOG.warning(data)
            LOG.error(data['project_manager_access'])
            employee = Employee.query.filter_by(employee_id=data['employee_id']).first()
            if employee:
                employee.employee_dept = data["employee_dept"]
                employee.updated_by =  data['updated_by']
                employee.update_date =  date.today()
                employee.employee_dob = data["employee_dob"]
                employee.employee_doj = data["employee_doj"]
                employee.employee_email = data["employee_email"]
                employee.employee_contact_number = data['employee_contact_number']
                employee.employee_designation = data['employee_designation']
                employee.cluster_lead_value=data['cluster_lead']
                employee.employee_previous_experience= data['employee_previous_experience']
                employee.reporting_manager= data['reporting_manager']
                

                employee.employee_permissions = 'Project Manager' if data["project_manager_access"] else 'Employee'
            user = Users.query.filter_by(employee_id=data['employee_id']).first()
            if user:
                user.employee_permissions = 'Project Manager' if data["project_manager_access"] else 'Employee'
            #  commits employee details
            LOG.warning(employee)
            db.session.commit()
            projects = get_employees()
            LOG.warning(projects)
            return {
                        "result": "success",
                        "internal_users": projects,
                        "count": len(projects)
                        }
        except Exception as e:
            LOG.error(e)
