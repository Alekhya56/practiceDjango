from datetime import date

from flask import request
from flask_login import current_user, login_required
from flask_restx import Resource, reqparse

from ... import LOG
from ...models import db
from ...models.employee_skills import EmployeeSkills
from ..verify_token import login_required
from . import ns
from .get_employee_skills import get_employee_skills

parser = reqparse.RequestParser()
parser.add_argument('employee_id', type= str, location='json', required=True)
parser.add_argument('skill_id',type=int,location='json', required=True)

@ns.route("/delete_employee_skill")
class DeleteEmployeeSkills(Resource):
    """Delete skills of the employee.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        list of skills.

    """
    @ns.doc(description='delete_employee_skill',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)
    @login_required
    def post(self):
        try:
            data = request.get_json()
            LOG.error(data)
            data_model = EmployeeSkills.query.filter_by(employee_id = data['employee_id'],skill_id = data['skill_id']).delete()
            LOG.error(data_model)
            db.session.commit()
            skills = get_employee_skills()
            return {"result": "success",
                    "skills":skills,
                    "count":len(skills)}
        except Exception as e:
            LOG.error(e)
