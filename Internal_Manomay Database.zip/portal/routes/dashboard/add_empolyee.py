from datetime import date

from flask import request
from flask_login import current_user
from flask_restx import Resource, reqparse
from werkzeug.exceptions import UnprocessableEntity

from ... import APP, LOG
from ...encryption import Encryption
from ...helpers import random_string_with_digits_and_symbols, send_email
from ...models import db
from ...models.employee import Employee
from ...models.users import Users
from ..verify_token import login_required
from . import ns
from .get_employees import get_employees

parser = reqparse.RequestParser()
parser.add_argument('employee_id', type=str, location='json', required=True)
parser.add_argument('employee_name',type=str,location='json', required=True)
parser.add_argument('employee_dept',type=str,location='json', required=True)
parser.add_argument('employee_previous_experience',type=int,location='json', required=True)
parser.add_argument('employee_email',type=str,location='json', required=True)
parser.add_argument('updated_by',type=str,location='json', required=True)
parser.add_argument('employee_designation',type=str,location='json', required=True)
parser.add_argument('employee_contact_number',type=str,location='json', required=True)
parser.add_argument('employee_dob',type=date,location='json', required=True)
parser.add_argument('employee_doj',type=date,location='json', required=True)
parser.add_argument('reporting_manager',type=str,location='json', required=True)
parser.add_argument('project_manager',type=str,location='json', required=False)
parser.add_argument('cluster_lead',type=str,location='json', required=True)

@ns.route("/add_employee")
class AddEmployee(Resource):
    """Add employees in the portal.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Redirect : list of employees

    """

    @ns.doc(description='add_employee',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @ns.expect(parser, validate=True)

    @login_required
    def post(self):
        try:
            today_date = date.today()
            data = request.get_json()
            employee = Employee.query.filter_by(employee_id=data['employee_id']).first()
            if employee:
                return {"result":"error","message":"Employee ID/Email/Contact Number already exists"}
            emp_model = Employee(
            employee_id = data["employee_id"],
            employee_name = data["employee_name"],
            employee_dept = data["employee_dept"],
            updated_by = data['updated_by'],
            updated_date =  today_date,
            created_on = today_date,
            employee_dob = data["employee_dob"],
            employee_status="Active",
            employee_doj = data["employee_doj"],
            employee_previous_experience = data["employee_previous_experience"],
            employee_email = data["employee_email"],
            employee_designation = data["employee_designation"],
            employee_contact_number = data["employee_contact_number"],
            reporting_manager = data['reporting_manager'],
            employee_permissions = 'Project Manager' if data["project_manager"] else 'Employee',
            cluster_lead_value=data['cluster_lead'])
            permissions=''
            if data['employee_designation'] == 'CEO / MD' or (data["project_manager"] and data['employee_designation'] =='CEO / MD'):
                  permissions='CEOLEVEL'
            elif data['project_manager']:
                permissions='PMLEVEL'

            elif (data['project_manager'] and (data['employee_designation'] =='HR Manager' or data['employee_designation'] =='HR Executive' )) or (data['employee_designation'] =='HR Manager' or data['employee_designation'] =='HR Executive' ):
                permissions="HRLEVEL"
            else:
                permissions="EMPLOYEELEVEL" 
            user_model = Users(
            employee_id = data["employee_id"],
            UserName = data["employee_name"],
            Email	= data["employee_email"],
            permissions=permissions,
            Password = Encryption().encrypt('Manomay@123'),
            Status = 'ACTIVE',
            TemporaryPassword = True)

            db.session.add(emp_model)
            db.session.add(user_model)
            db.session.commit()

            # Notify the user with Temporary Password
            subject = f"Account Creation"
            body = f'''<p>Dear {data['employee_name']},</p>
                        <p>Your account has been registered.</p>
                        <p>Please use the following credentials to log
                        in for the first-time</p>
                        <p>Employee Id : {data['employee_id']}</p>
                        <p>Password : {('Manomay@123')}</p>
                        <p>Please note this is a temporary password & you
                        would be forced to setup a new password on the first
                        <a href={APP.config["FRONTEND_URL"]}>login</a></p>
                        '''
            cc = []
            toaddress = [data['employee_email']]
            if len(toaddress):

                    # Mail to be sent with the temporary password
                send_email(
                                body=body,
                                subject=subject,
                                cc=cc,
                                to_address=toaddress
                                )
            else:
                LOG.error("CREATE USER : MAIL NOT SEND DUE\
                        TO NO TO ADDRESS GIVEN")
                UnprocessableEntity("Cannot Send Mail")

            employees = get_employees()
            return {
                        "result": "success",
                        "internal_users": employees,
                        "count": len(employees)
                        }
        except Exception as e:
            LOG.error(e)
