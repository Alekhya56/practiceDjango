from flask import jsonify
from flask_restx import Resource
from sqlalchemy import func

from ... import LOG
from ...models import db
from ...models.employee import Employee
from ...models.project_description import ProjectDescription
from ..verify_token import login_required
from . import ns


def get_project_employee_views():

    """Get list of projects.

        Parameters:
        -----------
        Parms : None.

        Returns:
        -----------
        response : dict
                Project details.
    """
    """ Quering project details """

    sub_projects = db.session.query(func.max(ProjectDescription.id)).group_by(
        ProjectDescription.project_id).subquery()

    projects = db.session.query(ProjectDescription).filter(ProjectDescription.id.in_(sub_projects)).all()
    employees = Employee.query.filter_by(employee_status="Inactive").all()
    employee_list =[]
    for employee in employees:
        employee_list.append({
            "employee_designation":employee.employee_designation,
            "employee_name":employee.employee_name
        })
    project_list = []
    for project in projects:
        project_list.append({
            "project_name": project.Project.project_name,
            "status": project.status,
            "end_date": project.end_date,
        })
    return  {"employee_list":employee_list,"project_list":project_list}


@ns.route("/home")
class Home(Resource):

    """Gets all projects.

        Required:
        -----------
        login with admin creds

        returns:
        -----------
        Internal_users : dict
                    Render admin.html template with project details

    """
    @ns.doc(description='home',
            responses={200: 'OK', 400: 'Bad Request', 401: 'Unauthorized', 500: 'Internal Server Error'})
    @login_required
    def get(self):
        try:
            response = get_project_employee_views()
            return jsonify(response)
        except Exception as e:
            LOG.error(e)
