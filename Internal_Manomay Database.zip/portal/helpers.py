import os
import random
import smtplib
import string
import time
import uuid
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from flask import current_app as app

RESPONSE_OK = {"result": "Success"}


def get_config_file_path():
    env = os.getenv("BACKEND_ENV", default="development")
    print('env--->',env)
    base = os.path.dirname(os.path.abspath(__file__))
    absolute_path = os.path.abspath(os.path.join(base, '..', 'config', env + '.py'))
    return absolute_path


def delete_excel(filename):
    time.sleep(5)  # ??!!
    print("deleting file -" + filename)
    os.remove(filename)

def random_string_with_digits_and_symbols(string_length=10):
    """Generate a random string of letters, digits and special characters """

    password_characters = string.ascii_letters + string.digits
    return ''.join(random.choice(password_characters) for i in range(string_length))

def random_digits(string_length=10):
    """Generate a random digits """

    password_characters = string.digits
    return ''.join(random.choice(password_characters) for i in range(string_length))


def send_email(to_address,subject,body,cc=[]):
    domain = app.config['MAILSERVER_DOMAIN']
    email= app.config['MAILSERVER_USERNAME']
    if app.config["ENVIRONMENT"] == "DEVELOPMENT":
        port= app.config['MAILSERVER_PORT']
        password= app.config['MAILSERVER_PASSWORD']

    msg = MIMEMultipart()
    msg['subject'] = subject
    msg['from'] = email
    msg['to'] = ', '.join(to_address)
    msg['cc'] = ', '.join(cc)
    msg.attach(MIMEText(body, 'html'))

    if app.config["ENVIRONMENT"] == "DEVELOPMENT":
        # connecting to mailserver and send the email
        mailserver = smtplib.SMTP(domain, port=port)
        mailserver.starttls() #enable security
        mailserver.login(email, password)

    if app.config["ENVIRONMENT"] == "PRODUCTION":
        # connecting to mailserver and send the email
        mailserver = smtplib.SMTP(domain)
    try:
        mailserver.sendmail(email, (to_address+cc), msg.as_string())

    except Exception as e:
        print(e)
        domain = app.config['MAILSERVER_DOMAIN']
        email= app.config['MAILSERVER_USERNAME']
        to_address = ["alekhya.muddada@manomay.biz"]
        # to_address = ["shaik.farooq@manomay.biz","neetha.pasham@manomay.biz"]
        if app.config["ENVIRONMENT"] == "DEVELOPMENT":
            port= app.config['MAILSERVER_PORT']
            password= app.config['MAILSERVER_PASSWORD']

        msg = MIMEMultipart()
        msg['subject'] = "Error Sending Mails"
        msg['from'] = email
        msg['to'] = ', '.join(to_address)
        body = f'''<p>Hi, Admin</p>
                    <p>Looks like There is some Problem triggering the Emails</p>
                    <p>Please Check!</p>
                    <p>Error is {e}</p>
                    <p>Thanks and Regards</p>
                '''
        msg.attach(MIMEText(body, 'html'))

        if app.config["ENVIRONMENT"] == "DEVELOPMENT":
            # connecting to mailserver and send the email
            mailserver = smtplib.SMTP_SSL(domain, port=port)
            mailserver.login(email, password)

        if app.config["ENVIRONMENT"] == "PRODUCTION":
            # connecting to mailserver and send the email
            mailserver = smtplib.SMTP(domain)
        mailserver.sendmail(email, (to_address), msg.as_string())
        return f"mail failed: {e}"
    print("mail sent") 
    return "mail sent"
