import os
import logging

LOG_LEVEL = logging.DEBUG
ROOT_DIR = os.path.abspath(os.path.join(os.path.abspath(__file__),"..",".."))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
LOG_DIR = os.path.join(DATA_DIR, 'log')

SECRET_KEY = 'BT-=f~i1IlIHF(#'
JWT_SECRET_KEY = '-3SS0GhzWHsSpa8sZPP-45vnzhk_7TgwUT3gautXXkc'
# SQLALCHEMY_ECHO = True
#SQLALCHEMY_DATABASE_URI = 'mssql+pyodbc://DESKTOP-30LJVHL\SQLEXPRESS/Manomay_database?driver=SQL Server?Trusted_Connection=Yes'
#SQLALCHEMY_DATABASE_URI = 'mssql+pyodbc://LAPTOP-5KNII04G/Manomay_database?driver=SQL Server?Trusted_Connection=Yes'
SQLALCHEMY_DATABASE_URI = 'mssql+pyodbc://PocVM/Manomay_database?driver=SQL Server?Trusted_Connection=Yes'
SQLALCHEMY_TRACK_MODIFICATIONS = True

DEFAULT_PASSWORD= 'kl7Ew+PnxZLZ4ADjePo9oA=='
EXCEL_URL = os.path.abspath(os.path.join(os.path.abspath(__file__),"..\\..","portal\\static"))
TEMP_URL = os.path.abspath(os.path.join(os.path.abspath(__file__),"..\\..","portal\\static\\temporary"))

FRONTEND_URL= 'http://127.0.0.1:5000/'
#SQLALCHEMY_ECHO = True
MAILSERVER_DOMAIN = 'smtp.gmail.com'
MAILSERVER_PORT = 587
MAILSERVER_USERNAME = 'manomaytesting@gmail.com'
MAILSERVER_PASSWORD = 'jzaemibovlwkqvht'

ENVIRONMENT = "DEVELOPMENT"
# CORS_HEADERS = [
#     'Ipaddress', 'Authorization', 'username',
#     'Content-Type'
# ]

# CORS_ORIGIN_WHITELIST = [
#     "http://127.0.0.1:5000/",
# ]

# flask run -h 192.168.2.111 -p 9000
# $env:FLASK_ENV="DEVELOPMENT"
# $env:FLASK_APP="ICB_RI_Dev"
# $env:FLASK_DEBUG="1"
# flask db init
# flask db migrate -m "Adding columns"
# flask db upgrade