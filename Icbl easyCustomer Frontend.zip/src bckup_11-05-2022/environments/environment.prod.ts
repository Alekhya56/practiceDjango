export const environment = {
  production: true,
  apiUrl: 'http://localhost:4000',
  URL : 'http://172.20.32.157:5000/',
  //URL : 'http://172.21.32.34:4800',
};

