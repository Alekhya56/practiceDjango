export enum Role {
    Admin = 'Admin',
    CSR = 'CSR',
  }