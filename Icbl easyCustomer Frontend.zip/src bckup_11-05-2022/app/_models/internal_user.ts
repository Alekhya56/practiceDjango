import {Role} from './role';

export interface InternalUser {
    member_id: number;
    user_name: string;
    display_name : string;
    email_id: string;
    status: string;
    role: Role;
}