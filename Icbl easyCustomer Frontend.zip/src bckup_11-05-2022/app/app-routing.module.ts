import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { AdintuserpageComponent } from './admin/adintuserpage/adintuserpage.component';
import { LoginComponent } from './login';
import { AuthGuard } from './_helpers';
import { Role } from './_models/role';
import { ForgotDialogComponent } from './login/forgot-dialog/forgot-dialog.component';
import { ResetpasswordComponent } from './login/resetpassword/resetpassword.component';
import {DashboardComponent} from '../app/dashboard/dashboard.component';
import {InquiriesComponent} from '../app/inquiries/inquiries.component';
import {ReferredComponent} from '../app/referred/referred.component';
import {CallbackComponent} from '../app/callback/callback.component';
import {AllinquiriesComponent} from '../app/allinquiries/allinquiries.component';
import {Layout1Component} from '../app/layout1/layout1.component';
import {ComplaintsComponent} from '../app/complaints/complaints.component';
const routes: Routes = [
  { path: 'adintuserpage/:username', component: AdintuserpageComponent, canActivate: [AuthGuard], data: { roles: [Role.Admin] } },
  { path: 'login', component: LoginComponent },
  { path: 'forgot-dialog', component : ForgotDialogComponent },
  { path: 'resetpassword/:username', component: ResetpasswordComponent },
  { path: 'layout1', component: Layout1Component },
  { path: 'dashboard/:username', component: DashboardComponent, canActivate: [AuthGuard], data: { roles: [Role.CSR] } },
  { path: 'complaints/:username', component: ComplaintsComponent, canActivate: [AuthGuard], data: { roles: [Role.CSR] } },
  { path: 'inquiries/:username', component: InquiriesComponent , canActivate: [AuthGuard], data: { roles: [Role.CSR] }},
  { path: 'referred/:username', component: ReferredComponent , canActivate: [AuthGuard], data: { roles: [Role.CSR] }},
  { path: 'callback/:username', component: CallbackComponent , canActivate: [AuthGuard], data: { roles: [Role.CSR] }},
  { path: 'allinquiries/:username', component: AllinquiriesComponent , canActivate: [AuthGuard], data: { roles: [Role.CSR] }},
  { path: '**', redirectTo: '/login' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }
