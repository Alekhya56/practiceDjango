import { Component } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthenticationService } from './_services/authentication.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import {IpaddressService} from './_services/ipaddress.service'
import {SecureLocalStorageService} from './_services/secure-local-storage.service'

export let browserRefresh = false;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Mantra1';
  routerp: string;
  subscription: Subscription;
  role: string;
  username: any;

  constructor(public router: Router, private authenticationService: AuthenticationService,
              private http: HttpClient, private securestore: SecureLocalStorageService, 
              private ip: IpaddressService) {

                this.routerp = router.url;
  this.subscription = this.router.events.subscribe(async (event) => {
            if (event instanceof NavigationStart) {
              browserRefresh = !this.router.navigated;
              if (browserRefresh){
                this.ip.setIpAddress();
                this.ip.intercept12(false);
                this.http.get(environment.URL + '/ip').subscribe(data=>{
                  // this.ipAddress = data['ip'];
                  this.securestore.setitem("sdklgsjkdgbjksdbg", data['ip']);
                  this.ip.intercept12(true);
                }, error => {
                  console.log('th data');
                });
                this.ip.intercept12(true);
              }
              if (browserRefresh && this.authenticationService.currentUserValue) {
                const ip_address = this.ip.getIpAddress;
                var currentuservalue = this.authenticationService.currentUserValue;
                // var currentuservalue = ;
                currentuservalue.ipaddress = ip_address;
                this.securestore.setitem('currentUser', JSON.stringify(currentuservalue));
                const token = this.authenticationService.currentUserValue.token;
                const user = this.authenticationService.currentUserValue.username;
                const role = this.authenticationService.currentUserValue.role;
                const token1 =  await this.http.post<any>(environment.URL + '/auth/token/check', {user})
                .toPromise()
                .then(u => {
                  if (!(u.result)) {
                    this.authenticationService.logout();
                  }
                })
                .catch(u => {

                  this.authenticationService.logout();
                });
                
              }
            }

            // else { 
            //   console.log("else");
            // }

        });

  }

  ngOnInit(){
  this.role = this.authenticationService.currentUserValue.role;
  
  // console.log(this.role)
  // this. username = JSON.parse(this.securestore.getitem('currentUser'));
  // this.username = this.username['username'];
  
}
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}

