import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SimpleNotificationsModule } from 'angular2-notifications';
import {MatInputModule,MatMenuModule, MatPaginatorModule, MatSnackBarModule} from '@angular/material'
import {MaterialModule} from './material/material.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CommonModule} from '@angular/common';
import { AdintuserpageComponent } from './admin/adintuserpage/adintuserpage.component';
import {AdintusertableComponent} from './admin/adintuserpage/adintusertable/adintusertable.component';
import {  deleteIntUserDialogComponent, editUserInfoDialogComponent,
  timeDialogIntUserComponent,statusChangeDialogIntUserComponent } from './admin/adintuserpage/adintusertable';
import { AdduserDialogComponent } from './admin/adintuserpage/adduser-dialog/adduser-dialog.component';
import { SecureLocalStorageService, IpaddressService, AuthenticationService ,ConfigService} from './_services';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import {LoginComponent} from './login';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { SafePipe } from './_helpers/url.pipe';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ForgotDialogComponent } from './login/forgot-dialog/forgot-dialog.component';
import { ResetpasswordComponent } from './login/resetpassword/resetpassword.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { JwPaginationComponent } from 'jw-angular-pagination';
import { Layout1Component } from './layout1/layout1.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InquiriesComponent } from './inquiries/inquiries.component';
import { ReferredComponent } from './referred/referred.component';
import { CallbackComponent } from './callback/callback.component';
// import {callbackservice} from './callback/callback.component';
import { AllinquiriesComponent } from './allinquiries/allinquiries.component';
import { SearchtableComponent } from './inquiries/searchtable/searchtable.component';
import { SearchdialogComponent } from './inquiries/searchdialog/searchdialog.component';
import { ConfirmdialogComponent } from './inquiries/confirmdialog/confirmdialog.component';
import { BottomSheetComponent } from './inquiries/bottom-sheet/bottom-sheet.component';
import { CorrespondencedialogComponent } from './inquiries/correspondencedialog/correspondencedialog.component';
import { EditreferdialogComponent } from './referred/editreferdialog/editreferdialog.component';
import { ComplaintsComponent } from './complaints/complaints.component';
import { HashLocationStrategy, LocationStrategy  } from '@angular/common';
import { MatDatepickerModule } from '@angular/material';
import { SatDatepickerModule } from 'saturn-datepicker';
import { SatNativeDateModule } from 'saturn-datepicker';
import { MatSortModule} from '@angular/material/sort';
import { EditAllInquiryComponent } from './allinquiries/edit-all-inquiry/edit-all-inquiry.component';
import { IntusersearchComponent } from './admin/adintuserpage/adintusertable/intusersearch/intusersearch.component';

@NgModule({
  declarations: [
    Layout1Component,
    DashboardComponent,
    InquiriesComponent,
    ReferredComponent,
    CallbackComponent,
    AllinquiriesComponent,
    SearchtableComponent,
    SearchdialogComponent,
    SafePipe,
    JwPaginationComponent,
    AppComponent,
    AdintuserpageComponent,
    AdintusertableComponent,
    AdduserDialogComponent,
    LoginComponent,
    ForgotDialogComponent,
  deleteIntUserDialogComponent,
     editUserInfoDialogComponent, timeDialogIntUserComponent,
     statusChangeDialogIntUserComponent,
     ResetpasswordComponent,
     ConfirmdialogComponent,
     BottomSheetComponent,
     CorrespondencedialogComponent,
     EditreferdialogComponent,
     ComplaintsComponent,
     IntusersearchComponent ,
     EditAllInquiryComponent,
  ],
  imports: [
    SimpleNotificationsModule.forRoot(),
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    BrowserAnimationsModule,
    CommonModule,
    MatInputModule,
    FormsModule,
    // PdfViewerModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatSortModule,
    MatSnackBarModule,
    MatMenuModule,
    MatPaginatorModule,
    MatDatepickerModule ,
    SatDatepickerModule,
    SatNativeDateModule,
    AppRoutingModule,
    HttpClientModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
  ],
  exports: [

  ],
  entryComponents: [
    SearchdialogComponent,
    AdduserDialogComponent,EditAllInquiryComponent,
 ForgotDialogComponent,IntusersearchComponent,
deleteIntUserDialogComponent,editUserInfoDialogComponent,
    timeDialogIntUserComponent,statusChangeDialogIntUserComponent,
    ConfirmdialogComponent,BottomSheetComponent,CorrespondencedialogComponent,EditreferdialogComponent,
  ],
  providers: [ IpaddressService, AuthenticationService,ConfigService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    {provide : LocationStrategy , useClass: HashLocationStrategy},
    SecureLocalStorageService],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ],
})
export class AppModule { }
