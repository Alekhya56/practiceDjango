import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl, FormBuilder, FormGroup} from "@angular/forms";
import {Validators} from '@angular/forms';
import { InternalUser } from '../../../_models';
import { MatDialogRef, MatSnackBar } from '@angular/material';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { PasswordStrengthValidator } from 'src/app/_helpers/password-strength.validator';
// import { PhoneNumberValidator } from 'src/app/_helpers/phonenumber.validator';

@Component({
  selector: 'app-adduser-dialog',
  templateUrl: './adduser-dialog.component.html',
  styleUrls: ['./adduser-dialog.component.css']
})
export class AdduserDialogComponent implements OnInit {

  isLoadingResults : boolean = false;
  mobNumberPattern = "^((\\+1345-?))?[0-9]{7}$";
  internal_user : any;
  hide:boolean = true;
  submitted: boolean = false;
  addInternalUserForm : FormGroup;
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
]);
  @Output() changed = new EventEmitter();
  constructor(private formBuilder: FormBuilder,
    private http : HttpClient, private _snackbar : MatSnackBar,
    public dialogRef: MatDialogRef<AdduserDialogComponent>) {

    this.internal_user= {
      status : 'active',
      username : '',
      displayname : '',
      email : '',
      role : '',
    }
   }

  ngOnInit() {
    this.addInternalUserForm = this.formBuilder.group({
        accountType : ['',Validators.required],
        username : ['',[Validators.required, Validators.pattern(/^[a-zA-Z0-9.!#$@%&'*+/=?^_`{|}~-]*$/)]],
        displayname : ['',Validators.required],
        email : ['',[Validators.required,Validators.pattern(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]*$/)]],
        // password : ['',Validators.required,PasswordStrengthValidator],
       // sessionDuration : ['',Validators.required],
        dept : [''],
        team: [''],
        permission:['']
    });

  }
// returns addinternaluserform controls
  get formcontrolss() {
    return this.addInternalUserForm.controls; }
admin(value){
debugger
  if(value=="Admin"){
    this.addInternalUserForm.get('permission').disable()
  }else{
    this.addInternalUserForm.get('permission').enable()
  }

}
    // on submit of add user dialog form
  onSubmit(){
    console.log(this.formcontrolss.email.value+"@icb.com.bb")
    let em = this.formcontrolss.email.value+"@icb.com.bb";
    console.log(em)
    console.log(this.formcontrolss.email);
    this.submitted = true;

    // stop here if form is invalid
    if (this.addInternalUserForm.invalid) {
      console.log('form is invalid');
      this.openSnackBar("Please enter all the required details.")
        // return;
    }
    else{
      this.isLoadingResults = true;
      console.log('form is valid');
      this.internal_user.username = this.formcontrolss.username.value;
      this.internal_user.email = this.formcontrolss.email.value;
      this.internal_user.displayname = this.formcontrolss.displayname.value;
      this.internal_user.role = this.formcontrolss.accountType.value;

      console.log("permsdfbfdswadsvc xfdsew",this.addInternalUserForm.get('permission').value)
      const httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' })
      };
      this.http.post(environment.URL + '/admin/createuser', {

        username : this.formcontrolss.username.value,
        userid : this.formcontrolss.username.value,
        DisplayName : this.formcontrolss.displayname.value,
        email : this.formcontrolss.email.value+"@icbl.com",
        Role : this.formcontrolss.accountType.value,
        Department : this.formcontrolss.dept.value,
        Permissions:this.addInternalUserForm.get('permission').value,
        Team: this.formcontrolss.team.value, //, session_expiry :  this.f.sessionDuration.value
      },httpOptions).subscribe(data => {
              console.log(data)
              this.isLoadingResults = false;
              this.openSnackBar("Success");
              this.changed.emit();
              if(data['result']=="Success"){
              this.dialogRef.close();
      }
      },error=>{
        this.isLoadingResults = false;
        console.error(error);
        if(error){
        this.openSnackBar(error);
        }
      });
    }


    // this.http.post(environment.URL + '/resetpass', {
    //   request_type: 'admin',
    //   username : this.f.username.value,
    //   email : this.f.email.value,
    // }).subscribe(data => {
    //   console.log(data);
    //   const successMsg = 'Password is updated successfully';
    //   this.openSnackBar(successMsg);
    // },
    // error => {
    //   console.log(error);
    //   this.openSnackBar(error);
    // });
  }


  // numberOnly(event): boolean {
  //   const charCode = (event.which) ? event.which : event.keyCode;
  //   if (charCode > 31 && (charCode < 48 || charCode > 57)) {
  //     return false;
  //   }
  //   return true;
  // }

  openSnackBar(msg){
    this._snackbar.open(msg, 'Dismiss', {duration:3000});
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
