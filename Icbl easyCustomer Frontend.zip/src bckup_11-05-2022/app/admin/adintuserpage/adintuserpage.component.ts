import { Component, OnInit, ViewChild } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatStepper} from '@angular/material';
import { AdduserDialogComponent } from './adduser-dialog/adduser-dialog.component';
import { AdintusertableComponent } from './adintusertable/adintusertable.component';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import * as FileSaver from 'file-saver';
import { isEmpty } from 'rxjs-compat/operator/isEmpty';
import { type } from 'jquery';
import * as moment from 'moment';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-adintuserpage',
  templateUrl: './adintuserpage.component.html',
  styleUrls: ['./adintuserpage.component.css'],
  providers: [DatePipe],
})
export class AdintuserpageComponent implements OnInit {
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  isEditable = false;
  // let ast = new AdintusertableComponent();
  @ViewChild(AdintusertableComponent, {static: false}) child : AdintusertableComponent;
  tomorrow = new Date();
  isLoadingResults : boolean = false;
  isRateLimitReached = false;
  reportform : FormGroup;
  constructor(private authenticationService: AuthenticationService,private _router: Router,private _snackbar : MatSnackBar,public dialog: MatDialog,private dp: DatePipe,private f1 : FormBuilder,private http: HttpClient) {
    this.tomorrow.setDate(this.tomorrow.getDate() + 0);
  }

  ngOnInit() {
    const Role = localStorage.getItem("role")
    console.log("Role********",Role)
    if (Role != "Admin"){
      this.authenticationService.logout();
      this._router.navigate(['/login']);
    }
    this.reportform = this.f1.group({
      fromdate: ['',Validators.required],
      todate: ['',Validators.required],
      report_type: ['',Validators.required],
    });
    this.firstFormGroup = this.f1.group({
      password: ['', Validators.required]
    });
    this.secondFormGroup = this.f1.group({

    });
  }


// to open add user dialog on click of add user button

  openadduserDialog(): void {
    const dialogRef = this.dialog.open(AdduserDialogComponent, {
      width: '450px',
      height: '500px',
    })

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog is closedaaa');
      this.isLoadingResults = false;
      this.isRateLimitReached = false;
      this.child.ngOnInit();
    }, error => {
      this.isRateLimitReached = true;
      console.log(error);
    });
  }

  // clear the search results based on flusing the input parameters
  clearsearch(){
    let fromdate = this.reportform.get('fromdate').value;
    fromdate = moment(fromdate).format("YYYY-MM-DD");
    // this.dp.transform(fromdate, 'yyyy-MM-dd','es-ES');
    let todate = this.reportform.get('todate').value;
    todate = moment(todate).format("YYYY-MM-DD");
    // this.dp.transform(todate, 'yyyy-MM-dd','es-ES');
    if(this.reportform.valid){
      console.log(fromdate);
      console.log(todate);
      if(fromdate > todate){
        console.log("yess")
        this.openSnackBar("From date is greater than To date, Please select again")
      }
      else{
        console.log("no");
        let file = this.reportform.get('report_type').value;
this.download(fromdate,todate,file);
      }

    }

  }
  openSnackBar(msg){
    this._snackbar.open(msg, 'Dismiss', {duration:3000});
  }
download(fromdate,todate,file){
  this.http.post<any>(environment.URL + "/reports/generate",
        {fromdate:fromdate,todate:todate,file:file},
          {responseType: "blob" as 'json'}).subscribe(data=>{
          FileSaver.saveAs(data, "Reports.xlsx");
          console.log(data);
       },
       error=>{
         console.log(error);
       });}
  // manual password check for special admin user hardcoded
  goForward(stepper: MatStepper) {
    let pass = this.firstFormGroup.get('password').value;
    if(pass == isEmpty || pass == ""){
      this.openSnackBar("Please enter password to proceed further")
    }
    else{
      if(pass == "kesi@234") {
        stepper.next();
            console.log("hhh")
            }
            else{
              this.openSnackBar("Wrong password, please try again!")
            }
    }

  }


}
