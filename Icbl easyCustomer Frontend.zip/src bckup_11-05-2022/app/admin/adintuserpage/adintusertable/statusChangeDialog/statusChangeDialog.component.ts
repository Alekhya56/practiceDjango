import { Component, Inject } from '@angular/core';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { timeDialogIntUserComponent } from '../timeDialogIntUser/timeDialogIntUser.component';

@Component({
    templateUrl :'confirmStatusChangeIntUser.html',
    })
export class statusChangeDialogIntUserComponent{
constructor(
      public dialogRef: MatDialogRef<timeDialogIntUserComponent>,
      @Inject(MAT_DIALOG_DATA) public data) {}
    onNoClick(): void {
      this.dialogRef.close();
    }
    }