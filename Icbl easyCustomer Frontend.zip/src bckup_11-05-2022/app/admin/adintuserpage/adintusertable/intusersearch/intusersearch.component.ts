import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-intusersearch',
  templateUrl: './intusersearch.component.html',
  styleUrls: ['./intusersearch.component.css']
})
export class IntusersearchComponent implements OnInit {

  intuserSearchForm : FormGroup;
  active : string = 'active';
  inactive : string = 'inactive';
  constructor(private fb : FormBuilder) {
      this.intuserSearchForm = this.fb.group({
        username : [''],
        displayname : [''],
        email : [''],
        status : [''],
      });
   }

  ngOnInit() {
  }

  get f() {
    return this.intuserSearchForm.controls;
  }

  onSubmit() {

  }
}
