import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntusersearchComponent } from './intusersearch.component';

describe('IntusersearchComponent', () => {
  let component: IntusersearchComponent;
  let fixture: ComponentFixture<IntusersearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntusersearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntusersearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
