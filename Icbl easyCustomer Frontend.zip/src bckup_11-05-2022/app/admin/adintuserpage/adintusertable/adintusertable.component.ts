import { Component, OnInit, Inject } from '@angular/core';
import { MatSort, MatTableDataSource, MatDialog, Sort, MatSortable} from '@angular/material';
import { ViewChild } from '@angular/core';
import { AuthenticationService } from '../../../_services';
import { editUserInfoDialogComponent } from './editUserInfoDialog/edituserInfoDialog.component';
import { deleteIntUserDialogComponent } from './deleteUserDialog/deleteUserDialog.component';
import { statusChangeDialogIntUserComponent } from './statusChangeDialog/statusChangeDialog.component';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
// import { IntusersearchComponent } from './intusersearch/intusersearch.component';

@Component({
  selector: 'app-adintusertable',
  templateUrl: './adintusertable.component.html',
  styleUrls: ['./adintusertable.component.css'],
  // animations: [
  //   trigger('detailExpand', [
  //     state('collapsed', style({height: '0px', minHeight: '0'})),
  //     state('expanded', style({height: '*'})),
  //     transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
  //   ]),
  // ],
})
export class AdintusertableComponent implements OnInit {

  resultsLength : any = 0;

  isLoadingResults : boolean = false;
  isMainAdmin : boolean = true;
  usersList :any;
  filterList = [];
  username : string;
  member_id : number;
  status : string;
  email: string;
  displayname: string;
  constructor(
    private http : HttpClient,
    private as : AuthenticationService,
    private dialog : MatDialog ) {}
  editable : boolean =  true;
    private user_type = 'internal';
  ngOnInit() {
  this.getIntUsers();
  this.username = this.as.currentUserValue.username;
  // this.dataSource.paginator = this.paginator;
    this.sort.sort(({ id: 'name', start: 'asc'}) as MatSortable);
    this.dataSource.sort = this.sort;
  }
  displayedColumns = ['Username', 'DisplayName','Department', 'Email', 'Status','Action'];
  dataSource: any;

  // @ViewChild(MatPaginator, {static:false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static:false}) sort: MatSort;
  
// filtering the table data 
   applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
// get internal users data to fetch data records
  getIntUsers(){
    this.isLoadingResults = true;
    return this.http.get(environment.URL + '/admin/users/internal/get').
      subscribe( 
        customers => {  
          console.log(customers);
                        this.isLoadingResults =false;
                        this.usersList = customers['users'];
                        this.resultsLength = this.usersList.length;
                        this.filterList = this.usersList.filter(t => { t.Username === this.username });
                        
                        const index = this.usersList.map(function(item) { return item.Username; }).indexOf(this.username)

                        if (index > -1) {
                          this.usersList.splice(index, 1);
                        }
                        const index2 = this.usersList.map(function(item) { return item.Username; }).indexOf('Admin')
                        if (index2 > -1) {
                          this.usersList.splice(index, 1);
                        }

                        this.dataSource = new MatTableDataSource(this.usersList);
                        // this.dataSource.paginator = this.paginator;
                        this.dataSource.sort = this.sort;
                        // const sortState: Sort = {active: 'Username', direction: 'asc'};
                        // this.sort.active = sortState.active;
                        // this.sort.direction = sortState.direction;
                        // this.sort.sortChange.emit(sortState);
    },
    error =>{
      console.log(error);
      this.isLoadingResults = false;
    }, ()=>{
      this.isLoadingResults = false;
    });
  }

// on click of edit icon open editdialog 
  openEditDialog(row){
    const dialogRef = this.dialog.open(editUserInfoDialogComponent, {
      width: '450px',
      height : '600px',
      data : {row:row}
    });
  
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.ngOnInit();
    });
  }
  
  // on click of delete icon open delete dialog 
openDeleteDialog(id,user_name){
  const dialogRef = this.dialog.open(deleteIntUserDialogComponent, {
    width: '250px',
    height: '250px',
    data : {username : user_name}
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
    if(result){this.deleteUser(user_name)}
  });
}


// open status change dialog 
openStatusChangeDialog(row){  
  let counterStatus ='';
  if(row.Status=="ACTIVE"){
    counterStatus = "INACTIVE";
  }
  else{
    if(row.Status=="INACTIVE"){
      counterStatus = "ACTIVE";
    }
  }
  const dialogRef = this.dialog.open(statusChangeDialogIntUserComponent, {
    width: '350px',  data : {username : row.username, status : row.Status, counterStatus : counterStatus, }
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
    if(result){this.changeStatus(row.DisplayName, row.Username,counterStatus, row.Role, row.Email)}
  });

}


// change the status of the user 
changeStatus(DisplayName, username, counterStatus, role, email){
  // this.firebaseService.changeStatusInternalUser(key, counterStatus);
  this.http.post(environment.URL + '/admin/user/update', {
     user : username, 
     email :email,
     displayname : DisplayName,
     status : counterStatus,
     role : role, 
     statuschange : true,
     passwordchange : false,
     phonenumber : null }).subscribe(data=>{
  this.ngOnInit();
  }, error =>{
    console.log(error);
  });
}

// to delete the user 
deleteUser(id){
 // this.firebaseService.deleteInternalUser(id);
  this.http.post(environment.URL + '/admin/user/internal/delete', { user : id}).subscribe(data => {
    console.log(data);
    this.ngOnInit();
  },
  error => {
    console.log(error);
  });
}


}
