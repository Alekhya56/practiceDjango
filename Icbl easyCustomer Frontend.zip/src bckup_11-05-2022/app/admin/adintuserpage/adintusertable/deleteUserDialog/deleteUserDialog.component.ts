import { Component, Inject } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';;

@Component({
    templateUrl :'deleteDialog.html',
    // styleUrls:['editMemberInfo.css']
    })
    export class deleteIntUserDialogComponent{
constructor(
      public dialogRef: MatDialogRef<deleteIntUserDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data) {
            console.log(data)
      }
      onNoClick(): void {
            this.dialogRef.close();
      }
    }

