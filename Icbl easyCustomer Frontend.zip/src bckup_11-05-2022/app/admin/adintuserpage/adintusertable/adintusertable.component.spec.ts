import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdintusertableComponent } from './adintusertable.component';

describe('AdintusertableComponent', () => {
  let component: AdintusertableComponent;
  let fixture: ComponentFixture<AdintusertableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdintusertableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdintusertableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
