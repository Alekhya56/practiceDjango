import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdintuserpageComponent } from './adintuserpage.component';

describe('AdintuserpageComponent', () => {
  let component: AdintuserpageComponent;
  let fixture: ComponentFixture<AdintuserpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdintuserpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdintuserpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
