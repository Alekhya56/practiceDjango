import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import {MediaMatcher} from '@angular/cdk/layout';
import {ChangeDetectorRef, OnDestroy} from '@angular/core';
import { Router,RouterModule, ActivatedRoute } from '@angular/router';
import { AuthenticationService, SecureLocalStorageService } from '../_services';
import { ThrowStmt } from '@angular/compiler';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-layout1',
  templateUrl: './layout1.component.html',
  styleUrls: ['./layout1.component.css']
})
export class Layout1Component implements OnInit {

  wasFormChanged = false;
  public breakpoint: number;
  mobileQuery: MediaQueryList;
  router: string;
  username: any;
  usertype: any;
  resetpass: boolean = false;
  @ViewChild('snav',{static: false}) snav:any;
  reset: any;
  toggleSidenav()
    {
      this.snav.toggle();
      console.log(this.snav.toggle);
    }
  fillerNav = Array.from({length: 50}, (_, i) => `Nav Item ${i + 1}`);

  private _mobileQueryListener: () => void;
  role: string;


  public ngOnInit(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
    this.breakpoint = window.innerWidth <= 790 ? 1 : 2;
    this.role = this.authenticationService.currentUserValue.role;
    

  console.log(this.role);
  if(this.role == "Admin"){
   this.usertype = "Admin"
  }
  else{
  this.usertype = "Customer Rep"
  }
  }
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 790 ? 1 : 2;
  }

  constructor(private authenticationService: AuthenticationService,changeDetectorRef: ChangeDetectorRef, media: MediaMatcher, private _router: Router,
   private route:ActivatedRoute,private securestore: SecureLocalStorageService,@Inject(DOCUMENT) private document: any) {
    this.mobileQuery = media.matchMedia('(max-width: 768px)');
    debugger
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.router = _router.url;
    // this.username = this.route.snapshot.params['username'];
    this. username = JSON.parse(securestore.getitem('currentUser'));
    this.username = this.username['username']
console.log(this.username);
console.log();  
// let quotei =  this.route.snapshot.paramMap.get('view');
let reset = location.href;
console.log(reset)
if(reset.includes('resetpassword')){
  console.log("resettttttttttt")
  this.resetpass = true;
}
  }
  logout(){
    debugger
    this.authenticationService.logout();
    this._router.navigate(['/login']);
  }
}
