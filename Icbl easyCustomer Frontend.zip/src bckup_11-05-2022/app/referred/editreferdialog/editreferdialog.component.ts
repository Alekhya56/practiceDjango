import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { DatePipe, DeprecatedPercentPipe } from '@angular/common';
import { SecureLocalStorageService } from '../../_services';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { J } from '@angular/cdk/keycodes';
import { MatChipInputEvent, MatChipList } from '@angular/material';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
@Component({
  selector: 'app-editreferdialog',
  templateUrl: './editreferdialog.component.html',
  styleUrls: ['./editreferdialog.component.css'],
  providers: [DatePipe],
})
export class EditreferdialogComponent implements OnInit {
  editInfoForm: FormGroup;
  today: number;
  ID:number
  panelOpenState = false;
  routerurl = this.router.url
  isReferred$: Observable<boolean>;
  selecteddept: string;
  dept:any;
  emaildept:any
  selectdept:any
/* department:string[]=['Group Life & Health','ICBL Customer Support','ICBL Online Support',
'ICBL Policy Services','ICBL Quotations','Inbound Call Team','Individual Life & Health','Omniplus Team'
,'Key business Partners','Payment Admin','Policy Benefits Team','Pensions Support Team','Other'
]
de */
editable:boolean
otherdepts = {
  emails: []
}
readonly separatorKeysCodes: number[] = [ENTER, COMMA];
department:any[]=
[  {id:0,value:'Agency - Kendal Ince'},
{id:1,value:'Agency - Natasha Licorish'},
{id:2,value:'Customer Support'},
  {id:3,value:'Group Life & Health'},
  {id:4,value:'Inbound Call Team'},
   {id:5,value:'Individual Life & Health'},
   {id:6,value:'Key business Partners'},
  {id:7,value:'Omniplus Team'},
  {id:8,value:'Online Support'},
  {id:9,value:'Payment Admin'},
  {id:10,value:'Pensions Support Team'},
  {id:11,value:'Policy Benefits Team'},

  {id:12,value:'Policy Services'},
  {id:13,value:'Quotations'},






  {id:14,value:'Other'}
]
visible = true;
selectable = true;
removable = true;
addOnBlur = true;
  departshow: boolean;
  @ViewChild('chipList',{static:true}) chipList: MatChipList;
  otherdept: boolean;
  constructor(private snackBar: MatSnackBar, private securestore: SecureLocalStorageService, public dialogRef: MatDialogRef<EditreferdialogComponent>,
    private formbuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) public data, private http: HttpClient,
    private dp: DatePipe, private router: Router) {

    setInterval(() => {
      this.today = Date.now();
    }, 1);
    console.log(data);
    debugger
    this.editInfoForm = this.formbuilder.group({

      notes: [this.data.row.Remarks],
      displayname: [this.data.row.Customer_Name],
      respondedby: [this.data.row.Responded_By, Validators.required],
      rnotes: [this.data.row.Resolution_Notes],
      inqtype: [this.data.row.Type_Of_Inquiry],
      deptemail:this.formbuilder.array(this.otherdepts.emails),
      id: [this.data.row.Task_Id],
      dept:[''],

    });
  }

  ngOnInit() {
    debugger
    console.log(this.data)
    this.selecteddept=""
    console.log("123456easdf",this.data.row.Department_Name)
    //this.editInfoForm.get('deptemail').setValue(this.data.row.Reassign_Other_Department_Email)
    //this.editInfoForm.controls.deptemail.setValue(this.data.row.Reassign_Other_Department_Email)

this.dept=this.data.row.Department_Name
    if(this.data.row.Reassaigned_dept!=""){
    this. dept=this.data.row.Reassaigned_dept
    }else{
    this.dept=this.data.row.Department_Name
    }

    if(localStorage.getItem("permissions")=="None"){
      this.editInfoForm.controls['dept'].disable()
      this.editable=false
    }else{
        this.editable=true
    }
   // this.editInfoForm.setValue([this.data.row.Department_Name])
    //this.selecteddept=this.data.row.Department_Name
     let i=0;
     let val=0;
    for(i=0;i<this.department.length;i++){
      debugger
      if(this.department[i].value==this.dept){
    //this.selecteddept=this.department[i].id

    /* let val=0;
    val=this.department[i].id;
this.department[0].id=val
      this.department[i].id=0; */
    this.editInfoForm.controls['dept'].setValue(this.department[i].id);
    //this.selecteddept=this.department[i].value;
    console.log(this.selecteddept)}

    }
    //this.editInfoForm.controls['deptemail'].setValue(this.data.row.Reassign_Other_Department_Email);
    }
deptchange(event)
{console.log(event)
}
  add(event: MatChipInputEvent, form: FormGroup): void {
    const input = event.input;
    const value = event.value;

    // Add name
    if ((value || '').trim()) {
      const control = <FormArray>form.get('deptemail');
      control.push(this.initName(value.trim()));
      console.log("ddddddddddddddddddddd")
      console.log(control.value);
    }
    // Reset the input value
    if (input) {
      input.value = '';
    }
  }
  initName(name: string): FormControl {
    return this.formbuilder.control(name);
  }
  remove(form, index) {

    console.log(form);
    form.get('deptemail').removeAt(index);
  }
  fun(){
    this.onselecteddept()
  }
    onselecteddept(){
      console.log(this.editInfoForm.get('dept').value)

      if(this.editInfoForm.get('dept').value==14){
        console.log("in therrrrrrrr")
        this.otherdept = true;
        this.editInfoForm.get('deptemail').setValidators([Validators.required]);
        this.editInfoForm.get('deptemail').updateValueAndValidity();

      }
      else{
        this.otherdept = false;
        this.editInfoForm.get('deptemail').clearValidators();
        this.editInfoForm.get('deptemail').updateValueAndValidity();
      }
    }
  onSubmit(action) {
    console.log(action)
    let notes = this.editInfoForm.get('notes').value;
    let response = this.editInfoForm.get('respondedby').value;
    let inquirytype = this.editInfoForm.get('inqtype').value;
    let resolution_notes = this.editInfoForm.get('rnotes').value;
    let updatedate = this.dp.transform(this.today, 'yyyy-MM-dd', 'es-ES');
    let username = JSON.parse(this.securestore.getitem('currentUser'));
    let id = this.editInfoForm.get('id').value;
    let deptt = this.editInfoForm.get('dept').value;
    const control = <FormArray>this.editInfoForm.get('deptemail');
    let deptemail=control.value
    /* let i=0
    let j=0;
    let k=0;
    let deptt=[]
    debugger

     for(i=0;i<this.department.length;i++){
      if(this.department[i].id==dept[j]){
        deptt[k]=this.department[i].value
        k++
        j++
        i=0
      }*/
let dept
      let i=0;
      let j=0;
      for(j=0;j<this.department.length;j++){
        debugger
        if(this.department[j].id==deptt){
dept=this.department[j].value
this.data.row.Reassaigned_dept=dept
this.editInfoForm.controls['dept'].setValue(this.department[j].id);
        }
      }
if(dept==this.dept){
    this.editable=false
}
this.ID=this.data.row.ID
    console.log("department value",dept)
    username = username['username']
    if (this.editInfoForm.valid && action == "Close") {
      console.log(this.data.row.Complaint)
      const httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' })
      };
      return this.http.post<any>(environment.URL + '/queries/refer_inquiry_versions', { other_dept_email:deptemail,editable:this.editable,inquirytype: inquirytype, Remarks: notes, dept:dept,Responded_By: response, Last_Updated_Date: updatedate, inq_id:this.ID,task_id: id, Closed_By: username, Last_Updated_By: username, action: action, Resolution_Notes: resolution_notes, Complaint: this.data.row.Complaint }, httpOptions).subscribe((aftersubmit) => { // not callback
        console.log(aftersubmit);
        if (aftersubmit['Referred_inquiry'] == "success") {
          console.log("successsss")
          this.onNoClick();
          this.openSnackBar("Inquiry Closed Successfully", "Dismiss");
          this.ngOnInit();
        }

      }, error => {
        console.error("Error", error);
      });
    }
    else if (action == "Save") {
      const httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' })
      };
      return this.http.post<any>(environment.URL + '/queries/refer_inquiry_versions', {other_dept_email:deptemail, editable:this.editable,inquirytype: inquirytype, Remarks: notes, dept:dept, Responded_By: response, Last_Updated_Date: updatedate, inq_id:this.ID,task_id: id, Last_Updated_By: username, action: action, Resolution_Notes: resolution_notes }, httpOptions).subscribe((aftersubmit) => { // not callback
        console.log(aftersubmit);
        if (aftersubmit['Referred_inquiry'] == "success") {
          console.log("successsss")
          this.onNoClick();
          this.openSnackBar("Inquiry Saved Successfully", "Dismiss");
          this.ngOnInit();
        }

      }, error => {
        console.error("Error", error);
      });
    }
    else {
      this.openSnackBar("Please fill the mandatory fields", "Dismiss");
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }
}



