import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditreferdialogComponent } from './editreferdialog.component';

describe('EditreferdialogComponent', () => {
  let component: EditreferdialogComponent;
  let fixture: ComponentFixture<EditreferdialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditreferdialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditreferdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
