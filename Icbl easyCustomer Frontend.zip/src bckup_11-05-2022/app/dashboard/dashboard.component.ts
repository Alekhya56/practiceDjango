import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
// import * as FileSaver from 'file-saver';  
// import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  // providers: [DatePipe]
})
export class DashboardComponent implements OnInit {
  reportform : FormGroup;
  constructor(private f1 : FormBuilder,private http: HttpClient) { }

  ngOnInit(): void {

  }

}
