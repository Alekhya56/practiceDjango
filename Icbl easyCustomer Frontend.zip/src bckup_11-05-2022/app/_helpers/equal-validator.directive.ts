
import { FormGroup } from '@angular/forms';

// custom validator to check that two fields match
export function MustMatch(controlName: string, matchingControlName: string) {
   (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];

        if (matchingControl.errors && !matchingControl.errors.mustMatch) {
            // return if another validator has already found an error on the matchingControl
            console.log(matchingControlName)
            return;
        }

        // set error on matchingControl if validation fails
        if (control.value !== matchingControl.value) {
            return matchingControl.setErrors({ mustMatch: true });
        } else {
           return matchingControl.setErrors(null);
        }
    }
}