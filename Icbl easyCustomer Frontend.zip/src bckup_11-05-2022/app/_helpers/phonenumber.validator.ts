import { AbstractControl, ValidationErrors } from "@angular/forms"

export const PhoneNumberValidator = function (control: AbstractControl): ValidationErrors | null {

  let value: string = control.value || '';
  let msg = "";
  if (!value) {
    return null
  }

  let numberCharacters = /^(345){0,1}[\d]{7}$/g;
  if (numberCharacters.test(value) === false) {
    return {
      phoneNumberStrength: 'Phone number must contain at least two of the following: numbers, lowercase letters, uppercase letters, or special characters.'
    }

  }

}