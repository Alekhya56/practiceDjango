import { Injectable, OnInit } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../_services';
import { IpaddressService } from '../_services/ipaddress.service';

@Injectable()
export class JwtInterceptor implements HttpInterceptor, OnInit {
    ipaddress:string = '';
    constructor(private authenticationService: AuthenticationService, 
        private IpaddressService:IpaddressService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // add authorization header with jwt token if available
        let currentUser = this.authenticationService.currentUserValue;
        // console.log(this.ip.currentUserValue);
        let ip = this.IpaddressService.getIpAddress;
        if (currentUser && currentUser.token && this.IpaddressService.intercept1) {
            request = request.clone({
                setHeaders: {
                    Authorization: `${"Bearer "+currentUser.token}`,
                    Ipaddress: `${ip}`,
                    username: `${currentUser.username}`
                }
            });
        } 
        return next.handle(request);
    }
    ngOnInit(){

        // this.IpaddressService.getIpAddress().subscribe(res => {
  
        //   this.ipaddress = res['ip'];
        //   console.log("jbjhvbjhvjhkv");
  
        // });
     }
}