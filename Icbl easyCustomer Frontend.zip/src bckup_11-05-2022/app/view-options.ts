export interface ViewOptions {
    sortField: string;
    sortDirection: string;
    page: number;
    pageSize: number;
  }