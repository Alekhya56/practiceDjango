﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs-compat';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { SecureLocalStorageService } from './secure-local-storage.service';
import { environment } from '../../environments/environment';
import { User } from '../_models';
import { throwError } from 'rxjs';
import {IpaddressService} from './ipaddress.service';
// import { userInfo } from 'os';

@Injectable({ providedIn: 'root' })
  
export class AuthenticationService {
    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;
    public User : Observable<User>;
    private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    private ipadd: string;
  ip: any;
  usernamelogout: any;

    constructor(private http: HttpClient, 
                private router: Router, private securestore: SecureLocalStorageService,
                private ipAddress: IpaddressService) {
        try{
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(securestore.getitem('currentUser')));
        }
        catch (error){
          console.log("about to logout")
          this.logout();
        }
        this.currentUser = this.currentUserSubject.asObservable();

    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    login(userName: string, passWord: string) {
       // var username = username.toLowerCase();
        this.ip =  this.ipAddress.getIpAddress;
        console.log(this.ip);
        return this.http.post<any>(environment.URL + '/auth/login', 
        {username : userName, password : passWord, Ipaddress : this.ip})

        // const ip =  this.ipAddress.getIpAddress;
        // return this.http.post<any>(environment.URL + '/auth/login', {username : userName, password : passWord})

        .pipe(map(user => {
          console.log(user);
          if (user && user.token) {
                this.securestore.setitem('currentUser', JSON.stringify(user));
                this.currentUserSubject.next(user);
            }
           
          return user;
        },
        
        error=>{
          console.log(error);
        }));
    }

    logout() {
      debugger
      this.usernamelogout = JSON.parse(this.securestore.getitem('currentUser'));
    this.usernamelogout = this.usernamelogout['username']
console.log(this.usernamelogout);  
       this.http.post<any>(environment.URL + '/auth/logout', 
       {username : this.usernamelogout}).subscribe((aftersubmit) => { // not callback

         console.log(aftersubmit);
      }, error => {
        console.error("Error", error);
      });
        localStorage.removeItem('currentUser');
        localStorage.removeItem('ipaddress');
        localStorage.removeItem('user');
        localStorage.removeItem('permissions')
        this.currentUserSubject.next(null);
        this.router.navigate(['login']);
    }
    isLoggedIn() {
         return this.currentUser;
      }
}
