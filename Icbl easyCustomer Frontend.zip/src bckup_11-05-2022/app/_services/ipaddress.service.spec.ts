import { TestBed } from '@angular/core/testing';

import { IpaddressService } from './ipaddress.service';

describe('IpaddressService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IpaddressService = TestBed.get(IpaddressService);
    expect(service).toBeTruthy();
  });
});
