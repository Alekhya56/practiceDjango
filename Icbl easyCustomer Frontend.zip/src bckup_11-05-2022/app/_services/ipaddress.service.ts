import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import {SecureLocalStorageService} from './secure-local-storage.service';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class IpaddressService {
  ipAddress:string;
  intercept:any = true;

  constructor(private http: HttpClient, private sec: SecureLocalStorageService){
  }
   
public get intercept1():any{
return this.intercept;
}
public intercept12(intr:any){
  this.intercept = intr;
}
  // public get setIpAddress() {
  //   this.intercept = false;
  //   return this.http.get<{ip : string}>('https://jsonip.com')
  //   .subscribe( data => {
  //     console.log('th data', data);
  //     this.ipAddress = data.ip;
  //     this.sec.setitem('sdklgsjkdgbjksdbg', data.ip);
  //     this.intercept = true;
  //     return this.ipAddress;
  //   })
  
  // }


  public setIpAddress() {
    console.log('setip');
    this.intercept = false;
    this.http.get(environment.URL + '/ip').subscribe(data=>{
      this.sec.setitem("sdklgsjkdgbjksdbg", data['ip']);
    }, error => {
    });
    this.intercept = true;
  };

  public get getIpAddress(){
    return this.sec.getitem("sdklgsjkdgbjksdbg");
  }
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  }

}
