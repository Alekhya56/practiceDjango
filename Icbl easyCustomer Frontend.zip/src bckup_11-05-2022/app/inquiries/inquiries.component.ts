import { Component, OnInit, EventEmitter, Injectable, ViewChild} from '@angular/core';
import {SearchdialogComponent} from '../inquiries/searchdialog/searchdialog.component';
import{ConfirmdialogComponent} from '../inquiries/confirmdialog/confirmdialog.component';
import { MatDialog} from '@angular/material/dialog';
import {FormGroup, FormBuilder, FormControl, FormArray,FormGroupDirective, NgForm, Validators} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import {MatTabGroup, MatRadioChange} from '@angular/material';
import { DatePipe } from '@angular/common';
import {MatSnackBar} from '@angular/material';
import { AuthenticationService, SecureLocalStorageService,ConfigService } from '../_services';
import {MatBottomSheet} from '@angular/material';
import {BottomSheetComponent} from '../inquiries/bottom-sheet/bottom-sheet.component';
import { type } from 'jquery';
import * as moment from 'moment';
import { CorrespondencedialogComponent } from './correspondencedialog/correspondencedialog.component';
import { ActivatedRoute, Router } from '@angular/router';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
import { AppDateAdapter, APP_DATE_FORMATS} from './date.adapter';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { MatChipInputEvent, MatChipList } from '@angular/material';
@Injectable({
  providedIn: 'root'
})

// policy table population service
export class policytableservice {
  $data = new EventEmitter();
  policydata: any;
  constructor() { }

  policydetails(policydetail) {
    console.log("in policytableservice");
    console.log(policydetail);
    console.log(typeof(policydetail));
    this.$data.emit(policydetail);
  }
}
@Component({
  selector: 'app-inquiries',
  templateUrl: './inquiries.component.html',
  styleUrls: ['./inquiries.component.css'],
  providers: [DatePipe,{
    provide: DateAdapter, useClass: AppDateAdapter
},
{
    provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
}]
})
export class InquiriesComponent implements OnInit {
  @ViewChild('chipList',{static:true}) chipList: MatChipList;
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;

  cleardateicon = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  labelPosition: 'before' | 'after' = 'before';
  contactForm1 : FormGroup;
  selectedinquiry: string;
  selecteddept: string;
  selectedreq: string;
  selectedcontact: string;
  selectedidtype: string;
  customerreachval: string;
  inoutboundhide = false;
  priorityhide = false;
  callbackbuttonhide = true;
  callbackhide = true;
  clearhide = true;
  depthide = false;
  otherdept = false;
  othereq = false;
  searchdataobj : any = [];
  correspondenceobj : any = [];
  demo1TabIndex: number;
  today: number;
  lastupdatedate: string;
  clientid: string;
  system: string;
  lastupdatedtime: string;
  followupdatem: string;
  calldetailsm: string;
  notesm: string;
  isLoadingResults : boolean = false;
  // isSubmittedradio = false;
  tomorrow = new Date();
  otherdepts = {
    emails: []
  }
  search: boolean;
  existingshow: boolean;

constructor(private config: ConfigService,private authenticationService: AuthenticationService,private _router: Router,private http: HttpClient, private router: Router,private route: ActivatedRoute,private bottomSheet: MatBottomSheet,private securestore: SecureLocalStorageService,public snackBar: MatSnackBar,public dialog: MatDialog,private dp: DatePipe,private policytableservice: policytableservice,private f1 : FormBuilder){
  setInterval(() => {
    this.today = Date.now();
  }, 1);

  this.tomorrow.setDate(this.tomorrow.getDate() + 0);
  }
  ngOnInit(): void {
    debugger
    const Role = localStorage.getItem("role")
    console.log("Role********",Role)
    if (Role != "CSR"){
      this.authenticationService.logout();
      this._router.navigate(['/login']);
    }
    debugger
 this.config.getData()
      .subscribe(data => {
        console.log(data);
      });
    this.contactForm1 = this.f1.group({
      name: ['',Validators.required],
      dob: [''],
      // phno: ['',[Validators.required,Validators.pattern(/\-?\d*\.?\d{1,2}/)]],

      //phno: ['',[Validators.required,Validators.pattern(/1?[\s-]?\(?(\d{3})\)?[\s-]?\d{3}[\s-]?\d{1}/)]],
      //contacttype: ['',Validators.required],
      channeltype: ['',Validators.required],
      policyno: [''],
      barbadosid: [''],
      email: ['',[Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\\\.[a-z]{2,4}$')]],
      vehicleregno: [''],
      existingcustomer: [''],
      typeofinq: ['',Validators.required],
      typeofreq: ['',Validators.required],
      othereq: [''],
      typeofprod:['',Validators.required],
      priority: [''],
      dept: [''],
      idtype: [''],
      // otherdept: [''],
      calldetails: ['',Validators.required],
      complaint: [false],
      // lastcorpdnc: [''],
      customereached: ['No'],
      customeresponse: [''],
      remarks: [''],
      followupdate: [''],
      deptemail: this.f1.array(this.otherdepts.emails),
      cellTel:[''],
      faxNo:[''],
      telHome:[''],
      telWork:[''],
      updateContact:false
    });
    this.customerreachval = "No";
    // getting the inquiry number from url snap shot for population of call back details
    let inquiryid =  this.route.snapshot.paramMap.get('inquiryid');
    if(inquiryid==null){
      this.existingshow=false
    }else{
      this.existingshow=true
    }
    let inquirytype = this.route.snapshot.paramMap.get('inq');
    console.log(inquiryid)
    console.log(inquirytype)
    if(inquiryid != null){
    this.getcallbackdata(inquiryid,inquirytype);
  }
  // this.contactForm1.get('deptemail').statusChanges.subscribe(
  //   status => this.chipList.errorState = status === 'INVALID'
  // );
   console.log(this.add);
  }
  initName(name: string): FormControl {
    return this.f1.control(name);
  }

  // validateArrayNotEmpty(c: FormControl) {
  //   if (c.value && c.value.length === 0) {
  //     return {
  //       validateArrayNotEmpty: { valid: false }
  //     };
  //   }
  //   return null;
  // }

  add(event: MatChipInputEvent, form: FormGroup): void {
    const input = event.input;
    const value = event.value;

    // Add name
    if ((value || '').trim()) {
      const control = <FormArray>form.get('deptemail');
      control.push(this.initName(value.trim()));
      console.log("ddddddddddddddddddddd")
      console.log(control.value);
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  remove(form, index) {

    console.log(form);
    form.get('deptemail').removeAt(index);
  }

  // Callbackdata from the id present in the url which is called by a function call by passing arguments
  getcallbackdata(inquiryid,inquirytype){

    return this.http.post<any>(environment.URL + '/queries/getinfo',{id:inquiryid,typeofinquiry:inquirytype}).subscribe((selecteddata) => { // not callback
      console.log(selecteddata);
      debugger
      this.contactForm1.get('existingcustomer').setValue(selecteddata.info['ExistingCustomer']);
    this.contactForm1.get('name').setValue(selecteddata.info['Name']);
    this.contactForm1.get('name').disable();
    this.contactForm1.get('dob').setValue(moment(selecteddata.info['DateOfBirth']).utc().format());
    this.contactForm1.get('dob').disable();
    this.cleardateicon = false;
    //this.contactForm1.get('phno').setValue(selecteddata.info['PhoneNumber']);
    //this.contactForm1.get('phno').disable();
    this.contactForm1.get('policyno').setValue(selecteddata.info['PolicyNumber']);
    this.contactForm1.get('policyno').disable();
    this.contactForm1.get('barbadosid').setValue(selecteddata.info['Id']);
    this.contactForm1.get('barbadosid').disable();
    this.contactForm1.get('email').setValue(selecteddata.info['Email']);
    this.contactForm1.get('email').disable();
    //this.contactForm1.get('contacttype').setValue(selecteddata.info['Contact_Type']);
    //this.contactForm1.get('contacttype').disable();
    this.contactForm1.get('vehicleregno').setValue(selecteddata.info['VehicleRegNo']);
    this.contactForm1.get('vehicleregno').disable();

    this.contactForm1.get('existingcustomer').disable();
    this.contactForm1.get('typeofinq').setValue(selecteddata.info['TypeOfInquiry']);
    this.clearhide = false;
    console.log(selecteddata.info['TypeOfInquiry']);
    // this.onselectedinquiry();
    // if(selecteddata.info['TypeOfInquiry'] == "Outbound"){
    //   this.inoutboundhide = true;
    //   this.lastupdatedate = this.dp.transform(this.today, 'yyyy-MM-dd','es-ES');
    //   this.lastupdatedtime = this.dp.transform(this.today, 'hh:mm:ss a','es-ES');
    //   this.contactForm1.get('customereached').setValidators([Validators.required]);
    //   this.contactForm1.get('customereached').updateValueAndValidity();
    //   this.contactForm1.get('customeresponse').setValidators([Validators.required]);
    //   this.contactForm1.get('customeresponse').updateValueAndValidity();
    //   console.log(this.lastupdatedate)
    //   if(this.lastupdatedate == null || this.lastupdatedtime == null){
    //     console.log("wokkk")
    //     this.lastupdatedate = this.dp.transform(this.today, 'yyyy-MM-dd','es-ES');
    //     this.lastupdatedtime = this.dp.transform(this.today, 'hh:mm:ss a','es-ES');
    //     console.log(this.lastupdatedate)
    //   }
    // }
    // else if(selecteddata.info['TypeOfInquiry'] == "Inbound"){
    //   this.inoutboundhide = false;
    //   this.lastupdatedate = this.dp.transform(this.today, 'yyyy-MM-dd','es-ES');
    //   this.lastupdatedtime = this.dp.transform(this.today, 'hh:mm:ss a','es-ES');
    //   this.contactForm1.get('customereached').clearValidators();
    //   this.contactForm1.get('customereached').updateValueAndValidity();
    //   this.contactForm1.get('customeresponse').clearValidators();
    //   this.contactForm1.get('customeresponse').updateValueAndValidity();
    //   console.log(this.lastupdatedate)
    //   if(this.lastupdatedate == null || this.lastupdatedtime == null){
    //     console.log("wokkk")
    //     this.lastupdatedate = this.dp.transform(this.today, 'yyyy-MM-dd','es-ES');
    //     this.lastupdatedtime = this.dp.transform(this.today, 'hh:mm:ss a','es-ES');
    //     console.log(this.lastupdatedate)
    //   }
    // }
    this.contactForm1.get('typeofreq').setValue(selecteddata.info['TypeOfRequest']);
    this.contactForm1.get('typeofreq').disable();
    this.contactForm1.get('othereq').setValue(selecteddata.info['OtherRequest']);
    this.contactForm1.get('typeofprod').setValue(selecteddata.info['TypeOfProduct']);
    this.contactForm1.get('typeofprod').disable();
    this.contactForm1.get('priority').setValue(selecteddata.info['Priority']);
    if(selecteddata.info['Priority'] != null){
      this.priorityhide = true;
    }
    this.contactForm1.get('priority').disable();
    this.contactForm1.get('dept').setValue(selecteddata.info['TypeOfDepartment']);
    this.contactForm1.get('idtype').setValue(selecteddata.info['Id_Type']);
    this.contactForm1.get('idtype').disable();
    this.contactForm1.get('channeltype').setValue(selecteddata.info['Type_Of_Channel']);
    this.contactForm1.get('channeltype').disable();
    this.contactForm1.get('calldetails').setValue(selecteddata.info['DetailsOfCall']);
    this.contactForm1.get('complaint').setValue(selecteddata.info['Complaints']);
    this.contactForm1.get('customereached').setValue(selecteddata.info['CustomerReached']);
    this.contactForm1.get('customeresponse').setValue(selecteddata.info['CustomerResponse']);
    this.contactForm1.get('remarks').setValue(selecteddata.info['Remarks']);
    this.contactForm1.get('followupdate').setValue(moment(selecteddata.info['FollowUpDate']).utc().format());
  /*
    if(selecteddata.info['DepartmentEmail']==null){
      this.contactForm1.get('deptemail').setValue(" ");
    }else{
      this.contactForm1.get('deptemail').setValue(selecteddata.info['DepartmentEmail']);
    } */
    this.contactForm1.get('cellTel').setValue(selecteddata.info['TelePhone'])
    this.contactForm1.get('cellTel').disable()
    this.contactForm1.get('telHome').setValue(selecteddata.info['TeleHome'])
    this.contactForm1.get('telHome').disable()
    this.contactForm1.get('telWork').setValue(selecteddata.info['TeleWork'])
    this.contactForm1.get('telWork').disable()
    this.contactForm1.get('faxNo').setValue(selecteddata.info['Fax'])
    this.contactForm1.get('faxNo').disable();

    this.contactForm1.get('typeofinq').disable();

    // this.callbackhide = false;


  }, error => {
    console.error("Error", error);
  });
  }
// ngmodelchange event on selection of an option on selected inquiry is triggred
  onselectedinquiry() {
    console.log(this.selectedinquiry);


    if(this.selectedinquiry == "Outbound"){
      this.inoutboundhide = true;

      this.lastupdatedate = this.dp.transform(moment().toDate(), 'yyyy-MM-dd','es-ES');
      this.lastupdatedtime = this.dp.transform(moment().toDate(), 'hh:mm:ss a','es-ES');
      this.contactForm1.get('customereached').setValidators([Validators.required]);
      this.contactForm1.get('customereached').updateValueAndValidity();
      this.contactForm1.get('customeresponse').setValidators([Validators.required]);
      this.contactForm1.get('customeresponse').updateValueAndValidity();
      let inquiryid =  this.route.snapshot.paramMap.get('inquiryid');
      let inquirytype = this.route.snapshot.paramMap.get('inq');
      console.log(inquiryid)
      console.log(inquirytype)
      if(inquiryid == null){
        this.contactForm1.get('channeltype').setValue("None");
        this.contactForm1.get('typeofreq').setValue("None");
        this.contactForm1.get('typeofprod').setValue("None");
    }

      console.log(this.lastupdatedate)
      if(this.lastupdatedate == null || this.lastupdatedtime == null){
        console.log("wokkk")
        this.lastupdatedate = this.dp.transform(moment().toDate(), 'yyyy-MM-dd','es-ES');
        this.lastupdatedtime = this.dp.transform(moment().toDate(), 'hh:mm:ss a','es-ES');
        console.log(this.lastupdatedate)
      }
    }
    else if(this.selectedinquiry == "Inbound"){
      this.inoutboundhide = false;
      this.lastupdatedate = this.dp.transform(moment().toDate(), 'yyyy-MM-dd','es-ES');
      this.lastupdatedtime = this.dp.transform(moment().toDate(), 'hh:mm:ss a','es-ES');
      this.contactForm1.get('customereached').clearValidators();
      this.contactForm1.get('customereached').updateValueAndValidity();
      this.contactForm1.get('customeresponse').clearValidators();
      this.contactForm1.get('customeresponse').updateValueAndValidity();
      if(this.lastupdatedate == null || this.lastupdatedtime == null){
        console.log("wokkk")
        this.lastupdatedate = this.dp.transform(moment().toDate(), 'yyyy-MM-dd','es-ES');
        this.lastupdatedtime = this.dp.transform(moment().toDate(), 'hh:mm:ss a','es-ES');
        console.log(this.lastupdatedate)
      }
    }
  }

  // ngmodelchange event on selection of an option on selected contact type is triggred
  onselectedcontact(){
    if(this.clientid){
      console.log(this.clientid)
      return this.http.post<any>(environment.URL + '/get/contact', {Id:this.clientid,Contact_Type:this.selectedcontact,System: this.system}).subscribe((number) => { // not callback
        console.log(number);
        //this.contactForm1.get('phno').setValue(number['contact_number']);
    }, error => {
      console.error("Error", error);
    });
    }
  }
   // ngmodelchange event on selection of an option on selected ID type is triggred
  onselectedidtype(){
    if(this.clientid){
      console.log(this.clientid)
      console.log(this.selectedidtype)
      if(this.selectedidtype != "None"){
        this.contactForm1.get('barbadosid').setValidators([Validators.required]);
        this.contactForm1.get('barbadosid').updateValueAndValidity();
      }
      return this.http.post<any>(environment.URL + '/get/idnumber', {Id:this.clientid,Id_Type:this.selectedidtype}).subscribe((number) => { // not callback
        console.log(number);
        this.contactForm1.get('barbadosid').setValue(number['ID']);
        if(this.selectedidtype == "None"){
          console.log(this.selectedidtype)
          this.contactForm1.get('barbadosid').clearValidators();
          this.contactForm1.get('barbadosid').updateValueAndValidity();
        }
    }, error => {
      console.error("Error", error);
    });

    }
    else{
      console.log(this.selectedidtype);
    }
    if(this.selectedidtype != "None"){
      this.contactForm1.get('barbadosid').setValidators([Validators.required]);
      this.contactForm1.get('barbadosid').updateValueAndValidity();
    }
    if(this.selectedidtype == "None" || this.selectedidtype == null || this.selectedidtype == undefined){
      console.log(this.selectedidtype)
      this.contactForm1.get('barbadosid').clearValidators();
      this.contactForm1.get('barbadosid').updateValueAndValidity();
    }
  }
   // ngmodelchange event on selection of an option on selected department is triggred
  onselecteddept(){
    console.log(this.selecteddept)

    if(this.selecteddept.includes('Other')){
      console.log("in therrrrrrrr")
      this.otherdept = true;
      this.contactForm1.get('deptemail').setValidators([Validators.required]);
      this.contactForm1.get('deptemail').updateValueAndValidity();
    }
    else{
      this.otherdept = false;
      this.contactForm1.get('deptemail').clearValidators();
      this.contactForm1.get('deptemail').updateValueAndValidity();
    }
  }
   // ngmodelchange event on selection of an option on selected Type of request is triggred
  onselectedreq(){
    console.log(this.selectedreq)

    if(this.selectedreq == "Other"){
      this.othereq = true;
      this.contactForm1.get('othereq').setValidators([Validators.required]);
      this.contactForm1.get('othereq').updateValueAndValidity();
    }
    else{
      this.othereq = false;
      this.contactForm1.get('othereq').clearValidators();
      this.contactForm1.get('othereq').updateValueAndValidity();
    }


    if(this.selectedreq == "Update Contact Details"){
      this.contactForm1.get('email').enable();
      //this.contactForm1.get('phno').enable();
      //this.contactForm1.get('contacttype').enable();
      this.contactForm1.get('barbadosid').enable();
      this.contactForm1.get('idtype').enable();
      this.callbackbuttonhide = false;
    }
    else{
      console.log(this.clientid);
      if(this.clientid != undefined){
        this.contactForm1.get('email').disable();
        //this.contactForm1.get('phno').disable();
        //this.contactForm1.get('contacttype').disable();
        this.contactForm1.get('barbadosid').disable();
        this.contactForm1.get('idtype').disable();
      }
      this.callbackbuttonhide = true;
    }
  }
  // used to search for existing client details when the search button is clicked the below function is triggered
  searchres() {
    debugger
    let name = this.contactForm1.get('name').value;
    let dateofbirth = this.contactForm1.get('dob').value;
    dateofbirth = moment(dateofbirth).format("YYYY-MM-DD");
    //let phone = this.contactForm1.get('phno').value;
    //console.log(phone)
    let policyno = this.contactForm1.get('policyno').value;
    let barbadosid =  this.contactForm1.get('barbadosid').value;
    let email = this.contactForm1.get('email').value;
    let vehicleregno = this.contactForm1.get('vehicleregno').value;
    //let contacttype = this.contactForm1.get('contacttype').value;
    let idtype = this.contactForm1.get('idtype').value;
    let cellTel = this.contactForm1.get('cellTel').value
    let fax = this.contactForm1.get('faxNo').value
    let telHome = this.contactForm1.get('telHome').value
    let telWork = this.contactForm1.get('telWork').value
    if(name || dateofbirth || policyno || barbadosid || email || vehicleregno  ){
      this.isLoadingResults = true;
    }
    console.log(dateofbirth)
    if(dateofbirth == null || dateofbirth == undefined || dateofbirth == "Invalid date"){
      dateofbirth = ''
    }
    console.log(name);
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    };

    return this.http.post<any>(environment.URL + '/get/users', {name:name,dateofbirth:dateofbirth,
      policyno:policyno,id_type:idtype,id:barbadosid,email:email,vehicleregno:vehicleregno,
      telphone:cellTel,fax:fax,
      telhome:telHome,telwork:telWork
    },httpOptions ).subscribe((searchdata) => { // not callback
      debugger
      console.log(searchdata);
      this.isLoadingResults =false;
      if(searchdata){
        this.searchdataobj = searchdata;
      }
   this.searchdata(this.searchdataobj)

  }, error => {
  this.isLoadingResults =false;
    console.error("Error", error);
  });
}
fun($event){
  debugger
  console.log("value",this.contactForm1.get('updateContact').value)
  if(this.contactForm1.get('updateContact').value==true){
    debugger
    this.contactForm1.get('email').enable()
    this.contactForm1.get('cellTel').enable()
    this.contactForm1.get('telHome').enable()
    this.contactForm1.get('telWork').enable()
    if(this.system.includes("Wynsure")){
    this.contactForm1.get('faxNo').disable()}else{
     this.contactForm1.get('faxNo').enable()

    }
    this.contactForm1.get('dept').clearValidators();
        this.contactForm1.get('dept').updateValueAndValidity();
        this.contactForm1.get('dept').reset();
        this.contactForm1.get('deptemail').clearValidators();
        this.contactForm1.get('deptemail').updateValueAndValidity();
        this.contactForm1.get('deptemail').reset();
        this.contactForm1.get('priority').clearValidators();
        this.contactForm1.get('priority').updateValueAndValidity();
        this.contactForm1.get('priority').reset();
        this.contactForm1.get('followupdate').clearValidators();
        this.contactForm1.get('followupdate').updateValueAndValidity()
        this.contactForm1.get('calldetails').clearValidators()
        this.contactForm1.get('calldetails').updateValueAndValidity()
        this.contactForm1.get('typeofprod').clearValidators()
        this.contactForm1.get('typeofprod').updateValueAndValidity()
        this.contactForm1.get('typeofreq').clearValidators()
        this.contactForm1.get('typeofreq').updateValueAndValidity()
        this.contactForm1.get('channeltype').clearValidators()
        this.contactForm1.get('channeltype').updateValueAndValidity()
  }else{
    this.contactForm1.get('email').disable()
    this.contactForm1.get('cellTel').disable()
    this.contactForm1.get('telHome').disable()
    this.contactForm1.get('telWork').disable()

    this.contactForm1.get('faxNo').disable()
    this.contactForm1.get('dept').setValidators(Validators.required)
    this.contactForm1.get('dept').updateValueAndValidity();
    this.contactForm1.get('dept').reset();
    this.contactForm1.get('deptemail').setValidators(Validators.required)
    this.contactForm1.get('deptemail').updateValueAndValidity();
    this.contactForm1.get('deptemail').reset();
    this.contactForm1.get('priority').setValidators(Validators.required)
    this.contactForm1.get('priority').updateValueAndValidity();
    this.contactForm1.get('priority').reset();
    this.contactForm1.get('followupdate').setValidators(Validators.required)
    this.contactForm1.get('followupdate').updateValueAndValidity()
    this.contactForm1.get('calldetails').setValidators(Validators.required)
    this.contactForm1.get('calldetails').updateValueAndValidity()
    this.contactForm1.get('typeofprod').setValidators(Validators.required)
    this.contactForm1.get('typeofprod').updateValueAndValidity()
    this.contactForm1.get('typeofreq').setValidators(Validators.required)
    this.contactForm1.get('typeofreq').updateValueAndValidity()
    this.contactForm1.get('channeltype').setValidators(Validators.required)
    this.contactForm1.get('channeltype').updateValueAndValidity()
  }
}
lastres() {
    let name = this.contactForm1.get('name').value;
    let dateofbirth = this.contactForm1.get('dob').value;
    dateofbirth = moment(dateofbirth).format("YYYY-MM-DD");
   // let phone = this.contactForm1.get('phno').value;
    let policyno = this.contactForm1.get('policyno').value;
    let barbadosid =  this.contactForm1.get('barbadosid').value;
    let email = this.contactForm1.get('email').value;
    let vehicleregno = this.contactForm1.get('vehicleregno').value;
    if(name || dateofbirth || policyno || barbadosid || email || vehicleregno){
      this.isLoadingResults = true;
    }
    console.log(dateofbirth)
  if(dateofbirth == null || dateofbirth == undefined || dateofbirth == "Invalid date"){
      dateofbirth = ''
    }
    console.log(name);
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    };

    return this.http.post<any>(environment.URL + '/queries/last', {name:name,dateofbirth:dateofbirth,
      policyno:policyno,barbadosid:barbadosid,email:email,vehicleregno:vehicleregno},httpOptions ).subscribe((correspondencedata) => { // not callback
      console.log(correspondencedata);

      this.isLoadingResults = false;

      if(correspondencedata){
        this.correspondenceobj = correspondencedata;
      }
   this.correspondencedata(this.correspondenceobj)

  }, error => {
    console.error("Error", error);
  });


  }

// last correspondence dialog call where correspondence data obj is sent to the dialog in order to populate in the form of records
  correspondencedata(correspondenceobj){
    const dialogRef1 = this.dialog.open(CorrespondencedialogComponent,{
      width: '1300px',

      height: '700px',
      data: correspondenceobj,
      autoFocus: false,

    });
    dialogRef1.afterClosed().subscribe(result => {
    },error => {
          console.error("Error", error);
        });
      }
// search client dialog call where client data obj is sent to the dialog in order to populate in the form of records

  searchdata(searchdataobj){
    const dialogRef1 = this.dialog.open(SearchdialogComponent,{
      width: '1250px',

      height: '700px',
      data: searchdataobj,
      autoFocus: false,

    });
    dialogRef1.afterClosed().subscribe(result => {
      console.log(result)
      if(result != true){
        console.log(result);
        this.clientid =  result.ClientID;
        this.system = ";"+" "+"System:"+" "+ result.system;
        let sys =  result.system;
        const httpOptions = {
          headers: new HttpHeaders({ 'Content-Type': 'application/json' })
        };

      return this.http.post<any>(environment.URL + '/get/policy', {ClientID:this.clientid,system:sys,Policy_Number:result.Policy_Number},httpOptions).subscribe((searchdata) => { // not callback
        console.log(searchdata);
        if(searchdata){
          console.log(searchdata);
          console.log(searchdata['ClientData']);
          debugger
          this.contactForm1.get('name').setValue(searchdata['ClientData']['Customer_Name']);
          this.contactForm1.get('name').disable();
          this.contactForm1.get('dob').setValue(moment(searchdata['ClientData']['DOB']).utc().format());
          this.contactForm1.get('dob').disable();
          this.cleardateicon = false;
          // this.contactForm1.get('phno').setValue(searchdata['ClientData']['Phone_Number']);
          // this.contactForm1.get('phno').disable();
          this.contactForm1.get('email').setValue(searchdata['ClientData']['Email']);
          this.contactForm1.get('email').disable();
          // this.selectedidtype = searchdata['ClientData']['Id_Type'];
          this.contactForm1.get('idtype').setValue(searchdata['ClientData']['Id_Type']);
          this.contactForm1.get('idtype').disable();
          this.contactForm1.get('barbadosid').setValue(searchdata['ClientData']['Id']);
          this.contactForm1.get('barbadosid').disable();
          //this.contactForm1.get('phno').setValue(searchdata['ClientData']['Contact']);
          //this.contactForm1.get('phno').disable();
          this.contactForm1.get('vehicleregno').setValue(searchdata['ClientData']['Vehicle_Reg_No']);
          this.contactForm1.get('vehicleregno').disable();
          //this.contactForm1.get('contacttype').setValue(searchdata['ClientData']['ContactType']);
          // this.contactForm1.get('contacttype').disable();
          console.log(searchdata['PolicyData']['Policy_Number']);
          this.contactForm1.get('policyno').setValue(searchdata['ClientData']['Policy_Number']);
          this.contactForm1.get('policyno').disable();
          this.contactForm1.get('existingcustomer').setValue("Yes");
          if(this.contactForm1.get('existingcustomer').value=="Yes"){
            this.search=true;
          }
          this.contactForm1.get('cellTel').setValue(searchdata['ClientData']['telephone'])
        this.contactForm1.get('cellTel').disable()
        this.contactForm1.get('telHome').setValue(searchdata['ClientData']['telhome'])
        this.contactForm1.get('telHome').disable()
        this.contactForm1.get('telWork').setValue(searchdata['ClientData']['telwork'])
        this.contactForm1.get('telWork').disable()
        this.contactForm1.get('faxNo').setValue(searchdata['ClientData']['fax'])
        this.contactForm1.get('faxNo').disable();
          this.contactForm1.get('dob').clearValidators();
          this.contactForm1.get('dob').updateValueAndValidity();
         /// this.contactForm1.get('phno').clearValidators();
         // this.contactForm1.get('phno').updateValueAndValidity();
          this.contactForm1.get('email').clearValidators();
          this.contactForm1.get('email').updateValueAndValidity();
          // this.demo1TabIndex = 1
          this.policytableservice.policydetails(searchdata['PolicyData']);
        }

    }, error => {
      console.error("Error", error);
    });

        }},error => {
          console.error("Error", error);
        });
      }

      // clearing the searching parameters of the client details
      clearsearch(){
        this.clientid = ""
        this.system = ""
        this.cleardateicon = true;
        this.search=false
        this.contactForm1.get('telHome').reset()
        this.contactForm1.get('telWork').reset()
        this.contactForm1.get('name').reset();
        this.contactForm1.get('name').enable();
        this.contactForm1.get('dob').reset();
        this.contactForm1.get('dob').enable();
        //this.contactForm1.get('phno').reset();
        this.contactForm1.get('faxNo').reset()
        //this.contactForm1.get('phno').enable();
        this.contactForm1.get('email').reset();
        this.contactForm1.get('email').enable();
        this.contactForm1.get('idtype').reset();
        this.contactForm1.get('idtype').enable();
        this.contactForm1.get('barbadosid').reset();
        this.contactForm1.get('barbadosid').enable();
        this.contactForm1.get('vehicleregno').reset();
        this.contactForm1.get('vehicleregno').enable();
        //this.contactForm1.get('contacttype').reset();
       // this.contactForm1.get('contacttype').enable();
        this.contactForm1.get('policyno').reset();
        this.contactForm1.get('policyno').enable();
        this.contactForm1.get('updateContact').reset()
        this.contactForm1.get('cellTel').reset()
        this.contactForm1.get('existingcustomer').setValue(false)
        return false;
      }

      // Close the inquiry related dependency action where fields dependency and validators change
      close(){
        // this.isSubmittedradio = true;
        this.depthide = false;
        this.priorityhide = false;
        this.contactForm1.get('dept').clearValidators();
        this.contactForm1.get('dept').updateValueAndValidity();
        this.contactForm1.get('dept').reset();
        this.contactForm1.get('deptemail').clearValidators();
        this.contactForm1.get('deptemail').updateValueAndValidity();
        this.contactForm1.get('deptemail').reset();
        this.contactForm1.get('priority').clearValidators();
        this.contactForm1.get('priority').updateValueAndValidity();
        this.contactForm1.get('priority').reset();
        this.contactForm1.get('followupdate').clearValidators();
        this.contactForm1.get('followupdate').updateValueAndValidity();
        console.log(this.contactForm1.valid)
        if(this.contactForm1.valid){
          this.confirmationdialog("close")
        }
        else{
          this.openSnackBar("Please fill the mandatory fields", "Dismiss");
        }

      }
      // Refer the inquiry related dependency action where fields dependency and validators change
      refer(){
        // this.isSubmittedradio = true;
        debugger
        this.depthide = true;
        this.contactForm1.get('dept').setValidators([Validators.required]);
        this.contactForm1.get('dept').updateValueAndValidity();
        this.priorityhide = true;
        this.contactForm1.get('priority').setValidators([Validators.required]);
        this.contactForm1.get('priority').updateValueAndValidity();

        this.contactForm1.get('calldetails').setValidators(Validators.required)
        this.contactForm1.get('calldetails').updateValueAndValidity()
        this.contactForm1.get('typeofprod').setValidators(Validators.required)
        this.contactForm1.get('typeofprod').updateValueAndValidity()
        this.contactForm1.get('typeofreq').setValidators(Validators.required)
        this.contactForm1.get('typeofreq').updateValueAndValidity()
        this.contactForm1.get('channeltype').setValidators(Validators.required)
        this.contactForm1.get('channeltype').updateValueAndValidity()
        if(this.contactForm1.valid){
        this.confirmationdialog("refer")
        }
        else{
          this.openSnackBar("Please fill the mandatory fields", "Dismiss");
        }
      }
      //Setting the Callback related dependency action where fields dependency and validators change
      callback(){
        this.depthide = false;
        this.otherdept = false;
        this.priorityhide = true;
        this.contactForm1.get('dept').clearValidators();
        this.contactForm1.get('dept').updateValueAndValidity();
        this.contactForm1.get('dept').reset();
        this.contactForm1.get('priority').setValidators([Validators.required]);
        this.contactForm1.get('priority').updateValueAndValidity();
        this.contactForm1.get('followupdate').setValidators(Validators.required)
        this.contactForm1.get('followupdate').updateValueAndValidity()
        this.contactForm1.get('calldetails').setValidators(Validators.required)
        this.contactForm1.get('calldetails').updateValueAndValidity()
        this.contactForm1.get('typeofprod').setValidators(Validators.required)
        this.contactForm1.get('typeofprod').updateValueAndValidity()
        this.contactForm1.get('typeofreq').setValidators(Validators.required)
        this.contactForm1.get('typeofreq').updateValueAndValidity()
        this.contactForm1.get('channeltype').setValidators(Validators.required)
        this.contactForm1.get('channeltype').updateValueAndValidity()

        // this.isSubmittedradio = true;
        if(this.contactForm1.valid){
        this.confirmationdialog("callback")
        }
        else{
          this.openSnackBar("Please fill the mandatory fields", "Dismiss");
        }
      }submit(){

      }

      // on radio button change value dependency from existing customer radio buttons
      radioChange($event: MatRadioChange) {
        console.log($event.source.name, $event.value);

        if ($event.source.value == 'Yes') {
          this.contactForm1.get('dob').clearValidators();
      this.contactForm1.get('dob').updateValueAndValidity();
      //this.contactForm1.get('phno').clearValidators();
      //this.contactForm1.get('phno').updateValueAndValidity();
      this.contactForm1.get('email').clearValidators();
      this.contactForm1.get('email').updateValueAndValidity();
        }
        else{
          this.contactForm1.get('dob').setValidators([Validators.required]);
          this.contactForm1.get('dob').updateValueAndValidity();
          //this.contactForm1.get('phno').setValidators([Validators.required]);
         // this.contactForm1.get('phno').updateValueAndValidity();
          this.contactForm1.get('email').setValidators([Validators.required]);
          this.contactForm1.get('email').updateValueAndValidity();
        }
    }
      openSnackBar(message: string, action: string) {
        this.snackBar.open(message, action, {
          duration: 2000,
        });
      }
// confirmation dialog on click of any action buttons like refer, close, callback
      confirmationdialog(action){
        const dialogRef2 = this.dialog.open(ConfirmdialogComponent,{
          width: '380px',

          height: '200px',
          data: action,
          autoFocus: false,

        });
        dialogRef2.afterClosed().subscribe(result => {
          console.log(result);
          if(result != "no"){
            debugger
            let name = this.contactForm1.get('name').value;
            let dateofbirth = this.contactForm1.get('dob').value;
            console.log(dateofbirth)
            dateofbirth = moment(dateofbirth).format("YYYY-MM-DD");
            console.log(dateofbirth)
            //let phone = this.contactForm1.get('phno').value;
            let policyno = this.contactForm1.get('policyno').value;
            let barbadosid =  this.contactForm1.get('barbadosid').value;
            let idtype = this.contactForm1.get('idtype').value;
            let email = this.contactForm1.get('email').value;
            let vehicleregno = this.contactForm1.get('vehicleregno').value;
            let existingcustomer = this.contactForm1.get('existingcustomer').value;
            if(existingcustomer == "" || existingcustomer == undefined || existingcustomer == null){
                existingcustomer = "No"
            }
            let typeofreq = this.contactForm1.get('typeofreq').value;
            console.log(typeofreq)
            if(typeofreq==undefined || typeofreq==null){
typeofreq=""
            }
            let typeofinqiry = this.contactForm1.get('typeofinq').value;
            let othereq1 = this.contactForm1.get('othereq').value;
            let typeofprod = this.contactForm1.get('typeofprod').value;
            let priority = this.contactForm1.get('priority').value;
            let dept = this.contactForm1.get('dept').value;
            const control = <FormArray>this.contactForm1.get('deptemail');
            // control.push(this.initName(value.trim()));
            console.log("ddddddddddddddddddddd")
            console.log(control.value);
            // let otherdept = this.contactForm1.get('otherdept').value;
            let deptemail = control.value;

            let calldetails = this.contactForm1.get('calldetails').value;
            let customereached = this.contactForm1.get('customereached').value;
            let customeresponse = this.contactForm1.get('customeresponse').value;
            let notes = this.contactForm1.get('remarks').value;
            let followupdate = this.contactForm1.get('followupdate').value;
            console.log(followupdate);
            if(followupdate != undefined){
              followupdate = moment(followupdate).format("YYYY-MM-DD");
            }

            let complaint = this.contactForm1.get('complaint').value;
            let channeltype = this.contactForm1.get('channeltype').value;
            //let contacttype = this.contactForm1.get('contacttype').value;
            let status = result;

            let startdate = this.lastupdatedate;
            var starttime = startdate + ' ' + this.lastupdatedtime;
            console.log("start time")
            console.log(starttime)
            starttime = starttime.replace(/\-/g, '/');
            console.log(starttime)
            // starttime = starttime.toString();
            // console.log(Date.parse(starttime) || 0)
            // console.log("starttime using js parse")
            // console.log(Date.parse(starttime) || 0)
            // var starttimedate = new Date(starttime);
            // var starttimedate = starttime;
            // var starttimedate = moment(starttime).format('YYYY-MM-DD[T]HH:mm:ss');
            var starttimedate = moment(new Date(starttime)).format('YYYY-MM-DD HH:mm:ss');
            // var starttimedate = moment(starttime, 'YYYY-MM-DD hh:mm:ss a');
            console.log("start timee datee")
            console.log(starttimedate)
            // let endtime = new Date();
            // if(starttimedate == null || starttimedate == undefined || starttimedate == "Invalid date"){
            //   // starttimedate = moment(starttime).toDate(), 'yyyy-MM-dd hh:mm:ss a');
            //   console.log("invalid dateeee")
            // }
            let endtime = moment().format('YYYY-MM-DD HH:mm:ss');
            // let endtime = new Date();
            // endtime = endtime.toString();
            console.log(endtime)
            let username = JSON.parse(this.securestore.getitem('currentUser'));
            username = username['username']
            console.log(username);
            // console.log(starttime);
            console.log(startdate);
            // console.log(endtime);
            console.log(moment(followupdate).format("YYYY-MM-DD"));
            if(followupdate == null || followupdate == undefined || followupdate == "Invalid date"){
              followupdate = ''
            }
            else if(dateofbirth == null || dateofbirth == undefined || dateofbirth == "Invalid date"){
              console.log(dateofbirth)
              console.log("===========")
              dateofbirth = ''
            }

            if(result == "callback"){
              status = "open"
            }
this.isLoadingResults = true;
            const httpOptions = {
              headers: new HttpHeaders({ 'Content-Type': 'application/json' })
            };
            debugger
            let inquiryid =  this.route.snapshot.paramMap.get('inquiryid');
            let emails = this.contactForm1.get('email').value
            let cellTel = this.contactForm1.get('cellTel').value
            let fax = this.contactForm1.get('faxNo').value
            let telHome = this.contactForm1.get('telHome').value
            let telWork = this.contactForm1.get('telWork').value
            let update_contact = this.contactForm1.get('updateContact').value
            console.log(inquiryid)
            return this.http.post<any>(environment.URL + '/queries/inquiry', {Type_Of_Channel:channeltype,inquiryid:inquiryid,Customer_Name:name,Date_Of_Birth:dateofbirth,Id:barbadosid,
             username:username,Call_Type:typeofinqiry,Call_Start_Time:starttimedate,Call_Date:startdate,
              Call_End_Time:endtime,product_desc:typeofprod,req_desc:typeofreq,Priority:priority,Status:status,dept_name:dept,
              telphone:cellTel,fax:fax,email:emails,
      telhome:telHome,telwork:telWork,update_contact:update_contact,
              Dept_email:deptemail,Other_Request:othereq1,Call_Details:calldetails,Customer_Reached:customereached,Customer_Response:customeresponse
              ,Remarks:notes,Complaint :complaint,Follow_Up_Date:followupdate,Id_Type:idtype,Existing_Customer:existingcustomer,Policy_Number:policyno,Vehicle_Reg_No:vehicleregno,Email:email,System:this.system,ClientID: this.clientid},httpOptions).subscribe((aftersubmit) => { // not callback
              this.isLoadingResults = false;
 console.log(aftersubmit);
              if(aftersubmit['result'] == "Success"){
                this.openBottomSheet();
              }
              else if(aftersubmit['result'] == "Successcallback"){
this.openSnackBar("Submitted Successfully","Dismiss");
this.router.navigate(['/inquiries',username]);
this.contactForm1.reset();
this.contactForm1.enable();
this.callbackhide = true;
// window.location.reload();
              }

          }, error => {
            console.error("Error", error);
          });

      }
      else{

      }
    });
    }
// open bottom sheet popup in order to ask for adding another inquiry
    openBottomSheet() {
      let sheetRef =  this.bottomSheet.open(BottomSheetComponent, {
        disableClose: true,
      });
      sheetRef.afterDismissed().subscribe( data => {
        console.log('after close data :', data);
        if(data && data.message=='Cancel') {
          window.location.reload();
        }else if(data && data.message=='Status') {
          this.followupdatem = '';
          this.calldetailsm = '';
          this.notesm = '';
          this.contactForm1.get('complaint').reset();
          this.contactForm1.get('channeltype').reset();
            this.contactForm1.get('typeofreq').reset();
            this.contactForm1.get('typeofinq').reset();
            this.contactForm1.get('othereq').reset();
            this.contactForm1.get('typeofprod').reset();
            this.contactForm1.get('priority').reset();
            this.contactForm1.get('dept').reset();

            this.contactForm1.get('deptemail').reset();
            this.contactForm1.get('customereached').reset();
            this.contactForm1.get('customeresponse').reset();

            this.lastupdatedate = '';
            this.lastupdatedtime= '';
            this.contactForm1.get('otherdept').reset();
        }
      });
    }
    // clear date picker data for date of birth field
    clearDate(event) {
      event.stopPropagation();
      this.contactForm1.get('dob').setValue("");
    }
        // clear date picker data for follow up date field
    clearDatefollow(event) {
      event.stopPropagation();
      this.contactForm1.get('followupdate').setValue("");
    }


}
