import { Component, OnInit, ViewChild, Inject, AfterViewInit } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import { MatTableDataSource, MAT_DIALOG_DATA, MatDialogRef, MatSort } from '@angular/material';
@Component({
  selector: 'app-correspondencedialog',
  templateUrl: './correspondencedialog.component.html',
  styleUrls: ['./correspondencedialog.component.css']
})
export class CorrespondencedialogComponent implements OnInit,AfterViewInit {
  displayedColumns: string[] = ['Task_Id','Call_Date','Policy_No', 'Customer_Name', 'Type_Of_Inquiry', 'Details_Call','username','Closed_Days','Status','Resolution_Notes'];
  element: any;
  dataSource = new MatTableDataSource<any>();
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static:true}) sort: MatSort
  constructor(
    @Inject(MAT_DIALOG_DATA) public data,
    public dialogRef :MatDialogRef<CorrespondencedialogComponent>,
  ) { }
  ngOnInit() {
    console.log(this.data.Clients);
    this.element = this.data.Clients;
    this.dataSource = new MatTableDataSource(this.data.Clients);

  }
  ngAfterViewInit (){
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
}
