import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorrespondencedialogComponent } from './correspondencedialog.component';

describe('CorrespondencedialogComponent', () => {
  let component: CorrespondencedialogComponent;
  let fixture: ComponentFixture<CorrespondencedialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorrespondencedialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorrespondencedialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
