import { Component, OnInit, AfterViewInit,ViewChild, Inject } from '@angular/core';
// import {MatPaginator} from '@angular/material/paginator';
import { MatTableDataSource, MAT_DIALOG_DATA, MatDialogRef, MatSort } from '@angular/material';
@Component({
  selector: 'app-searchdialog',
  templateUrl: './searchdialog.component.html',
  styleUrls: ['./searchdialog.component.css']
})
export class SearchdialogComponent implements OnInit,AfterViewInit {
  displayedColumns: string[] = ['Customer_Name', 'Policy_Number', 'DOB', 'Id_Type','system','Status','edit'];
  element: any;
  dataSource = new MatTableDataSource<any>();
  // @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static:true}) sort: MatSort;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data,
    public dialogRef :MatDialogRef<SearchdialogComponent>,
  ) { }
  ngOnInit() {
    console.log(this.data.Clients);
     // assigning the data source from the emitted data by dialog data 
    this.element = this.data.Clients;
    this.dataSource = new MatTableDataSource(this.data.Clients);
   
    // this.dataSource.paginator = this.paginator;
 console.log(this.dataSource)
  }
  ngAfterViewInit (){
    this.dataSource.sort = this.sort;
  }
  onSelect(selectedelement) {
    console.log("Selected item Id: ", selectedelement); // You get the Id of the selected item here
    this.dialogRef.close(selectedelement);
}
}
