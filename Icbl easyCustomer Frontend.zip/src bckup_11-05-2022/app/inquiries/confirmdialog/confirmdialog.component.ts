import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
@Component({
  selector: 'app-confirmdialog',
  templateUrl: './confirmdialog.component.html',
  styleUrls: ['./confirmdialog.component.css']
})
export class ConfirmdialogComponent implements OnInit {
  action: string = ""
  constructor(@Inject(MAT_DIALOG_DATA) private data: any,public dialogRef :MatDialogRef<ConfirmdialogComponent>) {
    if (data) {
      this.action = data || this.action;
      }
   }

  ngOnInit() {
  }
  yes(data){
    console.log(data);
    this.dialogRef.close(data);
    }
}
