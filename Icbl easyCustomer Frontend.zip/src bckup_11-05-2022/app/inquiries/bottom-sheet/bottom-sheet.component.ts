import { Component, OnInit, Inject } from '@angular/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA} from '@angular/material';
@Component({
  selector: 'app-bottom-sheet',
  templateUrl: './bottom-sheet.component.html',
  styleUrls: ['./bottom-sheet.component.css']
})
export class BottomSheetComponent implements OnInit {

  constructor(private bottomSheetRef: MatBottomSheetRef<BottomSheetComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {}

// on click of No for not adding any additional inquiry
  clearBar(): void {
    this.bottomSheetRef.dismiss({
      message: 'Cancel',
      data: this.data
    });
    event.preventDefault();
  }
// on click of Yes for adding any additional inquiry the data is again sent back to the reciever component on dismiss
  changeStatus() {
    this.bottomSheetRef.dismiss({
      message: 'Status',
      data: this.data
    });
  }

  ngOnInit() {
    console.log('data received', this.data);
  }

}
