import { Component } from '@angular/core';
// import { DataSource } from '@angular/cdk/collections';
// import { Observable, of } from 'rxjs';
import { animate, state, style, transition, trigger } from '@angular/animations';
import {policytableservice} from '../inquiries.component';
import {MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-searchtable',
  templateUrl: './searchtable.component.html',
  styleUrls: ['./searchtable.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0', display: 'none'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class SearchtableComponent{
  constructor(private policytableservice:policytableservice){

  }
  columnsToDisplay = ['Policy_Number', 'Customer_Name', 'DOB'];
  dataSource: MatTableDataSource<any>;
  policydata: Element[] = [];
  expandedElement: null;
  ngAfterViewInit() {
    // assigning the data source from the emitted data by policytableservice 
    this.policytableservice.$data.subscribe((data)=>{
    
    
      this.policydata = data
      console.log("in driver table now ng after view");
     
      this.dataSource = new MatTableDataSource(this.policydata);
      this.policydata = this.policydata;
      
          });
  }
}

export interface Element {
  Customer_Name: string;
  Policy_Number: string;
  DOB: string;

}

