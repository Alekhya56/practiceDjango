import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { SecureLocalStorageService } from '../../_services';
import { environment } from 'src/environments/environment';
import { Validators } from '@angular/forms';
import { prepareEventListenerParameters } from '@angular/compiler/src/render3/view/template';
@Component({
  selector: 'app-edit-all-inquiry',
  templateUrl: './edit-all-inquiry.component.html',
  styleUrls: ['./edit-all-inquiry.component.css'],
  providers: [DatePipe]
  
})
export class EditAllInquiryComponent implements OnInit {
  today: number;
  editall:FormGroup;
  data1: any;
  existing:any
  savedisable:boolean=false
  constructor(private snackBar: MatSnackBar,private securestore:SecureLocalStorageService, public dialogRef: MatDialogRef<EditAllInquiryComponent>,
    private formbuilder : FormBuilder, @Inject(MAT_DIALOG_DATA) public data,private http:HttpClient,
    private dp: DatePipe) { 
      dialogRef.disableClose = true;
      setInterval(() => {
        this.today = Date.now();
      }, 1);
      console.log(data);
      this.data1=data['row']
    }

  ngOnInit() {
    this.editall=this.formbuilder.group({
fieldvalue:['',Validators.required],
fieldvalue1:[''],

    });
    console.log(this.data1)
    if(this.data1['Close_Comment']!=null){
this.existing="Existing Comments"+" "+"-"+" "+"by"+this.data1['Last_Updated_By']+" "+"on"+" "+this.data1['Last_Updated_Date']
      this.editall.get('fieldvalue1').setValue(this.data1['Close_Comment'])


this.savedisable=true
    }
    else{
      this.savedisable=false
    }
    }
get formcontrols(){
  return this.editall.controls
}
openSnackBar(message: string, action: string) {
  this.snackBar.open(message, action, {
    duration: 2000,
  });
}
closedialog(){
  debugger
  if(this.editall.valid){
    //this.savedisable=false
  let comment=this.editall.get('fieldvalue').value
  this.data1['Last_Updated_Date']=this.dp.transform(this.today, 'yyyy-MM-dd', 'es-ES');
  let username = JSON.parse(this.securestore.getitem('currentUser'));
  username=username['username']
  this.data1['Close_Comment']=comment
  this.data1['Closed_By']=username
  return this.http.post<any>(environment.URL + '/queries/close_comments',
this.data1).subscribe((searchdata) => { 
  debugger
  
    this.close()
  
  console.log(searchdata);

}, error => {
console.error("Error", error);
});
}
else{
  this.editall.get('fieldvalue').setValidators(Validators.required)
  this.openSnackBar("Please fill mandatory details","Dismiss")
}
}
close(){
  this.dialogRef.close()
  
}
value(){
  
}
}
