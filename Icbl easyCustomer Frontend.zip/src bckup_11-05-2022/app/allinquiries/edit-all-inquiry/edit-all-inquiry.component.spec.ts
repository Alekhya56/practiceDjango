import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAllInquiryComponent } from './edit-all-inquiry.component';

describe('EditAllInquiryComponent', () => {
  let component: EditAllInquiryComponent;
  let fixture: ComponentFixture<EditAllInquiryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditAllInquiryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditAllInquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
