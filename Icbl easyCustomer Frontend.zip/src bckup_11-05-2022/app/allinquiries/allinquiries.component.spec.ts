import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllinquiriesComponent } from './allinquiries.component';

describe('AllinquiriesComponent', () => {
  let component: AllinquiriesComponent;
  let fixture: ComponentFixture<AllinquiriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllinquiriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllinquiriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
