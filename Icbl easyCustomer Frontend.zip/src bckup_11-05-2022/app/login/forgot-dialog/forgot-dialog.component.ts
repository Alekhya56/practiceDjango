import { Component, OnInit, Input } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormBuilder, Validators, FormControl, FormGroupDirective, NgForm } from '@angular/forms';
import { MatSnackBar, ErrorStateMatcher } from '@angular/material';
import { Router } from '@angular/router';
import { map, delay } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-forgot-dialog',
  templateUrl: './forgot-dialog.component.html',
  styleUrls: ['./forgot-dialog.component.css']
})
export class ForgotDialogComponent implements OnInit {
  recoverPswdEmailForm : FormGroup;
  email: any;
  submitted = false;
  username: any;
  matcher = new MyErrorStateMatcher();
 


  constructor( private formBuilder : FormBuilder,
    private snackbar : MatSnackBar, private route : Router, private http : HttpClient,private router: Router,
    public dialogRef: MatDialogRef<ForgotDialogComponent>) { 
      this.recoverPswdEmailForm = this.formBuilder.group({ username: ['', Validators.required],
      email:['', [Validators.required,Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]]});
    }

    ngOnInit() {
      this.username = this.f.username.value;
      this.email = this.f.email.value;
    }
  
    get f(){
      return this.recoverPswdEmailForm.controls;
    }
    onSubmit() {
      this.submitted = true;
  
      if (this.recoverPswdEmailForm.invalid) {
        console.log('Form is invalid');
        return;
      }
      this.sendresetPassword();
  
    }
  
    getEmail() {
  
      this.http.get(environment.URL+'/').subscribe(emails => {
        console.log(emails)
        if (emails['users'].length>0 && this.f.email.value === emails[0]['email']) {
          this.sendresetPassword();
        } else {
          this.openSnackBar('Username/Email doesn\'t match', );
        }
      },
      err => { console.log(err); });
    }
  
    sendresetPassword(){
      console.log(this.f.email.value)
      if(this.recoverPswdEmailForm.valid){
      this.http.post(environment.URL + '/auth/password/reset',
      { Email : this.f.email.value , 
        request_type : 'Email',
        username:this.f.username.value}).subscribe(data=>{
        console.log(data);
        this.openSnackBar('Mail with auto-generated password has been sent to your registered email');
        this.route.navigate(['/login']);
        this.dialogRef.close();
      },
      err=>{
        console.log(err);
        this.openSnackBar("Could not find user");
        this.route.navigate(['/login']);
        this.dialogRef.close();
      });
    }
     
    }
  
    openSnackBar(message){
      this.snackbar.open(message, 'Dismiss', {
        duration: 3000
      });
    }
 

  onNoClick(): void {
    this.dialogRef.close();
  }

}
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {

    const invalidCtrl = !!(control.touched && control && control.invalid && control.parent.dirty);
    const invalidParent = !!(control.touched && control && control.parent && control.parent.invalid && control.parent.dirty);
    return (invalidCtrl || invalidParent);
  }
}