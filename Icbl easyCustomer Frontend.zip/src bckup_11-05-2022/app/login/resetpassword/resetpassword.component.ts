import { Component, OnInit, forwardRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { AuthenticationService, SecureLocalStorageService }  from '../../_services';
import { MatSnackBar } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Role } from 'src/app/_models/role';
import { PasswordStrengthValidator } from '../../_helpers/password-strength.validator';

@Component({
  selector: 'app-resetpassword',
  providers :[{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ResetpasswordComponent), multi: true }],
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {

  resetPasswordForm : FormGroup;
  submitted: boolean;
  username : string;
  role: string;
  hide : boolean = true;
  hide_o : boolean = true;
  hide_n : boolean = true;

  constructor(private fb  : FormBuilder,
    private _snackBar :MatSnackBar, private activatedRoute : ActivatedRoute, 
    private router : Router,
    private http : HttpClient, private authenticationService : AuthenticationService,private securestore: SecureLocalStorageService) { 
    this.resetPasswordForm = this.fb.group({
      oldPassword : [],
      password : ['', [Validators.required, PasswordStrengthValidator]],
      newPassword : ['', [Validators.required, PasswordStrengthValidator]],
    },
       { validator: this.checkPasswords
      });
    // this.username = this.activatedRoute.snapshot.params['username'];
    this. username = JSON.parse(securestore.getitem('currentUser'));
    this.username = this.username['username']
console.log(this.username);
    this.role = this.authenticationService.currentUserValue['role'];
  }

  ngOnInit() {
  }
  checkPasswords(group: FormGroup) { // here we have the 'passwords' group
  let pass = group.get('password').value;
  let confirmPass = group.get('newPassword').value;

  return pass === confirmPass ? null : { notSame: true }
  }
  get f() {
    return this.resetPasswordForm.controls;
  }
  onSubmit(){
    if(this.resetPasswordForm.invalid){
      console.log("inva")
      this.openSnackBar("We found a mismatch/errors in the above details.Please fix them before continuing!");
      return;
    }
    this.submitted = true;
    console.log(this.f.oldPassword.value)
    console.log(this.f.newPassword.value)
    if(this.f.oldPassword.value==this.f.newPassword.value){
      this.openSnackBar("Old Password and new password should not be same");
    }
    else{
      console.log("inchane")
    this.http.post(environment.URL + '/auth/password/change', {
      oldPassword : this.f.oldPassword.value,
      newPassword : this.f.newPassword.value,
      user : this.username
    }).subscribe(data => {
      console.log(data);
      const successMsg = 'Password is updated successfully';
      this.openSnackBar(successMsg);
      console.log(this.role);
     if (this.role === Role.Admin){
          this.logout();
        } else if(this.role===Role.CSR){
            this.logout();
        }
  
      else {
        this.router.navigate(['/authentication',this.username]);
      }
    },
    error => {
      console.log(error);
      // this.openSnackBar(error);
    });
  }
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, 'Dismiss', {
      duration: 3000
    });
  }

  logout(){
    this.authenticationService.logout();
  }


}
