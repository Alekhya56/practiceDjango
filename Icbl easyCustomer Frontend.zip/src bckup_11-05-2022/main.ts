import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from 'src/environments/environment';

if (environment.production) {
  enableProdMode();


}

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));

// export var counter = 0;
 
// if(counter == 0){
// export var tame = setInterval(()=>{  
//     platformBrowserDynamic().bootstrapModule(AppModule); 
    
//   },2900);


// var tame=setInterval(()=>{
//     platformBrowserDynamic().bootstrapModule(AppModule).then(ref => {
//       // Ensure Angular destroys itself on hot reloads.
//       if (window['ngRef']) {
      
//         window['ngRef'].destroy();
//        // registerServiceWorker('sw');
//         clearInterval(tame);
//       }
//       window['ngRef'] = ref;
    
//       // Otherise, log the boot error
//     }).catch(err => console.error(err));  
//   },1000);
//   counter++;
// }
// else{
//   console.log(tame);
//   console.log(counter);
//   clearInterval(tame);
//   platformBrowserDynamic().bootstrapModule(AppModule); 
// }
//   console.log("sdjkbfjksavbd");
//   console.log(tame);
  // localStorage.setItem("tame", tame);
  // clearInterval(tame);
  // ngOnInit() {
  //   this.getQuote();
  //   var tame = setInterval(this.getQuote, 2900);
  // }


// function registerServiceWorker(swName: string) {
//   if ('serviceWorker' in navigator) {
//     navigator.serviceWorker
//       .register(`${swName}.js`)
//       .then(reg => {
//         console.log('[App] Successful service worker registration', reg);
//       })
//       .catch(err =>
//         console.error('[App] Service worker registration failed', err)
//       );
//   } else {
//     console.error('[App] Service Worker API is not supported in current browser');
//   }
// }
