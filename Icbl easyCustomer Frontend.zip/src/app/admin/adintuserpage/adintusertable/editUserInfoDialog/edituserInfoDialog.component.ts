import {Component, Inject} from '@angular/core';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthenticationService, SecureLocalStorageService,ConfigService } from '../../../../_services';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
// import { PhoneNumberValidator } from 'src/app/_helpers/phonenumber.validator';
import { PasswordStrengthValidator } from 'src/app/_helpers/password-strength.validator';
import { trigger } from '@angular/animations';
@Component({
    templateUrl :'editUserInfoDialog.html',
    // styleUrls:['editMemberInfo.css']
    })
    export class editUserInfoDialogComponent{

      editInfoForm : FormGroup;
      // postdata: { role: any; username: any; displayname: any; email: any; sessionTime: any; statuschange: boolean; passwordchange: boolean; phonenumber: any; };
      postdata : any;
      hide :boolean =true;
      typeofdepartment:any[]=[];
    constructor(private config: ConfigService,
      public dialogRef: MatDialogRef<editUserInfoDialogComponent>,
      private formbuilder : FormBuilder,
      private _snackbar : MatSnackBar,
      private http : HttpClient,
      @Inject(MAT_DIALOG_DATA) public data) {
          this.editInfoForm = this.formbuilder.group({
          email: [this.data.row.Email, [Validators.email, Validators.required]],
         // password: [''],
          displayname : [this.data.row.DisplayName, Validators.required],

          checked : ['false', Validators.required],
          dept : [this.data.row.Department],
          permission:[this.data.row.Permissions],
          team: [this.data.row.Team],
          password : ['', Validators.compose([
             PasswordStrengthValidator])]
        });
      }

  ngOnInit(){
    console.log(this.data.row);
    this.config.getData()
    .subscribe(data => {
      console.log(data);


    this.typeofdepartment=  Object.values(data.Departments)


    });
    console.log(this.editInfoForm.controls);
    if(this.data.row.Role=="Admin"){
this.editInfoForm.get('permission').disable()
    }
  }
  trackByFn(index, item) {
  return item.id;
}
  // return edit form controls
  get formcontrols(){
    return this.editInfoForm.controls;
  }

    onNoClick(): void {
      this.dialogRef.close();
    }
  // on submit of edit form dialog data
    onSubmit(){
     // if(this.f.checked.value){
        // this.firebaseService.updateIntUserInfo(this.data.row.key, this.f.displayname.value,
        // this.f.email.value, this.f.sessionTime.value);
        debugger
        if(this.formcontrols.password.value){
          debugger
          this.postdata =   {
            role : this.data.row.Role,
            user : this.data.row.Username,
            displayname :  this.formcontrols.displayname.value,
            email : this.formcontrols.email.value ,
            Department : this.formcontrols.dept.value,
            Team: this.formcontrols.team.value,
            passwordchange : this.formcontrols.checked.value == 'true' ? true : false,
            statuschange : false,
            password : this.formcontrols.password.value,
            Permissions:this.formcontrols.permission.value

          }
        }
          else {
            debugger
            this.postdata =    {
              role : this.data.row.Role,
              user : this.data.row.Username,
              displayname :  this.formcontrols.displayname.value,
              email : this.formcontrols.email.value ,
              Department : this.formcontrols.dept.value,
              Team: this.formcontrols.team.value,
              passwordchange : this.formcontrols.checked.value == 'true' ? true : false,
              statuschange : false,

              Permissions:this.formcontrols.permission.value
            }
          }
          console.log(this.postdata);
        if(this.editInfoForm.valid){
        this.http.post(environment.URL + '/admin/user/update', this.postdata).subscribe(data => {
            console.log(data)
            this.openSnackBar('Info Updated Successfully');
            this.onNoClick()
          },
          error => {
            console.log(error);
            this.openSnackBar(error)
          });
        }

      //   if (this.f.checked.value === 'true') {
      //     this.http.post(environment.URL + '/resetpass', {
      //       request_type: 'admin',
      //       username : this.data.row.Username,
      //       email : this.f.email.value,
      //     }).subscribe(data => {
      //       console.log(data);
      //       const successMsg = 'Password is updated successfully';
      //       this.openSnackBar(successMsg);
      //     },
      //     error => {
      //       console.log(error);
      //       this.openSnackBar(error);
      //     });
      //     this.onNoClick();
      // } else {
      //   this.openSnackBar('Info Updated Successfully');
      //   this.onNoClick();
      // }
    //}
    }

    openSnackBar(msg){
      this._snackbar.open(msg, 'Dismiss',{duration : 3000});
    }
    }
