import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs-compat';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
@Injectable()
export class ConfigService {

  constructor(private http: HttpClient) { }

  getData() {
 return this.http.get<any>(environment.URL +'/queries/get_lookup_values');
  }


}
