import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
// import {MatPaginator} from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { EditreferdialogComponent } from '../referred/editreferdialog/editreferdialog.component';
import { MatDialog, MatPaginator, MatSort, throwMatDialogContentAlreadyAttachedError } from '@angular/material';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { DatePipe } from '@angular/common';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
import { AppDateAdapter, APP_DATE_FORMATS} from '../inquiries/date.adapter';
import { ViewOptions } from '../view-options';
import { AuthenticationService, SecureLocalStorageService,ConfigService } from '../_services';
@Component({
  selector: 'app-referred',
  templateUrl: './referred.component.html',
  styleUrls: ['./referred.component.css'],
  providers: [DatePipe,{
    provide: DateAdapter, useClass: AppDateAdapter
},
{
    provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
}]
})
export class ReferredComponent implements AfterViewInit, OnInit {
  displayedColumns: string[] = ['Task_Id','Call_Date','Policy_No', 'Customer_Name', 'Type_Of_Request','Type_Of_Inquiry','InitialDepartment_Name','ReassignDepartment_Name', 'Details_Call', 'Last_Updated_By','Days_Open','Resolution_Notes','edit'];
  dataSource = new MatTableDataSource<any>();
  element: any;
  callcount: number;
  count1: number = 0;
  data:any[]=[]
  searchform: FormGroup;
  isLoadingResults: boolean = false;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, {static:true}) sort: MatSort;
  no_of_records: any;
  displayNoRecords: boolean;
  routerUrl = this.router.url
  isReferred:boolean
search:boolean=false
  search_records: any;
  typeofdepartment:any[]=[];
typeofchannel:any[]=[];
typeofproduct:any[]=[];
typeofrequest:any[]=[]
typeofcustomerresponse:any[]=[]
  searchrecords: any;
  constructor(private config: ConfigService,private datepipe:DatePipe,private snackBar:MatSnackBar,private f1: FormBuilder, private http: HttpClient, private dialog: MatDialog,
    private router: Router) {

  }
  ngAfterViewInit(): void {
    this.paginator.length=this.searchrecords
    this.dataSource.paginator = this.paginator;
    this.sort.sortChange.subscribe((sort: MatSort) => {
      debugger
      console.log('sortChange', this.sort.active);

      this.refresh(this.getCurrentOptions());
    });

  }
  ngOnInit() {
    this.config.getData()
    .subscribe(data => {
      console.log(data);

      this.typeofproduct=Object.values(data.Products)
      this.typeofchannel=Object.values(data.Type_of_channel)

      this.typeofrequest=Object.values(data.requests)
    this.typeofdepartment=  Object.values(data.Departments)

      console.log(this.typeofchannel,this.typeofdepartment,this.typeofproduct)


    });
    console.log("paginator", this.paginator)
    this.searchform = this.f1.group({
      username: [''],
      customername: [''],
      deptname: [''],
      inquiryId: [''],
      typeOfRequest: [''],
      typeOfInquiry: [''],
      startdate: [''],
      enddate:['']
    });
    this.sort.direction="desc"
    setTimeout(() => {
      this.getcallback("","","","","","",null,null,[]);
    }, 1000);

    //this.refresh(this.getDefaultOptions());



  }
  getCurrentOptions() {
    const options: ViewOptions = {
      sortField: this.sort.active,
      sortDirection: this.sort.direction,
      page: this.paginator.pageIndex,
      pageSize: this.paginator.pageSize
    };

    return options;
  }
  refresh(options: ViewOptions){
   this.findBooks(options)

  }
findBooks(options:ViewOptions){
  debugger
  let data1=this.data
  data1 = data1.sort((a, b) => {
    debugger
    const sortOrder = options.sortDirection === 'desc' ? -1 : 1;
    const valueA = a[options.sortField];
    const valueB = b[options.sortField];

    var result = (valueA < valueB) ? -1 : (valueA > valueB) ? 1 : 0;
    console.log(result*sortOrder)
    return result * sortOrder;
  });
  this.getcallback("","","","","","",null,null,data1)
  console.log(data1)
  this.dataSource.data=data1
  console.log(this.data)
}
  getDefaultOptions() {
    const options: ViewOptions = {
      sortField: 'name',
      sortDirection: 'desc',
      page: 0,
      pageSize: 5
    };

    return options;
  }


  getcallback(username,customername,deptname,inquiryId,requestType,inquirytype,date,enddate,sortdata ) {
   /*  let username = this.searchform.get('username').value;
    let customername = this.searchform.get('customername').value;
    let deptname = this.searchform.get('deptname').value;
    let inquiryId = this.searchform.get('inquiryId').value;
    let requestType = this.searchform.get('typeOfRequest').value;
    let date = this.searchform.get('startdate').value;
    date=this.datepipe.transform(date, 'yyyy-MM-dd')
    let enddate = this.searchform.get('enddate').value;
    enddate=this.datepipe.transform(enddate, 'yyyy-MM-dd') */
    console.log(date,enddate)
    this.isLoadingResults = true;
    let pagesize=this.paginator.pageSize
    let pageindex=this.paginator.pageIndex
    pageindex=pageindex+1
    let val=pageindex
    let len=(val-1)*(pagesize)
    console.log(len,pageindex,pagesize)

  /*   if((username!=""|| customername!="" || inquiryId !="" || date!=null|| enddate!=null||requestType!="" || deptname!="") && this.search==false){
      this.paginator.firstPage()
      this.search=true
    } */
    return this.http.post<any>(environment.URL + '/queries/referred_inquiries/'+pageindex+"/"+pagesize+"/"+len,
      { searchrecords:this.searchrecords,noofrecords:this.no_of_records,sortdata:sortdata,username: username, Department: deptname, customer: customername, inquiryId: inquiryId, requestType: requestType,inquiryType:inquirytype, fromdate: date,todate:enddate }).subscribe((searchdata) => { // not callback
        console.log(searchdata['count']);
        console.log(searchdata['Referred_inquiries']);
        this.isLoadingResults = false;
        console.log(typeof (searchdata));
        console.log(searchdata)
        this.callcount = searchdata.Referred_inquiries.length;
        console.log(this.callcount);
        this.no_of_records = searchdata['count'];
        this.paginator.length=searchdata['search_count']
        this.searchrecords = searchdata['search_count']
        this.element = searchdata.Referred_inquiries;
        this.paginator.pageIndex=pageindex-1;
      this.paginator.pageSize=pagesize

          this.data=searchdata.Referred_inquiries

        /* this.dataSource = new MatTableDataSource(searchdata.Referred_inquiries);
        this.dataSource.paginator = this.paginator;


        this.dataSource.sort = this.sort; */
      }, error => {
        console.error("Error", error);
      });
  }
 /*  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  } */
  onPaginateChange(event) {
    debugger
    console.log(this.dataSource.paginator.hasNextPage(), this.dataSource.connect().value);
    this.dataSource.connect().value
    let username = this.searchform.get('username').value;
    let customername = this.searchform.get('customername').value;
    let deptname = this.searchform.get('deptname').value;
    let inquiryId = this.searchform.get('inquiryId').value;
    let requestType = this.searchform.get('typeOfRequest').value;
     let inquirytype = this.searchform.get('typeOfInquiry').value;
    let date = this.searchform.get('startdate').value;
    date=this.datepipe.transform(date, 'yyyy-MM-dd')
    let enddate = this.searchform.get('enddate').value;
    enddate=this.datepipe.transform(enddate, 'yyyy-MM-dd')
    let sortdata=this.data;
    this.getcallback(username,customername,deptname,inquiryId,requestType,inquirytype,date,enddate,[])
    console.log(event);
}
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.filteredData.length == 0) {
      this.displayNoRecords = true;
      this.openSnackBar("No Records Found","Dismiss")
    } else {
      this.displayNoRecords = false;
      this.paginator.firstPage()

    }
  }
  searchres(){
    let username = this.searchform.get('username').value;
    let customername = this.searchform.get('customername').value;
    let deptname = this.searchform.get('deptname').value;
    let inquiryId = this.searchform.get('inquiryId').value;
    let requestType = this.searchform.get('typeOfRequest').value;
      let inquirytype = this.searchform.get('typeOfInquiry').value;
    let date = this.searchform.get('startdate').value;
    date=this.datepipe.transform(date, 'yyyy-MM-dd')
    let enddate = this.searchform.get('enddate').value;
    enddate=this.datepipe.transform(enddate, 'yyyy-MM-dd')
    if((username!=""|| customername!="" || inquiryId !="" || date!=null|| enddate!=null||requestType!="" ||inquirytype!=""|| deptname!="")){
        this.paginator.firstPage()
        this.search=true
      }
      let sortdata=this.data;
      this.getcallback(username,customername,deptname,inquiryId,requestType,inquirytype,date,enddate,[])
  }

  cleares() {
    this.searchform.reset();
    this.search=false
    this.ngOnInit();
    this.sort.direction="desc"
  }
  previouscallRecords() {
    //this.getcallback((this.count1 - 1 >= 0 ? this.count1 - 1 : 0) * 50);
    this.count1 = this.count1 - 1;

  }trackByFn(index, item) {
  return item.id;
}
  isref:boolean
  openEditDialog(row) {
    debugger
    if (this.routerUrl == "/referred/Test") {
      this.isref=true
    } else {
      this.isref=false
    }
    console.log(row)
    const dialogRef = this.dialog.open(EditreferdialogComponent, {
 width: '1300px',
      height: '450px',

      data: { row: row ,ref:this.isref}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
     this.getcallback("","","","","","",null,null,[]);
      // this.ngOnInit();
    });
  }
  nextcallRecords() {
   // this.getcallback((this.count1 + 1) * 50);
    this.count1 = this.count1 + 1;
  }

openSnackBar(message: string, action: string) {
  this.snackBar.open(message, action, {
    duration: 3000,
  });
}
}
