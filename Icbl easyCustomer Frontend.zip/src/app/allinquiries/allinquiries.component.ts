import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
// import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { HttpClient} from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog, MatPaginator, MatSort } from '@angular/material';
import { EditreferdialogComponent } from '../referred/editreferdialog/editreferdialog.component';
import { EditAllInquiryComponent } from './edit-all-inquiry/edit-all-inquiry.component';
import {MatSnackBar} from '@angular/material'
import { DatePipe } from '@angular/common';
import {PageEvent} from '@angular/material';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
import { AppDateAdapter, APP_DATE_FORMATS} from '../inquiries/date.adapter';
import { TOUCH_BUFFER_MS } from '@angular/cdk/a11y';
import { ViewOptions } from '../view-options';
import { AuthenticationService, SecureLocalStorageService,ConfigService } from '../_services';

@Component({
  selector: 'app-allinquiries',
  templateUrl: './allinquiries.component.html',
  styleUrls: ['./allinquiries.component.css'],
  providers: [DatePipe,{
    provide: DateAdapter, useClass: AppDateAdapter
},
{
    provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
}
]
})
export class AllinquiriesComponent implements AfterViewInit,OnInit {
  displayedColumns: string[] = ['Task_Id','Call_Date','Policy_No', 'Customer_Name', 'Type_Of_Request','Type_Of_Inquiry','Departments', 'Details_Call','Last_Updated_By','Closed_Days','Status','Resolution_Notes','Edit','closed'];
  // dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  element: any;
  typeofdepartment:any[]=[];
typeofchannel:any[]=[];
typeofproduct:any[]=[];
typeofrequest:any[]=[]
typeofcustomerresponse:any[]=[]
  dataSource = new MatTableDataSource<any>();
  data:any[]=[]
  searchdata: any;
  callcount: any;
  count1: number =0;
  pageSize = 5;
  count:number;
  c:number=0;
  pageEvent: PageEvent;
  searchform : FormGroup;
  search:boolean=false
  isLoadingResults : boolean = false;
   @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static:true}) sort: MatSort;
  no_of_records: any;
  displayNoRecords: boolean;
  search_records: any;
  searchrecords: any;
constructor(private config: ConfigService,private datepipe:DatePipe,private snackBar:MatSnackBar,private http: HttpClient,private f1 : FormBuilder,private dialog : MatDialog){

}
  ngAfterViewInit(): void {
    this.paginator.length=this.searchrecords
    this.dataSource.paginator = this.paginator;
    this.sort.sortChange.subscribe((sort: MatSort) => {
      debugger
      console.log('sortChange', this.sort.active);

      this.refresh(this.getCurrentOptions());
    });;
  }
ngOnInit(){
    this.config.getData()
    .subscribe(data => {
      console.log(data);

      this.typeofproduct=Object.values(data.Products)
      this.typeofchannel=Object.values(data.Type_of_channel)

      this.typeofrequest=Object.values(data.requests)
    this.typeofdepartment=  Object.values(data.Departments)
    this.typeofcustomerresponse=Object.values(data.customer_response)
      console.log(this.typeofchannel,this.typeofdepartment,this.typeofproduct)


    });
    this.count=0;
    this.searchform = this.f1.group({
      username: [''],
      status: [''],
      customername: [''],
      inquiryId:[''],
      typeOfRequest:[''],
      startdate:[''],
      enddate:[''],
      deptname:['']
    });
    this.sort.direction="desc"
    this.sort.start="desc"
    setTimeout(() => {
      this.getallinquiries("","","","","","",null,null,[])
    }, 1000);
    /* this.getallinquiries(0) */

  }
  getCurrentOptions() {
    const options: ViewOptions = {
      sortField: this.sort.active,
      sortDirection: this.sort.direction,
      page: this.paginator.pageIndex,
      pageSize: this.paginator.pageSize
    };

    return options;
  }
  refresh(options: ViewOptions){
   this.findBooks(options)

  }trackByFn(index, item) {
  return item.id;
}
findBooks(options:ViewOptions){
  debugger
  let data1=this.data
  data1 = data1.sort((a, b) => {
    debugger
    const sortOrder = options.sortDirection === 'desc' ? -1 : 1;
    const valueA = a[options.sortField];
    const valueB = b[options.sortField];

    var result = (valueA < valueB) ? -1 : (valueA > valueB) ? 1 : 0;
    console.log(result*sortOrder)
    return result * sortOrder;
  });
  this.getallinquiries("","","","","","",null,null,data1)
  console.log(data1)
  this.dataSource.data=data1
  console.log(this.data)
}
  getDefaultOptions() {
    const options: ViewOptions = {
      sortField: 'name',
      sortDirection: 'desc',
      page: 0,
      pageSize: 5
    };

    return options;
  }


  // initial call for fetching data records related to all inquiries by passing the min count as 0
  getallinquiries(username,status,customername,inquiryId,requestType,deptname,date,enddate,sortdata){
    debugger
 /*    let username = this.searchform.get('username').value;
    let status = this.searchform.get('status').value;
    let customername = this.searchform.get('customername').value;
    let inquiryId= this.searchform.get('inquiryId').value;
    let requestType=this.searchform.get('typeOfRequest').value;
    let deptname=this.searchform.get('deptname').value;

    let date=this.searchform.get('startdate').value;
    let enddate=this.searchform.get('enddate').value; */


    let pagesize=this.paginator.pageSize
    let pageindex=this.paginator.pageIndex
    pageindex=pageindex+1
    let val=pageindex
    let len=(val-1)*(pagesize)
    console.log(len,pageindex,pagesize)

    console.log(enddate)
    console.log(date)
   // this.search=false

    console.log("date",date)
    this.isLoadingResults = true;
    return this.http.post<any>(environment.URL + '/queries/all_inquiries/'+pageindex+"/"+pagesize+"/"+len,
    {sortdata:sortdata,searchrecords:this.searchrecords,noofrecords:this.no_of_records,dept:deptname,username:username,customer:customername,status:status,inquiryId:inquiryId,requestType:requestType,fromdate:date,todate:enddate}).subscribe((searchdata) => { // not callback
      this.isLoadingResults = false;
      console.log(searchdata);
     debugger
      //this.element = searchdata.all_inquiries;
      //this.calthlcount = searchdata.all_inquiries.length;
    //this.dataSource = new MatTableDataSource(searchdata.all_inquiries);


      console.log(this.data)
      this.no_of_records = searchdata['count'];
      this.searchrecords = searchdata['search_count']
      this.paginator.length=searchdata['search_count']
      this.paginator.pageIndex=pageindex-1;
      this.paginator.pageSize=pagesize
      this.data=searchdata.all_inquiries
    console.log("datasource",this.dataSource)


  }, error => {
    console.error("Error", error);
  });

  }
  searchres(){
    let username = this.searchform.get('username').value;
    let status = this.searchform.get('status').value;
    let customername = this.searchform.get('customername').value;
    let inquiryId= this.searchform.get('inquiryId').value;
    let requestType=this.searchform.get('typeOfRequest').value;
    let deptname=this.searchform.get('deptname').value;

    let date=this.searchform.get('startdate').value;
    let enddate=this.searchform.get('enddate').value;
    date=this.datepipe.transform(date, 'yyyy-MM-dd')
    enddate=this.datepipe.transform(enddate, 'yyyy-MM-dd')
    if((username!=""|| customername!="" || status!=""|| inquiryId !="" || enddate!=null || date!=null|| requestType!="" || deptname!="")){
      this.paginator.firstPage()
    this.search=true
    this.c++;
    }
    this.getallinquiries(username,status,customername,inquiryId,requestType,deptname,date,enddate,[])
  }
  onPaginateChange(event) {
    debugger
    console.log(this.dataSource.paginator.hasNextPage(), this.dataSource.connect().value);
    this.dataSource.connect().value
    let username = this.searchform.get('username').value;
    let status = this.searchform.get('status').value;
    let customername = this.searchform.get('customername').value;
    let inquiryId= this.searchform.get('inquiryId').value;
    let requestType=this.searchform.get('typeOfRequest').value;
    let deptname=this.searchform.get('deptname').value;

    let date=this.searchform.get('startdate').value;
    let enddate=this.searchform.get('enddate').value;
    date=this.datepipe.transform(date, 'yyyy-MM-dd')
    enddate=this.datepipe.transform(enddate, 'yyyy-MM-dd')
    this.getallinquiries(username,status,customername,inquiryId,requestType,deptname,date,enddate,[])
    console.log(event);
}

    // used to filter datasource in order to search by an input parameter
  applyFilter(event: Event) {
    debugger
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

      if(this.dataSource.filteredData.length==0){
        this.displayNoRecords=true;

         console.log(this.dataSource.filteredData)

        /* this.getallinquiries(0) */



      }else{
        this.displayNoRecords=false;

      }


  }

      // clear form to update search results or reset
  cleares(){
    this.searchform.reset();
    this.search=false
    this.c=0;
    this.ngOnInit()
    this.paginator.firstPage()
  }

// used to call previous records by sending the updated count
  previouscallRecords(){
   // this.getallinquiries((this.count1-1 >=0 ? this.count1-1 : 0)*50);
    this.count1 =this.count1-1;
}
  // used to call next records by sending the required count
nextcallRecords(){
 // his.getallinquiries((this.count1+1)*50);
  this.count1 =this.count1+1;
}
openEditDialog(row){
  debugger
  console.log("allinq",row)
  const dialogRef = this.dialog.open(EditAllInquiryComponent, {
    width: '400px',
    height : '290px',
    data : {row:row}
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
    this.getallinquiries("","","","","","",null,null,[])
    // this.ngOnInit();
  });
}
openSnackBar(message: string, action: string) {
  this.snackBar.open(message, action, {
    duration: 2000,
  });
}
}


