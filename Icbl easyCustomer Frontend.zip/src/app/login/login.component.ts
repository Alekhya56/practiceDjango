﻿import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar} from '@angular/material';
import { ForgotDialogComponent } from 'src/app/login/forgot-dialog/forgot-dialog.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthenticationService } from '../_services'
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { IpaddressService } from '../_services';
import { Role } from '../_models/role';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';
  msg : string;

  constructor(public dialog: MatDialog,
    private authenticationService: AuthenticationService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router, private _snackBar: MatSnackBar,
    private ipservice: IpaddressService) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.isLoggedInFn();
    this.ipservice.setIpAddress;

    }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
  });

  // this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/revdashpage';
  }

  get f() {
    console.log(this.loginForm.controls)
    return this.loginForm.controls;
  }



  onSubmit() {
    debugger
    this.submitted = true;
    // stop here if form is invalid
    if (this.f.username.value == '' &&  this.f.password.value == '')
    {
      const msg: string = 'Please enter Username/Password';
      // this.openSnackBar("Please enter Username/password")
      this.openSnackBar(msg)
    }
else if(this.f.username.value==''){
  const msg: string = 'Please enter Username';
  this.openSnackBar(msg)
}else if(this.f.password.value==''){
  const msg: string = 'Please enter Password';
  // this.openSnackBar("Please enter Username/password")
  this.openSnackBar(msg)
}
    if (this.loginForm.invalid) {
        return;
    }
    console.log('onsubmit');
    this.loading = true;
    this.authenticationService.login(this.f.username.value, this.f.password.value)
        .pipe(first())
        .subscribe(
            data => {
                console.log(data);
                debugger
                localStorage.setItem("role", data.role);
                localStorage.setItem('permissions',data.permissions)

                if(data.temppass){
                  // this.router.navigate(['/resetpassword', this.f.username.value]);
                  this.router.navigate(['/resetpassword',this.f.username.value]);
               }
              else {
                if(data) {
               if (data.role === Role.Admin) {
                      this.router.navigate(['/adintuserpage', this.f.username.value]);
                  } else if(data.role === Role.CSR) {

                      this.router.navigate(['/inquiries', this.f.username.value]);
                      // this.router.navigate(['/dashboard', this.f.username.value]);

                      // this.openSnackBar(this.msg);
                  }
                }
                else{
                 console.log("No data");
                }
              }
            },
            error => {
                console.log(error)
                console.log(error.error)
                if(error){
                  let arr = error.split(':');
                  if(arr[1]){
                    console.log(arr);
                    console.log(arr[1])
                  // this.openSnackBar(arr[1]);
                  } else {
                    console.log(arr);
                    console.log(arr[1])
                    // this.openSnackBar(arr[1]);
                  }
                }
                  // else{
                  //   this.openSnackBar("Some error occurred");
                  // }
            }, () => {
              console.log("catch")
            });

}


openSnackBar(msg) {
  this._snackBar.open(msg,'Dismiss',{ duration : 6000, panelClass: ['snack-bar']});
}

isLoggedInFn(){

        let data = this.authenticationService.currentUserValue;
        console.log(data);
        if(data){
          console.log(data) ;
          debugger
          if(data['temppass']==true){
          debugger
              this.router.navigate(['/resetpassword', data['username']]);
          }
          else {

            if(data) {
              if (data.role === Role.Admin){
                  this.router.navigate(['/adintuserpage', data['username']]);
              }else if(data.role ===Role.CSR){
                  this.router.navigate(['/inquiries', data['username']]);
              }
            }
            else {
              console.log("No data");
            }
          }
        }

}


  openforgotDialog(): void {
    let dialogRef = this.dialog.open(ForgotDialogComponent, {
      width: '390px',
      height: '350px',
      panelClass: 'bgm',
    });
  }

}
