import { Component, OnInit, ViewChild, EventEmitter, Injectable, AfterViewInit } from '@angular/core';
// import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { environment } from 'src/environments/environment';
import { HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';

import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator, MatSort } from '@angular/material';
import {MatSnackBar} from '@angular/material';
import { DatePipe } from '@angular/common';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
import { AppDateAdapter, APP_DATE_FORMATS} from '../inquiries/date.adapter';
import { ViewOptions } from '../view-options';
import { AuthenticationService, SecureLocalStorageService,ConfigService } from '../_services';
@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-callback',
  templateUrl: './callback.component.html',
  styleUrls: ['./callback.component.css'],
  providers: [DatePipe,{
    provide: DateAdapter, useClass: AppDateAdapter
},
{
    provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
}]

})
export class CallbackComponent implements AfterViewInit,OnInit {
  displayedColumns: string[] = ['Task_Id','Call_Date','Policy_No','Name', 'Request', 'Type_of_Inquiry', 'Call_Details', 'Last_Updated_By','Days_Open', 'Followup_Date', 'Select'];
  dataSource = new MatTableDataSource<any>();
  data:any[]=[]
  // searchdata: any;
  element: any;
  typeofdepartment:any[]=[];
typeofchannel:any[]=[];
typeofproduct:any[]=[];
typeofrequest:any[]=[]
typeofcustomerresponse:any[]=[]
  callcount: any;
  count1: number =0;
  searchform : FormGroup;
  isLoadingResults : boolean = false;
   @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static:true}) sort: MatSort;
  no_of_records: any;
  displayNoRecords: boolean;
  search: boolean=false;
  search_records: any;
  searchrecords: any;
  constructor(private config: ConfigService,private datepipe:DatePipe,private snackBar:MatSnackBar,private f1 : FormBuilder,private http: HttpClient,private router: Router,private authenticationService: AuthenticationService){

  }
  ngAfterViewInit(): void {
    this.paginator.length=this.searchrecords
    this.dataSource.paginator = this.paginator;
    this.sort.sortChange.subscribe((sort: MatSort) => {
      debugger
      console.log('sortChange', this.sort.active);

      this.refresh(this.getCurrentOptions());
    });}
  ngOnInit() {
    this.config.getData()
    .subscribe(data => {
      console.log(data);

      this.typeofproduct=Object.values(data.Products)
      this.typeofchannel=Object.values(data.Type_of_channel)

      this.typeofrequest=Object.values(data.requests)
    this.typeofdepartment=  Object.values(data.Departments)
    this.typeofcustomerresponse=Object.values(data.customer_response)
      console.log(this.typeofchannel,this.typeofdepartment,this.typeofproduct)


    });
    this.searchform = this.f1.group({
      username: [''],
      customername: [''],
      inquiryId:[''],
      typeOfRequest:[''],
      startdate:[''],
      enddate:[''],
    });
    this.sort.direction="desc"
    setTimeout(() => {
      this.getcallback("","","","",null,null,[]);
    }, 800);


  }
  getCurrentOptions() {
    const options: ViewOptions = {
      sortField: this.sort.active,
      sortDirection: this.sort.direction,
      page: this.paginator.pageIndex,
      pageSize: this.paginator.pageSize
    };

    return options;
  }
  refresh(options: ViewOptions){
   this.findBooks(options)

  }
  trackByFn(index, item) {
  return item.id;
}
findBooks(options:ViewOptions){
  debugger
  let data1=this.data
  data1 = data1.sort((a, b) => {
    debugger
    const sortOrder = options.sortDirection === 'desc' ? -1 : 1;
    const valueA = a[options.sortField];
    const valueB = b[options.sortField];

    var result = (valueA < valueB) ? -1 : (valueA > valueB) ? 1 : 0;
    console.log(result*sortOrder)
    return result * sortOrder;
  });
  this.getcallback("","","","",null,null,data1)
  console.log(data1)
  this.dataSource.data=data1
  console.log(this.data)
}
  getDefaultOptions() {
    const options: ViewOptions = {
      sortField: 'name',
      sortDirection: 'desc',
      page: 0,
      pageSize: 5
    };

    return options;
  }

   // initial call for fetching data records related to callback inquiries by passing the min count as 0
   getcallback(username,customername,inquiryId,requestType,date,enddate,sortdata){
  /*   let username = this.searchform.get('username').value;
    let customername = this.searchform.get('customername').value;
    let inquiryId= this.searchform.get('inquiryId').value;
    let requestType=this.searchform.get('typeOfRequest').value;
    let date=this.searchform.get('startdate').value;
    let enddate=this.searchform.get('enddate').value;
    date=this.datepipe.transform(date, 'yyyy-MM-dd')
    enddate=this.datepipe.transform(enddate, 'yyyy-MM-dd') */
    this.isLoadingResults = true;
    let pagesize=this.paginator.pageSize
    let pageindex=this.paginator.pageIndex
    pageindex=pageindex+1
    let val=pageindex
    let len=(val-1)*(pagesize)
    debugger

    return this.http.post<any>(environment.URL + '/queries/callback/'+pageindex+"/"+pagesize+"/"+len,
    {sortdata:sortdata,searchrecords:this.searchrecords,noofrecords:this.no_of_records,username:username,customer:customername,inquiryId:inquiryId,requestType:requestType,fromdate:date,todate:enddate}).subscribe((searchdata) => { // not callback
      this.isLoadingResults = false;
      console.log(searchdata['CallBacks']);
      this.no_of_records = searchdata['count'];
      this.searchrecords = searchdata['search_count']
      this.paginator.length=searchdata['search_count']
      this.data=searchdata['CallBacks']
      this.paginator.pageIndex=pageindex-1;
      this.paginator.pageSize=pagesize
       console.log(typeof(searchdata));
      this.callcount = searchdata.CallBacks.length;
      this.element = searchdata.CallBacks;
    /* this.dataSource = new MatTableDataSource(searchdata.CallBacks);
     this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort; */
  }, error => {
    console.error("Error", error);
  });
  }
  // used to filter datasource in order to search by an input parameter
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if(this.dataSource.filteredData.length==0){
      this.displayNoRecords=true;
      this.openSnackBar("No Records Found","Dismiss")
    }else{
      this.displayNoRecords=false;
      this.paginator.firstPage()


    }
  }
  onPaginateChange(event) {
    debugger
    console.log(this.dataSource.paginator.hasNextPage(), this.dataSource.connect().value);
    this.dataSource.connect().value
    let username = this.searchform.get('username').value;
    let customername = this.searchform.get('customername').value;
    let inquiryId= this.searchform.get('inquiryId').value;
    let requestType=this.searchform.get('typeOfRequest').value;
    let date=this.searchform.get('startdate').value;
    let enddate=this.searchform.get('enddate').value;
    date=this.datepipe.transform(date, 'yyyy-MM-dd')
    enddate=this.datepipe.transform(enddate, 'yyyy-MM-dd')
  this.getcallback(username,customername,inquiryId,requestType,date,enddate,[])
    console.log(event);
}
    // clear form to update search results or reset
  cleares(){
    this.searchform.reset();
    this.search=false
    this.ngOnInit();
  }
  searchres(){
    let username = this.searchform.get('username').value;
    let customername = this.searchform.get('customername').value;
    let inquiryId= this.searchform.get('inquiryId').value;
    let requestType=this.searchform.get('typeOfRequest').value;
    let date=this.searchform.get('startdate').value;
    let enddate=this.searchform.get('enddate').value;
    date=this.datepipe.transform(date, 'yyyy-MM-dd')
    enddate=this.datepipe.transform(enddate, 'yyyy-MM-dd')
    if((username!=""|| customername!="" || inquiryId !="" || date!=null|| enddate!=null|| requestType!="" )){
      this.paginator.firstPage()
      this.search=true
    }
    this.getcallback(username,customername,inquiryId,requestType,date,enddate,[])
  }

// on select of a particular record we will send id, type of inquiry to inquiries component in a url to fetch the callback data
  selectedrecord(id,typeofinquiry){
const username = this.authenticationService.currentUserValue.username;
      this.router.navigate(['/inquiries',username,{inquiryid:id,inq:typeofinquiry, skipLocationChange: true}]);
      // this.router.navigate(['/inquiries', this.f.username.value]);
  }

    // used to call previous records by sending the updated count
  previouscallRecords(){
      //this.getcallback((this.count1-1 >=0 ? this.count1-1 : 0)*50);
      this.count1 =this.count1-1;

  }

  // used to call next records by sending the required count
  nextcallRecords(){
    //this.getcallback((this.count1+1)*50);
    this.count1 =this.count1+1;
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }
}



