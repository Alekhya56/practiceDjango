export const environment = {
  production: true,
  apiUrl: 'http://localhost:4000',
  //URL : 'http://172.20.32.157:5000/',
URL : 'http://172.21.32.34:4800',
    //URL:'https://easytest.icbl.com.bb:8001/'
  //URL : 'https://' + window.location.hostname + ':8001',
};

