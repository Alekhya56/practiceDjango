module.exports = {
  "globDirectory": "src/",
  maximumFileSizeToCacheInBytes: 30 * 1024 * 1024,
  "globPatterns": [
    "**/*.{html,ts,css,xlsx,js,png,svg,jpg,ico,less}"
  ],
  "swDest": "src\\sw.js",
  "swSrc": "src/serviceworker.js"
};